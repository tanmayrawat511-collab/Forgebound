#!/usr/bin/env python3
"""Remake all 49 humanoid actors (player, Ben, 22 named NPCs, 25 civilians) on Rig_Humanoid_Standard."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from glb_builder import export_glb, validate_glb
from humanoid_rig import (
    HumanoidStyle,
    build_humanoid_clips,
    build_humanoid_mesh,
    create_humanoid_bones,
    humanoid_materials,
)

ROOT = Path(__file__).resolve().parents[1]
MODELS_DIR = ROOT / "public" / "assets" / "models"
ANIMS_DIR = ROOT / "public" / "assets" / "animations"

CIVILIAN_PALETTES = [
    (0xD4B18A, 0x9B5544, 0x304E5D, 0xC49450),
    (0xDDBB92, 0x456E69, 0x6D493B, 0xB88B4A),
    (0xD9B18B, 0x79618C, 0x395C4B, 0xD2A65C),
    (0xE0C39A, 0xA47A3E, 0x374C66, 0x8F6238),
    (0xCDA27F, 0x59769A, 0x624C38, 0xC19858),
    (0xD6B990, 0x8A5C51, 0x576A50, 0xA87A40),
    (0xE3C7A2, 0x557F82, 0x68556E, 0xB89352),
    (0xC99875, 0x9B6E43, 0x495C70, 0xC89F58),
]


def main() -> None:
    bones = create_humanoid_bones(1.0)
    clips = build_humanoid_clips(bones)
    mats = humanoid_materials()

    # Shared clip library (lightweight dummy mesh + all 19 clips)
    from glb_builder import make_box
    export_glb(
        ANIMS_DIR / "humanoid-clips.glb",
        [make_box((0.01, 0.01, 0.01), (0, 0, 0), (1, 1, 1, 1))],
        mats, bones, clips, "HumanoidClips",
    )

    # Player
    player_style = HumanoidStyle(
        skin=0xD8B490, primary=0x4E6E66, secondary=0x344647, accent=0xC69244,
        boots=0x283233, visor=0x6BB6FF, has_helmet=True, has_pauldron=True,
    )
    export_glb(MODELS_DIR / "player.glb", build_humanoid_mesh(player_style), mats, bones, clips[:8], "Player")

    # Ben (tutorial mentor)
    ben_style = HumanoidStyle(
        skin=0xD8B088, primary=0x7A573C, secondary=0x4A3828, accent=0xC99242,
        boots=0x3A2C22, hair=0x5B4638, has_hat=True, has_backpack=True, height_scale=1.02,
    )
    export_glb(MODELS_DIR / "npc-ben.glb", build_humanoid_mesh(ben_style), mats, bones, None, "NpcBen")

    # 22 Named NPCs
    npc_specs: dict[str, HumanoidStyle] = {
        "npc-combat-01": HumanoidStyle(primary=0x823A36, secondary=0x3E464D, accent=0xC89646, has_helmet=True, has_pauldron=True),
        "npc-combat-02": HumanoidStyle(skin=0xC69772, primary=0x6B322E, secondary=0x333940, accent=0xD0A150, has_helmet=True, has_pauldron=True),
        "npc-combat-03": HumanoidStyle(skin=0xE2C19A, primary=0x90453E, secondary=0x464C54, accent=0xB8873D, has_helmet=True, has_pauldron=True),
        "npc-miner-01": HumanoidStyle(primary=0x4F6B7A, secondary=0x5A4634, accent=0xD4A448, has_hat=True, has_backpack=True),
        "npc-miner-02": HumanoidStyle(skin=0xC99A74, primary=0x435D6B, secondary=0x4E3D2E, accent=0xC49640, has_hat=True, has_backpack=True),
        "npc-miner-03": HumanoidStyle(skin=0xDFBD94, primary=0x5D7988, secondary=0x634E3C, accent=0xDDA84E, has_hat=True, has_backpack=True),
        "npc-blacksmith-01": HumanoidStyle(primary=0x5C4842, secondary=0x362C29, accent=0xD87638, has_apron=True, bulk=1.08),
        "npc-blacksmith-02": HumanoidStyle(skin=0xC89670, primary=0x4C3B36, secondary=0x2D2421, accent=0xE08442, has_apron=True, bulk=1.10),
        "npc-blacksmith-03": HumanoidStyle(skin=0xDFBD94, primary=0x6A544E, secondary=0x413531, accent=0xCA6B32, has_apron=True, bulk=1.06),
        "npc-shopkeeper-01": HumanoidStyle(primary=0x4A7260, secondary=0x826242, accent=0xD6B056, has_hat=True),
        "npc-shopkeeper-02": HumanoidStyle(skin=0xCE9E78, primary=0x3E6454, secondary=0x725438, accent=0xDFBA60, has_hat=True),
        "npc-shopkeeper-03": HumanoidStyle(skin=0xE4C6A0, primary=0x56806D, secondary=0x8F6D4B, accent=0xC8A24A, has_hat=True),
        "npc-refiner-01": HumanoidStyle(primary=0x685482, secondary=0x3C344D, accent=0x86B4E8, has_apron=True),
        "npc-refiner-02": HumanoidStyle(skin=0xC99A74, primary=0x584570, secondary=0x312B40, accent=0x76A4D8, has_apron=True),
        "npc-refiner-03": HumanoidStyle(skin=0xDFBD94, primary=0x786294, secondary=0x473D5C, accent=0x96C4F4, has_apron=True),
        "npc-timber-giver": HumanoidStyle(primary=0x5D7448, secondary=0x6C4E34, accent=0xB8924C, has_hat=True, has_backpack=True),
        "npc-billy": HumanoidStyle(primary=0x7A6648, secondary=0x4C3D2E, accent=0xC69A50, has_hat=True),
        "npc-jason": HumanoidStyle(skin=0xC99874, primary=0x4C6884, secondary=0x364454, accent=0xC4944A, has_pauldron=True),
        "npc-tyler": HumanoidStyle(skin=0xDFBF98, primary=0x7E4E42, secondary=0x4C342E, accent=0xD4A254),
        "npc-michael": HumanoidStyle(skin=0xC59470, primary=0x486E62, secondary=0x324640, accent=0xB88C46, has_backpack=True),
        "npc-frank": HumanoidStyle(skin=0xD8B490, primary=0x6E5B46, secondary=0x44382C, accent=0xC9984C, has_apron=True),
        "npc-james": HumanoidStyle(skin=0xE2C49E, primary=0x52647C, secondary=0x344050, accent=0xC49A54, has_hat=True),
    }
    for name, style in npc_specs.items():
        b_scaled = create_humanoid_bones(style.height_scale)
        export_glb(MODELS_DIR / f"{name}.glb", build_humanoid_mesh(style), mats, b_scaled, None, name)

    # 25 Civilians
    for i in range(1, 26):
        skin, pri, sec, acc = CIVILIAN_PALETTES[(i - 1) % len(CIVILIAN_PALETTES)]
        h_scale = 0.92 + ((i - 1) % 5) * 0.035
        c_style = HumanoidStyle(
            skin=skin, primary=pri, secondary=sec, accent=acc,
            has_hat=(i % 3 == 0), has_backpack=(i % 4 == 1), height_scale=h_scale,
        )
        c_bones = create_humanoid_bones(h_scale)
        export_glb(MODELS_DIR / f"civilian-{i:02d}.glb", build_humanoid_mesh(c_style), mats, c_bones, None, f"Civilian{i:02d}")

    # Validate all 49 humanoids
    targets = ["player.glb", "npc-ben.glb"] + [f"{k}.glb" for k in npc_specs] + [f"civilian-{i:02d}.glb" for i in range(1, 26)]
    results = [validate_glb(MODELS_DIR / f) for f in targets]
    print(f"Validated {len(results)} humanoid GLBs. Sample: {results[0]}, {results[1]}, {results[-1]}")


if __name__ == "__main__":
    main()
