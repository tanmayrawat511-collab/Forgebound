#!/usr/bin/env python3
"""Remake, rig, and animate enemies (crawler, ember, guardian) and companions (pet-dog, quest-cat)."""
from __future__ import annotations

import math
import sys
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from glb_builder import (
    AnimClip,
    AnimTrack,
    BoneSpec,
    MaterialSpec,
    MeshPart,
    bind_part_rigid,
    euler_xyz_to_quat,
    export_glb,
    hex_rgba,
    make_blade,
    make_box,
    make_icosphere,
    make_tapered_cylinder,
    validate_glb,
)

ROOT = Path(__file__).resolve().parents[1]
MODELS_DIR = ROOT / "public" / "assets" / "models"


def _rot_track(bone: str, dur: float, fps: int, fn) -> AnimTrack:
    n = max(2, int(round(dur * fps)) + 1)
    times = np.linspace(0.0, dur, n, dtype=np.float32)
    vals = np.array([euler_xyz_to_quat(*fn(float(t) / dur)) for t in times], dtype=np.float32)
    return AnimTrack(bone, "rotation", times, vals)


def _pos_track(bone: str, base: tuple[float, float, float], dur: float, fps: int, fn) -> AnimTrack:
    n = max(2, int(round(dur * fps)) + 1)
    times = np.linspace(0.0, dur, n, dtype=np.float32)
    vals = np.array([[base[0] + d[0], base[1] + d[1], base[2] + d[2]] for t in times for d in [fn(float(t) / dur)]], dtype=np.float32)
    return AnimTrack(bone, "translation", times, vals)


def build_quadruped(is_cat: bool) -> tuple[list[MeshPart], list[BoneSpec], list[AnimClip], list[MaterialSpec]]:
    bones = [
        BoneSpec("Root", -1, (0.0, 0.0, 0.0)),      # 0
        BoneSpec("Body", 0, (0.0, 0.36, 0.0)),       # 1
        BoneSpec("Neck", 1, (0.0, 0.08, 0.22)),      # 2
        BoneSpec("Head", 2, (0.0, 0.08, 0.08)),      # 3
        BoneSpec("Tail_0", 1, (0.0, 0.06, -0.24)),   # 4
        BoneSpec("Tail_1", 4, (0.0, 0.04, -0.16)),   # 5
        BoneSpec("Leg_FL", 1, (-0.12, -0.06, 0.16)), # 6
        BoneSpec("Leg_FR", 1, (0.12, -0.06, 0.16)),  # 7
        BoneSpec("Leg_BL", 1, (-0.12, -0.06, -0.16)),# 8
        BoneSpec("Leg_BR", 1, (0.12, -0.06, -0.16)), # 9
    ]
    fur = hex_rgba(0x464B58 if is_cat else 0xB98558)
    dark = hex_rgba(0x23262E if is_cat else 0x694832)
    cream = hex_rgba(0xD8DCE4 if is_cat else 0xE1C39B)
    eye_c = hex_rgba(0x70E088 if is_cat else 0x201C1C)

    s = 0.84 if is_cat else 1.0
    parts = [
        bind_part_rigid(make_icosphere(0.20 * s, (0.0, 0.36 * s, 0.0), (0.82, 0.82, 1.38), 1, fur), 1),
        bind_part_rigid(make_tapered_cylinder(0.11 * s, 0.09 * s, 0.14 * s, (0.0, 0.44 * s, 0.22 * s), 7, fur), 2),
        bind_part_rigid(make_icosphere(0.14 * s, (0.0, 0.52 * s, 0.30 * s), (0.95, 0.90, 1.02), 1, fur), 3),
        bind_part_rigid(make_box((0.09 * s, 0.07 * s, 0.11 * s), (0.0, 0.48 * s, 0.42 * s), cream), 3),
        bind_part_rigid(make_icosphere(0.024 * s, (-0.055 * s, 0.55 * s, 0.41 * s), subdivisions=1, color=eye_c), 3),
        bind_part_rigid(make_icosphere(0.024 * s, (0.055 * s, 0.55 * s, 0.41 * s), subdivisions=1, color=eye_c), 3),
        bind_part_rigid(make_tapered_cylinder(0.045 * s, 0.01 * s, 0.11 * s, (-0.08 * s, 0.65 * s, 0.28 * s), 5, dark), 3),
        bind_part_rigid(make_tapered_cylinder(0.045 * s, 0.01 * s, 0.11 * s, (0.08 * s, 0.65 * s, 0.28 * s), 5, dark), 3),
        bind_part_rigid(make_tapered_cylinder(0.042 * s, 0.032 * s, 0.18 * s, (0.0, 0.42 * s, -0.32 * s), 6, dark, axis="z"), 4),
        bind_part_rigid(make_tapered_cylinder(0.032 * s, 0.018 * s, 0.18 * s, (0.0, 0.48 * s, -0.46 * s), 6, cream, axis="z"), 5),
        bind_part_rigid(make_tapered_cylinder(0.045 * s, 0.038 * s, 0.28 * s, (-0.12 * s, 0.15 * s, 0.16 * s), 6, cream), 6),
        bind_part_rigid(make_tapered_cylinder(0.045 * s, 0.038 * s, 0.28 * s, (0.12 * s, 0.15 * s, 0.16 * s), 6, cream), 7),
        bind_part_rigid(make_tapered_cylinder(0.048 * s, 0.038 * s, 0.28 * s, (-0.12 * s, 0.15 * s, -0.16 * s), 6, cream), 8),
        bind_part_rigid(make_tapered_cylinder(0.048 * s, 0.038 * s, 0.28 * s, (0.12 * s, 0.15 * s, -0.16 * s), 6, cream), 9),
    ]
    fps = 30
    clips = [
        AnimClip("idle", [
            _pos_track("Body", bones[1].translation, 2.0, fps, lambda u: (0.0, math.sin(u * 2 * math.pi) * 0.012, 0.0)),
            _rot_track("Tail_0", 2.0, fps, lambda u: (0.25, math.sin(u * 2 * math.pi) * 0.28, 0.0)),
            _rot_track("Tail_1", 2.0, fps, lambda u: (0.20, math.sin(u * 2 * math.pi - 0.5) * 0.35, 0.0)),
        ]),
        AnimClip("walk", [
            _pos_track("Body", bones[1].translation, 0.8, fps, lambda u: (0.0, abs(math.sin(u * 2 * math.pi)) * 0.025, 0.0)),
            _rot_track("Leg_FL", 0.8, fps, lambda u: (math.sin(u * 2 * math.pi) * 0.5, 0.0, 0.0)),
            _rot_track("Leg_BR", 0.8, fps, lambda u: (math.sin(u * 2 * math.pi) * 0.5, 0.0, 0.0)),
            _rot_track("Leg_FR", 0.8, fps, lambda u: (-math.sin(u * 2 * math.pi) * 0.5, 0.0, 0.0)),
            _rot_track("Leg_BL", 0.8, fps, lambda u: (-math.sin(u * 2 * math.pi) * 0.5, 0.0, 0.0)),
            _rot_track("Tail_0", 0.8, fps, lambda u: (0.3, math.sin(u * 2 * math.pi) * 0.2, 0.0)),
        ]),
        AnimClip("run", [
            _pos_track("Body", bones[1].translation, 0.55, fps, lambda u: (0.0, abs(math.sin(u * 2 * math.pi)) * 0.055, 0.0)),
            _rot_track("Leg_FL", 0.55, fps, lambda u: (math.sin(u * 2 * math.pi) * 0.75, 0.0, 0.0)),
            _rot_track("Leg_FR", 0.55, fps, lambda u: (math.sin(u * 2 * math.pi + 0.4) * 0.75, 0.0, 0.0)),
            _rot_track("Leg_BL", 0.55, fps, lambda u: (-math.sin(u * 2 * math.pi) * 0.75, 0.0, 0.0)),
            _rot_track("Leg_BR", 0.55, fps, lambda u: (-math.sin(u * 2 * math.pi + 0.4) * 0.75, 0.0, 0.0)),
        ]),
        AnimClip("pet-happy", [
            _pos_track("Body", bones[1].translation, 1.0, fps, lambda u: (0.0, abs(math.sin(u * 4 * math.pi)) * 0.09, 0.0)),
            _rot_track("Head", 1.0, fps, lambda u: (-0.25, math.sin(u * 4 * math.pi) * 0.15, 0.0)),
            _rot_track("Tail_0", 1.0, fps, lambda u: (0.55, math.sin(u * 8 * math.pi) * 0.65, 0.0)),
            _rot_track("Tail_1", 1.0, fps, lambda u: (0.35, math.sin(u * 8 * math.pi - 0.4) * 0.75, 0.0)),
        ]),
        AnimClip("sit", [
            _pos_track("Body", bones[1].translation, 1.5, fps, lambda u: (0.0, -0.06, 0.0)),
            _rot_track("Body", 1.5, fps, lambda u: (-0.25, 0.0, 0.0)),
            _rot_track("Leg_BL", 1.5, fps, lambda u: (0.85, 0.0, 0.0)),
            _rot_track("Leg_BR", 1.5, fps, lambda u: (0.85, 0.0, 0.0)),
        ]),
    ]
    mats = [MaterialSpec("QuadrupedFur", (1, 1, 1, 1), metallic=0.02, roughness=0.84)]
    return parts, bones, clips, mats


def build_crawler() -> tuple[list[MeshPart], list[BoneSpec], list[AnimClip], list[MaterialSpec]]:
    bones = [
        BoneSpec("Root", -1, (0.0, 0.0, 0.0)),        # 0
        BoneSpec("Thorax", 0, (0.0, 0.42, 0.0)),       # 1
        BoneSpec("Abdomen", 1, (0.0, 0.04, -0.35)),    # 2
        BoneSpec("Head", 1, (0.0, 0.0, 0.34)),         # 3
        BoneSpec("Leg_L1", 1, (-0.24, -0.02, 0.22)),   # 4
        BoneSpec("Leg_L2", 1, (-0.26, -0.02, 0.0)),    # 5
        BoneSpec("Leg_L3", 1, (-0.24, -0.02, -0.22)),  # 6
        BoneSpec("Leg_R1", 1, (0.24, -0.02, 0.22)),    # 7
        BoneSpec("Leg_R2", 1, (0.26, -0.02, 0.0)),     # 8
        BoneSpec("Leg_R3", 1, (0.24, -0.02, -0.22)),   # 9
    ]
    shell = hex_rgba(0x3B2D38)
    belly = hex_rgba(0x5E3E4B)
    eye_c = hex_rgba(0xFF5A2A)
    parts = [
        bind_part_rigid(make_icosphere(0.28, (0.0, 0.42, 0.0), (1.0, 0.72, 1.15), 1, shell), 1),
        bind_part_rigid(make_icosphere(0.32, (0.0, 0.46, -0.42), (1.05, 0.85, 1.25), 1, belly), 2),
        bind_part_rigid(make_icosphere(0.18, (0.0, 0.42, 0.36), (1.0, 0.8, 0.95), 1, shell), 3),
        bind_part_rigid(make_icosphere(0.035, (-0.07, 0.45, 0.50), subdivisions=1, color=eye_c, material_index=1), 3),
        bind_part_rigid(make_icosphere(0.035, (0.07, 0.45, 0.50), subdivisions=1, color=eye_c, material_index=1), 3),
    ]
    for idx, (sx, z_off, b_idx) in enumerate([
        (-1, 0.22, 4), (-1, 0.0, 5), (-1, -0.22, 6),
        (1, 0.22, 7), (1, 0.0, 8), (1, -0.22, 9),
    ]):
        upper = make_tapered_cylinder(0.045, 0.03, 0.38, (sx * 0.40, 0.42, z_off), 6, shell, axis="x")
        lower = make_tapered_cylinder(0.03, 0.015, 0.42, (sx * 0.56, 0.21, z_off), 6, belly)
        parts.append(bind_part_rigid(upper, b_idx))
        parts.append(bind_part_rigid(lower, b_idx))

    fps = 30
    clips = [
        AnimClip("idle", [
            _pos_track("Thorax", bones[1].translation, 1.8, fps, lambda u: (0.0, math.sin(u * 2 * math.pi) * 0.02, 0.0)),
            _rot_track("Abdomen", 1.8, fps, lambda u: (math.sin(u * 2 * math.pi) * 0.06, 0.0, 0.0)),
        ]),
        AnimClip("chase", [
            _pos_track("Thorax", bones[1].translation, 0.55, fps, lambda u: (0.0, abs(math.sin(u * 2 * math.pi)) * 0.04, 0.0)),
            _rot_track("Leg_L1", 0.55, fps, lambda u: (0.0, math.sin(u * 2 * math.pi) * 0.45, 0.15)),
            _rot_track("Leg_R2", 0.55, fps, lambda u: (0.0, -math.sin(u * 2 * math.pi) * 0.45, -0.15)),
            _rot_track("Leg_L3", 0.55, fps, lambda u: (0.0, math.sin(u * 2 * math.pi) * 0.45, 0.15)),
            _rot_track("Leg_R1", 0.55, fps, lambda u: (0.0, math.sin(u * 2 * math.pi) * 0.45, -0.15)),
            _rot_track("Leg_L2", 0.55, fps, lambda u: (0.0, -math.sin(u * 2 * math.pi) * 0.45, 0.15)),
            _rot_track("Leg_R3", 0.55, fps, lambda u: (0.0, math.sin(u * 2 * math.pi) * 0.45, -0.15)),
        ]),
        AnimClip("attack", [
            _pos_track("Thorax", bones[1].translation, 0.5, fps, lambda u: (0.0, 0.08 * math.sin(u * math.pi), 0.18 * math.sin(u * math.pi))),
            _rot_track("Thorax", 0.5, fps, lambda u: (-0.35 * math.sin(u * math.pi), 0.0, 0.0)),
        ]),
        AnimClip("hit-react", [
            _rot_track("Thorax", 0.35, fps, lambda u: (-0.25 * math.sin(u * math.pi), 0.0, 0.2 * math.sin(u * math.pi))),
        ]),
        AnimClip("death", [
            _pos_track("Thorax", bones[1].translation, 0.65, fps, lambda u: (0.0, -0.22 * u, 0.0)),
            _rot_track("Thorax", 0.65, fps, lambda u: (0.0, 0.0, 2.8 * u)),
        ]),
    ]
    mats = [
        MaterialSpec("CrawlerChitin", (1, 1, 1, 1), metallic=0.18, roughness=0.55),
        MaterialSpec("CrawlerGlow", (1, 1, 1, 1), metallic=0.05, roughness=0.25, emissive=(0.9, 0.3, 0.1)),
    ]
    return parts, bones, clips, mats


def build_ember() -> tuple[list[MeshPart], list[BoneSpec], list[AnimClip], list[MaterialSpec]]:
    bones = [
        BoneSpec("Root", -1, (0.0, 0.0, 0.0)),     # 0
        BoneSpec("Core", 0, (0.0, 0.95, 0.0)),      # 1
        BoneSpec("Crown", 1, (0.0, 0.34, 0.0)),     # 2
        BoneSpec("Arm_L", 1, (-0.36, 0.05, 0.0)),   # 3
        BoneSpec("Arm_R", 1, (0.36, 0.05, 0.0)),    # 4
        BoneSpec("Orbit_A", 1, (0.0, -0.25, 0.36)), # 5
        BoneSpec("Orbit_B", 1, (0.0, -0.25, -0.36)),# 6
    ]
    magma = hex_rgba(0xF15C23)
    char = hex_rgba(0x362B2A)
    gold = hex_rgba(0xFFB338)
    parts = [
        bind_part_rigid(make_icosphere(0.32, (0.0, 0.95, 0.0), (0.95, 1.15, 0.95), 1, magma, material_index=1), 1),
        bind_part_rigid(make_tapered_cylinder(0.18, 0.02, 0.36, (0.0, 1.38, 0.0), 6, gold, material_index=1), 2),
        bind_part_rigid(make_blade(0.45, 0.16, 0.12, (-0.42, 0.95, 0.05), char), 3),
        bind_part_rigid(make_blade(0.45, 0.16, 0.12, (0.42, 0.95, 0.05), char), 4),
        bind_part_rigid(make_icosphere(0.11, (0.0, 0.70, 0.38), subdivisions=1, color=char), 5),
        bind_part_rigid(make_icosphere(0.11, (0.0, 0.70, -0.38), subdivisions=1, color=char), 6),
    ]
    fps = 30
    clips = [
        AnimClip("idle", [
            _pos_track("Core", bones[1].translation, 2.0, fps, lambda u: (0.0, math.sin(u * 2 * math.pi) * 0.08, 0.0)),
            _rot_track("Core", 2.0, fps, lambda u: (0.0, u * 2 * math.pi, 0.0)),
            _rot_track("Arm_L", 2.0, fps, lambda u: (math.sin(u * 2 * math.pi) * 0.25, 0.0, 0.15)),
            _rot_track("Arm_R", 2.0, fps, lambda u: (-math.sin(u * 2 * math.pi) * 0.25, 0.0, -0.15)),
        ]),
        AnimClip("chase", [
            _pos_track("Core", bones[1].translation, 0.8, fps, lambda u: (0.0, math.sin(u * 2 * math.pi) * 0.1, 0.0)),
            _rot_track("Core", 0.8, fps, lambda u: (0.25, u * 2 * math.pi, 0.0)),
        ]),
        AnimClip("attack", [
            _rot_track("Core", 0.5, fps, lambda u: (0.45 * math.sin(u * math.pi), 0.0, 0.0)),
            _rot_track("Arm_L", 0.5, fps, lambda u: (-1.4 * math.sin(u * math.pi), 0.0, 0.0)),
            _rot_track("Arm_R", 0.5, fps, lambda u: (-1.4 * math.sin(u * math.pi), 0.0, 0.0)),
        ]),
        AnimClip("hit-react", [
            _rot_track("Core", 0.35, fps, lambda u: (-0.35 * math.sin(u * math.pi), 0.0, 0.0)),
        ]),
        AnimClip("death", [
            _pos_track("Core", bones[1].translation, 0.7, fps, lambda u: (0.0, -0.75 * u, 0.0)),
            _rot_track("Core", 0.7, fps, lambda u: (1.4 * u, 3.0 * u, 0.0)),
        ]),
    ]
    mats = [
        MaterialSpec("EmberStone", (1, 1, 1, 1), metallic=0.15, roughness=0.75),
        MaterialSpec("EmberCore", (1, 1, 1, 1), metallic=0.05, roughness=0.25, emissive=(0.95, 0.35, 0.08)),
    ]
    return parts, bones, clips, mats


def build_guardian() -> tuple[list[MeshPart], list[BoneSpec], list[AnimClip], list[MaterialSpec]]:
    bones = [
        BoneSpec("Root", -1, (0.0, 0.0, 0.0)),      # 0
        BoneSpec("Hips", 0, (0.0, 0.85, 0.0)),       # 1
        BoneSpec("Torso", 1, (0.0, 0.35, 0.0)),      # 2
        BoneSpec("Head", 2, (0.0, 0.42, 0.0)),       # 3
        BoneSpec("Arm_L", 2, (-0.48, 0.25, 0.0)),    # 4
        BoneSpec("Arm_R", 2, (0.48, 0.25, 0.0)),     # 5
        BoneSpec("Leg_L", 1, (-0.24, -0.05, 0.0)),   # 6
        BoneSpec("Leg_R", 1, (0.24, -0.05, 0.0)),    # 7
    ]
    stone = hex_rgba(0x4C5258)
    rune = hex_rgba(0x6BB6FF)
    parts = [
        bind_part_rigid(make_box((0.56, 0.28, 0.38), (0.0, 0.85, 0.0), stone), 1),
        bind_part_rigid(make_tapered_cylinder(0.30, 0.42, 0.62, (0.0, 1.28, 0.0), 8, stone), 2),
        bind_part_rigid(make_box((0.24, 0.24, 0.10), (0.0, 1.30, 0.32), rune, material_index=1), 2),
        bind_part_rigid(make_box((0.28, 0.26, 0.26), (0.0, 1.72, 0.02), stone), 3),
        bind_part_rigid(make_box((0.18, 0.06, 0.06), (0.0, 1.73, 0.14), rune, material_index=1), 3),
        bind_part_rigid(make_box((0.22, 0.72, 0.22), (-0.52, 1.15, 0.0), stone), 4),
        bind_part_rigid(make_box((0.22, 0.72, 0.22), (0.52, 1.15, 0.0), stone), 5),
        bind_part_rigid(make_box((0.22, 0.76, 0.26), (-0.24, 0.38, 0.0), stone), 6),
        bind_part_rigid(make_box((0.22, 0.76, 0.26), (0.24, 0.38, 0.0), stone), 7),
    ]
    fps = 30
    clips = [
        AnimClip("idle", [
            _pos_track("Hips", bones[1].translation, 2.4, fps, lambda u: (0.0, math.sin(u * 2 * math.pi) * 0.02, 0.0)),
            _rot_track("Torso", 2.4, fps, lambda u: (math.sin(u * 2 * math.pi) * 0.04, 0.0, 0.0)),
        ]),
        AnimClip("chase", [
            _pos_track("Hips", bones[1].translation, 1.0, fps, lambda u: (0.0, abs(math.sin(u * 2 * math.pi)) * 0.045, 0.0)),
            _rot_track("Leg_L", 1.0, fps, lambda u: (math.sin(u * 2 * math.pi) * 0.55, 0.0, 0.0)),
            _rot_track("Leg_R", 1.0, fps, lambda u: (-math.sin(u * 2 * math.pi) * 0.55, 0.0, 0.0)),
            _rot_track("Arm_L", 1.0, fps, lambda u: (-math.sin(u * 2 * math.pi) * 0.45, 0.0, -0.1)),
            _rot_track("Arm_R", 1.0, fps, lambda u: (math.sin(u * 2 * math.pi) * 0.45, 0.0, 0.1)),
        ]),
        AnimClip("attack", [
            _rot_track("Torso", 0.75, fps, lambda u: (0.35 * math.sin(u * math.pi), 0.0, 0.0)),
            _rot_track("Arm_L", 0.75, fps, lambda u: (-1.9 * math.sin(u * math.pi), 0.0, 0.0)),
            _rot_track("Arm_R", 0.75, fps, lambda u: (-1.9 * math.sin(u * math.pi), 0.0, 0.0)),
        ]),
        AnimClip("hit-react", [
            _rot_track("Torso", 0.4, fps, lambda u: (-0.25 * math.sin(u * math.pi), 0.0, 0.0)),
        ]),
        AnimClip("death", [
            _pos_track("Hips", bones[1].translation, 0.85, fps, lambda u: (0.0, -0.7 * u, 0.0)),
            _rot_track("Hips", 0.85, fps, lambda u: (-1.45 * u, 0.0, 0.0)),
        ]),
    ]
    mats = [
        MaterialSpec("GuardianStone", (1, 1, 1, 1), metallic=0.1, roughness=0.82),
        MaterialSpec("GuardianRune", (1, 1, 1, 1), metallic=0.2, roughness=0.2, emissive=(0.25, 0.65, 0.95)),
    ]
    return parts, bones, clips, mats


def main() -> None:
    specs = {
        "pet-dog.glb": (build_quadruped(is_cat=False), "PetDog"),
        "quest-cat.glb": (build_quadruped(is_cat=True), "QuestCat"),
        "enemy-crawler.glb": (build_crawler(), "EnemyCrawler"),
        "enemy-ember.glb": (build_ember(), "EnemyEmber"),
        "enemy-guardian.glb": (build_guardian(), "EnemyGuardian"),
    }
    for fname, ((parts, bones, clips, mats), name) in specs.items():
        p = MODELS_DIR / fname
        export_glb(p, parts, mats, bones, clips, name)
        print(validate_glb(p))


if __name__ == "__main__":
    main()
