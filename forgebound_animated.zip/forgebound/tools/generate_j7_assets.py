#!/usr/bin/env python3
"""Generate Phase J7 low-poly GLBs: 25 townsfolk, one dog, 13 gear models, Ben, and his house.

The generated models are intentionally lightweight static geometry. Runtime procedural
motion is supplied by Civilian/PetDog/Npc controllers; skeletal animation authoring is tracked
separately in public/assets/animation-manifest.json.
"""
from __future__ import annotations
import json
import math
from pathlib import Path
import numpy as np
import trimesh

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "public" / "assets" / "models"

PALETTES = [
    (0x9B5544, 0xD4B18A, 0x304E5D), (0x456E69, 0xDDBB92, 0x6D493B),
    (0x79618C, 0xD9B18B, 0x395C4B), (0xA47A3E, 0xE0C39A, 0x374C66),
    (0x59769A, 0xCDA27F, 0x624C38), (0x8A5C51, 0xD6B990, 0x576A50),
    (0x557F82, 0xE3C7A2, 0x68556E), (0x9B6E43, 0xC99875, 0x495C70),
]

def rgba(hex_color: int, alpha: int = 255) -> np.ndarray:
    return np.array([(hex_color >> 16) & 255, (hex_color >> 8) & 255, hex_color & 255, alpha], dtype=np.uint8)

def mesh_box(extents, translation, color):
    m = trimesh.creation.box(extents=extents)
    m.apply_translation(translation)
    m.visual.vertex_colors = rgba(color)
    return m

def mesh_ellipsoid(radius, translation, color, scale=(1,1,1), sections=12):
    m = trimesh.creation.icosphere(subdivisions=2, radius=radius)
    m.apply_scale(scale); m.apply_translation(translation)
    m.visual.vertex_colors = rgba(color)
    return m

def mesh_cylinder(radius, height, translation, color, sections=12):
    m = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    m.apply_translation(translation); m.visual.vertex_colors = rgba(color)
    return m

def scene_from_parts(parts):
    s = trimesh.Scene()
    for i, part in enumerate(parts):
        s.add_geometry(part, node_name=f"j7-part-{i:02d}", geom_name=f"j7-geometry-{i:02d}")
    return s

def human(index: int, ben: bool = False):
    skin, cloth, accent = PALETTES[index % len(PALETTES)]
    scale = 0.88 + (index % 7) * 0.045
    shoulder = 0.36 + (index % 4) * 0.045
    parts = [
        mesh_ellipsoid(0.17, (0, 1.52 * scale, 0), skin, (0.86, 1.0, 0.84)),
        mesh_box((shoulder * 2, 0.52 * scale, 0.25), (0, 1.05 * scale, 0), cloth),
        mesh_box((0.18, 0.64 * scale, 0.19), (-0.13, 0.48 * scale, 0), cloth),
        mesh_box((0.18, 0.64 * scale, 0.19), (0.13, 0.48 * scale, 0), accent),
        mesh_box((0.26, 0.18, 0.25), (0, 1.28 * scale, 0.02), accent),
        mesh_ellipsoid(0.08, (-0.067, 1.54 * scale, 0.14), 0x29292b, (0.75,0.75,0.55)),
        mesh_ellipsoid(0.08, (0.067, 1.54 * scale, 0.14), 0x29292b, (0.75,0.75,0.55)),
    ]
    parts.extend([
        mesh_box((0.17, 0.55 * scale, 0.19), (-0.12, 0.18 * scale, 0), 0x55483E),
        mesh_box((0.17, 0.55 * scale, 0.19), (0.12, 0.18 * scale, 0), 0x55483E),
    ])
    if index % 3 == 0 or ben:
        parts.append(mesh_cylinder(0.23, 0.12, (0, 1.72 * scale, 0), 0x483A31, 10))
    if index % 4 == 1:
        parts.append(mesh_box((0.32, 0.38, 0.2), (0, 0.95 * scale, -0.20), accent))
    if index % 5 == 2:
        parts.append(mesh_box((0.58, 0.08, 0.1), (0, 1.38 * scale, 0.02), 0x6A4734))
    if ben:
        parts.append(mesh_box((0.62, 0.52, 0.28), (0, 1.0, -0.23), 0x7B5437))
    return scene_from_parts(parts)

def dog_scene():
    tan, dark, cream = 0xB98558, 0x694832, 0xE1C39B
    parts = [
        mesh_ellipsoid(0.32, (0, 0.55, 0), tan, (1.35,0.86,0.8)),
        mesh_ellipsoid(0.22, (0, 0.69, 0.38), tan, (1,1,0.92)),
        mesh_ellipsoid(0.12, (-0.16,0.85,0.36), dark, (0.48,0.95,0.55)),
        mesh_ellipsoid(0.12, (0.16,0.85,0.36), dark, (0.48,0.95,0.55)),
        mesh_ellipsoid(0.06, (-0.075,0.72,0.57), 0x242222),
        mesh_ellipsoid(0.06, (0.075,0.72,0.57), 0x242222),
        mesh_ellipsoid(0.07, (0,0.62,0.59), 0x292322),
        mesh_cylinder(0.07,0.45,(0,0.63,-0.49),dark,8),
    ]
    for x in (-0.2,0.2):
        for z in (-0.18,0.22): parts.append(mesh_box((0.13,0.35,0.14),(x,0.24,z),cream))
    return scene_from_parts(parts)

def weapon_model(gear_id: str):
    metal = 0xB8C2C2
    wood = 0x72513A
    copper = 0xC7824A
    parts=[]
    if gear_id in ('daggers','straight-sword','katana','great-sword','colossal-sword'):
        length = {'daggers':0.78,'straight-sword':1.1,'katana':1.28,'great-sword':1.45,'colossal-sword':1.8}[gear_id]
        width = 0.045 if gear_id in ('katana','daggers') else (0.14 if gear_id == 'colossal-sword' else 0.09)
        parts.append(mesh_box((width,length,0.055),(0,length*0.48,0),metal))
        parts.append(mesh_box((0.36 if gear_id not in ('daggers','katana') else 0.24,0.08,0.12),(0,0,0),copper))
        parts.append(mesh_cylinder(0.045,0.28,(0,-0.15,0),wood,8))
        if gear_id=='daggers': parts.append(mesh_box((0.045,0.75,0.05),(0.18,0.38,0),metal))
        if gear_id=='katana': parts.append(mesh_ellipsoid(0.12, (0,0.03,0), 0x30271e, (1,0.25,1)))
    elif gear_id in ('mace','axe','great-axe','spear'):
        shaft=1.2 if gear_id in ('spear','great-axe') else 0.9
        parts.append(mesh_cylinder(0.045,shaft,(0,0,0),wood,10))
        if gear_id=='mace':
            parts.append(mesh_ellipsoid(0.27,(0,shaft*0.47,0),metal,(0.8,1,0.8)))
            for k in range(6):
                a=k*math.pi/3; parts.append(mesh_ellipsoid(0.08,(math.cos(a)*0.25,shaft*0.47+math.sin(a)*0.25,0),copper))
        elif gear_id in ('axe','great-axe'):
            w=0.43 if gear_id=='axe' else 0.72
            parts.append(mesh_box((w,0.46,0.12),(w*0.18,shaft*0.38,0),metal))
            parts.append(mesh_box((0.12,0.18,0.15),(0.04,shaft*0.38,0),copper))
        else:
            parts.append(mesh_box((0.22,0.36,0.08),(0,shaft*0.52,0),metal))
    elif gear_id=='gauntlet':
        parts.extend([mesh_box((0.42,0.42,0.32),(0,0.15,0),metal),mesh_box((0.46,0.12,0.35),(0,0.4,0),copper)])
        for x in (-0.14,0,0.14): parts.append(mesh_box((0.09,0.18,0.24),(x,0.53,0),metal))
    elif gear_id=='helmet':
        parts.extend([mesh_ellipsoid(0.48,(0,0.2,0),metal,(1,0.9,0.9)),mesh_box((0.55,0.15,0.18),(0,0.0,0.32),copper)])
    elif gear_id=='chestplate':
        parts.extend([mesh_box((0.94,0.9,0.42),(0,0.3,0),metal),mesh_box((0.34,0.34,0.1),(0,0.3,0.27),copper)])
    elif gear_id=='leggings':
        for x in (-0.23,0.23): parts.append(mesh_box((0.32,1.0,0.35),(x,0.1,0),metal))
    return scene_from_parts(parts)

def house_scene():
    parts=[mesh_box((5.4,3.1,4.5),(0,1.55,0),0x856442),mesh_box((6.1,0.35,5.1),(0,3.28,0),0x52372B),mesh_box((0.9,1.8,0.12),(0,0.95,2.31),0x38281f),mesh_box((1.3,0.85,0.12),(-1.45,2.0,2.31),0x8ac0cb)]
    roof=trimesh.creation.cone(radius=3.8,height=2.4,sections=4); roof.apply_transform(trimesh.transformations.rotation_matrix(math.pi/4,[0,1,0])); roof.apply_translation([0,4.4,0]); roof.visual.vertex_colors=rgba(0x704638); parts.append(roof)
    return scene_from_parts(parts)

def export(scene, file_name):
    path=OUT/file_name; data=scene.export(file_type='glb')
    if not isinstance(data,bytes) or not data.startswith(b'glTF'): raise RuntimeError(f'Invalid GLB: {file_name}')
    path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(data)
    loaded=trimesh.load(path,force='scene')
    if not isinstance(loaded,trimesh.Scene) or not loaded.geometry: raise RuntimeError(f'GLB verification failed: {file_name}')
    return {'file':file_name,'path':f'/assets/models/{file_name}','bytes':path.stat().st_size,'triangles':sum(len(mesh.faces) for mesh in loaded.geometry.values()),'source':'tools/generate_j7_assets.py'}

def main():
    entries=[]
    for i in range(25): entries.append(export(human(i),f'civilian-{i+1:02d}.glb'))
    entries.append(export(dog_scene(),'pet-dog.glb'))
    entries.append(export(human(4,True),'npc-ben.glb'))
    entries.append(export(house_scene(),'ben-house.glb'))
    for gear_id in ('daggers','straight-sword','mace','gauntlet','axe','katana','great-sword','spear','great-axe','colossal-sword','helmet','chestplate','leggings'):
        entries.append(export(weapon_model(gear_id),f'gear-{gear_id}.glb'))
    manifest_path=ROOT/'public'/'assets'/'j7-model-manifest.json'
    manifest_path.write_text(json.dumps({'phase':'J7','runtime':'Python + trimesh + numpy','modelCount':len(entries),'models':entries},indent=2)+'\n')
    print(f'Generated and verified {len(entries)} J7 GLB assets.')

if __name__=='__main__': main()
