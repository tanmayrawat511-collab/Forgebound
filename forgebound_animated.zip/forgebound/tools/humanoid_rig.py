#!/usr/bin/env python3
"""Shared Rig_Humanoid_Standard (25 bones), stylized humanoid mesh builder, and 30fps animation library."""
from __future__ import annotations

import math
from dataclasses import dataclass
import numpy as np

from glb_builder import (
    AnimClip,
    AnimTrack,
    BoneSpec,
    MaterialSpec,
    MeshPart,
    bind_part_rigid,
    bind_part_two_bones,
    euler_xyz_to_quat,
    hex_rgba,
    make_box,
    make_icosphere,
    make_tapered_cylinder,
)

HUMANOID_BONE_NAMES = [
    "Root",            # 0
    "Hips",            # 1
    "Spine",           # 2
    "Chest",           # 3
    "Neck",            # 4
    "Head",            # 5
    "Socket_Helmet",   # 6
    "Socket_Chest",    # 7
    "Socket_Legs",     # 8
    "Shoulder_L",      # 9
    "UpperArm_L",      # 10
    "Forearm_L",       # 11
    "Hand_L",          # 12
    "Socket_Weapon_L", # 13
    "Shoulder_R",      # 14
    "UpperArm_R",      # 15
    "Forearm_R",       # 16
    "Hand_R",          # 17
    "Socket_Weapon_R", # 18
    "Thigh_L",         # 19
    "Shin_L",          # 20
    "Foot_L",          # 21
    "Thigh_R",         # 22
    "Shin_R",          # 23
    "Foot_R",          # 24
]

BONE_IDX = {name: i for i, name in enumerate(HUMANOID_BONE_NAMES)}


def create_humanoid_bones(height_scale: float = 1.0) -> list[BoneSpec]:
    s = height_scale
    return [
        BoneSpec("Root", -1, (0.0, 0.0, 0.0)),
        BoneSpec("Hips", 0, (0.0, 0.88 * s, 0.0)),
        BoneSpec("Spine", 1, (0.0, 0.14 * s, 0.0)),
        BoneSpec("Chest", 2, (0.0, 0.22 * s, 0.0)),
        BoneSpec("Neck", 3, (0.0, 0.24 * s, 0.0)),
        BoneSpec("Head", 4, (0.0, 0.10 * s, 0.0)),
        BoneSpec("Socket_Helmet", 5, (0.0, 0.18 * s, 0.0)),
        BoneSpec("Socket_Chest", 3, (0.0, 0.10 * s, 0.0)),
        BoneSpec("Socket_Legs", 1, (0.0, -0.08 * s, 0.0)),
        BoneSpec("Shoulder_L", 3, (-0.21 * s, 0.18 * s, 0.0)),
        BoneSpec("UpperArm_L", 9, (-0.08 * s, -0.02 * s, 0.0)),
        BoneSpec("Forearm_L", 10, (0.0, -0.26 * s, 0.0)),
        BoneSpec("Hand_L", 11, (0.0, -0.24 * s, 0.0)),
        BoneSpec("Socket_Weapon_L", 12, (0.0, -0.05 * s, 0.04 * s)),
        BoneSpec("Shoulder_R", 3, (0.21 * s, 0.18 * s, 0.0)),
        BoneSpec("UpperArm_R", 14, (0.08 * s, -0.02 * s, 0.0)),
        BoneSpec("Forearm_R", 15, (0.0, -0.26 * s, 0.0)),
        BoneSpec("Hand_R", 16, (0.0, -0.24 * s, 0.0)),
        BoneSpec("Socket_Weapon_R", 17, (0.0, -0.05 * s, 0.04 * s)),
        BoneSpec("Thigh_L", 1, (-0.12 * s, -0.04 * s, 0.0)),
        BoneSpec("Shin_L", 19, (0.0, -0.38 * s, 0.0)),
        BoneSpec("Foot_L", 20, (0.0, -0.38 * s, 0.0)),
        BoneSpec("Thigh_R", 1, (0.12 * s, -0.04 * s, 0.0)),
        BoneSpec("Shin_R", 22, (0.0, -0.38 * s, 0.0)),
        BoneSpec("Foot_R", 23, (0.0, -0.38 * s, 0.0)),
    ]


@dataclass
class HumanoidStyle:
    skin: int = 0xD8B490
    primary: int = 0x4E6E66
    secondary: int = 0x8F653E
    accent: int = 0xC69244
    boots: int = 0x3D3530
    hair: int = 0x4A372B
    visor: int | None = None
    has_helmet: bool = False
    has_hat: bool = False
    has_backpack: bool = False
    has_apron: bool = False
    has_pauldron: bool = False
    height_scale: float = 1.0
    bulk: float = 1.0


def humanoid_materials() -> list[MaterialSpec]:
    return [
        MaterialSpec("ClothSkin", base_color=(1.0, 1.0, 1.0, 1.0), metallic=0.04, roughness=0.78),
        MaterialSpec("MetalTrim", base_color=(1.0, 1.0, 1.0, 1.0), metallic=0.72, roughness=0.35),
        MaterialSpec("VisorGlow", base_color=(1.0, 1.0, 1.0, 1.0), metallic=0.1, roughness=0.2, emissive=(0.25, 0.45, 0.75)),
    ]


def build_humanoid_mesh(style: HumanoidStyle) -> list[MeshPart]:
    s = style.height_scale
    b = style.bulk
    parts: list[MeshPart] = []

    skin_c = hex_rgba(style.skin)
    pri_c = hex_rgba(style.primary)
    sec_c = hex_rgba(style.secondary)
    acc_c = hex_rgba(style.accent)
    boot_c = hex_rgba(style.boots)
    hair_c = hex_rgba(style.hair)
    eye_c = hex_rgba(0x1E2024)

    # Hips & Belt
    hips = make_tapered_cylinder(0.17 * b * s, 0.16 * b * s, 0.18 * s, (0.0, 0.88 * s, 0.0), sections=8, color=sec_c)
    parts.append(bind_part_rigid(hips, BONE_IDX["Hips"]))
    belt = make_tapered_cylinder(0.18 * b * s, 0.18 * b * s, 0.06 * s, (0.0, 0.94 * s, 0.0), sections=8, color=acc_c, material_index=1)
    parts.append(bind_part_rigid(belt, BONE_IDX["Hips"]))

    # Spine & Chest (soft blend across Spine/Chest)
    torso = make_tapered_cylinder(0.16 * b * s, 0.22 * b * s, 0.40 * s, (0.0, 1.15 * s, 0.0), sections=8, color=pri_c)
    parts.append(bind_part_two_bones(torso, BONE_IDX["Spine"], BONE_IDX["Chest"], 0.96 * s, 1.34 * s))

    # Collar / Neck
    neck = make_tapered_cylinder(0.075 * s, 0.065 * s, 0.12 * s, (0.0, 1.40 * s, 0.0), sections=8, color=skin_c)
    parts.append(bind_part_rigid(neck, BONE_IDX["Neck"]))

    # Head
    head = make_icosphere(0.16 * s, (0.0, 1.59 * s, 0.0), scale=(0.92, 1.05, 0.94), subdivisions=1, color=skin_c)
    parts.append(bind_part_rigid(head, BONE_IDX["Head"]))

    if style.visor is not None:
        visor = make_box((0.20 * s, 0.065 * s, 0.08 * s), (0.0, 1.60 * s, 0.13 * s), hex_rgba(style.visor), material_index=2)
        parts.append(bind_part_rigid(visor, BONE_IDX["Head"]))
    else:
        for sx in (-1, 1):
            eye = make_icosphere(0.025 * s, (sx * 0.058 * s, 1.60 * s, 0.135 * s), subdivisions=1, color=eye_c)
            parts.append(bind_part_rigid(eye, BONE_IDX["Head"]))

    if style.has_helmet:
        helm = make_icosphere(0.18 * s, (0.0, 1.63 * s, -0.01 * s), scale=(0.98, 0.95, 1.02), subdivisions=1, color=acc_c, material_index=1)
        parts.append(bind_part_rigid(helm, BONE_IDX["Head"]))
        crest = make_box((0.04 * s, 0.10 * s, 0.22 * s), (0.0, 1.79 * s, -0.02 * s), sec_c, material_index=1)
        parts.append(bind_part_rigid(crest, BONE_IDX["Head"]))
    elif style.has_hat:
        brim = make_tapered_cylinder(0.24 * s, 0.22 * s, 0.03 * s, (0.0, 1.70 * s, 0.0), sections=10, color=hair_c)
        crown = make_tapered_cylinder(0.15 * s, 0.11 * s, 0.12 * s, (0.0, 1.77 * s, 0.0), sections=10, color=hair_c)
        parts.append(bind_part_rigid(brim, BONE_IDX["Head"]))
        parts.append(bind_part_rigid(crown, BONE_IDX["Head"]))
    else:
        hair = make_icosphere(0.165 * s, (0.0, 1.64 * s, -0.02 * s), scale=(0.96, 0.86, 0.98), subdivisions=1, color=hair_c)
        parts.append(bind_part_rigid(hair, BONE_IDX["Head"]))

    if style.has_backpack:
        pack = make_box((0.26 * s, 0.34 * s, 0.16 * s), (0.0, 1.15 * s, -0.20 * s), sec_c)
        parts.append(bind_part_rigid(pack, BONE_IDX["Chest"]))

    if style.has_apron:
        apron = make_box((0.28 * s, 0.44 * s, 0.04 * s), (0.0, 0.95 * s, 0.17 * b * s), sec_c)
        parts.append(bind_part_rigid(apron, BONE_IDX["Spine"]))

    # Arms (L and R)
    for side, sx in (("L", -1.0), ("R", 1.0)):
        ax = sx * 0.29 * b * s
        if style.has_pauldron:
            pauldron = make_icosphere(0.10 * s, (ax, 1.32 * s, 0.0), scale=(1.1, 0.85, 1.05), subdivisions=1, color=acc_c, material_index=1)
            parts.append(bind_part_rigid(pauldron, BONE_IDX[f"Shoulder_{side}"]))
        u_arm = make_tapered_cylinder(0.062 * s, 0.072 * s, 0.25 * s, (ax, 1.16 * s, 0.0), sections=7, color=pri_c)
        parts.append(bind_part_rigid(u_arm, BONE_IDX[f"UpperArm_{side}"]))
        f_arm = make_tapered_cylinder(0.052 * s, 0.060 * s, 0.23 * s, (ax, 0.91 * s, 0.0), sections=7, color=sec_c)
        parts.append(bind_part_rigid(f_arm, BONE_IDX[f"Forearm_{side}"]))
        hand = make_icosphere(0.055 * s, (ax, 0.76 * s, 0.0), subdivisions=1, color=skin_c)
        parts.append(bind_part_rigid(hand, BONE_IDX[f"Hand_{side}"]))

    # Legs (L and R)
    for side, sx in (("L", -1.0), ("R", 1.0)):
        lx = sx * 0.12 * s
        thigh = make_tapered_cylinder(0.075 * s, 0.090 * s, 0.36 * s, (lx, 0.65 * s, 0.0), sections=7, color=sec_c)
        parts.append(bind_part_rigid(thigh, BONE_IDX[f"Thigh_{side}"]))
        shin = make_tapered_cylinder(0.060 * s, 0.072 * s, 0.36 * s, (lx, 0.27 * s, 0.0), sections=7, color=boot_c)
        parts.append(bind_part_rigid(shin, BONE_IDX[f"Shin_{side}"]))
        foot = make_box((0.12 * s, 0.09 * s, 0.22 * s), (lx, 0.045 * s, 0.04 * s), boot_c)
        parts.append(bind_part_rigid(foot, BONE_IDX[f"Foot_{side}"]))

    return parts


def _sample_rot_track(bone: str, duration: float, fps: int, fn) -> AnimTrack:
    n = max(2, int(round(duration * fps)) + 1)
    times = np.linspace(0.0, duration, n, dtype=np.float32)
    vals = np.zeros((n, 4), dtype=np.float32)
    for i, t in enumerate(times):
        rx, ry, rz = fn(float(t) / duration if duration > 0 else 0.0)
        vals[i] = euler_xyz_to_quat(rx, ry, rz)
    return AnimTrack(bone, "rotation", times, vals)


def _sample_pos_track(bone: str, base_pos: tuple[float, float, float], duration: float, fps: int, fn) -> AnimTrack:
    n = max(2, int(round(duration * fps)) + 1)
    times = np.linspace(0.0, duration, n, dtype=np.float32)
    vals = np.zeros((n, 3), dtype=np.float32)
    for i, t in enumerate(times):
        dx, dy, dz = fn(float(t) / duration if duration > 0 else 0.0)
        vals[i] = [base_pos[0] + dx, base_pos[1] + dy, base_pos[2] + dz]
    return AnimTrack(bone, "translation", times, vals)


def build_humanoid_clips(bones: list[BoneSpec], fps: int = 30) -> list[AnimClip]:
    hips_base = bones[BONE_IDX["Hips"]].translation
    clips: list[AnimClip] = []

    # 1. idle (2.0s loop)
    clips.append(AnimClip("idle", [
        _sample_pos_track("Hips", hips_base, 2.0, fps, lambda u: (0.0, math.sin(u * 2 * math.pi) * 0.014, 0.0)),
        _sample_rot_track("Chest", 2.0, fps, lambda u: (math.sin(u * 2 * math.pi) * 0.03, 0.0, 0.0)),
        _sample_rot_track("Head", 2.0, fps, lambda u: (-math.sin(u * 2 * math.pi) * 0.02, math.sin(u * 2 * math.pi) * 0.04, 0.0)),
        _sample_rot_track("UpperArm_L", 2.0, fps, lambda u: (0.04 * math.sin(u * 2 * math.pi), 0.0, -0.08)),
        _sample_rot_track("UpperArm_R", 2.0, fps, lambda u: (-0.04 * math.sin(u * 2 * math.pi), 0.0, 0.08)),
    ]))

    # 2. walk (0.9s loop)
    clips.append(AnimClip("walk", [
        _sample_pos_track("Hips", hips_base, 0.9, fps, lambda u: (0.0, abs(math.sin(u * 2 * math.pi)) * 0.035, 0.0)),
        _sample_rot_track("Hips", 0.9, fps, lambda u: (0.03, math.sin(u * 2 * math.pi) * 0.07, 0.0)),
        _sample_rot_track("Chest", 0.9, fps, lambda u: (0.05, -math.sin(u * 2 * math.pi) * 0.09, 0.0)),
        _sample_rot_track("Thigh_L", 0.9, fps, lambda u: (math.sin(u * 2 * math.pi) * 0.55, 0.0, 0.0)),
        _sample_rot_track("Shin_L", 0.9, fps, lambda u: (max(0.0, -math.cos(u * 2 * math.pi)) * 0.65, 0.0, 0.0)),
        _sample_rot_track("Thigh_R", 0.9, fps, lambda u: (-math.sin(u * 2 * math.pi) * 0.55, 0.0, 0.0)),
        _sample_rot_track("Shin_R", 0.9, fps, lambda u: (max(0.0, math.cos(u * 2 * math.pi)) * 0.65, 0.0, 0.0)),
        _sample_rot_track("UpperArm_L", 0.9, fps, lambda u: (-math.sin(u * 2 * math.pi) * 0.45, 0.0, -0.06)),
        _sample_rot_track("UpperArm_R", 0.9, fps, lambda u: (math.sin(u * 2 * math.pi) * 0.45, 0.0, 0.06)),
    ]))

    # 3. run (0.65s loop)
    clips.append(AnimClip("run", [
        _sample_pos_track("Hips", hips_base, 0.65, fps, lambda u: (0.0, abs(math.sin(u * 2 * math.pi)) * 0.06, 0.0)),
        _sample_rot_track("Chest", 0.65, fps, lambda u: (0.18, -math.sin(u * 2 * math.pi) * 0.14, 0.0)),
        _sample_rot_track("Thigh_L", 0.65, fps, lambda u: (math.sin(u * 2 * math.pi) * 0.85, 0.0, 0.0)),
        _sample_rot_track("Shin_L", 0.65, fps, lambda u: (max(0.0, -math.cos(u * 2 * math.pi)) * 0.95, 0.0, 0.0)),
        _sample_rot_track("Thigh_R", 0.65, fps, lambda u: (-math.sin(u * 2 * math.pi) * 0.85, 0.0, 0.0)),
        _sample_rot_track("Shin_R", 0.65, fps, lambda u: (max(0.0, math.cos(u * 2 * math.pi)) * 0.95, 0.0, 0.0)),
        _sample_rot_track("UpperArm_L", 0.65, fps, lambda u: (-math.sin(u * 2 * math.pi) * 0.78, 0.0, -0.1)),
        _sample_rot_track("Forearm_L", 0.65, fps, lambda u: (-0.55, 0.0, 0.0)),
        _sample_rot_track("UpperArm_R", 0.65, fps, lambda u: (math.sin(u * 2 * math.pi) * 0.78, 0.0, 0.1)),
        _sample_rot_track("Forearm_R", 0.65, fps, lambda u: (-0.55, 0.0, 0.0)),
    ]))

    # 4. jump (0.7s oneshot)
    clips.append(AnimClip("jump", [
        _sample_pos_track("Hips", hips_base, 0.7, fps, lambda u: (0.0, math.sin(u * math.pi) * 0.18, 0.0)),
        _sample_rot_track("Thigh_L", 0.7, fps, lambda u: (-0.45 * math.sin(u * math.pi), 0.0, 0.0)),
        _sample_rot_track("Shin_L", 0.7, fps, lambda u: (0.65 * math.sin(u * math.pi), 0.0, 0.0)),
        _sample_rot_track("Thigh_R", 0.7, fps, lambda u: (-0.25 * math.sin(u * math.pi), 0.0, 0.0)),
        _sample_rot_track("UpperArm_L", 0.7, fps, lambda u: (-0.9 * math.sin(u * math.pi), 0.0, -0.35 * math.sin(u * math.pi))),
        _sample_rot_track("UpperArm_R", 0.7, fps, lambda u: (-0.9 * math.sin(u * math.pi), 0.0, 0.35 * math.sin(u * math.pi))),
    ]))

    # 5. attack (0.5s oneshot)
    clips.append(AnimClip("attack", [
        _sample_rot_track("Chest", 0.5, fps, lambda u: (0.15 * math.sin(u * math.pi), -0.45 * math.sin(u * 2 * math.pi), 0.0)),
        _sample_rot_track("UpperArm_R", 0.5, fps, lambda u: (-1.45 * math.sin(u * math.pi) + 0.3 * u, 0.35 * math.sin(u * math.pi), 0.25)),
        _sample_rot_track("Forearm_R", 0.5, fps, lambda u: (-0.55 * math.sin(u * math.pi), 0.0, 0.0)),
        _sample_rot_track("UpperArm_L", 0.5, fps, lambda u: (0.25 * math.sin(u * math.pi), 0.0, -0.15)),
    ]))

    # 6. mine (0.75s oneshot)
    clips.append(AnimClip("mine", [
        _sample_rot_track("Spine", 0.75, fps, lambda u: (0.38 * math.sin(u * math.pi), 0.0, 0.0)),
        _sample_rot_track("UpperArm_R", 0.75, fps, lambda u: (-1.75 * math.sin(u * math.pi), 0.0, 0.15)),
        _sample_rot_track("UpperArm_L", 0.75, fps, lambda u: (-1.55 * math.sin(u * math.pi), 0.0, -0.15)),
        _sample_rot_track("Forearm_R", 0.75, fps, lambda u: (-0.4 * math.sin(u * math.pi), 0.0, 0.0)),
    ]))

    # 7. greet / wave / talk / trade-reaction / smelt / refine / item cues
    one_shot_specs = {
        "greet": (0.9, lambda u: (-0.2 * math.sin(u * math.pi), 0.0, 0.0), lambda u: (-1.6 * math.sin(u * math.pi), 0.0, 0.45 * math.sin(u * 3 * math.pi))),
        "wave": (1.1, lambda u: (0.0, 0.0, 0.0), lambda u: (-2.1 * math.sin(min(1.0, u * 1.4) * math.pi), 0.0, 0.35 * math.sin(u * 6 * math.pi))),
        "talk": (1.2, lambda u: (0.05 * math.sin(u * 4 * math.pi), 0.0, 0.0), lambda u: (-0.55 * math.sin(u * 2 * math.pi), 0.0, 0.15)),
        "trade-reaction": (0.9, lambda u: (-0.12 * math.sin(u * math.pi), 0.0, 0.0), lambda u: (-0.8 * math.sin(u * math.pi), 0.2 * math.sin(u * math.pi), 0.15)),
        "pet-dog": (1.2, lambda u: (0.45 * math.sin(u * math.pi), 0.0, 0.0), lambda u: (-0.85 * math.sin(u * math.pi), 0.0, 0.15 * math.sin(u * 4 * math.pi))),
        "smelt": (1.0, lambda u: (0.22 * math.sin(u * math.pi), 0.0, 0.0), lambda u: (-1.1 * math.sin(u * 2 * math.pi), 0.0, 0.12)),
        "trade": (0.85, lambda u: (0.14 * math.sin(u * math.pi), 0.0, 0.0), lambda u: (-0.75 * math.sin(u * math.pi), 0.0, 0.1)),
        "refine-success": (1.1, lambda u: (-0.15 * math.sin(u * math.pi), 0.0, 0.0), lambda u: (-2.2 * math.sin(u * math.pi), 0.0, 0.25)),
        "refine-failure": (1.0, lambda u: (0.28 * math.sin(u * math.pi), 0.0, 0.0), lambda u: (-0.3 * math.sin(u * math.pi), 0.0, -0.15)),
        "pickaxe-pickup": (0.9, lambda u: (0.42 * math.sin(u * math.pi), 0.0, 0.0), lambda u: (-1.0 * math.sin(u * math.pi), 0.0, 0.1)),
        "hand-over-item": (0.8, lambda u: (0.18 * math.sin(u * math.pi), 0.0, 0.0), lambda u: (-0.95 * math.sin(u * math.pi), 0.0, 0.05)),
        "receive-item": (0.8, lambda u: (-0.10 * math.sin(u * math.pi), 0.0, 0.0), lambda u: (-0.85 * math.sin(u * math.pi), 0.0, 0.15)),
    }
    for name, (dur, chest_fn, arm_fn) in one_shot_specs.items():
        clips.append(AnimClip(name, [
            _sample_rot_track("Chest", dur, fps, chest_fn),
            _sample_rot_track("UpperArm_R", dur, fps, arm_fn),
            _sample_rot_track("Forearm_R", dur, fps, lambda u: (-0.45 * math.sin(u * math.pi), 0.0, 0.0)),
        ]))

    # 8. NPC work loops
    clips.append(AnimClip("work-smith", [
        _sample_rot_track("Chest", 1.2, fps, lambda u: (0.2 * math.sin(u * 2 * math.pi), 0.0, 0.0)),
        _sample_rot_track("UpperArm_R", 1.2, fps, lambda u: (-1.3 * abs(math.sin(u * 2 * math.pi)), 0.0, 0.12)),
        _sample_rot_track("Forearm_R", 1.2, fps, lambda u: (-0.5 * abs(math.sin(u * 2 * math.pi)), 0.0, 0.0)),
    ]))
    return clips
