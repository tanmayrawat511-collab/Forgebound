#!/usr/bin/env python3
"""Generate ForgeBound J4 cave/ruin interiors as validated Python-authored GLBs.

All structural geometry, POI props, and exit markers are authored here with trimesh.
The app consumes the resulting GLBs directly and derives Rapier triangle colliders
from their meshes; no runtime primitive substitute is used for world models.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Iterable

import numpy as np
import trimesh

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "public" / "assets" / "dungeons"

PALETTES = {
    "quarry-cave": {"rock": (89, 79, 65, 255), "trim": (143, 112, 77, 255), "glow": (211, 143, 70, 255), "floor": (75, 69, 58, 255)},
    "quarry-ruin": {"rock": (105, 104, 91, 255), "trim": (175, 149, 105, 255), "glow": (226, 188, 111, 255), "floor": (83, 82, 72, 255)},
    "ember-cave": {"rock": (59, 48, 44, 255), "trim": (111, 67, 48, 255), "glow": (255, 91, 32, 255), "floor": (48, 40, 38, 255)},
    "ember-ruin": {"rock": (70, 55, 49, 255), "trim": (151, 89, 53, 255), "glow": (255, 123, 49, 255), "floor": (54, 43, 39, 255)},
    "crystal-cave": {"rock": (78, 91, 113, 255), "trim": (117, 139, 180, 255), "glow": (139, 188, 255, 255), "floor": (66, 76, 95, 255)},
    "crystal-ruin": {"rock": (92, 104, 128, 255), "trim": (166, 184, 219, 255), "glow": (171, 199, 255, 255), "floor": (75, 87, 108, 255)},
}

DUNGEONS = [
    {"id": "forgotten-mine", "kind": "cave", "theme": "quarry-cave", "points": ["forgotten-mine.ore-cache", "forgotten-mine.prospector-mark", "forgotten-mine.deep-vein"]},
    {"id": "old-stonewatch", "kind": "ruin", "theme": "quarry-ruin", "points": ["old-stonewatch.watch-inscription", "old-stonewatch.sealed-cache", "old-stonewatch.guardian-relief"]},
    {"id": "deep-ember-caverns", "kind": "cave", "theme": "ember-cave", "points": ["deep-ember-caverns.ember-core", "deep-ember-caverns.vent-prism", "deep-ember-caverns.smuggler-cache"]},
    {"id": "forgotten-furnace", "kind": "ruin", "theme": "ember-ruin", "points": ["forgotten-furnace.furnace-blueprint", "forgotten-furnace.ancient-anvil", "forgotten-furnace.furnace-heart"]},
    {"id": "luminous-caverns", "kind": "cave", "theme": "crystal-cave", "points": ["luminous-caverns.resonance-shard", "luminous-caverns.crystal-garden", "luminous-caverns.crystal-cache"]},
    {"id": "ancient-observatory", "kind": "ruin", "theme": "crystal-ruin", "points": ["ancient-observatory.star-map", "ancient-observatory.lunar-lens", "ancient-observatory.vault"]},
    {"id": "summit-temple", "kind": "ruin", "theme": "crystal-ruin", "points": ["summit-temple.summit-rune", "summit-temple.beacon-catalyst", "summit-temple.temple-relic"]},
]


def box(extents: tuple[float, float, float], center: tuple[float, float, float], color: tuple[int, int, int, int]) -> trimesh.Trimesh:
    mesh = trimesh.creation.box(extents=extents)
    mesh.apply_translation(center)
    mesh.visual.vertex_colors = np.tile(np.asarray(color, dtype=np.uint8), (len(mesh.vertices), 1))
    return mesh


def cylinder(radius: float, height: float, center: tuple[float, float, float], color: tuple[int, int, int, int], sections: int = 8) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    mesh.apply_translation(center)
    mesh.visual.vertex_colors = np.tile(np.asarray(color, dtype=np.uint8), (len(mesh.vertices), 1))
    return mesh


def sphere(radius: float, center: tuple[float, float, float], color: tuple[int, int, int, int], subdivisions: int = 1, scale: tuple[float, float, float] = (1, 1, 1)) -> trimesh.Trimesh:
    mesh = trimesh.creation.icosphere(subdivisions=subdivisions, radius=radius)
    mesh.apply_scale(scale)
    mesh.apply_translation(center)
    mesh.visual.vertex_colors = np.tile(np.asarray(color, dtype=np.uint8), (len(mesh.vertices), 1))
    return mesh


def cone(radius: float, height: float, center: tuple[float, float, float], color: tuple[int, int, int, int], sections: int = 6) -> trimesh.Trimesh:
    mesh = trimesh.creation.cone(radius=radius, height=height, sections=sections)
    mesh.apply_translation(center)
    mesh.visual.vertex_colors = np.tile(np.asarray(color, dtype=np.uint8), (len(mesh.vertices), 1))
    return mesh


def combine(meshes: Iterable[trimesh.Trimesh]) -> trimesh.Trimesh:
    result = trimesh.util.concatenate(list(meshes))
    result.remove_unreferenced_vertices()
    return result


def add(scene: trimesh.Scene, name: str, mesh: trimesh.Trimesh) -> None:
    scene.add_geometry(mesh, geom_name=name, node_name=name)


def build_poi_mesh(point_id: str, kind_index: int, palette: dict[str, tuple[int, int, int, int]], position: tuple[float, float, float]) -> trimesh.Trimesh:
    x, y, z = position
    rock, trim, glow = palette["rock"], palette["trim"], palette["glow"]
    meshes: list[trimesh.Trimesh] = []
    if kind_index == 0:
        # Recessed supply coffer with a bright lock plate.
        meshes.extend([
            box((1.65, 0.95, 1.1), (x, y + 0.48, z), rock),
            box((1.72, 0.16, 1.16), (x, y + 1.04, z), trim),
            box((0.3, 0.44, 0.08), (x, y + 0.75, z + 0.6), glow),
        ])
    elif kind_index == 1:
        # Inscription slab on a short pedestal.
        meshes.extend([
            box((1.05, 0.7, 0.9), (x, y + 0.35, z), trim),
            box((0.9, 1.25, 0.16), (x, y + 1.25, z), rock),
            box((0.08, 0.56, 0.035), (x, y + 1.26, z + 0.105), glow),
        ])
        for i in range(3):
            meshes.append(box((0.42, 0.055, 0.04), (x, y + 1.48 - i * 0.18, z + 0.105), glow))
    else:
        # Mineral/relic altar with a clear glowing focal object.
        meshes.extend([
            cylinder(0.88, 0.65, (x, y + 0.32, z), trim, 8),
            cone(0.56, 1.65, (x, y + 1.34, z), glow, 6),
            sphere(0.18, (x, y + 1.75, z), glow, 1, (0.7, 1.5, 0.7)),
        ])
    return combine(meshes)


def add_outer_walls(scene: trimesh.Scene, palette: dict[str, tuple[int, int, int, int]], theme: str) -> None:
    rock = palette["rock"]
    # Room footprint is a broad, connected three-chamber system, with openings in each partition.
    wall_h, wall_t = 6.6, 1.0
    # Side walls and rear wall.
    for x in (-32, 32):
        add(scene, f"wall-side-{x}", box((wall_t, wall_h, 50), (x, wall_h / 2, -7.5), rock))
    add(scene, "wall-back", box((64, wall_h, wall_t), (0, wall_h / 2, -32), rock))
    # Entrance wall has a 6 m opening in the middle.
    add(scene, "wall-entry-left", box((29, wall_h, wall_t), (-17.5, wall_h / 2, 17), rock))
    add(scene, "wall-entry-right", box((29, wall_h, wall_t), (17.5, wall_h / 2, 17), rock))
    # Room partitions with wide passages.
    add(scene, "wall-partition-upper-left", box((27, wall_h, wall_t), (-18.5, wall_h / 2, 0), rock))
    add(scene, "wall-partition-upper-right", box((27, wall_h, wall_t), (18.5, wall_h / 2, 0), rock))
    add(scene, "wall-partition-lower-left", box((27, wall_h, wall_t), (-18.5, wall_h / 2, -10), rock))
    add(scene, "wall-partition-lower-right", box((27, wall_h, wall_t), (18.5, wall_h / 2, -10), rock))
    # Side alcove partition opens to the chamber through a broad gap.
    add(scene, "wall-alcove-back", box((wall_t, wall_h, 10), (-14, wall_h / 2, -23), rock))
    add(scene, "wall-alcove-front", box((wall_t, wall_h, 3), (-14, wall_h / 2, -14.5), rock))

    # Roof ribs frame the chambers without making the interior claustrophobic.
    rib = palette["trim"]
    for index, z in enumerate((12, 3, -7, -17, -27)):
        for x in (-28, 28):
            add(scene, f"rib-pillar-{index}-{x}", box((0.9, 5.6, 0.9), (x, 2.8, z), rib))
        add(scene, f"rib-crossbeam-{index}", box((57, 0.72, 0.8), (0, 5.35, z), rib))


def add_cave_dressing(scene: trimesh.Scene, palette: dict[str, tuple[int, int, int, int]], variant: int) -> None:
    rock, glow = palette["rock"], palette["glow"]
    # Stalactites and low mounds stay outside the central navigation lanes.
    for i, x in enumerate((-26, -21, 22, 27, -25, 25, -20, 20)):
        z = 12 - (i % 4) * 11
        height = 1.8 + (i % 3) * 0.55
        add(scene, f"stalactite-{i}", cone(0.72, height, (x, 6.6 - height / 2, z), rock, 6))
        add(scene, f"stalagmite-{i}", cone(0.58, height * 0.72, (x, height * 0.36, z - 1.8), rock, 6))
    for i, position in enumerate(((-7, 0, 8), (8, 0, -18), (-22, 0, -21), (21, 0, -24))):
        x, _, z = position
        add(scene, f"cave-glow-{i}", combine([
            sphere(0.62, (x, 1.15, z), glow, 1, (0.65, 1.8, 0.65)),
            sphere(0.28, (x + 0.5, 0.7, z + 0.4), glow, 1, (0.7, 1.5, 0.7)),
        ]))


def add_ruin_dressing(scene: trimesh.Scene, palette: dict[str, tuple[int, int, int, int]], variant: int) -> None:
    trim, glow = palette["trim"], palette["glow"]
    # Broken columns, lintels, and shallow wall reliefs make this feel like an authored ruin.
    for i, (x, z) in enumerate(((-25, 11), (25, 11), (-25, -19), (25, -19), (-8, -25), (8, -25))):
        height = 2.3 + (i % 3) * 0.65
        add(scene, f"ruin-column-{i}", cylinder(0.46, height, (x, height / 2, z), trim, 8))
        add(scene, f"ruin-column-cap-{i}", box((1.2, 0.22, 1.2), (x, height + 0.11, z), glow))
    for i, (x, z, rot) in enumerate(((-26, -3, 0.0), (26, -3, 0.0), (-8, -30, 0.2), (8, -30, -0.2))):
        lintel = box((5.4, 0.42, 0.5), (x, 4.8, z), trim)
        lintel.apply_transform(trimesh.transformations.rotation_matrix(rot, [0, 1, 0], point=(x, 4.8, z)))
        add(scene, f"ruin-lintel-{i}", lintel)
    for i in range(4):
        x = -20 + i * 13
        add(scene, f"rune-inlay-{i}", box((0.12, 1.2, 0.08), (x, 2.6, -31.42), glow))



def add_unique_landmark_dressing(scene: trimesh.Scene, dungeon_id: str, palette: dict[str, tuple[int, int, int, int]]) -> None:
    """Add a silhouette-defining landmark prop set unique to this interior."""
    rock, trim, glow = palette["rock"], palette["trim"], palette["glow"]

    if dungeon_id == "forgotten-mine":
        # A short ore-cart rail spur hugs the right-hand wall and leaves the centre lane open.
        for x in (17.0, 18.3):
            add(scene, f"mine-rail-{x}", box((0.18, 0.22, 18.0), (x, 0.22, -18.5), trim))
        for i, z in enumerate((-10, -13, -16, -19, -22, -25, -28)):
            add(scene, f"mine-sleeper-{i}", box((2.1, 0.18, 0.55), (17.65, 0.12, z), rock))
        add(scene, "ore-cart-bed", box((2.3, 0.82, 1.7), (17.65, 0.82, -18.0), trim))
        for x in (16.45, 18.85):
            for z in (-18.65, -17.35):
                wheel = cylinder(0.38, 0.16, (x, 0.42, z), glow, 10)
                wheel.apply_transform(trimesh.transformations.rotation_matrix(math.pi / 2, [0, 0, 1]))
                add(scene, f"ore-cart-wheel-{x}-{z}", wheel)

    elif dungeon_id == "old-stonewatch":
        # Raised rear parapet and a broken stair run evoke a compact watchtower interior.
        add(scene, "stonewatch-parapet", box((19, 1.1, 1.0), (21.5, 2.0, -29.8), trim))
        for i in range(6):
            height = 0.28 + i * 0.25
            add(scene, f"stonewatch-step-{i}", box((5.2, height, 1.15), (21.5, height / 2, -26.0 + i * 1.15), rock))
        for x in (14.0, 29.0):
            add(scene, f"stonewatch-battlement-{x}", box((1.1, 2.8, 1.2), (x, 3.0, -30.0), glow))

    elif dungeon_id == "deep-ember-caverns":
        # Basalt fins frame a shallow glowing fissure along the chamber edge.
        add(scene, "ember-fissure", box((1.25, 0.12, 17.0), (25.8, 0.08, -19.0), glow))
        for i, (x, z) in enumerate(((23.0, -10), (28.0, -15), (23.0, -22), (28.0, -27))):
            height = 2.4 + (i % 2) * 1.1
            add(scene, f"basalt-fin-{i}", cone(1.25, height, (x, height / 2, z), rock, 5))
        for i in range(4):
            add(scene, f"ember-crust-{i}", sphere(0.48, (24.8, 0.42, -12 - i * 4), glow, 1, (1.7, 0.35, 0.55)))

    elif dungeon_id == "forgotten-furnace":
        # Furnace block and anvil make the old industrial purpose unmistakable.
        add(scene, "furnace-hearth", box((7.0, 4.2, 3.2), (22.0, 2.1, -28.0), rock))
        add(scene, "furnace-mouth", box((3.1, 2.2, 0.2), (22.0, 1.45, -26.35), glow))
        add(scene, "furnace-chimney", box((2.2, 3.8, 2.2), (24.0, 5.8, -30.0), trim))
        add(scene, "furnace-anvil-base", box((3.0, 0.6, 1.6), (-26.0, 0.3, -25.5), rock))
        add(scene, "furnace-anvil-horn", combine([
            box((2.1, 0.55, 1.2), (-26.0, 0.88, -25.5), trim),
            cone(0.38, 1.0, (-24.75, 1.0, -25.5), trim, 5),
        ]))

    elif dungeon_id == "luminous-caverns":
        # Crystal spires cluster around the perimeter, leaving the three POIs unobstructed.
        clusters = ((-27, 11), (27, 8), (27, -13), (-27, -29), (27, -29))
        for cluster_index, (cx, cz) in enumerate(clusters):
            for crystal_index in range(3):
                x = cx + (crystal_index - 1) * 0.9
                height = 2.4 + ((cluster_index + crystal_index) % 3) * 0.9
                crystal = cone(0.62, height, (x, height / 2, cz + (crystal_index % 2) * 0.55), glow, 6)
                crystal.apply_transform(trimesh.transformations.rotation_matrix((crystal_index - 1) * 0.16, [0, 0, 1], point=(x, height / 2, cz)))
                add(scene, f"crystal-cluster-{cluster_index}-{crystal_index}", crystal)

    elif dungeon_id == "ancient-observatory":
        # A rear-wall armillary made from crossed hoops, a lens tube, and a star-map plinth.
        ring_a = trimesh.creation.torus(major_radius=2.25, minor_radius=0.13, major_sections=32, minor_sections=8)
        ring_a.apply_transform(trimesh.transformations.rotation_matrix(math.pi / 2, [1, 0, 0]))
        ring_a.apply_translation((22.0, 3.0, -29.0))
        ring_a.visual.vertex_colors = np.tile(np.asarray(trim, dtype=np.uint8), (len(ring_a.vertices), 1))
        add(scene, "observatory-armillary-ring-a", ring_a)
        ring_b = trimesh.creation.torus(major_radius=1.75, minor_radius=0.11, major_sections=32, minor_sections=8)
        ring_b.apply_transform(trimesh.transformations.rotation_matrix(0.68, [0, 0, 1]))
        ring_b.apply_translation((22.0, 3.0, -29.0))
        ring_b.visual.vertex_colors = np.tile(np.asarray(glow, dtype=np.uint8), (len(ring_b.vertices), 1))
        add(scene, "observatory-armillary-ring-b", ring_b)
        telescope = cylinder(0.42, 4.6, (22.0, 3.0, -26.0), rock, 12)
        telescope.apply_transform(trimesh.transformations.rotation_matrix(math.pi / 2, [1, 0, 0], point=(22.0, 3.0, -26.0)))
        add(scene, "observatory-lunar-telescope", telescope)
        add(scene, "observatory-star-map", box((6.5, 0.42, 3.2), (-25.0, 0.22, -27.0), trim))

    elif dungeon_id == "summit-temple":
        # Beacon altar and paired obelisks form a clear ceremonial focal point at the far end.
        add(scene, "temple-beacon-altar", box((6.0, 1.1, 4.2), (22.0, 0.55, -27.0), trim))
        add(scene, "temple-beacon-core", sphere(0.85, (22.0, 2.45, -27.0), glow, 2, (0.75, 1.2, 0.75)))
        for index, x in enumerate((16.0, 28.0)):
            height = 4.5 if index == 0 else 3.8
            add(scene, f"temple-obelisk-{index}", cone(0.9, height, (x, height / 2, -29.0), rock, 5))
            add(scene, f"temple-obelisk-cap-{index}", sphere(0.38, (x, height + 0.12, -29.0), glow, 1))


def build_dungeon(dungeon: dict[str, object], index: int) -> trimesh.Scene:
    scene = trimesh.Scene()
    palette = PALETTES[str(dungeon["theme"])]
    floor = palette["floor"]
    # Connected floor surfaces: entrance hall, short corridor, main chamber, and side alcove.
    for name, extents, center in (
        ("floor-entry-hall", (28, 0.6, 18), (0, -0.3, 8)),
        ("floor-link-corridor", (12, 0.6, 13), (0, -0.3, -7.5)),
        ("floor-main-chamber", (36, 0.6, 23), (0, -0.3, -23)),
        ("floor-side-alcove", (14, 0.6, 15), (-22, -0.3, -22)),
    ):
        add(scene, name, box(extents, center, floor))

    add_outer_walls(scene, palette, str(dungeon["theme"]))
    if dungeon["kind"] == "cave":
        add_cave_dressing(scene, palette, index)
    else:
        add_ruin_dressing(scene, palette, index)
    add_unique_landmark_dressing(scene, str(dungeon["id"]), palette)

    # Lantern/sconce geometry is baked into the GLB. The app adds matching point lights.
    for i, (x, z) in enumerate(((-28, 10), (28, 10), (-28, -27), (28, -27), (0, -28))):
        add(scene, f"sconce-{i}", combine([
            box((0.28, 0.92, 0.28), (x, 2.6, z), palette["trim"]),
            sphere(0.3, (x, 3.25, z), palette["glow"], 1, (0.8, 1.2, 0.8)),
        ]))

    # POIs are separate, named GLB nodes so the game can raycast and claim each once.
    positions = ((-8.0, 0.0, 8.0), (8.0, 0.0, -19.0), (-21.0, 0.0, -22.0))
    for point_index, point_id in enumerate(dungeon["points"]):
        node_name = "poi_" + str(point_id).replace(".", "_").replace("-", "_")
        add(scene, node_name, build_poi_mesh(str(point_id), point_index, palette, positions[point_index]))

    # Return arch sits just inside the entry gap and is itself an interaction target.
    exit_meshes = [
        box((1.0, 4.0, 0.75), (-3.0, 2.0, 15.0), palette["trim"]),
        box((1.0, 4.0, 0.75), (3.0, 2.0, 15.0), palette["trim"]),
        box((7.0, 0.72, 0.85), (0, 4.0, 15.0), palette["glow"]),
        box((7.0, 0.2, 1.0), (0, 0.1, 15.0), palette["trim"]),
    ]
    add(scene, "dungeon_exit_gate", combine(exit_meshes))

    # A small room-sign plate gives landmarks a visible authored identity.
    add(scene, "dungeon-title-plaque", combine([
        box((3.8, 1.2, 0.22), (0, 4.2, -30.9), palette["trim"]),
        box((2.8, 0.15, 0.08), (0, 4.15, -30.72), palette["glow"]),
    ]))
    return scene


def export_verified(scene: trimesh.Scene, path: Path) -> dict[str, object]:
    blob = scene.export(file_type="glb")
    if not isinstance(blob, bytes) or blob[:4] != b"glTF":
        raise RuntimeError(f"{path.name} did not export as GLB")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(blob)
    loaded = trimesh.load(path, force="scene")
    if not isinstance(loaded, trimesh.Scene) or not loaded.geometry:
        raise RuntimeError(f"{path.name} has no valid geometry")
    for name, geom in loaded.geometry.items():
        if not isinstance(geom, trimesh.Trimesh) or len(geom.vertices) == 0 or len(geom.faces) == 0:
            raise RuntimeError(f"{path.name}:{name} is empty")
        if not np.isfinite(geom.vertices).all():
            raise RuntimeError(f"{path.name}:{name} has non-finite vertices")
    return {"file": path.name, "bytes": path.stat().st_size, "meshCount": len(loaded.geometry), "source": "tools/generate_dungeons.py", "poiIds": list(next(item for item in DUNGEONS if item["id"] == path.stem)["points"])}


def main() -> int:
    manifest = []
    for index, dungeon in enumerate(DUNGEONS):
        path = OUTPUT / f"{dungeon['id']}.glb"
        manifest.append({"id": dungeon["id"], **export_verified(build_dungeon(dungeon, index), path)})
        print(f"Generated {path.relative_to(ROOT)} ({path.stat().st_size:,} bytes)")
    (OUTPUT / "manifest.json").write_text(json.dumps({
        "generator": "tools/generate_dungeons.py",
        "runtime": "Python + trimesh + numpy",
        "allInteriorGeometryGeneratedByPython": True,
        "interiorCount": len(manifest),
        "interiors": manifest,
    }, indent=2) + "\n")
    print(f"Verified {len(manifest)} dungeon interior GLBs.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
