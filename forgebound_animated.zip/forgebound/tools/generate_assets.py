#!/usr/bin/env python3
"""Generate deterministic low-poly Forgebound GLB placeholders with trimesh.

Run from the project root with system Python (not Blender's bundled Python):
    python -m pip install trimesh numpy
    python tools/generate_assets.py

The script writes local GLBs to public/assets/models. It downloads no models,
textures, fonts, or other runtime content. trimesh's glTF exporter writes GLB
files; each file is re-opened and checked for mesh geometry after export.
"""
from __future__ import annotations

import sys
import json
import math
from pathlib import Path

try:
    import numpy as np
    import trimesh
except ImportError as exc:  # actionable failure for a clean machine
    raise SystemExit(
        "Asset generation requires trimesh and numpy. Install them with: "
        "python -m pip install trimesh numpy"
    ) from exc

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "public" / "assets" / "models"

COLORS = {
    "rock": (91, 91, 83, 255),
    "copper": (194, 111, 62, 255),
    "iron": (142, 157, 158, 255),
    "gold": (225, 179, 68, 255),
    "crystal": (119, 150, 224, 255),
    "armor": (93, 125, 116, 255),
    "dark": (39, 53, 54, 255),
    "brass": (190, 139, 68, 255),
    "ember": (241, 92, 35, 255),
    "basalt": (54, 43, 42, 255),
    "violet": (151, 126, 221, 255),
    "silver": (183, 196, 198, 255),
}


def paint(mesh: trimesh.Trimesh, color: tuple[int, int, int, int]) -> trimesh.Trimesh:
    mesh.visual.vertex_colors = np.tile(np.array(color, dtype=np.uint8), (len(mesh.vertices), 1))
    return mesh


def add(scene: trimesh.Scene, mesh: trimesh.Trimesh, name: str,
        position=(0.0, 0.0, 0.0), scale=(1.0, 1.0, 1.0), color=COLORS["rock"],
        rotation_y: float = 0.0) -> None:
    mesh = paint(mesh, color)
    transform = trimesh.transformations.translation_matrix(position)
    if rotation_y:
        transform = transform @ trimesh.transformations.rotation_matrix(rotation_y, [0, 1, 0])
    scale_matrix = np.eye(4)
    scale_matrix[0, 0], scale_matrix[1, 1], scale_matrix[2, 2] = scale
    transform = transform @ scale_matrix
    scene.add_geometry(mesh, node_name=name, geom_name=f"{name}-geometry", transform=transform)


def box(extents, position, color, name, rotation_y=0.0):
    add(CURRENT, trimesh.creation.box(extents=extents), name, position, color=color, rotation_y=rotation_y)


def sphere(radius, position, color, name, subdivisions=2, scale=(1, 1, 1)):
    add(CURRENT, trimesh.creation.icosphere(subdivisions=subdivisions, radius=radius), name,
        position, scale=scale, color=color)


def cylinder(radius, height, position, color, name, sections=7, rotation=None):
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    mesh.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
    if rotation is not None:
        mesh.apply_transform(trimesh.transformations.rotation_matrix(rotation, [0, 0, 1]))
    add(CURRENT, mesh, name, position, color=color)


def cone(radius, height, position, color, name, sections=6, scale=(1, 1, 1), axis="y"):
    mesh = trimesh.creation.cone(radius=radius, height=height, sections=sections)
    if axis == "y":
        mesh.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
    elif axis == "x":
        mesh.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
    add(CURRENT, mesh, name, position, scale=scale, color=color)


def build_player() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    box((0.62, 0.9, 0.42), (0, 0.0, 0), COLORS["armor"], "player-torso")
    sphere(0.28, (0, 0.62, 0.02), COLORS["dark"], "player-helmet")
    box((0.32, 0.12, 0.08), (0, 0.62, 0.27), COLORS["crystal"], "player-visor")
    box((0.24, 0.5, 0.27), (-0.2, -0.63, 0), COLORS["dark"], "player-left-boot")
    box((0.24, 0.5, 0.27), (0.2, -0.63, 0), COLORS["dark"], "player-right-boot")
    box((0.16, 0.42, 0.2), (-0.43, 0.05, 0), COLORS["brass"], "player-left-shoulder")
    box((0.16, 0.42, 0.2), (0.43, 0.05, 0), COLORS["brass"], "player-right-shoulder")
    return s


def build_ore(color, name) -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    add(s, trimesh.creation.icosphere(subdivisions=1, radius=0.68), "ore-rock", (0, 0.2, 0), (1.08, 0.86, 0.94), COLORS["rock"])
    for index, pos in enumerate([(-0.28, 0.48, 0.26), (0.26, 0.42, -0.2), (0.02, 0.68, 0.12)]):
        cone(0.22 if index < 2 else 0.26, 0.68 if index < 2 else 0.84,
             pos, color, f"{name}-vein-{index}", scale=(0.74, 1, 0.74))
    return s


def build_pickaxe() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    cylinder(0.07, 1.75, (0, 0, 0), COLORS["brass"], "pickaxe-wooden-shaft", sections=7)
    box((1.0, 0.18, 0.22), (0.02, 0.83, 0), COLORS["silver"], "pickaxe-head")
    cone(0.13, 0.5, (-0.55, 0.83, 0), COLORS["silver"], "pickaxe-left-point", scale=(0.65, 1, 0.65), axis="x")
    cone(0.13, 0.5, (0.56, 0.83, 0), COLORS["silver"], "pickaxe-right-point", scale=(0.65, 1, 0.65), axis="x")
    return s


def build_sword() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    cylinder(0.07, 0.56, (0, -0.54, 0), COLORS["dark"], "sword-grip")
    box((0.78, 0.13, 0.16), (0, -0.2, 0), COLORS["brass"], "sword-guard")
    cone(0.19, 1.55, (0, 0.62, 0), COLORS["silver"], "sword-blade", scale=(0.72, 1, 0.2))
    return s


def build_hammer() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    cylinder(0.075, 1.55, (0, -0.18, 0), COLORS["brass"], "maul-handle")
    box((0.78, 0.72, 0.48), (0, 0.68, 0), COLORS["silver"], "maul-head")
    box((0.84, 0.12, 0.54), (0, 0.37, 0), COLORS["dark"], "maul-collar")
    return s


def build_enemy(kind: str) -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    if kind == "crawler":
        body, accent = COLORS["rock"], COLORS["copper"]
        add(s, trimesh.creation.icosphere(subdivisions=1, radius=0.73), "crawler-body", (0, 0, 0), (1.1, 0.8, 1.15), body)
        for i, x in enumerate([-0.58, 0.58]):
            for j, z in enumerate([-0.34, 0.34]):
                cylinder(0.07, 0.62, (x, -0.28, z), COLORS["dark"], f"crawler-leg-{i}-{j}")
        sphere(0.24, (0, 0.34, 0.4), accent, "crawler-shell")
    elif kind == "ember":
        body, accent = COLORS["basalt"], COLORS["ember"]
        add(s, trimesh.creation.icosphere(subdivisions=1, radius=0.7), "ember-body", (0, 0, 0), (1, 0.9, 1.12), body)
        for i in range(5):
            cone(0.15, 0.52, (-0.4 + i * 0.2, 0.46 + (i % 2) * 0.06, -0.18), accent, f"ember-spike-{i}")
        sphere(0.18, (0, -0.02, 0.52), accent, "ember-core")
    else:
        body, accent = COLORS["crystal"], COLORS["violet"]
        add(s, trimesh.creation.icosphere(subdivisions=1, radius=0.74), "guardian-body", (0, 0, 0), (1.05, 1.05, 1.05), body)
        cone(0.3, 0.9, (-0.52, 0.25, 0), accent, "guardian-left-crystal")
        cone(0.3, 0.9, (0.52, 0.25, 0), accent, "guardian-right-crystal")
        cone(0.34, 1.05, (0, 0.68, -0.08), accent, "guardian-crest")
    sphere(0.07, (-0.14, 0.27, 0.56), COLORS["gold"], f"{kind}-eye-left")
    sphere(0.07, (0.14, 0.27, 0.56), COLORS["gold"], f"{kind}-eye-right")
    return s


def build_forge() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    box((2.35, 0.45, 1.95), (0, 0.24, 0), COLORS["rock"], "forge-stone-base")
    box((1.55, 1.1, 1.32), (0, 0.91, 0), COLORS["dark"], "forge-body")
    box((1.2, 0.2, 1.08), (0, 1.58, 0), COLORS["brass"], "forge-rim")
    cylinder(0.44, 1.55, (-0.47, 2.0, -0.28), COLORS["rock"], "forge-chimney", sections=7)
    sphere(0.36, (0.12, 1.45, 0.69), COLORS["ember"], "forge-ember", scale=(1.05, 0.72, 0.28))
    cylinder(0.42, 0.33, (0.96, 0.67, -0.24), COLORS["dark"], "forge-anvil-base", sections=6)
    box((0.92, 0.3, 0.55), (0.96, 0.96, -0.24), COLORS["silver"], "forge-anvil")
    box((0.38, 0.24, 0.42), (1.54, 1.06, -0.24), COLORS["silver"], "forge-anvil-horn")
    return s


def build_pine_tree() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    cylinder(0.28, 3.4, (0, 1.65, 0), COLORS["dark"], "pine-trunk", sections=7)
    for i, (y, radius, height) in enumerate([(0.95, 1.05, 2.0), (1.8, 0.82, 1.9), (2.55, 0.58, 1.55)]):
        cone(radius, height, (0, y + 0.45, 0), COLORS["armor"], f"pine-crown-{i}", sections=7)
    return s


def build_broadleaf_tree() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    cylinder(0.24, 2.4, (0, 1.1, 0), COLORS["dark"], "broadleaf-trunk", sections=7)
    for i, pos in enumerate([(-0.58, 2.25, 0), (0.5, 2.15, 0.1), (0.0, 2.65, -0.38), (0.0, 2.5, 0.45)]):
        sphere(0.9, pos, (67 + i * 7, 117 + i * 8, 73 + i * 4, 255), f"leaf-canopy-{i}", scale=(1.0, 0.82, 0.95))
    return s


def build_rock_outcrop() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    for i, (pos, scale) in enumerate([((-0.45, 0.35, 0), (1.1, 0.8, 1.0)), ((0.4, 0.28, 0.25), (0.9, 0.65, 0.8)), ((0.05, 0.62, -0.38), (0.75, 1.1, 0.68))]):
        sphere(0.9, pos, COLORS["rock"], f"outcrop-boulder-{i}", scale=scale)
    return s


def build_stone_arch() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    box((0.48, 3.3, 0.55), (-1.3, 1.65, 0), COLORS["rock"], "arch-left-pillar")
    box((0.48, 3.3, 0.55), (1.3, 1.65, 0), COLORS["rock"], "arch-right-pillar")
    box((3.1, 0.55, 0.62), (0, 3.08, 0), COLORS["silver"], "arch-lintel")
    return s


def build_volcanic_vent() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    cylinder(1.1, 0.65, (0, 0.22, 0), COLORS["basalt"], "vent-base", sections=8)
    cone(0.86, 1.25, (0, 0.86, 0), COLORS["basalt"], "vent-cone", sections=8)
    cylinder(0.44, 0.14, (0, 1.48, 0), COLORS["ember"], "vent-mouth", sections=8)
    sphere(0.32, (0, 1.53, 0), COLORS["gold"], "vent-glow", scale=(1, 0.35, 1))
    return s


def build_crystal_spire() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    for i, (x, z, scale) in enumerate([(0, 0, 2.4), (-0.65, 0.25, 1.3), (0.62, -0.32, 1.55)]):
        cone(0.46 if i == 0 else 0.28, scale, (x, scale * 0.48, z), COLORS["violet"] if i else COLORS["crystal"], f"crystal-spire-{i}", sections=6, scale=(0.75, 1, 0.72))
    return s


def build_timber_stack() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    for row in range(3):
        for col in range(3):
            cylinder(0.18, 2.4, ((col - 1) * 0.42, row * 0.36 + 0.15, 0), (132, 91, 56, 255), f"timber-log-{row}-{col}", sections=8)
    return s


def build_mine_cart() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    box((1.55, 0.9, 1.08), (0, 0.88, 0), COLORS["dark"], "ore-cart-body")
    box((1.35, 0.12, 0.92), (0, 1.36, 0), COLORS["silver"], "ore-cart-rim")
    for x in (-0.62, 0.62):
        for z in (-0.48, 0.48):
            cylinder(0.22, 0.16, (x, 0.24, z), COLORS["brass"], f"ore-cart-wheel-{x}-{z}", sections=10)
    return s


def build_magma_corn() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    cylinder(0.06, 1.05, (0, 0.48, 0), (70, 126, 64, 255), "magma-corn-stalk", sections=7)
    for i, y in enumerate([0.38, 0.64, 0.88]):
        cone(0.18, 0.38, (0.02, y, 0.02), COLORS["gold"], f"magma-corn-cob-{i}", sections=7)
    for i, z in enumerate([-0.22, 0.22]):
        cone(0.14, 0.54, (0, 0.45, z), (70, 145, 74, 255), f"magma-corn-leaf-{i}", sections=5, axis="z")
    return s


def build_crystal_cod() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    add(s, trimesh.creation.icosphere(subdivisions=2, radius=0.56), "crystal-cod-body", (0, 0, 0), (1.55, 0.68, 0.58), COLORS["crystal"])
    cone(0.33, 0.7, (0.86, 0.0, 0), COLORS["violet"], "cod-tail", axis="x")
    sphere(0.08, (-0.45, 0.12, 0.42), COLORS["gold"], "cod-eye", subdivisions=1)
    return s


def build_chessboard() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    box((2.5, 0.18, 2.5), (0, 0, 0), COLORS["dark"], "chessboard-frame")
    for row in range(8):
        for col in range(8):
            color = COLORS["silver"] if (row + col) % 2 == 0 else COLORS["basalt"]
            box((0.29, 0.035, 0.29), ((col - 3.5) * 0.3, 0.11, (row - 3.5) * 0.3), color, f"chess-square-{row}-{col}")
    return s


def build_portal() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    box((3.25, 0.28, 1.4), (0, 0.14, 0), COLORS["dark"], "portal-base")
    for side in (-1, 1):
        cylinder(0.22, 3.5, (side * 1.38, 1.9, 0), COLORS["silver"], f"portal-pillar-{side}", sections=9)
    # The arch is authored as a torus mesh, not assembled in the game runtime.
    ring = trimesh.creation.torus(major_radius=1.35, minor_radius=0.13, major_sections=40, minor_sections=8)
    ring.apply_translation((0, 3.25, 0))
    add(s, ring, "portal-arch", (0, 0, 0), (1, 1, 1), COLORS["crystal"])
    disc = trimesh.creation.cylinder(radius=1.16, height=0.035, sections=40)
    disc.apply_transform(trimesh.transformations.rotation_matrix(math.pi / 2, [1, 0, 0]))
    add(s, disc, "portal-disc", (0, 2.0, -0.04), (1, 1, 1), COLORS["violet"])
    sphere(0.22, (0, 4.0, 0), COLORS["gold"], "portal-rune", subdivisions=1)
    return s


def build_water_plane() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    mesh = trimesh.creation.box(extents=(1, 0.035, 1))
    add(s, mesh, "water-plane", (0, 0, 0), (1, 1, 1), (54, 119, 148, 170))
    return s


def build_cave_arch() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    for side in (-1, 1):
        sphere(1.0, (side * 1.05, 0.8, 0), COLORS["basalt"], f"cave-pillar-{side}", scale=(0.65, 1.6, 0.7))
    box((2.5, 0.5, 0.75), (0, 2.0, 0), COLORS["rock"], "cave-lintel")
    return s


def build_quest_cat() -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    # A small low-poly companion cat, authored entirely in Python for the GLB pipeline.
    sphere(0.43, (0, 0.43, 0), (74, 68, 61, 255), "cat-body", scale=(1.25, 0.82, 0.72))
    sphere(0.29, (0, 0.88, 0.18), (91, 82, 73, 255), "cat-head", subdivisions=2)
    cone(0.13, 0.34, (-0.19, 1.14, 0.17), (91, 82, 73, 255), "cat-left-ear", sections=5)
    cone(0.13, 0.34, (0.19, 1.14, 0.17), (91, 82, 73, 255), "cat-right-ear", sections=5)
    sphere(0.045, (-0.105, 0.91, 0.43), (230, 192, 104, 255), "cat-left-eye", subdivisions=1)
    sphere(0.045, (0.105, 0.91, 0.43), (230, 192, 104, 255), "cat-right-eye", subdivisions=1)
    cone(0.075, 0.5, (0.49, 0.53, -0.08), (74, 68, 61, 255), "cat-tail", sections=6, axis="x")
    for x in (-0.22, 0.22):
        box((0.13, 0.36, 0.15), (x, 0.12, 0.02), (68, 62, 56, 255), f"cat-paw-{x}")
    return s


def build_npc(role: str, variant: int) -> trimesh.Scene:
    s = trimesh.Scene(); global CURRENT; CURRENT = s
    palette = [COLORS["armor"], COLORS["brass"], COLORS["copper"], COLORS["violet"], COLORS["silver"], COLORS["ember"]]
    primary = palette[variant % len(palette)]
    secondary = palette[(variant + 2) % len(palette)]
    box((0.58, 0.92, 0.38), (0, 0.25, 0), primary, f"{role}-torso")
    sphere(0.27, (0, 0.96, 0), COLORS["dark"], f"{role}-head", subdivisions=2, scale=(0.95, 1.04, 0.92))
    box((0.34, 0.09, 0.08), (0, 0.94, 0.24), secondary, f"{role}-face-guard")
    for side in (-1, 1):
        box((0.18, 0.68, 0.2), (side * 0.21, -0.48, 0), secondary, f"{role}-leg-{side}")
        sphere(0.12, (side * 0.48, 0.34, 0), secondary, f"{role}-shoulder-{side}", subdivisions=1)
    if role in ("blacksmith", "refiner"):
        box((0.58, 0.28, 0.14), (0, 0.4, 0.25), COLORS["dark"], f"{role}-apron")
    elif role in ("shopkeeper", "merchant"):
        cone(0.52, 0.45, (0, 1.2, 0), secondary, f"{role}-cap", sections=6)
    elif role in ("combat", "miner"):
        box((0.7, 0.12, 0.42), (0, 0.78, 0), secondary, f"{role}-headband")
    return s


def build_terrain_chunk(zone_id: str, ix: int, iz: int, width: float, depth: float) -> trimesh.Scene:
    """Build one Python-authored 256 m maximum terrain tile with real relief and biome colors."""
    scene = trimesh.Scene()
    samples = 25
    side = 7_000_000.0 ** 0.5
    min_x = -side / 2 + ix * 256.0
    min_z = -side / 2 + iz * 256.0
    xs = np.linspace(0.0, width, samples)
    zs = np.linspace(0.0, depth, samples)
    vertices = []
    colors = []
    for j, local_z in enumerate(zs):
        for i, local_x in enumerate(xs):
            x = min_x + local_x
            z = min_z + local_z
            if zone_id == "starter-quarry":
                ridge = 15 * np.sin(x / 330) * np.cos(z / 410) + 7 * np.sin((x + z) / 140)
                quarry_bowl = -19 * np.exp(-((x - 80) ** 2 + (z + 70) ** 2) / (2 * 280 ** 2))
                river_axis = 250 * np.sin(z / 340)
                river = -5.5 * np.exp(-((x - river_axis) / 42) ** 2)
                h = ridge + quarry_bowl + river
                color = (92, 112, 75, 255) if h < 16 else (115, 109, 87, 255) if h < 30 else (112, 105, 94, 255)
            elif zone_id == "molten-caves":
                radius = np.hypot(x + 120, z - 90)
                caldera_rim = 34 * np.exp(-((radius - 620) / 190) ** 2)
                basin = -13 * np.exp(-(radius / 440) ** 2)
                ridges = 10 * np.sin(x / 220) + 8 * np.cos(z / 180)
                fissure = -3.5 * np.exp(-((z - 0.28 * x + 160) / 24) ** 2)
                h = 15 + caldera_rim + basin + ridges + fissure
                color = (64, 53, 48, 255) if h < 25 else (82, 65, 57, 255) if h < 42 else (108, 80, 64, 255)
            else:
                ridge_a = 58 * abs(np.sin(x / 360) * np.cos(z / 290))
                ridge_b = 31 * abs(np.sin((x + z) / 220))
                peak = 28 * np.exp(-((x - 520) ** 2 + (z + 490) ** 2) / (2 * 260 ** 2))
                valley = -7 * np.exp(-((x + 110) ** 2 + (z - 180) ** 2) / (2 * 260 ** 2))
                h = 14 + ridge_a + ridge_b + peak + valley
                color = (113, 132, 157, 255) if h < 34 else (145, 158, 183, 255) if h < 62 else (183, 194, 213, 255)
            # A small, authored spawn terrace keeps each zone's entry safe while the
            # surrounding terrain retains the full biome elevation profile.
            spawn_height = {"starter-quarry": 0.0, "molten-caves": 12.0, "crystal-peaks": 14.0}[zone_id]
            plateau_weight = math.exp(-((x * x + z * z) / (2 * 75.0 ** 2)))
            h = h * (1.0 - plateau_weight) + spawn_height * plateau_weight
            vertices.append([local_x, float(h), local_z])
            # Slight vertex-color variation makes each terrain mesh read less like a uniform plane.
            shade = 0.92 + 0.08 * math.sin(i * 0.7 + j * 0.41)
            colors.append([int(min(255, c * shade)) for c in color[:3]] + [255])
    faces = []
    for j in range(samples - 1):
        for i in range(samples - 1):
            a = j * samples + i
            b = a + 1
            c = a + samples
            d = c + 1
            faces.extend([[a, c, b], [b, c, d]])
    terrain = trimesh.Trimesh(vertices=np.asarray(vertices), faces=np.asarray(faces), process=False)
    terrain.visual.vertex_colors = np.asarray(colors, dtype=np.uint8)
    scene.add_geometry(terrain, node_name=f"{zone_id}-terrain-{ix}-{iz}", geom_name="terrain-surface")
    return scene


ENVIRONMENT_ASSETS = {
    "tree-pine.glb": build_pine_tree,
    "tree-broadleaf.glb": build_broadleaf_tree,
    "rock-outcrop.glb": build_rock_outcrop,
    "stone-arch.glb": build_stone_arch,
    "volcanic-vent.glb": build_volcanic_vent,
    "crystal-spire.glb": build_crystal_spire,
    "timber-stack.glb": build_timber_stack,
    "ore-cart.glb": build_mine_cart,
    "magma-corn.glb": build_magma_corn,
    "crystal-cod.glb": build_crystal_cod,
    "chessboard.glb": build_chessboard,
    "cave-arch.glb": build_cave_arch,
    "portal.glb": build_portal,
    "water-plane.glb": build_water_plane,
    "npc-combat-01.glb": lambda: build_npc("combat", 0),
    "npc-combat-02.glb": lambda: build_npc("combat", 1),
    "npc-combat-03.glb": lambda: build_npc("combat", 2),
    "npc-miner-01.glb": lambda: build_npc("miner", 1),
    "npc-miner-02.glb": lambda: build_npc("miner", 2),
    "npc-miner-03.glb": lambda: build_npc("miner", 3),
    "npc-blacksmith-01.glb": lambda: build_npc("blacksmith", 2),
    "npc-blacksmith-02.glb": lambda: build_npc("blacksmith", 3),
    "npc-blacksmith-03.glb": lambda: build_npc("blacksmith", 4),
    "npc-shopkeeper-01.glb": lambda: build_npc("shopkeeper", 4),
    "npc-shopkeeper-02.glb": lambda: build_npc("shopkeeper", 5),
    "npc-shopkeeper-03.glb": lambda: build_npc("shopkeeper", 0),
    "npc-refiner-01.glb": lambda: build_npc("refiner", 5),
    "npc-refiner-02.glb": lambda: build_npc("refiner", 0),
    "npc-refiner-03.glb": lambda: build_npc("refiner", 1),
    "npc-timber-giver.glb": lambda: build_npc("miner", 4),
    "npc-billy.glb": lambda: build_npc("merchant", 5),
    "npc-jason.glb": lambda: build_npc("merchant", 0),
    "npc-tyler.glb": lambda: build_npc("merchant", 1),
    "npc-michael.glb": lambda: build_npc("merchant", 2),
    "npc-frank.glb": lambda: build_npc("merchant", 3),
    "npc-james.glb": lambda: build_npc("miner", 5),
    "quest-cat.glb": build_quest_cat,
}


def export_verified(scene: trimesh.Scene, output_path: Path) -> int:
    binary = scene.export(file_type="glb")
    if not isinstance(binary, bytes) or not binary.startswith(b"glTF"):
        raise RuntimeError("trimesh did not return a valid GLB binary")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(binary)
    check = trimesh.load(output_path, force="scene")
    if not isinstance(check, trimesh.Scene) or len(check.geometry) == 0:
        raise RuntimeError("exported GLB did not contain mesh geometry")
    return output_path.stat().st_size


def generate_environment_assets() -> list[dict[str, str | int]]:
    manifest = []
    for filename, factory in ENVIRONMENT_ASSETS.items():
        output_path = OUTPUT / filename
        try:
            size = export_verified(factory(), output_path)
        except Exception as exc:
            raise SystemExit(f"Failed to generate environment asset {filename}: {exc}") from exc
        print(f"Generated {output_path.relative_to(ROOT)} ({size:,} bytes)")
        manifest.append({"file": filename, "path": f"/assets/models/{filename}", "bytes": size, "source": "tools/generate_assets.py"})
    return manifest


def generate_terrain_chunks() -> list[dict[str, str | int | float]]:
    terrain_root = ROOT / "public" / "assets" / "terrain"
    side = 7_000_000.0 ** 0.5
    count = math.ceil(side / 256.0)
    entries: list[dict[str, str | int | float]] = []
    for zone_id in ("starter-quarry", "molten-caves", "crystal-peaks"):
        for iz in range(count):
            for ix in range(count):
                width = min(256.0, side - ix * 256.0)
                depth = min(256.0, side - iz * 256.0)
                scene = build_terrain_chunk(zone_id, ix, iz, width, depth)
                relative = Path(zone_id) / f"chunk-{ix:02d}-{iz:02d}.glb"
                output_path = terrain_root / relative
                size = export_verified(scene, output_path)
                entries.append({
                    "zoneId": zone_id, "x": ix, "z": iz,
                    "originX": -side / 2 + ix * 256.0,
                    "originZ": -side / 2 + iz * 256.0,
                    "width": width, "depth": depth,
                    "file": f"/assets/terrain/{relative.as_posix()}",
                    "bytes": size,
                })
        print(f"Generated terrain for {zone_id}: {count * count} GLB chunks")
    (terrain_root / "manifest.json").write_text(json.dumps({
        "generator": "tools/generate_assets.py", "format": "glb",
        "playableAreaSquareMeters": 7_000_000, "playableAreaSquareKilometers": 7,
        "sideMeters": side, "chunkSizeMeters": 256, "chunksPerAxis": count,
        "chunks": entries,
    }, indent=2) + "\n")
    return entries


ASSETS = {
    "player.glb": build_player,
    "ore-copper.glb": lambda: build_ore(COLORS["copper"], "copper"),
    "ore-iron.glb": lambda: build_ore(COLORS["iron"], "iron"),
    "ore-gold.glb": lambda: build_ore(COLORS["gold"], "gold"),
    "ore-crystal.glb": lambda: build_ore(COLORS["crystal"], "crystal"),
    "pickaxe.glb": build_pickaxe,
    "weapon-sword.glb": build_sword,
    "weapon-hammer.glb": build_hammer,
    "enemy-crawler.glb": lambda: build_enemy("crawler"),
    "enemy-ember.glb": lambda: build_enemy("ember"),
    "enemy-guardian.glb": lambda: build_enemy("guardian"),
    "forge.glb": build_forge,
}


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    core_manifest = []
    for filename, factory in ASSETS.items():
        output_path = OUTPUT / filename
        try:
            size = export_verified(factory(), output_path)
        except Exception as exc:
            raise SystemExit(f"Failed to generate {filename}: {exc}") from exc
        print(f"Generated {output_path.relative_to(ROOT)} ({size:,} bytes)")
        core_manifest.append({"file": filename, "path": f"/assets/models/{filename}", "bytes": size, "source": "tools/generate_assets.py"})

    environment_manifest = generate_environment_assets()
    terrain_manifest = generate_terrain_chunks()
    all_models = core_manifest + environment_manifest
    model_index = {
        "generator": "tools/generate_assets.py",
        "generatorRuntime": "Python + trimesh + numpy",
        "all3DModelsGeneratedByPython": True,
        "modelCount": len(all_models),
        "models": all_models,
        "terrainManifest": "/assets/terrain/manifest.json",
        "terrainChunkCount": len(terrain_manifest),
    }
    (ROOT / "public" / "assets" / "model-manifest.json").write_text(json.dumps(model_index, indent=2) + "\n")
    print(f"Verified {len(all_models)} model GLBs and {len(terrain_manifest)} terrain GLBs.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
