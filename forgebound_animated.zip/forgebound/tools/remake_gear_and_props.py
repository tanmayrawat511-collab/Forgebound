#!/usr/bin/env python3
"""Remake and optimize all 16 gear/weapon models, 11 stations/props, and 9 environment models."""
from __future__ import annotations

import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from glb_builder import (
    MaterialSpec,
    MeshPart,
    export_glb,
    hex_rgba,
    make_blade,
    make_box,
    make_icosphere,
    make_tapered_cylinder,
    validate_glb,
)

ROOT = Path(__file__).resolve().parents[1]
MODELS_DIR = ROOT / "public" / "assets" / "models"


def gear_mats() -> list[MaterialSpec]:
    return [
        MaterialSpec("GearWoodLeather", (1, 1, 1, 1), metallic=0.05, roughness=0.78),
        MaterialSpec("GearMetal", (1, 1, 1, 1), metallic=0.78, roughness=0.32),
    ]


def build_gear() -> dict[str, tuple[list[MeshPart], list[MaterialSpec]]]:
    wood = hex_rgba(0x745034)
    leather = hex_rgba(0x463228)
    steel = hex_rgba(0xB8C4C8)
    dark_steel = hex_rgba(0x6D787D)
    brass = hex_rgba(0xC99342)
    mats = gear_mats()
    out: dict[str, tuple[list[MeshPart], list[MaterialSpec]]] = {}

    out["pickaxe.glb"] = ([
        make_tapered_cylinder(0.032, 0.038, 1.10, (0, 0.45, 0), 8, wood, 0),
        make_tapered_cylinder(0.052, 0.052, 0.14, (0, 0.92, 0), 8, brass, 1),
        make_blade(0.42, 0.10, 0.06, (-0.22, 0.92, 0), steel, 1, curve_x=-0.04),
        make_blade(0.36, 0.09, 0.06, (0.20, 0.92, 0), steel, 1, curve_x=0.04),
    ], mats)

    out["weapon-sword.glb"] = ([
        make_tapered_cylinder(0.024, 0.028, 0.24, (0, 0.0, 0), 8, leather, 0),
        make_box((0.26, 0.045, 0.06), (0, 0.14, 0), brass, 1),
        make_tapered_cylinder(0.04, 0.03, 0.06, (0, -0.14, 0), 8, brass, 1),
        make_blade(0.88, 0.09, 0.035, (0, 0.60, 0), steel, 1),
    ], mats)

    out["weapon-hammer.glb"] = ([
        make_tapered_cylinder(0.032, 0.036, 0.95, (0, 0.36, 0), 8, wood, 0),
        make_box((0.46, 0.24, 0.24), (0, 0.84, 0), dark_steel, 1),
        make_box((0.50, 0.18, 0.18), (0, 0.84, 0), brass, 1),
    ], mats)

    out["gear-daggers.glb"] = ([
        make_tapered_cylinder(0.02, 0.022, 0.18, (0, 0, 0), 7, leather, 0),
        make_box((0.16, 0.03, 0.05), (0, 0.10, 0), brass, 1),
        make_blade(0.46, 0.055, 0.025, (0, 0.34, 0), steel, 1),
    ], mats)

    out["gear-straight-sword.glb"] = ([
        make_tapered_cylinder(0.024, 0.026, 0.24, (0, 0, 0), 8, leather, 0),
        make_box((0.28, 0.04, 0.06), (0, 0.14, 0), brass, 1),
        make_blade(0.92, 0.08, 0.032, (0, 0.62, 0), steel, 1),
    ], mats)

    # Retopologized mace (down from 2,280 tris to ~240 tris)
    mace_parts = [
        make_tapered_cylinder(0.03, 0.036, 0.86, (0, 0.34, 0), 8, wood, 0),
        make_icosphere(0.16, (0, 0.82, 0), (0.95, 1.15, 0.95), 1, dark_steel, 1),
    ]
    for k in range(6):
        ang = k * math.pi / 3.0
        mace_parts.append(make_box((0.06, 0.16, 0.04), (math.cos(ang) * 0.16, 0.82, math.sin(ang) * 0.16), brass, 1))
    out["gear-mace.glb"] = (mace_parts, mats)

    out["gear-gauntlet.glb"] = ([
        make_tapered_cylinder(0.09, 0.11, 0.24, (0, 0.0, 0), 8, dark_steel, 1),
        make_box((0.14, 0.14, 0.16), (0, -0.14, 0.02), brass, 1),
        make_box((0.13, 0.06, 0.15), (0, -0.20, 0.03), steel, 1),
    ], mats)

    out["gear-axe.glb"] = ([
        make_tapered_cylinder(0.028, 0.034, 0.90, (0, 0.35, 0), 8, wood, 0),
        make_box((0.09, 0.14, 0.10), (0.02, 0.72, 0), brass, 1),
        make_blade(0.38, 0.28, 0.05, (0.18, 0.72, 0), steel, 1, tip_ratio=0.3),
    ], mats)

    out["gear-katana.glb"] = ([
        make_tapered_cylinder(0.022, 0.024, 0.28, (0, -0.02, 0), 8, leather, 0),
        make_tapered_cylinder(0.08, 0.08, 0.025, (0, 0.13, 0), 10, brass, 1),
        make_blade(1.06, 0.05, 0.024, (0.02, 0.68, 0), steel, 1, curve_x=0.05),
    ], mats)

    out["gear-great-sword.glb"] = ([
        make_tapered_cylinder(0.028, 0.032, 0.34, (0, -0.04, 0), 8, leather, 0),
        make_box((0.38, 0.06, 0.08), (0, 0.16, 0), brass, 1),
        make_blade(1.24, 0.13, 0.045, (0, 0.80, 0), steel, 1),
    ], mats)

    out["gear-spear.glb"] = ([
        make_tapered_cylinder(0.026, 0.028, 1.55, (0, 0.55, 0), 8, wood, 0),
        make_tapered_cylinder(0.042, 0.042, 0.08, (0, 1.32, 0), 8, brass, 1),
        make_blade(0.40, 0.09, 0.035, (0, 1.52, 0), steel, 1, tip_ratio=0.65),
    ], mats)

    out["gear-great-axe.glb"] = ([
        make_tapered_cylinder(0.032, 0.038, 1.28, (0, 0.48, 0), 8, wood, 0),
        make_box((0.12, 0.20, 0.12), (0, 0.98, 0), brass, 1),
        make_blade(0.52, 0.34, 0.06, (0.24, 0.98, 0), steel, 1),
        make_blade(0.52, 0.34, 0.06, (-0.24, 0.98, 0), steel, 1),
    ], mats)

    out["gear-colossal-sword.glb"] = ([
        make_tapered_cylinder(0.034, 0.038, 0.40, (0, -0.06, 0), 8, leather, 0),
        make_box((0.48, 0.08, 0.10), (0, 0.18, 0), brass, 1),
        make_blade(1.56, 0.22, 0.065, (0, 0.98, 0), dark_steel, 1),
    ], mats)

    out["gear-helmet.glb"] = ([
        make_icosphere(0.20, (0, 0.02, 0), (1.0, 0.95, 1.05), 1, dark_steel, 1),
        make_box((0.24, 0.06, 0.08), (0, 0.01, 0.16), brass, 1),
        make_box((0.05, 0.12, 0.24), (0, 0.20, -0.02), brass, 1),
    ], mats)

    out["gear-chestplate.glb"] = ([
        make_tapered_cylinder(0.20, 0.25, 0.42, (0, 0.0, 0), 8, dark_steel, 1),
        make_box((0.36, 0.14, 0.30), (0, 0.10, 0.02), brass, 1),
    ], mats)

    out["gear-leggings.glb"] = ([
        make_box((0.16, 0.42, 0.18), (-0.12, -0.22, 0), dark_steel, 1),
        make_box((0.16, 0.42, 0.18), (0.12, -0.22, 0), dark_steel, 1),
        make_box((0.38, 0.12, 0.22), (0.0, 0.0, 0), brass, 1),
    ], mats)

    return out


def build_props_and_env() -> dict[str, tuple[list[MeshPart], list[MaterialSpec]]]:
    rock = hex_rgba(0x5B5B53)
    basalt = hex_rgba(0x362B2A)
    wood = hex_rgba(0x745034)
    foliage = hex_rgba(0x3C6B46)
    pine = hex_rgba(0x2B543C)
    ember = hex_rgba(0xF15C23)
    crystal = hex_rgba(0x7796E0)
    gold = hex_rgba(0xE1B344)
    copper = hex_rgba(0xC26F3E)
    iron = hex_rgba(0x8E9D9E)
    water = hex_rgba(0x3C7FA8, 0.85)

    std_mats = [
        MaterialSpec("WorldMatte", (1, 1, 1, 1), metallic=0.05, roughness=0.82),
        MaterialSpec("WorldMetal", (1, 1, 1, 1), metallic=0.65, roughness=0.38),
        MaterialSpec("WorldEmissive", (1, 1, 1, 1), metallic=0.1, roughness=0.25, emissive=(0.85, 0.42, 0.15)),
    ]
    crystal_mats = [
        MaterialSpec("WorldMatte", (1, 1, 1, 1), metallic=0.05, roughness=0.82),
        MaterialSpec("CrystalEmissive", (1, 1, 1, 1), metallic=0.2, roughness=0.18, emissive=(0.3, 0.55, 0.95)),
    ]

    out: dict[str, tuple[list[MeshPart], list[MaterialSpec]]] = {}

    # Ores
    for name, col, mat_i in [("ore-copper.glb", copper, 1), ("ore-iron.glb", iron, 1), ("ore-gold.glb", gold, 1), ("ore-crystal.glb", crystal, 1)]:
        mats = crystal_mats if "crystal" in name else std_mats
        out[name] = ([
            make_icosphere(0.62, (0, 0.35, 0), (1.1, 0.85, 0.95), 1, rock, 0),
            make_blade(0.70, 0.24, 0.22, (-0.25, 0.65, 0.20), col, mat_i),
            make_blade(0.84, 0.26, 0.24, (0.18, 0.72, -0.15), col, mat_i),
            make_blade(0.62, 0.20, 0.20, (0.04, 0.68, 0.22), col, mat_i),
        ], mats)

    # Forge
    out["forge.glb"] = ([
        make_box((1.6, 0.45, 1.4), (0, 0.22, 0), basalt, 0),
        make_box((1.3, 1.1, 1.1), (0, 0.95, -0.1), rock, 0),
        make_tapered_cylinder(0.32, 0.22, 1.3, (0, 2.1, -0.1), 8, basalt, 0),
        make_box((0.7, 0.45, 0.2), (0, 0.72, 0.48), ember, 2),
        make_box((0.6, 0.4, 0.38), (1.1, 0.2, 0.35), iron, 1),
    ], std_mats)

    # Portal
    portal_parts = [
        make_box((2.4, 0.25, 1.0), (0, 0.12, 0), basalt, 0),
        make_box((0.36, 2.5, 0.45), (-0.95, 1.45, 0), rock, 0),
        make_box((0.36, 2.5, 0.45), (0.95, 1.45, 0), rock, 0),
        make_box((2.3, 0.4, 0.5), (0, 2.75, 0), rock, 0),
        make_box((1.5, 2.2, 0.08), (0, 1.45, 0), crystal, 1),
    ]
    out["portal.glb"] = (portal_parts, crystal_mats)

    # Ben's House
    out["ben-house.glb"] = ([
        make_box((3.6, 2.2, 3.2), (0, 1.1, 0), hex_rgba(0xC9B496), 0),
        make_tapered_cylinder(2.7, 0.2, 1.6, (0, 2.95, 0), 4, hex_rgba(0x7A4634), 0),
        make_box((0.45, 1.2, 0.45), (1.1, 3.1, -0.7), rock, 0),
        make_box((0.75, 1.4, 0.12), (0, 0.7, 1.62), wood, 0),
        make_box((0.65, 0.55, 0.12), (-0.95, 1.3, 1.62), hex_rgba(0xF6D27A), 2),
        make_box((0.65, 0.55, 0.12), (0.95, 1.3, 1.62), hex_rgba(0xF6D27A), 2),
    ], std_mats)

    # Chessboard
    out["chessboard.glb"] = ([
        make_box((1.4, 0.14, 1.4), (0, 0.07, 0), wood, 0),
        make_box((1.2, 0.04, 1.2), (0, 0.15, 0), hex_rgba(0xE0D4BE), 0),
        make_tapered_cylinder(0.08, 0.05, 0.26, (-0.35, 0.28, 0.35), 8, hex_rgba(0xF0EDE4), 0),
        make_tapered_cylinder(0.08, 0.05, 0.26, (0.35, 0.28, -0.35), 8, basalt, 0),
    ], std_mats)

    # Quest & Station Props
    out["magma-corn.glb"] = ([
        make_tapered_cylinder(0.10, 0.06, 0.55, (0, 0.28, 0), 7, gold, 2),
        make_blade(0.45, 0.14, 0.04, (-0.12, 0.22, 0), foliage, 0),
        make_blade(0.45, 0.14, 0.04, (0.12, 0.22, 0), foliage, 0),
    ], std_mats)

    out["crystal-cod.glb"] = ([
        make_icosphere(0.24, (0, 0.22, 0), (0.6, 0.7, 1.6), 1, crystal, 1),
        make_blade(0.28, 0.20, 0.04, (0, 0.22, -0.40), crystal, 1),
    ], crystal_mats)

    out["ore-cart.glb"] = ([
        make_box((1.0, 0.55, 1.4), (0, 0.45, 0), wood, 0),
        make_box((0.9, 0.12, 1.3), (0, 0.72, 0), copper, 1),
        make_tapered_cylinder(0.18, 0.18, 0.10, (-0.52, 0.18, 0.45), 10, iron, 1, axis="x"),
        make_tapered_cylinder(0.18, 0.18, 0.10, (0.52, 0.18, 0.45), 10, iron, 1, axis="x"),
        make_tapered_cylinder(0.18, 0.18, 0.10, (-0.52, 0.18, -0.45), 10, iron, 1, axis="x"),
        make_tapered_cylinder(0.18, 0.18, 0.10, (0.52, 0.18, -0.45), 10, iron, 1, axis="x"),
    ], std_mats)

    out["timber-stack.glb"] = ([
        make_tapered_cylinder(0.14, 0.14, 1.4, (x, y, 0), 8, wood, 0, axis="z")
        for x, y in [(-0.3, 0.14), (0.0, 0.14), (0.3, 0.14), (-0.15, 0.38), (0.15, 0.38)]
    ], std_mats)

    # Environment & Nature
    out["cave-arch.glb"] = ([
        make_box((0.9, 2.8, 1.1), (-1.4, 1.4, 0), rock, 0),
        make_box((0.9, 2.8, 1.1), (1.4, 1.4, 0), rock, 0),
        make_box((3.7, 0.85, 1.2), (0, 2.9, 0), rock, 0),
    ], std_mats)

    out["stone-arch.glb"] = ([
        make_box((0.7, 2.4, 0.8), (-1.2, 1.2, 0), basalt, 0),
        make_box((0.7, 2.4, 0.8), (1.2, 1.2, 0), basalt, 0),
        make_box((3.1, 0.6, 0.9), (0, 2.5, 0), basalt, 0),
    ], std_mats)

    out["rock-outcrop.glb"] = ([
        make_icosphere(0.85, (0, 0.45, 0), (1.25, 0.85, 1.05), 1, rock, 0),
        make_icosphere(0.55, (0.65, 0.32, 0.35), (1.0, 0.75, 0.9), 1, basalt, 0),
    ], std_mats)

    out["volcanic-vent.glb"] = ([
        make_tapered_cylinder(1.1, 0.55, 0.85, (0, 0.42, 0), 9, basalt, 0),
        make_tapered_cylinder(0.45, 0.42, 0.15, (0, 0.80, 0), 9, ember, 2),
    ], std_mats)

    out["crystal-spire.glb"] = ([
        make_blade(2.2, 0.55, 0.55, (0, 1.1, 0), crystal, 1),
        make_blade(1.3, 0.35, 0.35, (-0.35, 0.65, 0.25), crystal, 1),
    ], crystal_mats)

    out["tree-pine.glb"] = ([
        make_tapered_cylinder(0.22, 0.14, 1.4, (0, 0.7, 0), 7, wood, 0),
        make_tapered_cylinder(1.15, 0.05, 1.6, (0, 1.9, 0), 7, pine, 0),
        make_tapered_cylinder(0.85, 0.05, 1.3, (0, 2.9, 0), 7, pine, 0),
    ], std_mats)

    out["tree-broadleaf.glb"] = ([
        make_tapered_cylinder(0.26, 0.18, 1.7, (0, 0.85, 0), 8, wood, 0),
        make_icosphere(1.15, (0, 2.35, 0), (1.15, 0.92, 1.1), 1, foliage, 0),
        make_icosphere(0.78, (-0.65, 2.05, 0.4), (1.0, 0.85, 1.0), 1, foliage, 0),
    ], std_mats)

    out["water-plane.glb"] = ([
        make_box((10.0, 0.05, 10.0), (0, 0, 0), water, 0),
    ], [MaterialSpec("WaterSurface", (1, 1, 1, 0.85), metallic=0.15, roughness=0.12)])

    return out


def main() -> None:
    all_assets = {}
    all_assets.update(build_gear())
    all_assets.update(build_props_and_env())
    results = []
    for fname, (parts, mats) in all_assets.items():
        p = MODELS_DIR / fname
        export_glb(p, parts, mats, mesh_name=fname.replace(".glb", ""))
        results.append(validate_glb(p))
    print(f"Remade and validated {len(results)} gear/prop/environment GLBs.")
    for r in results[:5]:
        print(" ", r)


if __name__ == "__main__":
    main()
