#!/usr/bin/env python3
"""Verify the release GLB inventory, SHA-256 digests, and finite non-empty geometry."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

try:
    import numpy as np
    import trimesh
except ImportError as exc:  # pragma: no cover - exercised on developer machines
    print(f"Missing asset verification dependency: {exc}. Install numpy and trimesh first.", file=sys.stderr)
    raise SystemExit(2)

ROOT = Path(__file__).resolve().parents[1]
J7_MANIFEST_PATH = ROOT / 'release' / 'j7-asset-sha256.json'
LEGACY_MANIFEST_PATH = ROOT / 'release' / 'asset-sha256.json'
MANIFEST_PATH = J7_MANIFEST_PATH if J7_MANIFEST_PATH.is_file() else LEGACY_MANIFEST_PATH


def main() -> int:
    if not MANIFEST_PATH.is_file():
        print(f"Integrity manifest missing: {MANIFEST_PATH}", file=sys.stderr)
        return 2
    manifest = json.loads(MANIFEST_PATH.read_text(encoding='utf-8'))
    if manifest.get('algorithm') != 'SHA-256':
        print('Unsupported checksum algorithm.', file=sys.stderr)
        return 2

    failures: list[str] = []
    mesh_count = vertex_count = face_count = 0
    entries = manifest.get('assets', [])
    expected = {entry['path']: entry for entry in entries}
    actual = sorted(path.relative_to(ROOT).as_posix() for path in (ROOT / 'public' / 'assets').rglob('*.glb'))

    if len(actual) != manifest.get('assetCount') or set(actual) != set(expected):
        failures.append('GLB file inventory differs from {MANIFEST_PATH.relative_to(ROOT).as_posix()}')

    for relative in actual:
        path = ROOT / relative
        entry = expected.get(relative)
        if entry is None:
            continue
        data = path.read_bytes()
        if len(data) != entry.get('bytes'):
            failures.append(f'{relative}: byte count mismatch')
        digest = hashlib.sha256(data).hexdigest()
        if digest != entry.get('sha256'):
            failures.append(f'{relative}: SHA-256 mismatch')
        try:
            scene = trimesh.load(path, force='scene', process=False)
            geometries = list(scene.geometry.values())
            if not geometries:
                raise ValueError('scene has no mesh geometry')
            for geometry in geometries:
                vertices = getattr(geometry, 'vertices', None)
                faces = getattr(geometry, 'faces', None)
                if vertices is None or len(vertices) == 0:
                    raise ValueError('mesh has no vertices')
                if faces is None or len(faces) == 0:
                    raise ValueError('mesh has no faces')
                if not np.isfinite(vertices).all():
                    raise ValueError('mesh contains non-finite vertices')
                vertex_count += len(vertices)
                face_count += len(faces)
            mesh_count += len(geometries)
        except Exception as exc:  # continue to report all bad assets
            failures.append(f'{relative}: geometry validation failed: {exc}')

    if failures:
        print('\n'.join(failures), file=sys.stderr)
        return 1

    print(
        f"Release asset verification passed: {len(actual)} GLBs, {mesh_count} mesh objects, "
        f"{vertex_count:,} vertices, {face_count:,} faces; hashes and geometry are valid."
    )
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
