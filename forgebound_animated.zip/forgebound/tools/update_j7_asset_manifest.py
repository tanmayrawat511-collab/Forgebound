#!/usr/bin/env python3
"""Rebuild the combined Phase J7 GLB SHA-256 inventory after asset generation."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSET_ROOT = ROOT / 'public' / 'assets'
OUTPUT = ROOT / 'release' / 'j7-asset-sha256.json'
EXPECTED_GLB_COUNT = 460


def main() -> int:
    files = sorted(ASSET_ROOT.rglob('*.glb'))
    if len(files) != EXPECTED_GLB_COUNT:
        raise SystemExit(
            f'Expected {EXPECTED_GLB_COUNT} GLB files for the J7 release inventory; found {len(files)}.'
        )
    assets = []
    for path in files:
        data = path.read_bytes()
        if not data.startswith(b'glTF'):
            raise SystemExit(f'Invalid GLB header: {path.relative_to(ROOT)}')
        assets.append({
            'path': path.relative_to(ROOT).as_posix(),
            'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
        })
    manifest = {
        'formatVersion': 1,
        'phase': 'J7',
        'algorithm': 'SHA-256',
        'assetCount': len(assets),
        'assets': assets,
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    print(f'Updated {OUTPUT.relative_to(ROOT)}: {len(assets)} GLBs hashed.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
