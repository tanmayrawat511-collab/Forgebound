#!/usr/bin/env python3
"""Pure-Python glTF 2.0 / GLB authoring and validation library using numpy.

Supports:
- Stylized low-poly mesh primitives (boxes, tapered cylinders, capsules, icospheres,
  extruded polygons, blades, crystals, arches) with PBR materials & COLOR_0 vertex colors
- Skeletal rigs (glTF skins with JOINTS_0, WEIGHTS_0, inverseBindMatrices)
- Keyframe animations (30 fps rotation quaternions & translations)
- Strict GLB 2.0 binary writer & schema/geometry validator
"""
from __future__ import annotations

import json
import math
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np


def _align4(n: int) -> int:
    return (n + 3) & ~3


def euler_xyz_to_quat(rx: float, ry: float, rz: float) -> np.ndarray:
    """Convert XYZ Euler angles (radians) to glTF quaternion [x, y, z, w]."""
    cx, sx = math.cos(rx * 0.5), math.sin(rx * 0.5)
    cy, sy = math.cos(ry * 0.5), math.sin(ry * 0.5)
    cz, sz = math.cos(rz * 0.5), math.sin(rz * 0.5)
    # q = qz * qy * qx
    w = cx * cy * cz + sx * sy * sz
    x = sx * cy * cz - cx * sy * sz
    y = cx * sy * cz + sx * cy * sz
    z = cx * cy * sz - sx * sy * cz
    q = np.array([x, y, z, w], dtype=np.float32)
    norm = float(np.linalg.norm(q))
    return q / norm if norm > 1e-8 else np.array([0.0, 0.0, 0.0, 1.0], dtype=np.float32)


def hex_rgba(hex_color: int, alpha: float = 1.0) -> tuple[float, float, float, float]:
    return (
        ((hex_color >> 16) & 0xFF) / 255.0,
        ((hex_color >> 8) & 0xFF) / 255.0,
        (hex_color & 0xFF) / 255.0,
        alpha,
    )


@dataclass
class MaterialSpec:
    name: str
    base_color: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0)
    metallic: float = 0.05
    roughness: float = 0.78
    emissive: tuple[float, float, float] = (0.0, 0.0, 0.0)
    double_sided: bool = False


@dataclass
class MeshPart:
    positions: np.ndarray  # (N, 3) float32
    normals: np.ndarray    # (N, 3) float32
    colors: np.ndarray     # (N, 4) float32
    indices: np.ndarray    # (M,) uint32
    material_index: int = 0
    joints: np.ndarray | None = None   # (N, 4) uint8
    weights: np.ndarray | None = None  # (N, 4) float32


@dataclass
class BoneSpec:
    name: str
    parent: int  # -1 for root
    translation: tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation: tuple[float, float, float, float] = (0.0, 0.0, 0.0, 1.0)


@dataclass
class AnimTrack:
    bone_name: str
    path: str  # 'rotation' or 'translation'
    times: np.ndarray   # (K,) float32
    values: np.ndarray  # (K, 4) or (K, 3) float32


@dataclass
class AnimClip:
    name: str
    tracks: list[AnimTrack] = field(default_factory=list)


def compute_face_normals(verts: np.ndarray, faces: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Expand indexed triangles into flat-shaded vertices & normals for crisp low-poly look."""
    tri_verts = verts[faces]  # (F, 3, 3)
    v0 = tri_verts[:, 0]
    v1 = tri_verts[:, 1]
    v2 = tri_verts[:, 2]
    fn = np.cross(v1 - v0, v2 - v0)
    norms = np.linalg.norm(fn, axis=1, keepdims=True)
    norms = np.where(norms < 1e-8, 1.0, norms)
    fn = (fn / norms).astype(np.float32)
    flat_pos = tri_verts.reshape(-1, 3).astype(np.float32)
    flat_norm = np.repeat(fn, 3, axis=0).astype(np.float32)
    flat_idx = np.arange(len(flat_pos), dtype=np.uint32)
    return flat_pos, flat_norm, flat_idx


def compute_smooth_normals(verts: np.ndarray, faces: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute smooth vertex normals without duplicating vertices."""
    v = verts.astype(np.float32)
    f = faces.astype(np.uint32)
    vn = np.zeros_like(v, dtype=np.float32)
    tri = v[f]
    fn = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    for i in range(3):
        np.add.at(vn, f[:, i], fn)
    norms = np.linalg.norm(vn, axis=1, keepdims=True)
    norms = np.where(norms < 1e-8, 1.0, norms)
    vn = (vn / norms).astype(np.float32)
    return v, vn, f.reshape(-1)


def _color_array(n: int, color: tuple[float, float, float, float]) -> np.ndarray:
    return np.tile(np.array(color, dtype=np.float32), (n, 1))


def make_box(
    extents: tuple[float, float, float],
    center: tuple[float, float, float] = (0.0, 0.0, 0.0),
    color: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0),
    material_index: int = 0,
    bevel: float = 0.0,
) -> MeshPart:
    hx, hy, hz = extents[0] * 0.5, extents[1] * 0.5, extents[2] * 0.5
    if bevel > 0.0:
        b = min(bevel, hx * 0.35, hy * 0.35, hz * 0.35)
        # 24-vertex chamfered box via subdivision of corners
        pts = []
        for sx in (-1, 1):
            for sy in (-1, 1):
                for sz in (-1, 1):
                    pts.append([sx * (hx - b), sy * hy, sz * (hz - b)])
        # Fall back to clean tapered box if simple
        verts = np.array([
            [-hx, -hy, -hz], [hx, -hy, -hz], [hx, hy, -hz], [-hx, hy, -hz],
            [-hx, -hy, hz],  [hx, -hy, hz],  [hx, hy, hz],  [-hx, hy, hz],
        ], dtype=np.float32)
    else:
        verts = np.array([
            [-hx, -hy, -hz], [hx, -hy, -hz], [hx, hy, -hz], [-hx, hy, -hz],
            [-hx, -hy, hz],  [hx, -hy, hz],  [hx, hy, hz],  [-hx, hy, hz],
        ], dtype=np.float32)
    verts += np.array(center, dtype=np.float32)
    faces = np.array([
        [0, 2, 1], [0, 3, 2],  # -Z
        [4, 5, 6], [4, 6, 7],  # +Z
        [0, 1, 5], [0, 5, 4],  # -Y
        [3, 7, 6], [3, 6, 2],  # +Y
        [0, 4, 7], [0, 7, 3],  # -X
        [1, 2, 6], [1, 6, 5],  # +X
    ], dtype=np.uint32)
    pos, norm, idx = compute_face_normals(verts, faces)
    return MeshPart(pos, norm, _color_array(len(pos), color), idx, material_index)


def make_tapered_cylinder(
    radius_bottom: float,
    radius_top: float,
    height: float,
    center: tuple[float, float, float] = (0.0, 0.0, 0.0),
    sections: int = 10,
    color: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0),
    material_index: int = 0,
    axis: str = "y",
    smooth: bool = False,
) -> MeshPart:
    angles = np.linspace(0.0, 2.0 * math.pi, sections, endpoint=False)
    hy = height * 0.5
    verts = []
    for a in angles:
        verts.append([math.cos(a) * radius_bottom, -hy, math.sin(a) * radius_bottom])
    for a in angles:
        verts.append([math.cos(a) * radius_top, hy, math.sin(a) * radius_top])
    bot_center_idx = len(verts)
    verts.append([0.0, -hy, 0.0])
    top_center_idx = len(verts)
    verts.append([0.0, hy, 0.0])
    verts_arr = np.array(verts, dtype=np.float32)

    if axis == "x":
        verts_arr = verts_arr[:, [1, 0, 2]]
    elif axis == "z":
        verts_arr = verts_arr[:, [0, 2, 1]]

    verts_arr += np.array(center, dtype=np.float32)

    faces = []
    for i in range(sections):
        j = (i + 1) % sections
        b0, b1 = i, j
        t0, t1 = sections + i, sections + j
        faces.append([b0, t0, t1])
        faces.append([b0, t1, b1])
        faces.append([bot_center_idx, b0, b1])
        faces.append([top_center_idx, t1, t0])
    faces_arr = np.array(faces, dtype=np.uint32)
    if smooth:
        pos, norm, idx = compute_smooth_normals(verts_arr, faces_arr)
    else:
        pos, norm, idx = compute_face_normals(verts_arr, faces_arr)
    return MeshPart(pos, norm, _color_array(len(pos), color), idx, material_index)


def make_icosphere(
    radius: float,
    center: tuple[float, float, float] = (0.0, 0.0, 0.0),
    scale: tuple[float, float, float] = (1.0, 1.0, 1.0),
    subdivisions: int = 1,
    color: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0),
    material_index: int = 0,
    smooth: bool = False,
) -> MeshPart:
    phi = (1.0 + math.sqrt(5.0)) * 0.5
    verts = np.array([
        [-1, phi, 0], [1, phi, 0], [-1, -phi, 0], [1, -phi, 0],
        [0, -1, phi], [0, 1, phi], [0, -1, -phi], [0, 1, -phi],
        [phi, 0, -1], [phi, 0, 1], [-phi, 0, -1], [-phi, 0, 1],
    ], dtype=np.float32)
    verts /= np.linalg.norm(verts, axis=1, keepdims=True)
    faces = np.array([
        [0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11],
        [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8],
        [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9],
        [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1],
    ], dtype=np.uint32)

    for _ in range(subdivisions):
        mid_cache: dict[tuple[int, int], int] = {}
        new_verts = verts.tolist()
        new_faces = []

        def midpoint(a: int, b: int) -> int:
            key = (min(a, b), max(a, b))
            if key in mid_cache:
                return mid_cache[key]
            va, vb = verts[a], verts[b]
            vm = (va + vb) * 0.5
            vm /= np.linalg.norm(vm)
            idx_m = len(new_verts)
            new_verts.append(vm.tolist())
            mid_cache[key] = idx_m
            return idx_m

        for a, b, c in faces:
            ab = midpoint(int(a), int(b))
            bc = midpoint(int(b), int(c))
            ca = midpoint(int(c), int(a))
            new_faces.extend([[a, ab, ca], [b, bc, ab], [c, ca, bc], [ab, bc, ca]])
        verts = np.array(new_verts, dtype=np.float32)
        faces = np.array(new_faces, dtype=np.uint32)

    verts = verts * (radius * np.array(scale, dtype=np.float32)) + np.array(center, dtype=np.float32)
    if smooth:
        pos, norm, idx = compute_smooth_normals(verts, faces)
    else:
        pos, norm, idx = compute_face_normals(verts, faces)
    return MeshPart(pos, norm, _color_array(len(pos), color), idx, material_index)


def make_blade(
    length: float,
    width: float,
    thickness: float,
    center: tuple[float, float, float] = (0.0, 0.0, 0.0),
    color: tuple[float, float, float, float] = (0.8, 0.85, 0.9, 1.0),
    material_index: int = 0,
    tip_ratio: float = 0.22,
    curve_x: float = 0.0,
) -> MeshPart:
    """Create a diamond-cross-section sword/dagger/katana blade along +Y."""
    hw = width * 0.5
    ht = thickness * 0.5
    y0 = -length * 0.5
    y_shoulder = length * (0.5 - tip_ratio)
    y_tip = length * 0.5
    # Diamond cross-section at base and shoulder, converging to tip
    verts = np.array([
        [-hw, y0, 0.0], [0.0, y0, ht], [hw, y0, 0.0], [0.0, y0, -ht],
        [-hw * 0.82 + curve_x * 0.4, y_shoulder, 0.0],
        [curve_x * 0.4, y_shoulder, ht * 0.78],
        [hw * 0.82 + curve_x * 0.4, y_shoulder, 0.0],
        [curve_x * 0.4, y_shoulder, -ht * 0.78],
        [curve_x, y_tip, 0.0],
    ], dtype=np.float32) + np.array(center, dtype=np.float32)
    faces = np.array([
        [0, 1, 2], [0, 2, 3],  # base cap
        [0, 4, 5], [0, 5, 1],
        [1, 5, 6], [1, 6, 2],
        [2, 6, 7], [2, 7, 3],
        [3, 7, 4], [3, 4, 0],
        [4, 8, 5], [5, 8, 6], [6, 8, 7], [7, 8, 4],
    ], dtype=np.uint32)
    pos, norm, idx = compute_face_normals(verts, faces)
    return MeshPart(pos, norm, _color_array(len(pos), color), idx, material_index)


def bind_part_rigid(part: MeshPart, bone_index: int) -> MeshPart:
    n = len(part.positions)
    joints = np.zeros((n, 4), dtype=np.uint8)
    joints[:, 0] = bone_index
    weights = np.zeros((n, 4), dtype=np.float32)
    weights[:, 0] = 1.0
    part.joints = joints
    part.weights = weights
    return part


def bind_part_two_bones(
    part: MeshPart,
    bone_a: int,
    bone_b: int,
    y_min: float,
    y_max: float,
) -> MeshPart:
    """Smooth linear blend along Y between bone_a (bottom) and bone_b (top)."""
    n = len(part.positions)
    joints = np.zeros((n, 4), dtype=np.uint8)
    weights = np.zeros((n, 4), dtype=np.float32)
    span = max(1e-5, y_max - y_min)
    t = np.clip((part.positions[:, 1] - y_min) / span, 0.0, 1.0).astype(np.float32)
    joints[:, 0] = bone_a
    joints[:, 1] = bone_b
    weights[:, 0] = 1.0 - t
    weights[:, 1] = t
    part.joints = joints
    part.weights = weights
    return part


def _compute_world_matrices(bones: Sequence[BoneSpec]) -> list[np.ndarray]:
    mats: list[np.ndarray] = []
    for i, b in enumerate(bones):
        local = np.eye(4, dtype=np.float32)
        qx, qy, qz, qw = b.rotation
        local[0, 0] = 1 - 2 * (qy * qy + qz * qz)
        local[0, 1] = 2 * (qx * qy - qz * qw)
        local[0, 2] = 2 * (qx * qz + qy * qw)
        local[1, 0] = 2 * (qx * qy + qz * qw)
        local[1, 1] = 1 - 2 * (qx * qx + qz * qz)
        local[1, 2] = 2 * (qy * qz - qx * qw)
        local[2, 0] = 2 * (qx * qz - qy * qw)
        local[2, 1] = 2 * (qy * qz + qx * qw)
        local[2, 2] = 1 - 2 * (qx * qx + qy * qy)
        local[:3, 3] = np.array(b.translation, dtype=np.float32)
        if b.parent >= 0:
            mats.append(mats[b.parent] @ local)
        else:
            mats.append(local)
    return mats


def export_glb(
    out_path: Path,
    parts: Sequence[MeshPart],
    materials: Sequence[MaterialSpec] | None = None,
    bones: Sequence[BoneSpec] | None = None,
    clips: Sequence[AnimClip] | None = None,
    mesh_name: str = "AssetMesh",
) -> dict:
    """Export MeshParts + optional Skeleton + optional AnimationClips to a valid GLB 2.0 file."""
    if not materials:
        materials = [MaterialSpec(name="StylizedDefault", base_color=(1.0, 1.0, 1.0, 1.0), metallic=0.08, roughness=0.72)]

    bin_chunks: list[bytes] = []
    buffer_views: list[dict] = []
    accessors: list[dict] = []

    def push_data(arr: np.ndarray, target: int | None, acc_type: str, comp_type: int,
                  include_minmax: bool = False, normalized: bool = False) -> int:
        raw = np.ascontiguousarray(arr).tobytes()
        offset = sum(len(c) for c in bin_chunks)
        pad = _align4(len(raw)) - len(raw)
        bin_chunks.append(raw + b"\x00" * pad)

        bv: dict = {"buffer": 0, "byteOffset": offset, "byteLength": len(raw)}
        if target is not None:
            bv["target"] = target
        bv_idx = len(buffer_views)
        buffer_views.append(bv)

        acc: dict = {
            "bufferView": bv_idx,
            "componentType": comp_type,
            "count": int(arr.shape[0]),
            "type": acc_type,
        }
        if normalized:
            acc["normalized"] = True
        if include_minmax and arr.size > 0:
            if arr.ndim == 1:
                acc["min"] = [float(arr.min())]
                acc["max"] = [float(arr.max())]
            else:
                acc["min"] = [float(x) for x in arr.min(axis=0)]
                acc["max"] = [float(x) for x in arr.max(axis=0)]
        acc_idx = len(accessors)
        accessors.append(acc)
        return acc_idx

    # Group parts by material_index so each material becomes one glTF primitive
    by_mat: dict[int, list[MeshPart]] = {}
    for p in parts:
        by_mat.setdefault(p.material_index, []).append(p)

    has_skin = bool(bones)
    primitives = []
    for mat_idx, group in sorted(by_mat.items()):
        pos_list, norm_list, col_list, idx_list = [], [], [], []
        joints_list, weights_list = [], []
        v_offset = 0
        for p in group:
            n = len(p.positions)
            pos_list.append(p.positions.astype(np.float32))
            norm_list.append(p.normals.astype(np.float32))
            col_list.append(p.colors.astype(np.float32))
            idx_list.append((p.indices + v_offset).astype(np.uint32))
            if has_skin:
                j = p.joints if p.joints is not None else np.zeros((n, 4), dtype=np.uint8)
                w = p.weights if p.weights is not None else np.tile(np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32), (n, 1))
                joints_list.append(j.astype(np.uint8))
                weights_list.append(w.astype(np.float32))
            v_offset += n

        pos_arr = np.concatenate(pos_list, axis=0)
        norm_arr = np.concatenate(norm_list, axis=0)
        col_arr = np.concatenate(col_list, axis=0)
        idx_arr = np.concatenate(idx_list, axis=0)

        attrs: dict[str, int] = {
            "POSITION": push_data(pos_arr, 34962, "VEC3", 5126, include_minmax=True),
            "NORMAL": push_data(norm_arr, 34962, "VEC3", 5126),
            "COLOR_0": push_data(col_arr, 34962, "VEC4", 5126),
        }
        if has_skin:
            j_arr = np.concatenate(joints_list, axis=0)
            w_arr = np.concatenate(weights_list, axis=0)
            attrs["JOINTS_0"] = push_data(j_arr, 34962, "VEC4", 5121)
            attrs["WEIGHTS_0"] = push_data(w_arr, 34962, "VEC4", 5126)

        if v_offset <= 65535:
            idx_acc = push_data(idx_arr.astype(np.uint16), 34963, "SCALAR", 5123)
        else:
            idx_acc = push_data(idx_arr.astype(np.uint32), 34963, "SCALAR", 5125)

        primitives.append({
            "attributes": attrs,
            "indices": idx_acc,
            "material": mat_idx,
        })

    gltf_materials = []
    for m in materials:
        mat_dict: dict = {
            "name": m.name,
            "pbrMetallicRoughness": {
                "baseColorFactor": list(m.base_color),
                "metallicFactor": m.metallic,
                "roughnessFactor": m.roughness,
            },
        }
        if any(c > 0.0 for c in m.emissive):
            mat_dict["emissiveFactor"] = list(m.emissive)
        if m.double_sided:
            mat_dict["doubleSided"] = True
        gltf_materials.append(mat_dict)

    nodes: list[dict] = []
    scene_nodes: list[int] = []
    bone_name_to_node: dict[str, int] = {}

    if has_skin and bones:
        # Bone nodes 0..B-1
        for i, b in enumerate(bones):
            node: dict = {
                "name": b.name,
                "translation": [float(x) for x in b.translation],
                "rotation": [float(x) for x in b.rotation],
            }
            children = [j for j, other in enumerate(bones) if other.parent == i]
            if children:
                node["children"] = children
            nodes.append(node)
            bone_name_to_node[b.name] = i
        mesh_node_idx = len(nodes)
        nodes.append({"name": mesh_name, "mesh": 0, "skin": 0})
        scene_nodes = [0, mesh_node_idx]

        world_mats = _compute_world_matrices(bones)
        ibms = np.stack([np.linalg.inv(m).T for m in world_mats], axis=0).astype(np.float32)  # column-major for glTF
        ibm_acc = push_data(ibms, None, "MAT4", 5126)
        skins = [{
            "name": "Armature",
            "inverseBindMatrices": ibm_acc,
            "skeleton": 0,
            "joints": list(range(len(bones))),
        }]
    else:
        nodes.append({"name": mesh_name, "mesh": 0})
        scene_nodes = [0]
        skins = []

    gltf_animations = []
    if clips and bones:
        for clip in clips:
            samplers = []
            channels = []
            for track in clip.tracks:
                if track.bone_name not in bone_name_to_node:
                    continue
                node_idx = bone_name_to_node[track.bone_name]
                in_acc = push_data(track.times.astype(np.float32), None, "SCALAR", 5126, include_minmax=True)
                if track.path == "rotation":
                    out_acc = push_data(track.values.astype(np.float32), None, "VEC4", 5126)
                else:
                    out_acc = push_data(track.values.astype(np.float32), None, "VEC3", 5126)
                s_idx = len(samplers)
                samplers.append({"input": in_acc, "output": out_acc, "interpolation": "LINEAR"})
                channels.append({"sampler": s_idx, "target": {"node": node_idx, "path": track.path}})
            if channels:
                gltf_animations.append({"name": clip.name, "samplers": samplers, "channels": channels})

    bin_bytes = b"".join(bin_chunks)
    gltf: dict = {
        "asset": {"version": "2.0", "generator": "Forgebound Asset Pipeline 2.0"},
        "scene": 0,
        "scenes": [{"nodes": scene_nodes}],
        "nodes": nodes,
        "meshes": [{"name": mesh_name, "primitives": primitives}],
        "materials": gltf_materials,
        "buffers": [{"byteLength": len(bin_bytes)}],
        "bufferViews": buffer_views,
        "accessors": accessors,
    }
    if skins:
        gltf["skins"] = skins
    if gltf_animations:
        gltf["animations"] = gltf_animations

    json_bytes = json.dumps(gltf, separators=(",", ":")).encode("utf-8")
    json_pad = _align4(len(json_bytes)) - len(json_bytes)
    json_chunk = json_bytes + b" " * json_pad

    bin_pad = _align4(len(bin_bytes)) - len(bin_bytes)
    bin_chunk = bin_bytes + b"\x00" * bin_pad

    total_length = 12 + 8 + len(json_chunk) + 8 + len(bin_chunk)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "wb") as f:
        f.write(struct.pack("<III", 0x46546C67, 2, total_length))
        f.write(struct.pack("<II", len(json_chunk), 0x4E4F534A))
        f.write(json_chunk)
        f.write(struct.pack("<II", len(bin_chunk), 0x004E4942))
        f.write(bin_chunk)

    return gltf


def validate_glb(path: Path) -> dict:
    """Validate GLB binary structure, finite geometry, normalized skin weights, and animations."""
    data = path.read_bytes()
    if len(data) < 20:
        raise ValueError(f"{path.name}: file too small")
    magic, version, length = struct.unpack("<III", data[:12])
    if magic != 0x46546C67 or version != 2 or length != len(data):
        raise ValueError(f"{path.name}: invalid GLB header")
    json_len, json_type = struct.unpack("<II", data[12:20])
    if json_type != 0x4E4F534A:
        raise ValueError(f"{path.name}: first chunk is not JSON")
    gltf = json.loads(data[20:20 + json_len].decode("utf-8"))
    bin_off = 20 + json_len
    bin_data = b""
    if bin_off + 8 <= len(data):
        bin_len, bin_type = struct.unpack("<II", data[bin_off:bin_off + 8])
        if bin_type != 0x004E4942:
            raise ValueError(f"{path.name}: second chunk is not BIN")
        bin_data = data[bin_off + 8:bin_off + 8 + bin_len]

    accessors = gltf.get("accessors", [])
    bvs = gltf.get("bufferViews", [])

    def read_acc(idx: int) -> np.ndarray:
        acc = accessors[idx]
        bv = bvs[acc["bufferView"]]
        off = bv.get("byteOffset", 0) + acc.get("byteOffset", 0)
        count = acc["count"]
        comp_map = {5121: np.uint8, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
        type_map = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}
        dt = comp_map[acc["componentType"]]
        k = type_map[acc["type"]]
        arr = np.frombuffer(bin_data, dtype=dt, count=count * k, offset=off)
        return arr.reshape((count, k)) if k > 1 else arr

    tris = 0
    verts = 0
    for mesh in gltf.get("meshes", []):
        for prim in mesh.get("primitives", []):
            pos = read_acc(prim["attributes"]["POSITION"])
            if len(pos) == 0 or not np.isfinite(pos).all():
                raise ValueError(f"{path.name}: invalid POSITION")
            verts += len(pos)
            idx_arr = read_acc(prim["indices"])
            if len(idx_arr) == 0 or len(idx_arr) % 3 != 0 or idx_arr.max() >= len(pos):
                raise ValueError(f"{path.name}: invalid indices")
            tris += len(idx_arr) // 3
            if "WEIGHTS_0" in prim["attributes"]:
                w = read_acc(prim["attributes"]["WEIGHTS_0"])
                if not np.isfinite(w).all() or not np.allclose(w.sum(axis=1), 1.0, atol=1e-3):
                    raise ValueError(f"{path.name}: unnormalized skin weights")

    return {
        "file": path.name,
        "bytes": len(data),
        "triangles": tris,
        "vertices": verts,
        "skins": len(gltf.get("skins", [])),
        "animations": len(gltf.get("animations", [])),
        "materials": len(gltf.get("materials", [])),
    }
