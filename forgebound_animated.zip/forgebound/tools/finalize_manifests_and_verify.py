#!/usr/bin/env python3
"""Update model, animation, and SHA-256 manifests and verify every GLB in public/assets."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from glb_builder import validate_glb

ROOT = Path(__file__).resolve().parents[1]
ASSETS_DIR = ROOT / "public" / "assets"
MODELS_DIR = ASSETS_DIR / "models"


def update_manifests() -> None:
    # 1. model-manifest.json
    mm_path = ASSETS_DIR / "model-manifest.json"
    mm = json.loads(mm_path.read_text(encoding="utf-8"))
    for entry in mm.get("models", []):
        p = MODELS_DIR / entry["file"]
        if p.is_file():
            info = validate_glb(p)
            entry["bytes"] = info["bytes"]
            entry["triangles"] = info["triangles"]
            entry["skins"] = info["skins"]
            entry["animations"] = info["animations"]
            entry["source"] = "tools/remake_humanoids.py + remake_creatures.py + remake_gear_and_props.py"
    mm_path.write_text(json.dumps(mm, indent=2) + "\n", encoding="utf-8")

    # 2. j7-model-manifest.json
    jm_path = ASSETS_DIR / "j7-model-manifest.json"
    jm = json.loads(jm_path.read_text(encoding="utf-8"))
    for entry in jm.get("models", []):
        p = MODELS_DIR / entry["file"]
        if p.is_file():
            info = validate_glb(p)
            entry["bytes"] = info["bytes"]
            entry["triangles"] = info["triangles"]
            entry["skins"] = info["skins"]
            entry["animations"] = info["animations"]
    jm_path.write_text(json.dumps(jm, indent=2) + "\n", encoding="utf-8")

    # 3. animation-manifest.json
    am_path = ASSETS_DIR / "animation-manifest.json"
    am = json.loads(am_path.read_text(encoding="utf-8"))
    am["animationSource"] = "Skeletal glTF 2.0 animations (30 fps) embedded in GLB + shared /assets/animations/humanoid-clips.glb"
    am["sharedHumanoidClips"] = "/assets/animations/humanoid-clips.glb"
    clip_durations = {
        "idle": 2.0, "walk": 0.9, "run": 0.65, "jump": 0.7, "mine": 0.75,
        "attack": 0.5, "greet": 0.9, "wave": 1.1, "talk": 1.2, "trade-reaction": 0.9,
        "pet-dog": 1.2, "smelt": 1.0, "trade": 0.85, "refine-success": 1.1,
        "refine-failure": 1.0, "pickaxe-pickup": 0.9, "hand-over-item": 0.8,
        "receive-item": 0.8, "work-smith": 1.2, "pet-happy": 1.0, "sit": 1.5,
        "chase": 0.8, "hit-react": 0.35, "death": 0.7,
    }
    for entry in am.get("clips", []):
        cname = entry.get("clip")
        entry["source"] = "gltf-skeletal-30fps"
        if cname in clip_durations:
            entry["durationSeconds"] = clip_durations[cname]
    am_path.write_text(json.dumps(am, indent=2) + "\n", encoding="utf-8")

    # 4. release/j7-asset-sha256.json
    all_glbs = sorted(ASSETS_DIR.rglob("*.glb"))
    sha_entries = []
    total_tris = 0
    total_verts = 0
    skinned_count = 0
    anim_count = 0
    for p in all_glbs:
        rel = p.relative_to(ROOT).as_posix()
        data = p.read_bytes()
        info = validate_glb(p)
        total_tris += info["triangles"]
        total_verts += info["vertices"]
        if info["skins"] > 0:
            skinned_count += 1
        anim_count += info["animations"]
        sha_entries.append({
            "path": rel,
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        })

    sha_manifest = {
        "algorithm": "SHA-256",
        "assetCount": len(sha_entries),
        "assets": sha_entries,
    }
    (ROOT / "release" / "j7-asset-sha256.json").write_text(
        json.dumps(sha_manifest, indent=2) + "\n", encoding="utf-8"
    )
    print(
        f"Verified {len(all_glbs)} GLBs | {skinned_count} rigged/skinned | "
        f"{anim_count} embedded animation clips | {total_verts:,} vertices | {total_tris:,} triangles"
    )


if __name__ == "__main__":
    update_manifests()
