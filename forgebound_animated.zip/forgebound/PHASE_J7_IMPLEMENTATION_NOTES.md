# ForgeBound — Phase J7 implementation notes

**Status:** J7 implementation candidate assembled. Offline regressions and the combined GLB integrity/geometry validation pass. This is not yet a browser-tested release.

## What changed

### Population and interactions

- Added 25 uniquely named civilian definitions and 25 generated low-poly GLBs, split across the three existing zones (9 / 8 / 8). The runtime population activates at most six in the current zone, rotates a reserve roster, and despawns distant civilians with a delayed respawn policy.
- Added one world dog actor, active only in the Starter Quarry home zone. It wanders, can be petted within interaction range, and responds with a tail wag and a short happy bounce. Civilian greetings trigger player and NPC reaction cues.
- Added Ben as an additional tutorial NPC (23 NPC entities including Ben; the original 22 named NPC quest-giver records remain intact).

### Ben’s mandatory tutorial and pickaxe identity

The tutorial is a persisted, ordered state machine:

1. Move at least three metres.
2. Meet Ben and receive ten tutorial Copper Ore.
3. Smelt Copper Ore into Copper Ingots.
4. Trade ingots with the Blacksmith for one J7 gear item.
5. Refine that gear item.
6. Use a minimap control.
7. Find the lost pickaxe at Ben’s house, marked by a yellow cross in the world and minimap.
8. Return the original pickaxe to Ben.
9. Speak to Ben again and receive that same pickaxe instance back.

The pickaxe identity is `ben-lost-pickaxe-001` throughout world pickup, player custody, Ben’s custody, and the final inventory reward. No second pickaxe instance is created. Mining remains locked until the final handover. The mandatory tutorial blocks zone travel before completion. Tutorial instructions include an accessible `aria-live` subtitle line. Legacy J6 saves bypass the new tutorial and keep their pre-existing equipment.

### Gear, trading and refinement

- Added the 13 requested gear types: Daggers, Straight Sword, Mace, Gauntlet, Axe, Katana, Great Sword, Spear, Great Axe, Colossal Sword, Helmet, Chestplate and Leggings.
- Added Copper, Iron, Gold and Crystal material definitions and GLB models for every gear type. Blacksmith trades consume the selected material's ingots only; no Coins are charged for a trade.
- Added unique gear-instance inventory, weapon/armor equip slots, combat stat resolution, weapon model mounting and armor model mounting.
- Refinement advances each item instance through tiers I–V. A failed roll consumes all required ingots and Coins, leaves the gear instance and tier intact, and increments a persisted failure counter keyed by `instanceId:targetTier`. After three consecutive failures, the next attempt for that item and tier is guaranteed to succeed. Pity is independent per gear instance and target tier.

### Minimap and persistence

- Added a canvas minimap with north-locked orientation by default, an optional player-facing orientation, zoom controls, and icons for the player, civilians, dog, Ben, Blacksmith, Refiner and tutorial objective.
- Bumped the save schema from v5 to v6. The migration preserves old inventory/equipment, creates empty J7 gear/refinement state, initializes north-locked minimap settings, and marks migrated saves' tutorial complete so existing players are not forced through a new-game tutorial.

### Assets and manifests

- `tools/generate_j7_assets.py` generates 41 J7 GLBs: 25 civilians, one dog, Ben, Ben’s house and 13 gear models.
- `public/assets/j7-model-manifest.json` contains the generated model inventory.
- `public/assets/animation-manifest.json` contains 340 declared clip entries for the player, Ben, all 25 civilians, the 22 existing named NPCs, dog, gear and refinement workbench.
- The J7 model GLBs are lightweight static low-poly geometry. Their animation manifest entries currently declare **procedural runtime motion**, not embedded skeletal animation tracks. Player/NPC/civilian/dog movement and interaction cues are implemented as procedural transforms. A complete articulated character rig and authored skeletal animation clips remain an asset-production task; this limitation is not hidden by the manifest.
- `release/j7-asset-sha256.json` fingerprints all 460 project GLBs (the original 419 plus 41 J7 models). `tools/verify_release_assets.py` prefers this combined manifest when present. Regeneration commands also refresh the hash inventory.

## Initial balance values — tune after playtesting

These are implementation defaults, not previously approved final balance values:

- Material stat multipliers: Copper 1.00×, Iron 1.18×, Gold 1.38×, Crystal 1.62×.
- Refinement base success chances by target tier: 90%, 85%, 80%, 75%, 70%.
- Refinement stat bonus by tier: +5%, +10%, +15%, +20%, +25%.
- Blacksmith trade quantities: 2 ingots for Daggers/Gauntlet, 3 for other weapons, 4 for each armor piece.
- Refinement cost: `targetTier` ingots plus `25 × targetTier` Coins.

The Copper tutorial supplies are ten Copper Ore (five Copper Ingots), with the new game's existing 100 Coins used for the first refinement lesson.

## Verification performed

- `npm run test:offline` — passed all offline regression suites through J7.
- `npm run test:phase-j7` — passed J7 domain, save/migration, population, tutorial identity, pity and manifest checks.
- `npm run assets:verify` — passed all 460 GLBs: 1,532 mesh objects, 265,018 vertices and 489,242 faces; matching hashes and finite non-empty geometry.

## Remaining release gates

- A full `npm run typecheck` and `npm run build` could not be completed because npm dependency installation left empty/incomplete package directories for Three.js, Rapier, Vite and type declarations. The package-registry install attempt timed out in this environment.
- Run the Phase G renderer and Phase H GameApp runtime harnesses after dependencies are restored.
- Load all 460 GLBs through Three.js `GLTFLoader` in a browser and play through the complete new-game tutorial, every gear/armor slot, mining unlock, zone population swaps, refinement failures/pity, save/resume and legacy migration.
- Build articulated rigs and embedded skeletal clips for the player, 25 civilians, Ben and all existing named NPCs; connect those imported tracks to the animation manifest/controller.
- Review the provisional material multipliers, probabilities, recipes and costs after combat/economy playtesting.

## Commands

```bash
python -m pip install -r requirements-assets.txt
npm run assets:generate:j7
npm run test:phase-j7
npm run test:offline
npm run assets:verify
npm run typecheck
npm run build
npm run dev
```

`npm run assets:generate:all` regenerates the historical asset sets, J7 models and the combined J7 hash inventory.
