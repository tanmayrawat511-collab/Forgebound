# ForgeBound — Phase J5 progress report

## Status

**Implemented and regression-tested offline. Full browser/runtime QA remains pending.**

Phase J5 hardens camera/world interaction, makes Draw Distance a real streaming budget, reduces world-population render work, adds adaptive performance policy wiring, applies difficulty consistently to player and enemies, and checks the full-clear Coin budget. No claim of an in-browser FPS result or Rapier/Three.js runtime verification is made because the local packages are incomplete.

## Implemented changes

### Camera obstruction

- Added `src/render/cameraObstruction.ts` with a pure camera-distance policy.
- The third-person camera now raycasts visible nested objects rather than treating hidden meshes as obstructions.
- The ray checks active structural world props and loaded terrain chunk roots in the overworld, plus active interior meshes while inside a cave/ruin.
- Camera contraction is fast when an obstruction approaches; recovery to full distance is slower to reduce visible popping.
- Camera smoothing is disabled when the Animations setting is Off.

### Terrain streaming and draw distance

- Added `getTerrainChunkWindow` in `src/world/open-world-config.ts`; it returns a zone-bounded square of chunk coordinates.
- `WorldChunkStreamer` uses that shared window function to load the configured chunk radius.
- Draw Distance now changes both camera far plane/fog and the real terrain mesh + Rapier collider streaming budget:
  - Tiny: radius 0 (1 chunk at zone center)
  - Short: radius 1 (9 chunks at zone center)
  - Normal: radius 3 (49 chunks at zone center)
  - Far: radius 10 (all 121 chunks in the 11 × 11 zone grid)
- Edge windows are clipped against the 7 km² zone boundary. The streamer removes chunks outside the active radius after the replacement window has loaded, with no extra resident buffer ring, so the setting directly bounds active chunk/collider count.
- Terrain GLB/collider work uses a six-worker bounded async queue, avoiding 121 simultaneous Far-mode requests.
- Changing the distance invalidates in-flight loads; the next streamer update requests the new budget.

### Vegetation and environment culling

- Added `src/world/worldPopulationPolicy.ts` to partition deterministic placements into 768 m spatial cells.
- `WorldPopulation` now creates spatially-local InstancedMesh batches and computes per-batch bounds for frustum culling.
- Large structural props may participate in camera occlusion; ordinary vegetation is excluded from per-frame camera raycasts.

### Adaptive performance presets

- `AdaptiveResolution.reconfigure` now resets the scaler's active ratio, bounds, target frame time, cooldown and recovery timers when settings change.
- Performance presets set frame pacing and adaptive-resolution goals:
  - FPS: no explicit frame cap; 60 FPS adaptive-resolution target.
  - Balance: 45 FPS target.
  - Power Saver: 30 FPS target and reduced pixel-ratio cap.
- Low Graphics disables shadow maps and caps pixel ratio; High allows the device/quality tier cap.
- These are policy targets, not measured device performance guarantees.

### Difficulty profile

| Difficulty | Player damage | Enemy damage | Enemy health |
|---|---:|---:|---:|
| Piece o' Cake | 1.20× | 0.45× | 0.85× |
| Easy | 1.10× | 0.70× | 0.95× |
| Normal | 1.00× | 1.00× | 1.00× |
| Hard | 0.90× | 1.40× | 1.15× |

- Added `difficultyCombatProfile` as the shared combat tuning source.
- `CombatSystem` applies player damage scaling from weapon attacks.
- `Enemy` applies health scaling while preserving the current health percentage, and receives difficulty damage scaling.
- Normal remains the baseline. XP and loot rewards are unchanged by difficulty.

### Animation option audit

- The Animations setting now disables player/enemy cosmetic animation, mini-game animation, CSS animations/transitions throughout the game UI, and camera-follow smoothing.
- Loading-to-menu boot presentation transitions remain enabled because they are presentation flow rather than gameplay animation.
- Gameplay motion and physics remain active; the setting disables cosmetic motion, not player movement or game simulation.

### Coin economy check

The full-clear audit calculates all authored one-time Coin income against all registered equipment stock and all three weapon refinement fees. It counts quests, each mini-game's Gold-best payout (the reward ledger pays only tier improvements), dungeon discovery/POI/completion rewards, and one defeat reward for each of the three regional enemies. It excludes any repeat farming and does not count starting wallet Coins.

| Source / sink | Coins |
|---|---:|
| All quest rewards | 1,675 |
| Nine mini-games at Gold best tier | 331 |
| Seven dungeons: discovery, 21 POIs, completion | 724 |
| Three regional enemy defeat rewards | 74 |
| **Total one-time earnable Coins** | **2,804** |
| Five equipment stock items (after price tuning) | 2,570 |
| Three refinement ranks | 175 |
| **Full equipment + refinement cost** | **2,745** |
| **Full-clear balance margin** | **+59** |

- Reduced the Crystal Peaks Summit Tooth pickaxe price from 1,200 to 1,050 Coins.
- This means a full-clear run achieving Gold on all nine activities can afford all five listed equipment purchases and all three refinement fees, before considering its starting 100 Coins.
- This is a deterministic budget check, not a substitute for playtesting different player choices or lower mini-game medal outcomes.

### Regression coverage

Added `tests/phase-j5-polish.test.mjs` and the `npm run test:phase-j5` script. The main `npm test` chain now includes the J5 suite after J4.

The J5 suite checks:
- A bounded asynchronous work queue (at most six concurrent terrain GLB loads, including Far-zone startup).
- Camera obstruction nearest-hit, near clipping and interpolation policy.
- Draw-distance streaming radius, zone-bounded chunk windows and camera/fog distances.
- Performance preset/frame-rate/pixel-ratio policy and adaptive resolution reconfiguration.
- World-population partition conservation and cell boundaries.
- Difficulty combat profiles.
- Full-clear Coin affordability from the actual quest, mini-game, dungeon, enemy, shop and refinement definitions.
- Static runtime wiring for camera, settings and animation effects.

## Verification performed in this execution

Passed independently:
- Phase C, D, E, F, I deterministic suites.
- Phase J2 NPC/quest/commerce/refinement suite.
- Phase J3 mini-game/chess/reward suite.
- Phase J4 interior/exploration suite.
- New Phase J5 performance/polish/economy suite.

Additional checks:
- 78 non-declaration TypeScript source files transpiled with zero syntax diagnostics using globally available TypeScript 5.8.3.
- All 419 shipped GLB assets reopened with Python/trimesh: 419 valid files, 1,215 non-empty mesh objects, zero failures.
- Existing `index.html` ID audit remains part of prior J4 validation; no HTML structure change was required for J5.

## Blocked / not verified

- `npm run typecheck` cannot complete: the archive's local `node_modules/@types` contains empty/incomplete `stats.js`, `three` and `webxr` type folders, producing TS2688 errors.
- A full Vite production build cannot be verified while Vite, Three.js and Rapier packages are missing.
- Package registry access failed with `EAI_AGAIN registry.npmjs.org`; `npm ci` previously timed out.
- Actual camera collision response, Rapier terrain contact, adaptive FPS on reference hardware, and mobile/controller in-browser playthrough are not verified here.
- Economy values have deterministic budget coverage but still require human playtesting for pacing and perceived prices.

## Local verification commands

```bash
npm ci
npm run typecheck
npm run test:phase-j5
npm test
npm run build
npm run dev
```

Do not regenerate GLBs for J5; all 419 Python-generated GLB files were already validated and no new 3D models were required for this systems/performance pass.
