# Phase J4 — Cave, Ruin, and Exploration Interiors

## Content delivered

Seven authored interiors are available as separate, Python-generated GLB assets:

| Zone | Interior | Distinctive environment dressing | POIs |
|---|---|---|---:|
| Starter Quarry | The Forgotten Mine | Mine rails and ore cart | 3 |
| Starter Quarry | Old Stonewatch | Broken parapet and watch stairs | 3 |
| Molten Caves | Deep Ember Caverns | Basalt fins and glowing fissure | 3 |
| Molten Caves | The Forgotten Furnace | Furnace hearth, chimney and anvil | 3 |
| Crystal Peaks | Luminous Caverns | Perimeter crystal spire clusters | 3 |
| Crystal Peaks | The Ancient Observatory | Armillary rings, lunar telescope and star map | 3 |
| Crystal Peaks | The Summit Temple | Beacon altar and paired obelisks | 3 |

Each interior contains a connected entry hall, corridor, main chamber, and side alcove; a return arch; five baked-in sconce models; and three named, one-time points of interest.

## Spatial architecture

- The overworld remains 7,000,000 m² of playable terrain per zone.
- Each entrance is placed with a zone-local offset and validated inside that zone's square playable boundary.
- Interiors are isolated instances with unique origins outside all overworld coordinate ranges.
- `DungeonInteriorManager` lazily loads one GLB at a time and builds static Rapier trimesh colliders from the exact transformed mesh geometry.
- Entering an interior suspends/unloads streamed overworld terrain and hides zone actors/population. Exiting streams the saved return area first; on a failed load, the player remains inside instead of being stranded.
- Failed partial collider creation rolls back already-created bodies. Interior meshes/materials/textures and streamed terrain GLB resources are disposed at the appropriate lifecycle boundary.

## Exploration and rewards

- The Exploration Log lists all seven interiors and per-interior POI completion progress.
- First entry pays a one-time discovery reward.
- Each of three POIs pays XP, Coins, and optional resources once.
- The third POI additionally pays the interior completion reward.
- Reward transactions are validated before progress is marked claimed, avoiding progress-without-payout when inventory or wallet capacity blocks a reward.
- Exploration progress is stored in save schema v5. Migration from v4 preserves quests, mini-game medals, wallet, equipment, and progression, and initializes the new exploration ledger.

## Runtime controls

- Aim at an entrance and use the normal Interact action to enter.
- Inside an interior, aim at an unclaimed landmark and Interact to record it.
- Aim at the return arch and Interact to return to the overworld.
- Open **Exploration Log** from the adventure HUD to see discoveries and landmark completion.

## Asset generation

```bash
python tools/generate_dungeons.py
```

The script uses Python, `trimesh`, and `numpy`, exports each interior to GLB, reopens the bytes, and checks all generated meshes for non-empty finite geometry. Use `npm run assets:generate:all` to regenerate the complete project asset set, including the existing world/model/terrain GLBs and the new interiors.

## Verification and limits

`tests/phase-j4-exploration.test.mjs` validates the seven GLB files and their named POI/exit/landmark nodes, zone distribution, entrance bounds, isolated interior origins, one-time exploration progression, malformed save rejection, and v4-to-v5 migration. The deterministic domain test does not replace an actual rendered gameplay walkthrough.

The current execution environment has incomplete Three.js, Rapier, and Vite packages; `npm ci` timed out while trying to restore them. Consequently the full TypeScript application typecheck, Vite production build, browser rendering, Rapier collision feel, camera occlusion, and desktop/mobile in-game walkthrough remain unverified.
