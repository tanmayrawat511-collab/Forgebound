# Phase J5 — Performance and balance notes

## Camera and visibility

Third-person camera collision uses one visible-object ray query per camera update. Hidden subtrees are skipped. Overworld candidates include the active zone's selected structural props and the currently loaded terrain roots; dungeon camera candidates are the active interior meshes. Ordinary vegetation is not added to the camera-ray list.

Camera policy values:

- Maximum desired distance: 8.8 m
- Minimum obstruction distance: 0.85 m
- Obstruction padding: 0.28 m
- Contraction rate: 26/s
- Expansion rate: 5.5/s

The resolver chooses the nearest finite obstruction and clamps the resulting camera distance. Runtime visuals still require browser validation because the actual GLB raycast behaviour could not be exercised without the local Three.js package.

## Draw Distance and chunk budget

The 7 km² playable area for each zone remains unchanged. Draw Distance changes how much of the same approved playable terrain is resident in memory/collision around the player; it does not change the map boundary.

| Setting | Chunk radius | Center window | Camera far plane | Fog far |
|---|---:|---:|---:|---:|
| Tiny | 0 | 1 | 180 m | 160 m |
| Short | 1 | 9 | 520 m | 470 m |
| Normal | 3 | 49 | 1,300 m | 1,180 m |
| Far | 10 | 121 (full zone) | 4,200 m | 4,000 m |

The chunk window clips at the playable zone edge. Far uses radius 10, which covers the complete 11 × 11 terrain grid (121 chunks) from any player position. Chunks outside the newly loaded active window are unloaded after the replacement window is ready, so the selected setting directly bounds resident mesh/collider count. GLB loads are queued with a maximum of six concurrent requests/builds to avoid launching 121 fetches at once. The complete zone terrain GLBs total about 3.4 MB per zone before browser decoding and GPU/collider allocation.

## Performance presets

| Preset | Frame budget | Behaviour |
|---|---:|---|
| FPS | No explicit cap | Adaptive resolution targets a 60 FPS interval and can use the display's refresh rate. |
| Balance | 45 FPS | 22.22 ms frame pacing target. |
| Power Saver | 30 FPS | 33.33 ms target and lower pixel-ratio cap. |

These values are software policies. They do not guarantee that a particular device can sustain its target. Real reference-device measurements belong in the J6 release test.

## Graphics and culling

Low Graphics disables shadow maps and limits pixel ratio; High Graphics permits a higher device/quality cap. Instanced vegetation/props are grouped into 768 m spatial cells so their instance bounds can be culled more locally. Shared source GLB geometry/materials remain owned by the asset registry.

## Difficulty multipliers

| Difficulty | Player outgoing damage | Enemy outgoing damage | Enemy max health |
|---|---:|---:|---:|
| Piece o' Cake | 1.20× | 0.45× | 0.85× |
| Easy | 1.10× | 0.70× | 0.95× |
| Normal | 1.00× | 1.00× | 1.00× |
| Hard | 0.90× | 1.40× | 1.15× |

XP, Coins and item drop quantities are not multiplied by difficulty. This avoids difficulty selection becoming an economy multiplier.

## Coin economy — authored full-clear budget

The deterministic audit totals all 22 quest reward definitions, the Gold-best payout of all nine mini-games, all seven dungeon discovery/POI/completion rewards, and one defeat payout for each regional enemy. It excludes repeat farming and the initial wallet.

| Metric | Coins |
|---|---:|
| One-time content rewards | 2,804 |
| All five equipment stock entries | 2,570 |
| All three refinement fees | 175 |
| Surplus after buying all stock and refining all ranks | 59 |

To bring the perfect full-clear reward budget into positive territory, Summit Tooth was adjusted from 1,200 to 1,050 Coins. This is the one price change in J5. A player who does not achieve Gold on all activities may need to prioritize purchases; the 59-Coin margin is not intended to guarantee every purchase after Bronze outcomes.

## Options integrity

`GameApp.applySettings` is statically audited by the J5 test to ensure the visible controls have concrete consumers:

- Music and sound effects: `AudioManager.configure` and volume gates.
- Inverted camera and sensitivity: input settings update.
- FOV: camera projection update.
- Graphics: shadow-map/light state and renderer pixel ratio.
- Draw Distance: camera far plane, fog, and terrain streamer radius.
- Smooth Lighting: supported material shading state.
- Performance: frame pacing and adaptive-resolution limits.
- Inverted Colors: renderer canvas CSS filter.
- Screen Shake: camera feedback gate.
- GUI Scale: per-overlay zoom.
- Animations: character/enemy/mini-game motion, UI CSS animation/transition, and camera-follow smoothing; loading/menu boot transition is exempt.
- Brightness: renderer tone-mapping exposure.
- Keyboard/gamepad: active binding maps; touch layout: dedicated position/scale editor.

The audit guards against a toggle or slider existing in the UI without a code path that consumes it. Browser QA is still needed to confirm perceived effects visually and on actual input devices.
