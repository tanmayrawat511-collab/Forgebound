# Forgebound input devices: integration guide (Phase I)

This pass adds touch controls, DualSense (PS5) support, and a feedback layer (rumble and adaptive
triggers) to the browser build. Keyboard and mouse behaviour is unchanged. This document covers
what was built, how it plugs into the game loop, what platform each feature needs, what has not
been verified on real hardware, and the testing checklist.

## 1. Assumptions

- **Engine.** The project is a Vite, TypeScript, Three.js, and Rapier browser game. Input runs on
  web platform APIs (Pointer Events, the Gamepad API, WebHID). Unity, Godot, and Unreal do not apply.
- **DualSense in a browser.** The Gamepad API gives buttons, sticks, and basic rumble. Adaptive
  triggers are not in that API. They need WebHID, which exists only in Chromium browsers, only over
  USB in this build, and only in a secure context (https or localhost). Sony publishes no web SDK.
  The PlayStation SDK applies to native PS5 builds through Sony's developer program. That path needs a
  different engine port and is not covered here.
- **"Attack".** The game has no separate attack. Mining, calming creatures, using the forge, and
  entering gates all use the same interact action (E on keyboard). Touch ACT and the DualSense Cross
  and R2 triggers map to that action.
- **Pinch-to-zoom.** Not implemented. The camera has a fixed distance and the centre reticle needs a
  steady view. The game surface sets `touch-action: none`, which stops browser pinch and scroll.
- **Touchpad.** Optional and off by default. The browser's gamepad index for the touchpad click varies,
  so it is discovered on the target machine (section 6).
- **Explosions and environmental haptics.** The feedback API accepts `explosion` and the impact events,
  but the current game has no source for them. They are ready for when such events exist.

## 2. What was built

| Area | Files | Role |
|---|---|---|
| Device-neutral vocabulary | `src/input/actions.ts`, `src/input/settings.ts` | Edge sets, menu intents, validated settings |
| Router (single entry point) | `src/input/InputRouter.ts` | Merges keyboard, touch, and controller into the existing `InputSnapshot`; tracks the active input family |
| Keyboard and mouse | `src/input/InputManager.ts` (unchanged) | Original source, now wrapped by the router |
| Touch geometry | `src/input/touch/touchMath.ts` | Dead zones, stick vector, tap rule, per-pointer tracking |
| Touch layout | `src/input/touch/TouchLayout.ts` | Per-orientation placement, 44 px floor, clamping, validated storage |
| Touch overlay | `src/input/touch/TouchControls.ts` | Stick, ACT, JUMP, PACK, the layout panel, reposition and hide |
| DualSense mapping | `src/input/gamepad/dualsenseMapping.ts` | Buttons to actions, rising edges, menu gating, flicks |
| Controller polling | `src/input/gamepad/GamepadPoller.ts` | Gamepad API sampling, connection tracking by polling, rumble |
| WebHID codec | `src/input/gamepad/dualsenseHid.ts` | Output report encoding, input report decoding (pure, no device access) |
| WebHID transport | `src/input/gamepad/DualSenseHidTransport.ts` | Opens the device, sends deduplicated reports, reads input |
| Menu focus | `src/input/menu/MenuNavigator.ts` | D-pad and flick focus, Cross to press |
| Prompts | `src/input/prompts.ts` | Button names per family; keyboard strings unchanged |
| Feedback | `src/feedback/FeedbackSystem.ts`, `src/feedback/triggerProfiles.ts` | Named events to rumble envelopes and trigger profiles |
| Tests | `tests/phase-i-input.test.mjs` | Compiles the modules under strict flags; runs the pure logic and the router and touch wiring against fakes |
| Game wiring | `src/core/GameApp.ts`, `src/systems/MiningSystem.ts`, `index.html`, `src/styles/main.css` | Connects the above to the existing loop and HUD |

## 3. Integration into the game loop

`GameApp` owns one `InputRouter` and one `FeedbackSystem`. The loop calls them in this order each
rendered frame:

```ts
this.input.beginFrame(frameDelta);            // poll controller, advance per-frame state
const look = this.input.consumeLook();        // mouse + touch drag + right stick, in px
// ... apply look to the camera when no panel is open ...
const menuIntent = this.input.consumeMenuIntent();
if (panelOpen) this.menuNavigator.apply(menuIntent, panelElement);

// fixed-step loop, unchanged shape:
const sampled = this.input.snapshot(gameplayEnabled);   // InputSnapshot, as before

// after targeting has run:
this.feedback.setTriggerContext(this.buildTriggerContext());
this.feedback.update(frameDelta);
```

Gameplay events emit feedback where they happen, for example `this.feedback.emit('mine-hit')` in
`handleMiningAction`. Panels call `this.input.setMenuOpen(open)` when they open or close. That pauses
touch input and sends menu edges to the navigator instead of to the world. `dispose()` calls
`feedback.reset()` before `input.dispose()`.

Keyboard behaviour is preserved on purpose. Prompt strings for keyboard are the original strings, and
the existing Phase H runtime test checks one of them exactly.

### HTML and CSS hooks

- `#touch-layer` is the overlay that holds the touch controls. It starts hidden. A touch-first screen
  shows it at boot, and any other device shows it on first touch.
- `#game-shell[data-input="…"]` carries the active family (`keyboard`, `touch`, `dualsense`, or
  `gamepad`). CSS swaps the keyboard, touch, and pad variants of the control text on that attribute.
- `#enable-dualsense` and `#haptics-toggle` are footer buttons. They stay hidden until they apply.

## 4. Platform requirements

| Browser and platform | Touch | Gamepad API (buttons, sticks, rumble) | WebHID (adaptive triggers, output reports) |
|---|---|---|---|
| Chrome or Edge, desktop (Windows, macOS, Linux) | Touchscreens only | Yes, DualSense over USB or Bluetooth | Yes, USB, https or localhost, user gesture |
| Chrome on Android | Yes | Controller support varies by device | No |
| Firefox | Yes on touch devices | Yes, verify DualSense mapping per OS | No |
| Safari, macOS | Trackpad only | Verify | No |
| Safari, iPhone and iPad | Yes | Verify for PS5 controllers | No |

Verify each row on the target browser before relying on it. The table shows which API surface exists,
not which behaviour has been tested. Notes that apply everywhere:

- **Secure context.** Chromium restricts the Gamepad API and WebHID to https or localhost. `npm run dev`
  binds to `0.0.0.0`, so a phone reaching the dev server over the LAN gets `http://` and loses controller
  input and WebHID. Touch still works. To test controllers on another machine, use https (for example
  a Vite basic-SSL plugin) or a tunnel.
- **Bluetooth DualSense.** Rumble still goes through the Gamepad API where the browser supports it.
  Adaptive triggers and WebHID output are disabled over Bluetooth in this build. Bluetooth framing (report
  0x31) needs a CRC and is not implemented. The UI says so.
- **No PlayStation SDK dependency.** Nothing here imports Sony code.

## 5. DualSense hardware verification

The byte layouts in `dualsenseHid.ts` follow the open community documentation, from memory of that
documentation. They are not published by Sony and have not been checked against a controller in this
build. The Phase I suite verifies that the bytes are where the documentation says. It cannot verify that
a real controller reacts as intended. Before shipping, check each item below on hardware and correct the
constant in that file if it differs.

| Item | Where | How to check |
|---|---|---|
| Output flags (compatible vibration, trigger motor enable) | `FLAG_*` in `dualsenseHid.ts` | Trigger effects do nothing or behave oddly. Set R2 to resistance while aiming at ore, then compare with the trigger reading. |
| Trigger mode codes | `TRIGGER_MODE` | Resistance should appear in the ore context and a pulse in the creature context. If the feel is wrong, try the other codes. |
| Parameter scales (start 0 to 9, strength 0 to 8) | `TRIGGER_START_STEPS`, `TRIGGER_STRENGTH_STEPS` | Compare the resistance onset and firmness against the intended strength. |
| Motor byte order (weak at byte 3, strong at byte 4) | `encodeUsbOutputReport` | Send a frame with only `strongMotor` set, then only `weakMotor`, and feel which motor responds. Swap if reversed. |
| Input report offsets (sticks 1 to 4, R2 at 6, face and hat at 8, shoulders at 9, system at 10) | `decodeUsbInputReport` | Temporarily log decoded samples from `handleReport` while pressing each control. Centred sticks should decode near zero. |
| Touchpad click (bit 0x02 at byte 10) | `decodeUsbInputReport` | Press the touchpad while logging. |
| Touchpad through the Gamepad API | `touchpadButtonIndex` on `InputRouter` | Open the game with `?inputDebug=1`, press the touchpad, and read the index from the console. Pass it as the option. |
| Rumble strength and envelope | `RUMBLE_PATTERNS` | Play each event and judge by feel. Values were tuned by reasoning, not measured. |

## 6. Configuration you may want to change

- `PAD_LOOK_PX_PER_SECOND` (`InputRouter.ts`): right-stick look speed. Default 620.
- `STICK_DEADZONE` (`touchMath.ts`) and `PAD_STICK_DEADZONE` (`dualsenseMapping.ts`): dead zones.
- `TAP_MAX_DURATION_MS` and `TAP_MAX_TRAVEL_PX` (`touchMath.ts`): what counts as a tap on the world.
- `BASE_DIAMETER_PX` and `uiScaleFor` (`TouchLayout.ts`): control sizes. The 44 px floor is enforced in
  `diameterFor` and must not be removed.
- `RUMBLE_PATTERNS` (`FeedbackSystem.ts`) and `triggerProfileFor` (`triggerProfiles.ts`): feedback tuning.
- Player-adjustable settings (`settings.ts`): haptics on or off, intensity, trigger effects on or off,
  look sensitivity, invert look. Only the haptics toggle has an on-screen control so far. The rest are
  read from storage and can be given a settings panel later.

To add an action, extend `ActionEdges` in `actions.ts`, bind it in `dualsenseMapping.ts`, merge it in
`InputRouter.snapshot` or `consumeMenuIntent`, and add its label in `prompts.ts`.

## 7. Known limitations

- Adaptive triggers and WebHID output work only over USB in Chromium browsers, served over https or localhost.
- The touchpad needs its index discovered on each machine, or a WebHID session.
- Haptic and trigger strengths are tuned by reasoning and need a feel pass.
- Pinch-to-zoom and a camera zoom do not exist. They are not added here.
- Controller focus covers the satchel and forge panels. Keyboard and mouse use in those panels is unchanged.
  Recipe buttons can be rebuilt when inventory changes. If that happens, controller focus is lost and the
  navigator starts again from the first button.
- The Phase G and H suites need `three` and Rapier. They could not be run in the environment where this pass
  was built. Phase I runs without them.

## 8. Testing checklist

### Automated (run in order)

1. `npm install`
2. `npm run typecheck`
3. `npm test`: Phases C to F, G, H, and I. All must pass.
4. `npm run build`
5. `npm run preview`, then load the game and confirm the loading sequence completes.

### Keyboard and mouse regression (desktop, no controller, no touchscreen)

- WASD movement, Space jump, mouse orbit after clicking the world, Esc to release.
- E mines, calms, enters gates, and uses the forge. Prompts read exactly as before, for example
  `E — Mine Copper Ore` and `PACK OPEN · Press I or Esc to close`.
- I opens and closes the satchel. Movement and creature updates pause while a panel is open.
- Forge smelting and crafting, equip and unequip, save restore after reload, and Reset Save.
- The camera readout reads `CLICK TO LOOK` before capture and `MOUSE LOCKED` after.

### Touch: device sizes and orientations

Test each size in portrait and in landscape. Suggested devices and viewports:

| Class | Example viewport (CSS px) |
|---|---|
| Small phone | 320 × 568 |
| Standard phone | 375 × 667, 390 × 844, 393 × 852 |
| Large phone | 430 × 932 |
| Small Android | 360 × 740, 412 × 915 |
| Tablet | 768 × 1024, 1024 × 1366 |

For each size:

- All five controls (stick, ACT, JUMP, PACK, layout button) are fully on screen and at least 44 px.
- Controls do not cover the readout cards, the prompt, or the damage vignette in a way that blocks play.
- Rotating the device moves controls to the saved landscape or portrait position, still on screen.
- On a notched phone in landscape, nothing sits under the notch or the rounded corners.
- The keyboard controls card is hidden, and the touch hint appears in its place.
- Pinch and double-tap do not zoom or scroll the page while playing.

Touch behaviour to check on each device:

- Stick: move in all directions. A thumb released inside the dead zone stops movement at once.
- Look: drag on the world. Finger movement maps 1:1 to look at sensitivity 1. Judge whether that feels right.
- Tap the world: acts on the reticle target. A drag that starts on the world does not act.
- Multi-touch: thumb on the stick, second finger looking, third tap on ACT, all at the same time.
  A second thumb on the stick is ignored.
- Layout panel: open it, use Move controls to drag a control, press Done, reload, and confirm the
  position survived. Hide and show a control. Reset the layout.
- Menus: open the satchel and the forge. Touch controls disappear and the panel buttons respond.
  Closing the panel brings the controls back.
- Latency: compare with the keyboard. Look and movement should feel immediate, with no added delay.
  A high-speed camera on the screen gives a precise number if one is needed.

### DualSense (USB, Chrome or Edge on desktop, https or localhost)

- Connecting shows the notice. Prompts switch to Cross, Circle, and Triangle on first use.
- Left stick moves. Right stick looks. Idle drift is not visible on the camera.
- Cross and R2 mine and calm. Circle jumps. Triangle opens the satchel. Options closes panels.
- In a panel, D-pad or the left stick moves focus, Cross presses the focused button, and Circle goes back.
  Movement is frozen while the panel is open.
- R2 resistance appears while aiming at ore in range. It gets heavier while the pickaxe cooldown runs.
  A light pulse appears while aiming at a creature in range. All triggers go free in menus.
- Haptics: mining, a creature strike, calming, zone travel, and defeat each produce a distinct rumble.
  The Haptics toggle turns rumble and trigger effects off together, and the setting survives a reload.
- Touchpad: once its index is known, a click opens the satchel.
- Disconnect during play: a notice appears, movement stops, and keyboard still works. Reconnecting
  restores the controller.
- Enable DualSense triggers: the button appears, the device picker opens from the click, and the
  button changes to Triggers active.
- Bluetooth: the notice appears, rumble still works where the browser supports it, and triggers stay off.
- Revoke the device in browser settings, reload, and confirm the button returns.

### Browsers without WebHID (Firefox, Safari)

- The Enable DualSense triggers button stays hidden.
- Controller buttons, sticks, and rumble (where supported) still work.
- No console errors appear when the page loads with no controller attached.

### Failure and edge handling

- Storage blocked or full: touch layout and settings still work for the session.
- Corrupt `forgebound.touchLayout.v1` or `forgebound.input.v1` in storage: the game starts with defaults.
- Rapid panel toggling while touching the world: no stuck stick, look, or button after closing.
- Switching browser tabs while a button is held: no stuck input when the tab returns (the router clears
  state on blur).
