# ForgeBound — Phase J6 Release Validation Report

**Status: Release candidate assembled; final release approval blocked by missing runtime dependencies and browser playtesting.**

## Scope of this pass

- Re-opened and audited the Phase J5 project archive.
- Added a repeatable release-integrity suite (`tests/phase-j6-release.test.mjs`).
- Added GLB SHA-256 inventory (`release/asset-sha256.json`).
- Added a local geometry/hash validator (`tools/verify_release_assets.py`).
- Added pinned Python asset-verification dependencies (`requirements-assets.txt`).
- Added `test:phase-j6`, `assets:verify`, `test:offline`, and `verify:offline` package scripts.
- Preserved the existing npm dependency versions and lockfile.

## Verified results

### Automated regression suites

Passed independently:

- Phase C — crafting and equipment domain tests.
- Phase D — creature configuration, progression, loot and stack limits.
- Phase E — zone data and travel rules.
- Phase F — save/load validation, migration and local assets.
- Phase I — keyboard, controller, DualSense and mobile input.
- Phase J2 — NPCs, quests, commerce, refinement and migration.
- Phase J3 — nine mini-games, chess rules, rewards and migration.
- Phase J4 — seven interiors, 21 POIs and exploration state.
- Phase J5 — camera, streaming policy, culling, difficulty, options wiring and economy.
- Phase J6 — release manifest, source assets, GLB binary headers, SHA-256, save schema, UI ID and dependency-lock integrity.

The offline aggregate is available as `npm run test:offline`.

### Asset integrity

- 49 Python-generated gameplay models.
- 363 terrain GLBs: 121 tiles for each zone.
- The three terrain manifests each cover exactly 7,000,000 m² (7 km²), including correctly clipped outer tile dimensions.
- Seven Python-generated cave/ruin interiors.
- 21 registered interior points of interest.
- 419 total GLB files; no missing or unmanifested files.
- 419/419 GLB headers and byte lengths valid.
- 419/419 SHA-256 digests match.
- Trimesh validation: 1,215 mesh objects, 247,752 vertices, 455,978 faces, zero geometry failures.

Run `npm run assets:verify` to repeat checksum and geometry validation. It requires the Python packages in `requirements-assets.txt`.

### Source and interface checks

- 80 non-declaration TypeScript files transpiled with zero syntax diagnostics using globally available TypeScript 5.8.3.
- 129 HTML IDs audited; zero duplicates.
- Settings audit from Phase J5 verifies a concrete runtime consumer for every user-facing setting.
- Phase J6 confirms Animations is exposed and the superseded Advanced OpenGL setting is absent from the Options UI.
- Package dependency versions match the lockfile and remain exact-pinned.
- Save schema v5 has explicit load/migration handling for schemas 0 through 4; the phase-specific tests cover quest, mini-game and exploration migrations.

## Blocked checks — must be completed before release

### Dependency installation

`npm ci --fetch-retries=0 --fetch-timeout=20000` could not restore packages. The npm log records DNS failure `EAI_AGAIN registry.npmjs.org` followed by npm's `Exit handler never called!` error. The environment has no usable installed `three`, `@dimforge/rapier3d-compat`, `vite`, or project-local TypeScript packages.

### Full renderer/runtime/build tests

- Phase G render/interaction test: blocked because Three.js and Rapier modules are missing.
- Phase H `GameApp` runtime harness: blocked for the same missing modules.
- `npm run typecheck`: blocked by incomplete/missing type definitions (`stats.js`, `three`, `webxr`).
- `npm run build`: blocked at the TypeScript dependency/type-definition stage; Vite build has not run.
- Browser playthrough: not performed.

### Manual release QA still required

Test on agreed reference devices:

1. New Adventure, Continue and save/restore, including legacy-save migration.
2. Main and optional quests, NPC services and merchant transactions.
3. Every mini-game and its tier-upgrade reward behavior.
4. All three overworlds, their chunk boundaries and seven interiors, including collisions and return gates.
5. Keyboard, gamepad, DualSense and mobile touch layouts in portrait and landscape.
6. Every Options setting after changing it, reloading and restoring a save.
7. Loading failures, asset fallbacks, low-storage saves and interrupted zone transitions.
8. FPS, memory, load times and sustained play on desktop and mobile devices.

No measured FPS, memory, browser compatibility, or complete gameplay success is claimed in this report.

## Local verification

```bash
npm ci
npm run typecheck
npm test
npm run build
npm run assets:verify
npm run dev
```

Offline tests and asset validation that do not need npm-installed renderer modules:

```bash
npm run verify:offline
```

Install the pinned Python tools for asset validation:

```bash
python -m pip install -r requirements-assets.txt
```

## Release decision

**Do not label this archive as a final release yet.** It is a Phase J6 release-candidate package with source, manifests, integrity hashes and passing offline regression/asset checks. Final approval requires successful dependency restoration, full typecheck, Phase G/H tests, Vite production build, and device/browser playtesting.
