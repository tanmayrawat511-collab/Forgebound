import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

// Phase I: input devices. Compiles the input and feedback modules under the project's strict
// settings, then checks the pure logic directly and drives InputRouter and TouchControls against
// small fakes for the DOM, the Gamepad API, and WebHID. The fakes test wiring and state handling,
// not how a real browser or controller behaves; see docs/INPUT_INTEGRATION.md for that checklist.
const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outputDirectory = mkdtempSync(join(tmpdir(), 'forgebound-phase-i-'));

const SOURCES = [
  'src/input/InputRouter.ts',
  'src/input/InputManager.ts',
  'src/input/actions.ts',
  'src/input/settings.ts',
  'src/input/prompts.ts',
  'src/input/touch/touchMath.ts',
  'src/input/touch/TouchLayout.ts',
  'src/input/touch/TouchControls.ts',
  'src/input/gamepad/dualsenseMapping.ts',
  'src/input/gamepad/dualsenseHid.ts',
  'src/input/gamepad/GamepadPoller.ts',
  'src/input/gamepad/DualSenseHidTransport.ts',
  'src/input/menu/MenuNavigator.ts',
  'src/feedback/triggerProfiles.ts',
  'src/feedback/FeedbackSystem.ts',
];

// ----- Fake browser globals ------------------------------------------------------------------
// Node has no DOM, so the element and window stand-ins below implement only what the input
// modules call. Anything else throws, so a missing fake shows up as a clear failure.

class FakeElementBase {}
class FakeHTMLElement extends FakeElementBase {}
globalThis.Element = FakeElementBase;
globalThis.HTMLElement = FakeHTMLElement;

class FakeClassList {
  constructor() { this.names = new Set(); }
  add(...names) { names.forEach((name) => this.names.add(name)); }
  remove(...names) { names.forEach((name) => this.names.delete(name)); }
  toggle(name, force) {
    const on = force ?? !this.names.has(name);
    if (on) this.names.add(name); else this.names.delete(name);
    return on;
  }
  contains(name) { return this.names.has(name); }
}

class FakeElement extends FakeHTMLElement {
  constructor(tag = 'div') {
    super();
    this.tagNameLower = tag.toLowerCase();
    this.tagName = tag.toUpperCase();
    this.dataset = {};
    this.style = {};
    this.classList = new FakeClassList();
    this.attributes = {};
    this.children = [];
    this.parentElement = null;
    this.listeners = new Map();
    this.hidden = false;
    this.disabled = false;
    this.tabIndex = 0;
    this.textContent = '';
    this.className = '';
    this.clientWidth = 0;
    this.clientHeight = 0;
  }
  addEventListener(type, handler) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(handler);
  }
  removeEventListener(type, handler) {
    this.listeners.set(type, (this.listeners.get(type) ?? []).filter((fn) => fn !== handler));
  }
  dispatch(type, event = {}) {
    for (const fn of [...(this.listeners.get(type) ?? [])]) fn({ type, target: this, ...event });
  }
  click() { this.dispatch('click'); }
  append(...nodes) {
    for (const node of nodes) {
      node.parentElement = this;
      this.children.push(node);
    }
  }
  replaceChildren(...nodes) {
    for (const child of this.children) child.parentElement = null;
    this.children = [];
    this.append(...nodes);
  }
  closest(selector) {
    if (selector !== '[data-touch-control]') throw new Error(`fake closest() does not support ${selector}`);
    let node = this;
    while (node) {
      if (node.dataset && node.dataset.touchControl !== undefined) return node;
      node = node.parentElement;
    }
    return null;
  }
  querySelectorAll(selector) {
    if (selector !== 'button:not([disabled]):not([hidden])') throw new Error(`fake querySelectorAll() does not support ${selector}`);
    const found = [];
    const walk = (node) => {
      for (const child of node.children) {
        if (child.tagNameLower === 'button' && !child.disabled && !child.hidden) found.push(child);
        walk(child);
      }
    };
    walk(this);
    return found;
  }
  setAttribute(name, value) { this.attributes[name] = String(value); }
  getAttribute(name) { return this.attributes[name] ?? null; }
  getBoundingClientRect() {
    return { left: 0, top: 0, width: this.clientWidth, height: this.clientHeight };
  }
  focus() { fakeDocument.activeElement = this; }
  blur() { if (fakeDocument.activeElement === this) fakeDocument.activeElement = null; }
}

const fakeDocument = {
  activeElement: null,
  pointerLockElement: null,
  createElement: (tag) => new FakeElement(tag),
  getElementById: () => null,
  addEventListener() {},
  removeEventListener() {},
  exitPointerLock() {},
};
globalThis.document = fakeDocument;

function createWindow() {
  const listeners = new Map();
  return {
    innerWidth: 390,
    innerHeight: 844,
    location: { search: '' },
    matchMedia: () => ({ matches: false }),
    addEventListener(type, fn) {
      if (!listeners.has(type)) listeners.set(type, []);
      listeners.get(type).push(fn);
    },
    removeEventListener(type, fn) {
      listeners.set(type, (listeners.get(type) ?? []).filter((candidate) => candidate !== fn));
    },
    dispatch(type, event) {
      for (const fn of [...(listeners.get(type) ?? [])]) fn(event);
    },
  };
}

function createStorage() {
  const values = new Map();
  return {
    values,
    failWrites: false,
    getItem: (key) => (values.has(key) ? values.get(key) : null),
    setItem(key, value) {
      if (this.failWrites) throw new Error('quota exceeded');
      values.set(key, String(value));
    },
    removeItem: (key) => { values.delete(key); },
  };
}

const clock = { now: 0 };
performance.now = () => clock.now;

/** Resets window, navigator, storage, and clock. Each scenario starts from here. */
function setupEnvironment({ coarse = false, maxTouchPoints = 0 } = {}) {
  const win = createWindow();
  win.matchMedia = (query) => ({ matches: coarse && query.includes('coarse') });
  globalThis.window = win;
  globalThis.location = win.location;
  fakeDocument.activeElement = null;
  fakeDocument.pointerLockElement = null;
  const nav = {
    maxTouchPoints,
    pads: [],
    hid: undefined,
    getGamepads() { return this.pads; },
  };
  Object.defineProperty(globalThis, 'navigator', { value: nav, configurable: true, writable: true });
  clock.now = 0;
  return { win, nav, storage: createStorage() };
}

function makePad({ index = 0, id = 'Sony Interactive Entertainment DualSense Wireless Controller (STANDARD GAMEPAD Vendor: 054c Product: 0ce6)' } = {}) {
  return {
    index,
    id,
    mapping: 'standard',
    connected: true,
    buttons: Array.from({ length: 18 }, () => ({ pressed: false, value: 0 })),
    axes: [0, 0, 0, 0],
    vibrationActuator: {
      calls: [],
      resets: 0,
      playEffect(type, params) {
        this.calls.push({ type, params });
        return Promise.resolve('complete');
      },
      reset() {
        this.resets += 1;
        return Promise.resolve();
      },
    },
  };
}

const PAD_INDEX = { cross: 0, circle: 1, triangle: 3, options: 9, r1: 5, r2: 7, dpadUp: 12, dpadDown: 13 };

function setPad(pad, name, pressed) {
  const index = PAD_INDEX[name];
  if (index === undefined) throw new Error(`no index for ${name}`);
  pad.buttons[index] = { pressed, value: name === 'r2' ? (pressed ? 1 : 0) : (pressed ? 1 : 0) };
}

function makeHidDevice() {
  const listeners = [];
  return {
    vendorId: 0x054c,
    productId: 0x0ce6,
    productName: 'DualSense Wireless Controller',
    opened: false,
    sent: [],
    async open() { this.opened = true; },
    async close() { this.opened = false; },
    sendReport(reportId, data) {
      this.sent.push({ id: reportId, data: Uint8Array.from(data) });
      return Promise.resolve();
    },
    addEventListener(type, fn) { if (type === 'inputreport') listeners.push(fn); },
    removeEventListener(type, fn) {
      const index = listeners.indexOf(fn);
      if (index >= 0) listeners.splice(index, 1);
    },
    /** Delivers a wire report. `bytes[0]` is the report id, as the device sends it. */
    emit(bytes) {
      const payload = Uint8Array.from(bytes).slice(1);
      const data = new DataView(payload.buffer);
      for (const fn of [...listeners]) fn({ reportId: bytes[0], data });
    },
  };
}

function pointer(type, pointerId, x, y, timeStamp, target, pointerType = 'touch') {
  return { type, pointerId, pointerType, clientX: x, clientY: y, timeStamp, target, preventDefault() {} };
}

function keyDown(win, code) {
  win.dispatch('keydown', { code, repeat: false, target: null, preventDefault() {} });
}

function createLayer(width = 390, height = 844) {
  const layer = document.createElement('div');
  layer.clientWidth = width;
  layer.clientHeight = height;
  layer.hidden = true;
  return layer;
}

const controlOf = (layer, id) => layer.children.find((child) => child.dataset.touchControl === id);
const centreOf = (element) => ({
  x: parseFloat(element.style.left) + parseFloat(element.style.width) / 2,
  y: parseFloat(element.style.top) + parseFloat(element.style.height) / 2,
});
function findButton(container, text) {
  for (const child of container.children) {
    if (child.tagNameLower === 'button' && child.textContent === text) return child;
    const nested = findButton(child, text);
    if (nested) return nested;
  }
  return null;
}
const closeTo = (actual, expected, tolerance = 1e-6) => {
  assert.ok(Math.abs(actual - expected) <= tolerance, `expected ${actual} to be within ${tolerance} of ${expected}`);
};
const flush = () => new Promise((resolveFlush) => setImmediate(resolveFlush));

try {
  execFileSync(process.platform === 'win32' ? 'tsc.cmd' : 'tsc', [
    '--strict',
    '--target', 'ES2022',
    '--module', 'commonjs',
    '--moduleResolution', 'node',
    '--lib', 'ES2022,DOM,DOM.Iterable',
    '--skipLibCheck',
    '--noUnusedLocals',
    '--noUnusedParameters',
    '--noUncheckedIndexedAccess',
    '--noImplicitOverride',
    '--noFallthroughCasesInSwitch',
    '--typeRoots', outputDirectory,
    '--outDir', outputDirectory,
    ...SOURCES,
  ], { cwd: projectRoot, stdio: 'inherit', shell: process.platform === 'win32' });
  writeFileSync(join(outputDirectory, 'package.json'), '{"type":"commonjs"}');

  const require = createRequire(import.meta.url);
  const load = (name) => require(join(outputDirectory, name));
  const actions = load('input/actions.js');
  const settings = load('input/settings.js');
  const prompts = load('input/prompts.js');
  const touchMath = load('input/touch/touchMath.js');
  const layout = load('input/touch/TouchLayout.js');
  const mapping = load('input/gamepad/dualsenseMapping.js');
  const hid = load('input/gamepad/dualsenseHid.js');
  const poller = load('input/gamepad/GamepadPoller.js');
  const triggers = load('feedback/triggerProfiles.js');
  const feedback = load('feedback/FeedbackSystem.js');
  const { MenuNavigator } = load('input/menu/MenuNavigator.js');
  const { InputRouter } = load('input/InputRouter.js');

  // ----- 1. Touch geometry ----------------------------------------------------------------
  {
    const { stickVectorFromOffset, applyRadialDeadzone, isTap, GestureTracker, MIN_TOUCH_TARGET_PX } = touchMath;
    assert.equal(MIN_TOUCH_TARGET_PX, 44);

    closeTo(stickVectorFromOffset(30, 0, 60).x, 0.5);
    closeTo(stickVectorFromOffset(120, 0, 60).x, 1);
    const pinned = stickVectorFromOffset(60, 80, 50);
    closeTo(pinned.x, 0.6);
    closeTo(pinned.y, 0.8);
    closeTo(Math.hypot(pinned.x, pinned.y), 1);
    assert.deepEqual(stickVectorFromOffset(10, 10, 0), { x: 0, y: 0 });
    assert.deepEqual(stickVectorFromOffset(Number.NaN, 10, 50), { x: 0, y: 0 });

    assert.deepEqual(applyRadialDeadzone(0.1, 0, 0.14), { x: 0, y: 0 }, 'inside the dead zone is zero');
    closeTo(applyRadialDeadzone(1, 0, 0.14).x, 1, 1e-9);
    closeTo(applyRadialDeadzone(0.5, 0, 0.14).x, (0.5 - 0.14) / 0.86, 1e-9);
    closeTo(applyRadialDeadzone(2, 0, 0.14).x, 1, 1e-9);
    assert.deepEqual(applyRadialDeadzone(Number.NaN, 0, 0.14), { x: 0, y: 0 });

    assert.equal(isTap(100, 5), true);
    assert.equal(isTap(300, 5), false);
    assert.equal(isTap(100, 20), false);

    const tracker = new GestureTracker();
    assert.equal(tracker.begin(1, 'a', 0, 0, 0), true);
    assert.equal(tracker.begin(1, 'b', 0, 0, 0), false, 'a pointer id is tracked once');
    assert.deepEqual(tracker.move(1, 5, 0).dx, 5);
    tracker.move(1, 30, 0);
    assert.deepEqual(tracker.end(1, 50), { role: 'a', tap: false, durationMs: 50 }, 'a long drag is not a tap');
    tracker.begin(2, 'c', 0, 0, 0);
    tracker.move(2, 3, 4);
    assert.equal(tracker.end(2, 100).tap, true, 'a short still press is a tap');
    tracker.begin(3, 'd', 0, 0, 0);
    assert.equal(tracker.cancel(3), 'd');
    assert.equal(tracker.cancel(3), null);
    assert.equal(tracker.move(9, 1, 1), null, 'moves for untracked pointers are ignored');
    tracker.begin(4, 'e', 0, 0, 0);
    tracker.begin(5, 'f', 0, 0, 0);
    assert.deepEqual(tracker.clear(), ['e', 'f']);
    assert.equal(tracker.size, 0);
  }
  console.log('Phase I: touch geometry, deadzones, tap classification, and per-pointer tracking behave as specified.');

  // ----- 2. Touch layout: sizes, bounds, validation, persistence ------------------------------
  {
    assert.equal(layout.diameterFor('act', 1, 390), 86);
    assert.ok(layout.diameterFor('menu', 0.75, 320) >= 44, 'the 44 px floor holds at the smallest scale');

    const sizes = [[320, 568], [375, 667], [390, 844], [430, 932], [568, 320], [844, 390], [1024, 768]];
    for (const [width, height] of sizes) {
      for (const id of layout.TOUCH_CONTROL_IDS) {
        const placement = layout.defaultLayout()[layout.orientationOf(width, height)][id];
        const { cx, cy, diameter } = layout.placeControl(id, placement, { width, height });
        assert.ok(diameter >= 44, `${id} at ${width}x${height} is at least 44 px`);
        assert.ok(cx - diameter / 2 >= 0 && cx + diameter / 2 <= width, `${id} stays inside ${width} px wide`);
        assert.ok(cy - diameter / 2 >= 0 && cy + diameter / 2 <= height, `${id} stays inside ${height} px tall`);
      }
    }
    const extreme = layout.placeControl('act', { x: 0.99, y: 0.99, scale: 1.5, visible: true }, { width: 320, height: 568 });
    assert.ok(extreme.cx + extreme.diameter / 2 <= 320, 'an extreme placement is pulled back inside the area');

    const base = layout.defaultLayout();
    const moved = layout.movedLayout(base, 'portrait', 'act', 10, 10, { width: 390, height: 844 });
    closeTo(moved.portrait.act.x, 10 / 390);
    closeTo(moved.portrait.act.y, 10 / 844);
    assert.equal(moved.landscape, base.landscape, 'the other orientation is untouched');
    const clamped = layout.movedLayout(base, 'landscape', 'pack', -50, 9000, { width: 390, height: 844 });
    assert.deepEqual([clamped.landscape.pack.x, clamped.landscape.pack.y], [0, 1]);
    assert.equal(layout.withVisibility(base, 'portrait', 'jump', false).portrait.jump.visible, false);
    assert.equal(layout.withVisibility(base, 'portrait', 'jump', false).landscape.jump.visible, true);

    assert.deepEqual(layout.parseTouchLayout(null), layout.defaultLayout());
    const partial = layout.parseTouchLayout({
      portrait: { act: { x: 'bad', y: 0.5, scale: 1, visible: true }, jump: { x: 0.1, y: 0.1, scale: 9, visible: true } },
    });
    assert.deepEqual(partial.portrait.act, layout.defaultLayout().portrait.act, 'a bad field reverts that control only');
    assert.deepEqual(partial.portrait.jump, layout.defaultLayout().portrait.jump, 'an out-of-range scale reverts');
    assert.deepEqual(partial.landscape, layout.defaultLayout().landscape);

    const storage = createStorage();
    assert.deepEqual(layout.loadTouchLayout(storage), layout.defaultLayout(), 'empty storage yields defaults');
    layout.saveTouchLayout(storage, moved);
    assert.deepEqual(layout.loadTouchLayout(storage), moved, 'a saved layout round-trips');
    storage.setItem(layout.TOUCH_LAYOUT_KEY, JSON.stringify({ version: 99, layout: moved }));
    assert.deepEqual(layout.loadTouchLayout(storage), layout.defaultLayout(), 'an unknown version is ignored');
    storage.setItem(layout.TOUCH_LAYOUT_KEY, '{not json');
    assert.deepEqual(layout.loadTouchLayout(storage), layout.defaultLayout(), 'corrupt JSON is ignored');
    storage.failWrites = true;
    layout.saveTouchLayout(storage, moved);
    storage.failWrites = false;
    layout.clearTouchLayout(storage);
    assert.equal(storage.getItem(layout.TOUCH_LAYOUT_KEY), null);
  }
  console.log('Phase I: touch layout keeps every control at 44 px or more, inside the screen, through validated storage.');

  // ----- 3. Settings ------------------------------------------------------------------------
  {
    assert.deepEqual(settings.parseInputSettings(null), settings.DEFAULT_INPUT_SETTINGS);
    const parsed = settings.parseInputSettings({ hapticIntensity: 5, lookSensitivity: 9, hapticsEnabled: 'yes', invertLookY: true });
    assert.equal(parsed.hapticIntensity, settings.DEFAULT_INPUT_SETTINGS.hapticIntensity);
    assert.equal(parsed.lookSensitivity, settings.DEFAULT_INPUT_SETTINGS.lookSensitivity);
    assert.equal(parsed.hapticsEnabled, settings.DEFAULT_INPUT_SETTINGS.hapticsEnabled);
    assert.equal(parsed.invertLookY, true);

    const storage = createStorage();
    assert.deepEqual(settings.loadInputSettings(null), settings.DEFAULT_INPUT_SETTINGS);
    storage.setItem(settings.INPUT_SETTINGS_KEY, '{broken');
    assert.deepEqual(settings.loadInputSettings(storage), settings.DEFAULT_INPUT_SETTINGS);
    const custom = { ...settings.DEFAULT_INPUT_SETTINGS, hapticsEnabled: false, lookSensitivity: 1.5 };
    settings.saveInputSettings(storage, custom);
    assert.deepEqual(settings.loadInputSettings(storage), custom);
    storage.failWrites = true;
    settings.saveInputSettings(storage, custom);
  }
  console.log('Phase I: input settings fall back field by field and never throw on bad storage.');

  // ----- 4. DualSense mapping and edges -----------------------------------------------------
  const sampleOf = ({ pressed = [], trigger = 0, left = { x: 0, y: 0 }, right = { x: 0, y: 0 } } = {}) => {
    const buttons = { ...mapping.noButtons() };
    for (const name of pressed) buttons[name] = true;
    return { buttons, triggerRight: trigger, stickLeft: left, stickRight: right };
  };
  {
    assert.equal(mapping.identifyPad('054c-0ce6-Sony Interactive Entertainment DualSense Wireless Controller'), 'dualsense');
    assert.equal(mapping.identifyPad('Sony Interactive Entertainment DualSense Wireless Controller (STANDARD GAMEPAD Vendor: 054c Product: 0df2)'), 'dualsense');
    assert.equal(mapping.identifyPad('Xbox Wireless Controller (STANDARD GAMEPAD Vendor: 045e Product: 0b13)'), 'gamepad');

    let state = mapping.INITIAL_PAD_STATE;
    const press = (sample, menuOpen = false) => {
      const step = mapping.interpretPadSample(sample, state, menuOpen);
      state = step.state;
      return step;
    };

    let step = press(sampleOf({ pressed: ['cross'] }));
    assert.equal(step.edges.interact, true, 'Cross fires interact on the press');
    assert.equal(step.active, true);
    step = press(sampleOf({ pressed: ['cross'] }));
    assert.equal(step.edges.interact, false, 'a held button does not repeat');
    press(sampleOf());
    assert.equal(press(sampleOf({ pressed: ['cross'] })).edges.interact, true, 'a new press fires again');

    state = mapping.INITIAL_PAD_STATE;
    assert.equal(press(sampleOf({ trigger: 0.6 })).edges.interact, true, 'R2 past the threshold strikes');
    assert.equal(press(sampleOf({ trigger: 0.4 })).edges.interact, false, 'R2 stays down until released below 0.35');
    assert.equal(state.triggerDown, true);
    press(sampleOf({ trigger: 0.3 }));
    assert.equal(state.triggerDown, false);

    state = mapping.INITIAL_PAD_STATE;
    step = press(sampleOf({ pressed: ['cross'] }), true);
    assert.equal(step.edges.menuConfirm, true, 'in menus, Cross confirms');
    assert.equal(step.edges.interact, false, 'in menus, Cross does not act on the world');
    press(sampleOf(), true);
    step = press(sampleOf({ pressed: ['circle'] }), true);
    assert.equal(step.edges.escape, true, 'in menus, Circle goes back');
    assert.equal(step.edges.jump, false);
    press(sampleOf(), true);
    assert.equal(press(sampleOf({ pressed: ['dpadDown'] }), true).edges.menuDown, true);

    state = mapping.INITIAL_PAD_STATE;
    step = press(sampleOf({ pressed: ['circle'] }));
    assert.equal(step.edges.jump, true, 'in play, Circle jumps');
    assert.equal(step.edges.escape, false);
    press(sampleOf());
    assert.equal(press(sampleOf({ pressed: ['options'] })).edges.escape, true, 'Options escapes');
    press(sampleOf());
    assert.equal(press(sampleOf({ pressed: ['triangle'] })).edges.satchel, true, 'Triangle opens the satchel');
    press(sampleOf());
    assert.equal(press(sampleOf({ pressed: ['touchpad'] })).edges.satchel, true, 'the touchpad click opens the satchel');

    state = mapping.INITIAL_PAD_STATE;
    step = press(sampleOf({ left: { x: 0.1, y: 0.1 } }));
    assert.deepEqual(step.move, { x: 0, y: 0 }, 'a drift-sized stick reading is ignored');
    assert.equal(step.active, false);
    step = press(sampleOf({ left: { x: 1, y: 0 } }), true);
    assert.deepEqual(step.move, { x: 0, y: 0 }, 'movement is zero while a menu is open');
    assert.equal(step.edges.menuRight, true, 'a flick in a menu moves focus');
    step = press(sampleOf({ left: { x: 1, y: 0 } }), false);
    closeTo(step.move.x, 1, 1e-9);
    assert.equal(step.edges.menuRight, false, 'a held flick does not repeat');
  }
  console.log('Phase I: DualSense edges fire once per press, R2 has hysteresis, and menus take over Cross and Circle.');

  // ----- 5. HID codec ------------------------------------------------------------------------
  {
    const off = { motorLeft: 1, motorRight: 0, left: hid.TRIGGER_OFF, right: hid.TRIGGER_OFF };
    const report = hid.encodeUsbOutputReport(off);
    assert.equal(report.length, 48);
    assert.equal(report[0], 0x02, 'output report id');
    assert.equal(report[1], 0x0d, 'compatible vibration and both trigger motors enabled');
    assert.equal(report[3], 0);
    assert.equal(report[4], 255);
    assert.equal(report[11], 0, 'an off trigger writes the off mode');
    assert.equal(report[22], 0);

    const active = hid.encodeUsbOutputReport({
      motorLeft: 0,
      motorRight: 0.5,
      right: { kind: 'resistance', start: 0.5, strength: 1 },
      left: { kind: 'pulse', start: 1, strength: 0.25 },
    });
    assert.equal(active[3], 128);
    assert.equal(active[11], hid.TRIGGER_MODE.resistance, 'right trigger mode sits at byte 11');
    assert.equal(active[12], 5);
    assert.equal(active[13], 8);
    for (let index = 14; index < 22; index += 1) assert.equal(active[index], 0, 'unused parameters are zeroed');
    assert.equal(active[22], hid.TRIGGER_MODE.pulse, 'left trigger mode sits at byte 22');
    assert.equal(active[23], 9);
    assert.equal(active[24], 2);

    const clamped = hid.encodeUsbOutputReport({
      motorLeft: 2,
      motorRight: Number.NaN,
      left: hid.TRIGGER_OFF,
      right: { kind: 'resistance', start: -1, strength: 4 },
    });
    assert.equal(clamped[3], 0, 'NaN motor values become zero');
    assert.equal(clamped[4], 255, 'motor values are clamped to 255');
    assert.equal(clamped[12], 0);
    assert.equal(clamped[13], 8);

    const bytes = new Uint8Array(64);
    bytes[0] = 0x01;
    bytes[1] = 128; bytes[2] = 128; bytes[3] = 128; bytes[4] = 128;
    bytes[6] = 255;
    bytes[8] = 0x20;
    bytes[9] = 0x08 | 0x02;
    bytes[10] = 0x02;
    const decoded = hid.decodeUsbInputReport(bytes);
    assert.equal(decoded.buttons.cross, true);
    assert.equal(decoded.buttons.circle, false);
    assert.equal(decoded.buttons.dpadUp, true, 'hat 0 is north');
    assert.equal(decoded.buttons.dpadRight, false);
    assert.equal(decoded.buttons.r2, true);
    assert.equal(decoded.buttons.r1, true);
    assert.equal(decoded.buttons.touchpad, true);
    assert.equal(decoded.buttons.ps, false);
    closeTo(decoded.triggerRight, 1);
    assert.deepEqual(decoded.stickLeft, { x: 0, y: 0 }, 'centred sticks decode to zero');

    bytes[8] = 0x02;
    const east = hid.decodeUsbInputReport(bytes);
    assert.equal(east.buttons.dpadRight, true, 'hat 2 is east');
    assert.equal(east.buttons.dpadUp, false);
    assert.equal(east.buttons.cross, false);

    assert.equal(hid.decodeUsbInputReport(new Uint8Array(5)), null, 'short reports are rejected');
    bytes[0] = 0x31;
    assert.equal(hid.decodeUsbInputReport(bytes), null, 'Bluetooth framing is not decoded as USB');
    assert.equal(hid.detectTransport(0x01), 'usb');
    assert.equal(hid.detectTransport(0x31), 'bluetooth');
    assert.equal(hid.detectTransport(0x05), 'unknown');
  }
  console.log('Phase I: HID output placement matches the documented layout, and input decoding handles USB and Bluetooth framing.');

  // ----- 6. Trigger profiles and feedback ---------------------------------------------------
  {
    const base = triggers.NO_TRIGGER_CONTEXT;
    assert.deepEqual(triggers.triggerProfileFor({ ...base, suppressed: true, target: 'ore', inRange: true }).right, { kind: 'off' }, 'menus silence triggers');
    assert.deepEqual(triggers.triggerProfileFor({ ...base, target: 'ore', inRange: false }).right, { kind: 'off' }, 'out of range is free');
    assert.deepEqual(triggers.triggerProfileFor({ ...base, target: 'ore', inRange: true }).right, { kind: 'resistance', start: 0.3, strength: 0.55 });
    assert.deepEqual(triggers.triggerProfileFor({ ...base, target: 'ore', inRange: true, cooldownActive: true }).right, { kind: 'resistance', start: 0.1, strength: 0.9 }, 'cooldown makes the swing heavier');
    assert.deepEqual(triggers.triggerProfileFor({ ...base, target: 'creature', inRange: true }).right, { kind: 'pulse', start: 0.4, strength: 0.5 });
    assert.deepEqual(triggers.triggerProfileFor({ ...base, target: 'other', inRange: true }).right, { kind: 'off' }, 'forge and portal targets stay free');
  }
  {
    const frames = [];
    let current = { ...settings.DEFAULT_INPUT_SETTINGS };
    const system = new feedback.FeedbackSystem({ output: () => ({ apply: (frame) => frames.push(frame) }), settings: () => current });
    system.emit('player-hit');
    system.update(1 / 60);
    assert.equal(frames.length, 1);
    assert.ok(frames[0].strongMotor > 0.5, 'a hit starts strong');
    for (let index = 0; index < 20; index += 1) system.update(0.02);
    const strongs = frames.map((frame) => frame.strongMotor);
    for (let index = 1; index < strongs.length; index += 1) {
      assert.ok(strongs[index] <= strongs[index - 1], 'a decaying hit never gets stronger');
    }
    assert.equal(frames.at(-1).strongMotor, 0, 'the envelope ends silent');
    const settled = frames.length;
    system.update(0.02);
    system.update(0.02);
    assert.equal(frames.length, settled, 'a finished effect sends nothing more');

    const disabledFrames = [];
    const muted = new feedback.FeedbackSystem({
      output: () => ({ apply: (frame) => disabledFrames.push(frame) }),
      settings: () => ({ ...current, hapticsEnabled: false }),
    });
    muted.emit('mine-hit');
    muted.update(1 / 60);
    assert.equal(disabledFrames.length, 0, 'haptics switched off sends nothing');

    const masterFrames = [];
    const master = new feedback.FeedbackSystem({
      output: () => ({ apply: (frame) => masterFrames.push(frame) }),
      settings: () => ({ ...current, hapticsEnabled: false }),
    });
    master.setTriggerContext({ ...triggers.NO_TRIGGER_CONTEXT, target: 'ore', inRange: true });
    master.update(1 / 60);
    assert.equal(masterFrames.length, 0, 'with haptics off, no trigger effect is sent');
    assert.equal(master.currentFrame().right.kind, 'off', 'the haptics switch releases the triggers too');

    const scaledFrames = [];
    const softer = new feedback.FeedbackSystem({
      output: () => ({ apply: (frame) => scaledFrames.push(frame) }),
      settings: () => ({ ...current, hapticIntensity: 0.5 }),
    });
    softer.emit('mine-hit');
    softer.update(0.0001);
    closeTo(scaledFrames[0].weakMotor, 0.21, 1 / 64);

    const triggerFrames = [];
    const trigger = new feedback.FeedbackSystem({ output: () => ({ apply: (frame) => triggerFrames.push(frame) }), settings: () => current });
    trigger.setTriggerContext({ ...triggers.NO_TRIGGER_CONTEXT, target: 'ore', inRange: true });
    trigger.update(1 / 60);
    assert.equal(triggerFrames[0].right.kind, 'resistance');
    closeTo(triggerFrames[0].right.strength, 0.55, 1e-9);
    trigger.setTriggerContext({ ...triggers.NO_TRIGGER_CONTEXT, suppressed: true });
    trigger.update(1 / 60);
    assert.equal(triggerFrames.at(-1).right.kind, 'off', 'opening a menu releases the trigger');

    const holdFrames = [];
    const hold = new feedback.FeedbackSystem({ output: () => ({ apply: (frame) => holdFrames.push(frame) }), settings: () => current });
    hold.emit('pacify');
    hold.update(0.001);
    hold.update(0.03);
    hold.update(0.03);
    assert.equal(holdFrames.length, 1, 'an unchanged frame is not resent before the refresh interval');
    hold.update(0.03);
    assert.equal(holdFrames.length, 2, 'timed rumble is refreshed every 80 ms while it runs');

    const resetFrames = [];
    const resettable = new feedback.FeedbackSystem({ output: () => ({ apply: (frame) => resetFrames.push(frame) }), settings: () => current });
    resettable.emit('impact');
    resettable.update(0.001);
    resettable.reset();
    assert.deepEqual(resetFrames.at(-1), feedback.SILENT_FRAME, 'reset sends one silent frame');
    const afterReset = resetFrames.length;
    resettable.reset();
    assert.equal(resetFrames.length, afterReset, 'a second reset sends nothing');
  }
  console.log('Phase I: trigger profiles follow the targeting context, and haptic envelopes decay, refresh, scale, and stop cleanly.');

  // ----- 7. Prompts -------------------------------------------------------------------------
  {
    assert.equal(prompts.panelCloseHint('keyboard'), 'Press I or Esc to close', 'keyboard wording is the original string');
    assert.equal(prompts.inputLabel('keyboard', 'interact'), 'E');
    assert.equal(prompts.inputLabel('touch', 'interact'), 'ACT');
    assert.equal(prompts.inputLabel('dualsense', 'interact'), 'Cross');
    assert.equal(prompts.lookModeLabel('keyboard', false), 'CLICK TO LOOK');
    assert.equal(prompts.lookModeLabel('keyboard', true), 'MOUSE LOCKED');
    assert.equal(prompts.lookModeLabel('touch', false), 'TOUCH LOOK');
    assert.equal(actions.mergeEdges(actions.NO_EDGES, { ...actions.NO_EDGES, jump: true }).jump, true);
  }
  console.log('Phase I: prompt wording keeps the keyboard strings and names the controls on other devices.');

  // ----- 8. Panel focus navigation ----------------------------------------------------------
  {
    setupEnvironment();
    const navigator = new MenuNavigator();
    const panel = document.createElement('div');
    const button = (label, disabled = false) => {
      const element = document.createElement('button');
      element.textContent = label;
      element.disabled = disabled;
      return element;
    };
    const first = button('A');
    const skipped = button('B', true);
    const last = button('C');
    panel.append(first, skipped, last);
    const none = { up: false, down: false, left: false, right: false, confirm: false };
    navigator.apply({ ...none, down: true }, panel);
    assert.equal(fakeDocument.activeElement, first, 'the first press focuses the first enabled button');
    navigator.apply({ ...none, down: true }, panel);
    assert.equal(fakeDocument.activeElement, last, 'disabled buttons are skipped');
    navigator.apply({ ...none, down: true }, panel);
    assert.equal(fakeDocument.activeElement, first, 'focus wraps around');
    navigator.apply({ ...none, up: true }, panel);
    assert.equal(fakeDocument.activeElement, last, 'up moves backwards');
    let clicked = null;
    last.addEventListener('click', () => { clicked = 'C'; });
    navigator.apply({ ...none, confirm: true }, panel);
    assert.equal(clicked, 'C', 'confirm presses the focused button');
    navigator.apply({ ...none, down: true }, null);
  }
  console.log('Phase I: panel focus moves through enabled buttons, wraps, and confirms with the focused one.');

  // ----- 9. Gamepad sampling and polling ----------------------------------------------------
  {
    const pad = makePad();
    setPad(pad, 'cross', true);
    pad.buttons[7] = { pressed: false, value: 0.8 };
    pad.axes = [0.5, -0.5, 0, 1];
    const sample = poller.sampleFromGamepad(pad, null);
    assert.equal(sample.buttons.cross, true);
    closeTo(sample.triggerRight, 0.8);
    assert.deepEqual(sample.stickLeft, { x: 0.5, y: -0.5 });
    assert.deepEqual(sample.stickRight, { x: 0, y: 1 });
    assert.equal(sample.buttons.touchpad, false, 'the touchpad is off unless its index is configured');
    pad.buttons[17] = { pressed: true, value: 1 };
    assert.equal(poller.sampleFromGamepad(pad, 17).buttons.touchpad, true);

    const notices = [];
    let source = [pad];
    const gamepads = new poller.GamepadPoller({ source: () => source, touchpadButtonIndex: null, onNotice: (notice) => notices.push(notice) });
    let result = gamepads.poll(null, false);
    assert.deepEqual(notices, [{ kind: 'connected', family: 'dualsense' }]);
    assert.equal(result.family, 'dualsense');
    assert.equal(result.step.edges.interact, true, 'a button already down when the pad appears fires once');
    assert.equal(gamepads.poll(null, false).step.edges.interact, false);

    source = [];
    result = gamepads.poll(null, false);
    assert.deepEqual(notices.at(-1), { kind: 'disconnected', family: 'dualsense' });
    assert.equal(result.family, null);

    const hidSample = sampleOf({ pressed: ['cross'] });
    result = gamepads.poll(hidSample, false);
    assert.equal(result.family, 'dualsense', 'a WebHID sample is reported as DualSense');
    assert.equal(result.step.edges.interact, true);

    source = [pad];
    gamepads.poll(null, false);
    gamepads.rumble(0.5, 0.25);
    const call = pad.vibrationActuator.calls.at(-1);
    assert.equal(call.type, 'dual-rumble');
    assert.equal(call.params.strongMagnitude, 0.5);
    assert.equal(call.params.weakMagnitude, 0.25);
    gamepads.rumble(0, 0);
    assert.equal(pad.vibrationActuator.resets, 1, 'stopping rumble resets the actuator');
  }
  console.log('Phase I: standard-mapped pads sample correctly, connection changes are announced by polling, and rumble reaches the actuator.');

  // ----- 10. Router: keyboard path ----------------------------------------------------------
  const newRouter = (env, extra = {}) => {
    const canvas = document.createElement('canvas');
    const shell = document.createElement('div');
    const notes = [];
    const router = new InputRouter({
      canvas,
      shell,
      touchLayer: null,
      storage: env.storage,
      hidButton: null,
      hapticsButton: null,
      onNotice: (message) => notes.push(message),
      ...extra,
    });
    return { router, canvas, shell, notes };
  };
  {
    const env = setupEnvironment();
    const { router, shell } = newRouter(env);
    assert.equal(shell.dataset.input, 'keyboard', 'the shell starts in keyboard mode');
    keyDown(env.win, 'KeyD');
    keyDown(env.win, 'KeyE');
    router.beginFrame(1 / 60);
    const first = router.snapshot(true);
    assert.equal(first.moveX, 1);
    assert.equal(first.moveZ, 0);
    assert.equal(first.interactPressed, true);
    assert.equal(first.jumpPressed, false);
    assert.equal(router.snapshot(true).interactPressed, false, 'the key edge is consumed once');
    assert.equal(router.activeFamily, 'keyboard');
    assert.equal(router.lookLabel(), 'CLICK TO LOOK');
    keyDown(env.win, 'Space');
    assert.equal(router.snapshot(false).jumpPressed, false, 'gameplay gating still applies to the keyboard');
    router.dispose();
  }
  console.log('Phase I: the keyboard path produces the same snapshot as before, with edges consumed once.');

  // ----- 11. Router: controller path, menus, look, movement, disconnect -------------------------
  {
    const env = setupEnvironment();
    const pad = makePad();
    env.nav.pads = [pad];
    const { router, shell, notes } = newRouter(env);
    router.beginFrame(1 / 60);
    assert.ok(notes.some((note) => note.startsWith('DualSense connected')), 'connection is announced');
    assert.equal(router.activeFamily, 'keyboard', 'a connected pad does not change the prompts until it is used');
    setPad(pad, 'cross', true);
    router.beginFrame(1 / 60);
    assert.equal(router.activeFamily, 'dualsense');
    assert.equal(shell.dataset.input, 'dualsense');
    assert.equal(router.snapshot(true).interactPressed, true);
    assert.equal(router.lookLabel(), 'STICK LOOK');
    setPad(pad, 'cross', false);
    env.nav.pads = [];
    router.beginFrame(1 / 60);
    assert.ok(notes.some((note) => note.startsWith('Controller disconnected')), 'disconnection is announced');
    assert.equal(router.activeFamily, 'keyboard', 'losing the pad falls back to keyboard prompts');
    assert.equal(shell.dataset.input, 'keyboard');
    assert.equal(router.hapticOutput(), null, 'no rumble target without a controller');
    router.dispose();
  }
  {
    const env = setupEnvironment();
    const pad = makePad();
    env.nav.pads = [pad];
    const { router } = newRouter(env);
    router.setMenuOpen(true);
    setPad(pad, 'cross', true);
    router.beginFrame(1 / 60);
    assert.equal(router.consumeMenuIntent().confirm, true, 'Cross confirms in a menu');
    assert.equal(router.snapshot(false).interactPressed, false, 'Cross does not act on the world in a menu');
    setPad(pad, 'cross', false);
    setPad(pad, 'circle', true);
    router.beginFrame(1 / 60);
    const back = router.snapshot(false);
    assert.equal(back.escapePressed, true, 'Circle goes back in a menu');
    assert.equal(back.jumpPressed, false);
    router.setMenuOpen(false);
    router.dispose();
  }
  {
    const env = setupEnvironment();
    const pad = makePad();
    env.nav.pads = [pad];
    const { router } = newRouter(env);
    pad.axes[2] = 1;
    router.beginFrame(0.1);
    const first = router.consumeLook();
    closeTo(first.x, 62, 1e-6);
    closeTo(first.y, 0, 1e-6);
    pad.axes[2] = 0;
    router.updateSettings({ ...router.settings, lookSensitivity: 2, invertLookY: true });
    pad.axes[3] = -1;
    router.beginFrame(0.1);
    const second = router.consumeLook();
    closeTo(second.y, 124, 1e-6);
    pad.axes[3] = 0;

    pad.axes[0] = 0.8;
    router.beginFrame(1 / 60);
    closeTo(router.snapshot(true).moveX, (0.8 - 0.15) / 0.85, 1e-6);
    pad.axes[0] = 0;
    keyDown(env.win, 'KeyD');
    pad.axes[1] = 0.3;
    router.beginFrame(1 / 60);
    const combined = router.snapshot(true);
    assert.equal(combined.moveX, 1, 'the strongest source wins, so the total never exceeds one');
    assert.equal(combined.moveZ, 0);
    router.dispose();
  }
  {
    const env = setupEnvironment();
    const pad = makePad();
    env.nav.pads = [pad];
    const { router } = newRouter(env);
    router.beginFrame(1 / 60);
    const feedbackSystem = new feedback.FeedbackSystem({ output: () => router.hapticOutput(), settings: () => router.settings });
    feedbackSystem.emit('mine-hit');
    feedbackSystem.update(1 / 60);
    assert.ok(pad.vibrationActuator.calls.length >= 1, 'feedback reaches the controller through the router');
    assert.equal(pad.vibrationActuator.calls[0].type, 'dual-rumble');
    router.dispose();
  }
  console.log('Phase I: the controller path announces connections, respects menu gating, scales look, merges movement, and routes rumble.');

  // ----- 12. Router: WebHID path ------------------------------------------------------------
  {
    const env = setupEnvironment();
    const device = makeHidDevice();
    env.nav.hid = {
      getDevices: async () => [device],
      requestDevice: async () => [device],
      addEventListener() {},
      removeEventListener() {},
    };
    const { router, notes } = newRouter(env);
    await flush();
    assert.equal(device.opened, true, 'a previously granted DualSense reopens without a prompt');
    assert.notEqual(router.hapticOutput(), null, 'the HID link is a feedback output');

    const outputFrame = {
      strongMotor: 0.5,
      weakMotor: 0.25,
      left: { kind: 'off' },
      right: { kind: 'resistance', start: 0.3, strength: 0.55 },
    };
    router.hapticOutput().apply(outputFrame);
    assert.equal(device.sent.length, 1);
    assert.equal(device.sent[0].id, 2, 'output reports use id 2');
    assert.equal(device.sent[0].data.length, 47, 'WebHID takes the payload without the id byte');
    assert.equal(device.sent[0].data[0], 0x0d);
    assert.equal(device.sent[0].data[2], 64, 'the weak motor is byte 3 of the wire report');
    assert.equal(device.sent[0].data[3], 128, 'the strong motor is byte 4 of the wire report');
    assert.equal(device.sent[0].data[10], 0x01, 'the right trigger mode is byte 11 of the wire report');
    router.hapticOutput().apply(outputFrame);
    assert.equal(device.sent.length, 1, 'an unchanged frame is not sent again');

    const report = new Uint8Array(64);
    report[0] = 0x01;
    report[1] = 128; report[2] = 128; report[3] = 128; report[4] = 128;
    report[8] = 0x20;
    clock.now = 1000;
    device.emit(report);
    clock.now = 1010;
    router.beginFrame(1 / 60);
    assert.equal(router.activeFamily, 'dualsense', 'a HID report switches the prompts');
    assert.equal(router.snapshot(true).interactPressed, true, 'Cross from the HID report acts');

    const bluetooth = new Uint8Array(78);
    bluetooth[0] = 0x31;
    device.emit(bluetooth);
    assert.ok(notes.some((note) => note.startsWith('DualSense is on Bluetooth')), 'Bluetooth is reported, not silently ignored');
    assert.equal(router.hapticOutput(), null, 'adaptive output is off over Bluetooth');

    device.emit(report);
    const feedbackSystem = new feedback.FeedbackSystem({ output: () => router.hapticOutput(), settings: () => router.settings });
    feedbackSystem.setTriggerContext({ ...triggers.NO_TRIGGER_CONTEXT, target: 'ore', inRange: true, cooldownActive: true });
    feedbackSystem.update(1 / 60);
    const latest = device.sent.at(-1);
    assert.equal(latest.data[10], 0x01, 'the ore context reaches the right trigger');
    assert.equal(latest.data[11], 1, 'the cooldown start position is 0.1 of nine steps');
    assert.equal(latest.data[12], 7, 'the cooldown strength is 0.9 of eight steps');
    router.dispose();
    await flush();
  }
  console.log('Phase I: WebHID re-opens granted devices, sends deduplicated output reports, reads reports for input, and reports Bluetooth.');

  // ----- 13. Router: settings persistence and the haptics control ---------------------------
  {
    const env = setupEnvironment();
    const hapticsButton = document.createElement('button');
    const { router } = newRouter(env, { hapticsButton });
    hapticsButton.click();
    assert.equal(router.settings.hapticsEnabled, false);
    assert.equal(hapticsButton.textContent, 'Haptics: Off');
    router.dispose();
    const { router: reloaded } = newRouter(env);
    assert.equal(reloaded.settings.hapticsEnabled, false, 'the choice survives a reload');
    reloaded.dispose();
  }
  console.log('Phase I: the haptics control switches and persists its setting.');

  // ----- 14. Router: touch play -------------------------------------------------------------
  {
    const env = setupEnvironment({ coarse: true, maxTouchPoints: 5 });
    const layer = createLayer();
    const { router, canvas, shell } = newRouter(env, { touchLayer: layer });
    assert.equal(layer.hidden, false, 'a touch-first screen shows the controls at boot');
    assert.equal(router.activeFamily, 'touch');
    assert.equal(shell.dataset.input, 'touch');
    const stick = controlOf(layer, 'stick');
    const act = controlOf(layer, 'act');
    const jump = controlOf(layer, 'jump');
    const pack = controlOf(layer, 'pack');
    const stickCentre = centreOf(stick);

    const win = globalThis.window;
    win.dispatch('pointerdown', pointer('pointerdown', 1, stickCentre.x, stickCentre.y, 100, stick));
    win.dispatch('pointermove', pointer('pointermove', 1, stickCentre.x + 50, stickCentre.y, 110, stick));
    router.beginFrame(1 / 60);
    const moving = router.snapshot(true);
    assert.ok(moving.moveX > 0.5 && moving.moveX <= 1, `the stick moves right (${moving.moveX})`);
    assert.equal(moving.moveZ, 0);
    win.dispatch('pointerup', pointer('pointerup', 1, stickCentre.x + 50, stickCentre.y, 130, stick));
    assert.equal(router.snapshot(true).moveX, 0, 'releasing the stick stops movement');

    win.dispatch('pointerdown', pointer('pointerdown', 2, 200, 300, 200, canvas));
    win.dispatch('pointermove', pointer('pointermove', 2, 210, 290, 220, canvas));
    router.beginFrame(1 / 60);
    const look = router.consumeLook();
    assert.equal(look.x, 10);
    assert.equal(look.y, -10);
    win.dispatch('pointerup', pointer('pointerup', 2, 210, 290, 230, canvas));

    win.dispatch('pointerdown', pointer('pointerdown', 3, 150, 400, 1000, canvas));
    win.dispatch('pointerup', pointer('pointerup', 3, 150, 400, 1100, canvas));
    assert.equal(router.snapshot(true).interactPressed, true, 'a quick tap on the world acts');
    assert.equal(router.snapshot(true).interactPressed, false);

    win.dispatch('pointerdown', pointer('pointerdown', 4, 150, 400, 2000, canvas));
    win.dispatch('pointermove', pointer('pointermove', 4, 200, 400, 2050, canvas));
    win.dispatch('pointerup', pointer('pointerup', 4, 200, 400, 2100, canvas));
    assert.equal(router.snapshot(true).interactPressed, false, 'a drag on the world does not act');
    router.consumeLook();

    const press = (element, pointerId, time) => {
      const at = centreOf(element);
      win.dispatch('pointerdown', pointer('pointerdown', pointerId, at.x, at.y, time, element));
      win.dispatch('pointerup', pointer('pointerup', pointerId, at.x, at.y, time + 50, element));
    };
    press(act, 5, 3000);
    assert.equal(router.snapshot(true).interactPressed, true, 'ACT interacts');
    press(jump, 6, 3100);
    assert.equal(router.snapshot(true).jumpPressed, true, 'JUMP jumps');
    press(pack, 7, 3200);
    assert.equal(router.snapshot(true).inventoryTogglePressed, true, 'PACK opens the satchel');

    win.dispatch('pointerdown', pointer('pointerdown', 10, stickCentre.x, stickCentre.y, 4000, stick));
    win.dispatch('pointerdown', pointer('pointerdown', 11, 200, 300, 4000, canvas));
    win.dispatch('pointerdown', pointer('pointerdown', 12, stickCentre.x, stickCentre.y, 4000, stick));
    win.dispatch('pointermove', pointer('pointermove', 10, stickCentre.x + 40, stickCentre.y, 4010, stick));
    win.dispatch('pointermove', pointer('pointermove', 11, 220, 300, 4010, canvas));
    router.beginFrame(1 / 60);
    const movingWhileLooking = router.snapshot(true);
    assert.ok(movingWhileLooking.moveX > 0.3, 'the thumb on the stick moves while the other finger looks');
    assert.equal(router.consumeLook().x, 20, 'the look finger is tracked on its own');
    const stickBefore = movingWhileLooking.moveX;
    win.dispatch('pointermove', pointer('pointermove', 12, stickCentre.x - 60, stickCentre.y, 4020, stick));
    assert.equal(router.snapshot(true).moveX, stickBefore, 'a second stick finger does not steer');
    win.dispatch('pointerup', pointer('pointerup', 10, stickCentre.x + 40, stickCentre.y, 4030, stick));
    win.dispatch('pointerup', pointer('pointerup', 11, 220, 300, 4030, canvas));
    win.dispatch('pointerup', pointer('pointerup', 12, stickCentre.x, stickCentre.y, 4030, stick));

    win.dispatch('pointerdown', pointer('pointerdown', 20, stickCentre.x, stickCentre.y, 5000, stick));
    router.setMenuOpen(true);
    assert.equal(layer.hidden, true, 'opening a menu hides the controls');
    router.setMenuOpen(false);
    assert.equal(layer.hidden, false, 'closing the menu shows them again');
    assert.equal(router.snapshot(true).moveX, 0, 'gestures in progress are dropped when a menu opens');
    router.dispose();
  }
  console.log('Phase I: touch play covers the stick, look and tap, ACT, JUMP and PACK, two-finger overlap, and menu pausing.');

  // ----- 15. Touch layout: reposition, hide, reset, and persistence -----------------------------
  {
    const env = setupEnvironment({ coarse: true, maxTouchPoints: 5 });
    const win = globalThis.window;
    const layer = createLayer();
    const first = newRouter(env, { touchLayer: layer });
    const panelOf = () => layer.children.find((child) => child.className === 'touch-panel');
    const editBarOf = () => layer.children.find((child) => child.className === 'touch-edit-bar');

    const menu = controlOf(layer, 'menu');
    const menuAt = centreOf(menu);
    win.dispatch('pointerdown', pointer('pointerdown', 1, menuAt.x, menuAt.y, 100, menu));
    win.dispatch('pointerup', pointer('pointerup', 1, menuAt.x, menuAt.y, 150, menu));
    assert.equal(panelOf().hidden, false, 'the layout button opens the panel');

    findButton(panelOf(), 'Move controls').click();
    assert.equal(layer.classList.contains('is-editing'), true, 'Move controls enters edit mode');
    assert.equal(editBarOf().hidden, false);
    const act = controlOf(layer, 'act');
    const actAt = centreOf(act);
    win.dispatch('pointerdown', pointer('pointerdown', 30, actAt.x, actAt.y, 6000, act));
    win.dispatch('pointermove', pointer('pointermove', 30, 100, 400, 6010, act));
    win.dispatch('pointerup', pointer('pointerup', 30, 100, 400, 6020, act));
    findButton(editBarOf(), 'Done').click();
    assert.equal(layer.classList.contains('is-editing'), false, 'Done leaves edit mode');

    const saved = JSON.parse(env.storage.getItem(layout.TOUCH_LAYOUT_KEY));
    assert.equal(saved.version, 1);
    closeTo(saved.layout.portrait.act.x, 100 / 390, 1e-9);
    closeTo(saved.layout.portrait.act.y, 400 / 844, 1e-9);
    closeTo(saved.layout.landscape.act.x, layout.defaultLayout().landscape.act.x, 1e-9);

    first.router.dispose();
    const reopenedLayer = createLayer();
    const reopened = newRouter(env, { touchLayer: reopenedLayer });
    const reopenedAct = centreOf(controlOf(reopenedLayer, 'act'));
    closeTo(reopenedAct.x, 100, 1);
    closeTo(reopenedAct.y, 400, 1);
    reopened.router.dispose();

    const hideLayer = createLayer();
    const hiding = newRouter(env, { touchLayer: hideLayer });
    controlOf(hideLayer, 'menu').dispatch('pointerdown', pointer('pointerdown', 40, 0, 0, 7000, controlOf(hideLayer, 'menu')));
    const hidePanel = hideLayer.children.find((child) => child.className === 'touch-panel');
    findButton(hidePanel, 'Hide jump').click();
    assert.equal(controlOf(hideLayer, 'jump').hidden, true, 'hiding removes the control from view');
    assert.equal(JSON.parse(env.storage.getItem(layout.TOUCH_LAYOUT_KEY)).layout.portrait.jump.visible, false, 'hidden controls persist');
    assert.ok(findButton(hidePanel, 'Show jump'), 'the toggle relabels itself');
    findButton(hidePanel, 'Show jump').click();
    assert.equal(controlOf(hideLayer, 'jump').hidden, false);
    findButton(hidePanel, 'Reset layout').click();
    assert.equal(env.storage.getItem(layout.TOUCH_LAYOUT_KEY), null, 'reset removes the saved layout');
    hiding.router.dispose();
  }
  console.log('Phase I: touch controls can be repositioned, hidden, and reset, and the layout survives a reload.');

  // ----- 16. Touch layout: sizes on real screen dimensions ----------------------------------------
  {
    const env = setupEnvironment({ coarse: true, maxTouchPoints: 5 });
    const win = globalThis.window;
    const layer = createLayer(320, 568);
    const { router } = newRouter(env, { touchLayer: layer });
    for (const [width, height] of [[320, 568], [390, 844], [844, 390], [1024, 768]]) {
      layer.clientWidth = width;
      layer.clientHeight = height;
      win.dispatch('resize', {});
      for (const id of ['stick', 'act', 'jump', 'pack', 'menu']) {
        const element = controlOf(layer, id);
        const size = parseFloat(element.style.width);
        const left = parseFloat(element.style.left);
        const top = parseFloat(element.style.top);
        assert.ok(size >= 44 && parseFloat(element.style.height) >= 44, `${id} is at least 44 px at ${width}x${height}`);
        assert.ok(left >= 0 && top >= 0 && left + size <= width && top + size <= height, `${id} sits inside ${width}x${height}`);
      }
    }
    router.dispose();
  }
  console.log('Phase I: every touch control meets the 44 px minimum and stays on screen in portrait and landscape.');

  console.log('Phase I input tests passed: geometry, layout, settings, DualSense mapping and HID codec, feedback, prompts, panel focus, gamepad polling, keyboard, controller, WebHID, and touch routing.');
} finally {
  rmSync(outputDirectory, { recursive: true, force: true });
}
