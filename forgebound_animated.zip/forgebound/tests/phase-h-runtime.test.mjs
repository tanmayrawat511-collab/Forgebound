import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { webcrypto } from 'node:crypto';

// Drives the real GameApp frame loop in Node. The WebGL renderer, the DOM, and GLB loading are
// replaced by small fakes, so this checks the JavaScript wiring (targeting, HUD writes, render
// gating, adaptive resolution, frame cap, zone travel) and not what appears on screen.
const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outputDirectory = mkdtempSync(join(projectRoot, '.runtime-'));

try {
  execFileSync(process.platform === 'win32' ? 'tsc.cmd' : 'tsc', [
    '--strict',
    '--target', 'ES2022',
    '--module', 'commonjs',
    '--moduleResolution', 'node',
    '--skipLibCheck',
    '--typeRoots', outputDirectory,
    '--outDir', outputDirectory,
    'src/core/GameApp.ts',
  ], { cwd: projectRoot, stdio: 'inherit', shell: process.platform === 'win32' });
  writeFileSync(join(outputDirectory, 'package.json'), '{"type":"commonjs"}');

  const require = createRequire(import.meta.url);
  const THREE = require(join(projectRoot, 'node_modules/three'));

  // ----- DOM fakes ---------------------------------------------------------------------------
  class FakeClassList {
    constructor() { this.names = new Set(); }
    add(...names) { names.forEach((n) => this.names.add(n)); }
    remove(...names) { names.forEach((n) => this.names.delete(n)); }
    toggle(name, force) {
      const on = force ?? !this.names.has(name);
      if (on) this.names.add(name); else this.names.delete(name);
      return on;
    }
    contains(name) { return this.names.has(name); }
  }
  class FakeElement {
    constructor(tag = 'div') {
      this.tagName = tag.toUpperCase();
      this.textContent = '';
      this.hidden = false;
      this.style = {};
      this.dataset = {};
      this.classList = new FakeClassList();
      this.children = [];
      this.parentElement = null;
      this.attributes = {};
      this.listeners = new Map();
      this.value = '';
      this.disabled = false;
      this.tabIndex = -1;
    }
    addEventListener(type, handler) {
      if (!this.listeners.has(type)) this.listeners.set(type, new Set());
      this.listeners.get(type).add(handler);
    }
    removeEventListener(type, handler) { this.listeners.get(type)?.delete(handler); }
    append(...nodes) {
      for (const node of nodes) {
        this.children.push(node);
        if (node instanceof FakeElement) node.parentElement = this;
      }
    }
    appendChild(node) { this.append(node); return node; }
    replaceChildren(...nodes) { this.children = []; this.append(...nodes); }
    prepend(...nodes) { this.children.unshift(...nodes); }
    contains() { return false; }
    closest() { return null; }
    setAttribute(name, value) { this.attributes[name] = String(value); }
    getAttribute(name) { return this.attributes[name] ?? null; }
    querySelectorAll() { return []; }
    querySelector() { return null; }
    focus() {}
    blur() {}
    remove() {}
    requestPointerLock() {}
  }
  const elements = new Map();
  const fakeDocument = {
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, new FakeElement(id));
      return elements.get(id);
    },
    createElement: (tag) => new FakeElement(tag),
    addEventListener() {},
    removeEventListener() {},
    exitPointerLock() {},
    pointerLockElement: null,
    activeElement: null,
    body: new FakeElement('body'),
  };

  let pendingFrame = null;
  let frameId = 0;
  const storage = () => {
    const values = new Map();
    return {
      getItem: (key) => (values.has(key) ? values.get(key) : null),
      setItem: (key, value) => values.set(key, String(value)),
      removeItem: (key) => values.delete(key),
    };
  };
  globalThis.document = fakeDocument;
  globalThis.window = {
    // Rapier's WebAssembly imports read window.crypto. Without it the first physics step panics.
    crypto: webcrypto,
    performance,
    innerWidth: 1280,
    innerHeight: 720,
    devicePixelRatio: 2,
    location: { search: '' },
    confirm: () => true,
    addEventListener() {},
    removeEventListener() {},
    requestAnimationFrame(callback) { pendingFrame = callback; frameId += 1; return frameId; },
    cancelAnimationFrame() { pendingFrame = null; },
    localStorage: storage(),
  };

  // ----- Renderer fake: records what GameApp asks of it; matrices update as a real render would. ----
  const rendererLog = { renders: 0, pixelRatios: [] };
  class FakeRenderer {
    constructor(options) {
      this.options = options;
      this.domElement = new FakeElement('canvas');
      this.shadowMap = { enabled: false, type: null };
      this.pixelRatio = 1;
      this.outputColorSpace = null;
      this.toneMapping = null;
      this.toneMappingExposure = 1;
      rendererLog.last = this;
    }
    setPixelRatio(ratio) { this.pixelRatio = ratio; rendererLog.pixelRatios.push(ratio); }
    setSize() {}
    render(scene, camera) {
      rendererLog.renders += 1;
      camera.updateMatrixWorld();
      scene.updateMatrixWorld();
    }
    dispose() {}
  }
  // three's CommonJS export is read-only, so the compiled game gets a patched copy from the require
  // cache. Every other export is the real module, and only the renderer is replaced.
  const threeModulePath = require.resolve('three', { paths: [outputDirectory] });
  require.cache[threeModulePath] = {
    id: threeModulePath, filename: threeModulePath, loaded: true,
    exports: { ...THREE, WebGLRenderer: FakeRenderer }, children: [], paths: [],
  };

  // ----- GLB fake: a Group for player and forge so the model path runs; procedural for the rest. ----
  class FakeAssetRegistry {
    constructor() { this.loaded = 0; this.attempted = 0; }
    async loadAll() { this.attempted = 4; this.loaded = 2; }
    createInstance(assetId) {
      if (assetId !== 'player' && assetId !== 'forge') return null;
      const group = new THREE.Group();
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.6, 1.2, 0.6), new THREE.MeshStandardMaterial());
      mesh.castShadow = true;
      group.add(mesh);
      return group;
    }
    has(assetId) { return assetId === 'player' || assetId === 'forge'; }
    loadedCount() { return this.loaded; }
    attemptedCount() { return this.attempted; }
    dispose() {}
  }
  const assetModulePath = require.resolve(join(outputDirectory, 'assets/AssetRegistry.js'));
  require.cache[assetModulePath] = {
    id: assetModulePath, filename: assetModulePath, loaded: true, exports: { AssetRegistry: FakeAssetRegistry },
    children: [], paths: [],
  };

  const { GameApp } = require(join(outputDirectory, 'core/GameApp.js'));
  const { ZONE_GATES } = require(join(outputDirectory, 'data/portal-data.js'));
  const { ORE_NODE_DEFINITIONS } = require(join(outputDirectory, 'data/mining-data.js'));

  // ----- Driving helpers ------------------------------------------------------------------------
  const loadingUi = { setStage() {}, finish() {} };
  let clock = 0;
  function tick(deltaMs = 1000 / 60) {
    const callback = pendingFrame;
    assert.ok(callback, 'a frame was requested');
    pendingFrame = null;
    clock += deltaMs;
    callback(clock);
  }
  function ticks(count, deltaMs) {
    for (let i = 0; i < count; i += 1) tick(deltaMs);
  }
  async function boot(quality) {
    rendererLog.renders = 0;
    rendererLog.pixelRatios = [];
    window.localStorage = storage();
    const app = new GameApp(new FakeElement('host'), loadingUi, quality);
    clock = performance.now();
    await app.start();
    // start() stamps lastFrameTime with the real clock; keep the simulated clock ahead of it.
    clock = performance.now();
    return app;
  }
  // Points the centre-of-screen ray at `point`. The camera orbits a look-at point 1.5 units ahead
  // of the player at height 0.95, so with yaw 0 the sightline runs straight through that point and
  // on towards it. The helper sets the pitch to match the drop and places the player `standOff`
  // units past the point, keeping the player's height so the capsule never sinks into the floor.
  function aimAt(app, point, standOff) {
    app['cameraYaw'] = 0;
    const player = app['player'];
    const height = player.visualRoot.position.y;
    app['cameraPitch'] = Math.atan2((height + 0.95) - point.y, standOff);
    player.respawnAt({ x: point.x, y: height, z: point.z + standOff + 1.5 });
    ticks(60, 1000 / 60);
  }
  const quality = (tier) => ({
    tier,
    antialias: tier !== 'low',
    maximumPixelRatio: tier === 'high' ? 2 : tier === 'medium' ? 1.5 : 1.25,
    minimumPixelRatio: tier === 'high' ? 1 : tier === 'medium' ? 1 : 0.75,
    shadowMapSize: tier === 'high' ? 2048 : 1024,
    shadowFilter: tier === 'high' ? 'pcf-soft' : 'pcf',
    frameRateCap: tier === 'high' ? null : 60,
  });

  // 1. A high-tier boot runs 5 seconds of ordinary frames without error, rendering each one.
  {
    const app = await boot(quality('high'));
    ticks(300, 1000 / 60);
    assert.equal(rendererLog.renders, 300, 'high tier renders every frame at display rate');
    assert.equal(rendererLog.last.shadowMap.enabled, true);
    assert.equal(rendererLog.last.shadowMap.type, THREE.PCFSoftShadowMap, 'high tier uses soft shadows');
    app.dispose();
  }
  console.log('Phase H runtime: a high-tier boot runs ordinary frames and renders each one.');

  // 2. Frame cap: on a capped tier, frames arriving at 120 Hz are rendered at 60 Hz.
  {
    const app = await boot(quality('low'));
    ticks(240, 1000 / 120);
    assert.ok(rendererLog.renders >= 110 && rendererLog.renders <= 130, `capped tier renders about 60 Hz (got ${rendererLog.renders} in 2 s)`);
    app.dispose();
  }
  console.log('Phase H runtime: the frame cap holds a 60 Hz tier to 60 renders per second on a 120 Hz feed.');

  // 3. Adaptive resolution: sustained overload steps the pixel ratio down; the gate is respected.
  {
    const app = await boot(quality('high'));
    ticks(200, 1000 / 33); // ~33 ms frames, well over the 20 ms overload threshold
    const stepped = rendererLog.pixelRatios.filter((ratio) => ratio < 2);
    assert.ok(stepped.length >= 1, 'overload steps the pixel ratio below its starting value');
    assert.ok(stepped.every((ratio) => ratio >= 1), 'the ratio never drops below the tier minimum');
    app.dispose();
  }
  console.log('Phase H runtime: sustained overload steps the render resolution down within the tier bounds.');

  // 4. A hidden-tab gap does not trigger a resolution change.
  {
    const app = await boot(quality('high'));
    ticks(5, 1000 / 60);
    const before = rendererLog.pixelRatios.length;
    ticks(10, 4000);
    assert.equal(rendererLog.pixelRatios.length, before, 'multi-second gaps are not load');
    app.dispose();
  }

  // 5. Panels pause rendering; opening one renders once more, then the scene stays still.
  {
    const app = await boot(quality('high'));
    ticks(20, 1000 / 60);
    rendererLog.renders = 0;
    app['setInventoryOpen'](true);
    ticks(60, 1000 / 60);
    assert.ok(rendererLog.renders <= 1, `an open panel renders at most once (rendered ${rendererLog.renders})`);
    assert.equal(app['interactionPromptText'].textContent, 'PACK OPEN · Press I or Esc to close', 'the HUD still updates while paused');
    app['setInventoryOpen'](false);
    ticks(10, 1000 / 60);
    assert.ok(rendererLog.renders >= 9, 'rendering resumes when the panel closes');
    app.dispose();
  }
  console.log('Phase H runtime: an open panel pauses scene rendering and rendering resumes on close.');

  // 6. Targeting end to end: aim at an ore node and the mining target and prompt follow.
  {
    const app = await boot(quality('high'));
    const node = app['oreNodes'].find((candidate) => candidate.zoneId === app['zoneProgression'].getCurrentZoneId());
    const aimPoint = node.visualRoot.position.clone().add(new THREE.Vector3(0, 0.8, 0));
    aimAt(app, aimPoint, 2);
    const target = app['miningSystem'].getTargetState();
    assert.ok(target, 'the centre ray selects the ore node');
    assert.equal(target.node.id, node.id, 'the targeted node is the one aimed at');
    assert.match(app['interactionPromptText'].textContent, /Mine|Move closer/, 'the prompt reflects the mining target');
    app.dispose();
  }
  console.log('Phase H runtime: aiming at ore selects that node through the probe and updates the prompt.');

  // 7. Zone travel updates mining's active zone (the bug this change fixes).
  {
    const app = await boot(quality('high'));
    const gate = ZONE_GATES.find((candidate) => candidate.sourceZoneId === app['zoneProgression'].getCurrentZoneId());
    while (app['progression'].getLevel() < gate.requiredLevel) app['progression'].awardXp(100);
    const discCentre = new THREE.Vector3(gate.position.x, 2.0, gate.position.z);
    aimAt(app, discCentre, 1.2);
    assert.equal(app['zonePortalTarget']?.id, gate.id, 'the centre ray selects the gate');
    app['handleInteractionAction']();
    assert.equal(app['zoneProgression'].getCurrentZoneId(), gate.targetZoneId, 'travel changes the active zone');
    assert.equal(app['miningSystem']['activeZoneId'], gate.targetZoneId, 'mining follows the new zone');
    app.dispose();
  }
  console.log('Phase H runtime: zone travel moves mining into the new zone as well as combat.');

  // 8. Shared resources are released on dispose without error.
  {
    const app = await boot(quality('medium'));
    ticks(5, 1000 / 60);
    app.dispose();
  }
  console.log('Phase H runtime: disposal releases shared resources cleanly.');

  console.log('Phase H runtime tests passed: boot, frame cap, adaptive resolution, render pausing, end-to-end targeting, and zone travel.');
} finally {
  rmSync(outputDirectory, { recursive: true, force: true });
}
