import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outputDirectory = mkdtempSync(join(tmpdir(), 'forgebound-phase-c-'));

try {
  const sourceFiles = [
    'src/types/resources.ts',
    'src/types/equipment.ts',
    'src/data/equipment-data.ts',
    'src/data/forge-data.ts',
    'src/systems/Inventory.ts',
    'src/systems/ForgeSystem.ts',
  ];
  execFileSync(process.platform === 'win32' ? 'tsc.cmd' : 'tsc', [
    '--strict',
    '--target', 'ES2022',
    '--module', 'commonjs',
    '--moduleResolution', 'node',
    '--skipLibCheck',
    '--typeRoots', outputDirectory,
    '--outDir', outputDirectory,
    ...sourceFiles,
  ], { cwd: projectRoot, stdio: 'inherit', shell: process.platform === 'win32' });
  writeFileSync(join(outputDirectory, 'package.json'), '{"type":"commonjs"}');

  const require = createRequire(import.meta.url);
  const { Inventory } = require(join(outputDirectory, 'systems/Inventory.js'));
  const { ForgeSystem } = require(join(outputDirectory, 'systems/ForgeSystem.js'));
  const { EQUIPMENT_DEFINITIONS } = require(join(outputDirectory, 'data/equipment-data.js'));

  const inventory = new Inventory();
  const forge = new ForgeSystem(inventory);
  let notifications = 0;
  inventory.subscribe(() => { notifications += 1; });

  assert.equal(inventory.getEquippedPickaxe(), null, 'a fresh J7 game must not start with a pickaxe');
  assert.equal(inventory.hasEquipment('starter-pickaxe'), false, 'Ben’s unique pickaxe is awarded only after the tutorial');
  assert.equal(inventory.getEquippedWeapon().attackDamage, 5);
  assert.equal(inventory.add('copper-ore', 6).ok, true);
  assert.equal(inventory.add('iron-ore', 4).ok, true);
  assert.equal(inventory.add('copper-ore', 0).ok, false);

  assert.equal(forge.smelt('smelt-copper').ok, true);
  assert.equal(inventory.count('copper-ore'), 4);
  assert.equal(inventory.count('copper-ingot'), 1);
  assert.equal(forge.smelt('smelt-iron').ok, true);
  assert.equal(inventory.count('iron-ore'), 2);
  assert.equal(inventory.count('iron-ingot'), 1);

  const beforeFailedSmelt = inventory.snapshot();
  assert.equal(forge.smelt('smelt-gold').ok, false);
  assert.deepEqual(inventory.snapshot(), beforeFailedSmelt, 'unaffordable smelting must not mutate inventory');

  const overflowInventory = new Inventory();
  const overflowForge = new ForgeSystem(overflowInventory);
  assert.equal(overflowInventory.add('copper-ore', 2).ok, true);
  assert.equal(overflowInventory.add('copper-ingot', 9999).ok, true);
  assert.equal(overflowForge.canSmelt('smelt-copper'), false, 'full output stack should disable the smelt action');
  assert.equal(overflowForge.smelt('smelt-copper').ok, false);
  assert.equal(overflowInventory.count('copper-ore'), 2, 'failed output-cap check must preserve input ore');
  assert.equal(overflowInventory.count('copper-ingot'), 9999);

  const goldInventory = new Inventory();
  const goldForge = new ForgeSystem(goldInventory);
  assert.equal(goldInventory.add('gold-ore', 2).ok, true);
  assert.equal(goldForge.smelt('smelt-gold').ok, true);
  assert.equal(goldInventory.count('gold-ingot'), 1);

  const craftInventory = new Inventory();
  const craftForge = new ForgeSystem(craftInventory);
  craftInventory.add('copper-ingot', 2);
  craftInventory.add('iron-ingot', 1);
  const beforeFailedCraft = craftInventory.snapshot();
  assert.equal(craftForge.craft('craft-copper-pickaxe').ok, false);
  assert.deepEqual(craftInventory.snapshot(), beforeFailedCraft, 'failed crafting must preserve all materials');

  craftInventory.add('copper-ingot', 1);
  assert.equal(craftForge.craft('craft-copper-pickaxe').ok, true);
  assert.equal(craftInventory.count('copper-ingot'), 0);
  assert.equal(craftInventory.count('iron-ingot'), 0);
  assert.equal(craftInventory.hasEquipment('copper-pickaxe'), true);
  assert.equal(craftForge.craft('craft-copper-pickaxe').ok, false, 'unique equipment must not be duplicated');
  assert.equal(craftForge.equip('copper-pickaxe').ok, true);
  assert.equal(craftInventory.getEquippedPickaxe().miningPower, 2);
  assert.equal(craftInventory.unequip('pickaxe').ok, true);
  assert.equal(craftInventory.getEquippedPickaxe(), null);

  craftInventory.add('copper-ingot', 2);
  craftInventory.add('iron-ingot', 1);
  craftInventory.add('iron-ingot', 3);
  assert.equal(craftForge.craft('craft-copper-sword').ok, true);
  assert.equal(craftForge.equip('copper-sword').ok, true);
  assert.equal(craftInventory.getEquippedWeapon().attackDamage, 8);
  craftInventory.add('copper-ingot', 1);
  assert.equal(craftForge.craft('craft-iron-maul').ok, true);
  assert.equal(craftForge.equip('iron-maul').ok, true);
  assert.equal(craftInventory.getEquippedWeapon().attackDamage, 13);
  assert.equal(EQUIPMENT_DEFINITIONS['iron-maul'].attackDamage, 13);
  assert.ok(EQUIPMENT_DEFINITIONS['iron-maul'].attacksPerSecond < EQUIPMENT_DEFINITIONS['copper-sword'].attacksPerSecond);

  assert.ok(notifications >= 4, 'inventory updates should notify subscribers');
  console.log('Phase C domain tests passed: smelting, output-cap atomicity, crafting, uniqueness, equip/unequip, and equipment stats.');
} finally {
  rmSync(outputDirectory, { recursive: true, force: true });
}
