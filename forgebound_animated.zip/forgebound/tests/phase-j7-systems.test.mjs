import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { existsSync, readFileSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = mkdtempSync(join(tmpdir(), 'forgebound-phase-j7-'));

try {
  const sources = [
    'src/types/resources.ts', 'src/types/equipment.ts', 'src/types/gear.ts', 'src/types/zones.ts', 'src/types/combat.ts',
    'src/data/equipment-data.ts', 'src/data/gear-data.ts', 'src/data/zone-data.ts', 'src/data/civilian-data.ts',
    'src/systems/Inventory.ts', 'src/systems/GearInventorySystem.ts', 'src/systems/BlacksmithSystem.ts',
    'src/systems/GearRefinementSystem.ts', 'src/systems/TutorialSystem.ts', 'src/systems/SaveSystem.ts',
  ];
  execFileSync(process.platform === 'win32' ? 'tsc.cmd' : 'tsc', [
    '--strict', '--noUncheckedIndexedAccess', '--noUnusedLocals', '--noUnusedParameters',
    '--target', 'ES2022', '--module', 'commonjs', '--moduleResolution', 'node',
    '--skipLibCheck', '--typeRoots', output, '--outDir', output, ...sources,
  ], { cwd: root, stdio: 'inherit', shell: process.platform === 'win32' });
  writeFileSync(join(output, 'package.json'), '{"type":"commonjs"}');

  const require = createRequire(import.meta.url);
  const { GEAR_IDS, BEN_PICKAXE_INSTANCE_ID } = {
    ...require(join(output, 'types/gear.js')),
    ...require(join(output, 'systems/TutorialSystem.js')),
  };
  const { GEAR_DEFINITIONS, GEAR_MATERIALS, getGearStats } = require(join(output, 'data/gear-data.js'));
  const { CIVILIAN_DEFINITIONS, CIVILIAN_CAP_PER_ZONE, ACTIVE_DOG_CAP } = require(join(output, 'data/civilian-data.js'));
  const { Inventory } = require(join(output, 'systems/Inventory.js'));
  const { GearInventorySystem, createEmptyGearInventorySnapshot } = require(join(output, 'systems/GearInventorySystem.js'));
  const { BlacksmithSystem } = require(join(output, 'systems/BlacksmithSystem.js'));
  const { GearRefinementSystem, createEmptyGearRefinementSnapshot } = require(join(output, 'systems/GearRefinementSystem.js'));
  const { TutorialSystem, createInitialTutorialSnapshot, createCompletedLegacyTutorialSnapshot, validateTutorialSnapshot } = require(join(output, 'systems/TutorialSystem.js'));
  const {
    SAVE_SCHEMA_VERSION, SAVE_STORAGE_KEY, PREVIOUS_SAVE_STORAGE_KEY,
    createSaveData, migrateVersionFiveSaveData, DEFAULT_MINIMAP_SNAPSHOT,
  } = require(join(output, 'systems/SaveSystem.js'));

  // The Blacksmith catalog is exactly the 13 requested gear types and takes ingots, never Coins.
  assert.equal(GEAR_IDS.length, 13);
  assert.deepEqual([...GEAR_IDS], [
    'daggers', 'straight-sword', 'mace', 'gauntlet', 'axe', 'katana', 'great-sword',
    'spear', 'great-axe', 'colossal-sword', 'helmet', 'chestplate', 'leggings',
  ]);
  assert.equal(new Set(GEAR_IDS).size, 13);
  for (const id of GEAR_IDS) assert.ok(GEAR_DEFINITIONS[id].modelAsset.startsWith('gear-'));
  assert.deepEqual(Object.keys(GEAR_MATERIALS), ['copper', 'iron', 'gold', 'crystal']);
  assert.ok(getGearStats('straight-sword', 'copper', 0).damage < getGearStats('straight-sword', 'iron', 0).damage);
  assert.ok(getGearStats('straight-sword', 'iron', 0).damage < getGearStats('straight-sword', 'gold', 0).damage);
  assert.ok(getGearStats('straight-sword', 'gold', 0).damage < getGearStats('straight-sword', 'crystal', 0).damage);

  const wallet = new Inventory();
  const gear = new GearInventorySystem();
  const blacksmith = new BlacksmithSystem(wallet, gear);
  const startCoins = wallet.getCoins();
  wallet.add('iron-ingot', 3);
  const traded = blacksmith.trade('straight-sword', 'iron');
  assert.equal(traded.ok, true);
  assert.equal(wallet.count('iron-ingot'), 0);
  assert.equal(wallet.getCoins(), startCoins, 'Blacksmith trade must not charge Coins');
  assert.equal(gear.getItems().length, 1);
  assert.equal(gear.getItems()[0].materialId, 'iron');
  const secondTradeWithoutIngots = blacksmith.trade('helmet', 'iron');
  assert.equal(secondTradeWithoutIngots.ok, false, 'Coins alone cannot buy Blacksmith gear');
  assert.equal(wallet.getCoins(), startCoins);

  // New games begin without a pickaxe, and the tutorial requires the original stable item ID.
  const fresh = new Inventory();
  assert.equal(fresh.hasEquipment('starter-pickaxe'), false);
  assert.equal(fresh.getEquippedPickaxe(), null);
  assert.equal(BEN_PICKAXE_INSTANCE_ID, 'ben-lost-pickaxe-001');
  const tutorial = new TutorialSystem();
  assert.equal(validateTutorialSnapshot(createInitialTutorialSnapshot()), true);
  assert.equal(validateTutorialSnapshot({ ...createInitialTutorialSnapshot(), step: 'return-pickaxe' }), false, 'return step requires player custody');
  assert.equal(tutorial.pickUpPickaxe('not-the-original-pickaxe'), false);
  assert.equal(tutorial.recordMovement(3), true);
  assert.equal(tutorial.getStep(), 'meet-ben');
  assert.equal(tutorial.meetBen(), true);
  assert.equal(tutorial.grantTutorialSupplies(), true);
  assert.equal(tutorial.markSmelted(), true);
  assert.equal(tutorial.markTraded(), true);
  assert.equal(tutorial.markRefined(), true);
  assert.equal(tutorial.markMinimapOpened(), true);
  assert.equal(tutorial.getStep(), 'find-pickaxe');
  assert.equal(tutorial.pickUpPickaxe(BEN_PICKAXE_INSTANCE_ID), true);
  assert.equal(tutorial.getPickaxeCustody(), 'player');
  assert.equal(tutorial.handPickaxeToBen(BEN_PICKAXE_INSTANCE_ID), true);
  assert.equal(tutorial.getPickaxeCustody(), 'ben');
  assert.equal(tutorial.receiveGift(BEN_PICKAXE_INSTANCE_ID), true);
  assert.equal(tutorial.getPickaxeCustody(), 'gifted');
  assert.equal(tutorial.isComplete(), true);
  assert.equal(tutorial.pickUpPickaxe(BEN_PICKAXE_INSTANCE_ID), false, 'the same pickaxe cannot be collected a second time');

  // Refinement failures consume all costs, preserve the same item/tier and save pity across reloads.
  const refinerInventory = new Inventory();
  const refinerGear = new GearInventorySystem();
  const issued = refinerGear.grant('daggers', 'copper', 1234);
  assert.equal(issued.ok, true);
  assert.ok(issued.item);
  refinerInventory.add('copper-ingot', 4);
  const beforeCoins = refinerInventory.getCoins();
  const failingRefiner = new GearRefinementSystem(refinerInventory, refinerGear, () => 1);
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    const result = failingRefiner.refine(issued.item.instanceId);
    assert.equal(result.ok, false);
    assert.equal(result.failed, true);
    assert.equal(result.consecutiveFailures, attempt);
    assert.equal(refinerGear.getItem(issued.item.instanceId).refinementTier, 0);
    assert.equal(refinerInventory.count('copper-ingot'), 4 - attempt);
    assert.equal(refinerInventory.getCoins(), beforeCoins - attempt * 25);
  }
  const savedPity = failingRefiner.snapshot();
  assert.equal(savedPity.failureStreaks[`${issued.item.instanceId}:1`], 3);
  const restoredRefiner = new GearRefinementSystem(refinerInventory, refinerGear, () => 1);
  assert.equal(restoredRefiner.restore(JSON.parse(JSON.stringify(savedPity))), true);
  const guaranteed = restoredRefiner.refine(issued.item.instanceId);
  assert.equal(guaranteed.ok, true);
  assert.equal(guaranteed.pityGuaranteed, true, 'the fourth consecutive attempt must succeed even on a failing random roll');
  assert.equal(guaranteed.item.refinementTier, 1);
  assert.equal(refinerInventory.count('copper-ingot'), 0);
  assert.equal(refinerInventory.getCoins(), 0);
  assert.equal(restoredRefiner.snapshot().failureStreaks[`${issued.item.instanceId}:1`], undefined);

  // Save schema v6 carries the J7 state; J6 v5 migration preserves old inventory and bypasses the new tutorial.
  assert.equal(SAVE_SCHEMA_VERSION, 6);
  assert.equal(SAVE_STORAGE_KEY, 'forgebound.save.v6');
  assert.equal(PREVIOUS_SAVE_STORAGE_KEY, 'forgebound.save.v5');
  assert.equal(DEFAULT_MINIMAP_SNAPSHOT.northLocked, true);
  assert.deepEqual(createEmptyGearInventorySnapshot().items, []);
  assert.deepEqual(createEmptyGearRefinementSnapshot().failureStreaks, {});

  const legacyInventory = new Inventory();
  legacyInventory.grantEquipment('starter-pickaxe', true, 'legacy-starter-pickaxe');
  const legacyBase = createSaveData({
    playerHealth: 91,
    progression: { level: 1, currentXp: 0, totalXp: 0 },
    inventory: legacyInventory.snapshot(),
    currentZoneId: 'starter-quarry',
    questState: { acceptedQuestIds: [], completedQuestIds: [], progress: {}, usedWorldObjectIds: [] },
    miniGameState: { bestTierByGame: {}, completionCounts: {}, unlockedRewards: [] },
    dungeonState: { discoveredDungeonIds: [], completedDungeonIds: [], claimedPointIds: [] },
  }, 1_800_000_000_000);
  const v5 = { ...legacyBase, schemaVersion: 5, inventory: { ...legacyBase.inventory } };
  delete v5.gearInventory;
  delete v5.gearRefinement;
  delete v5.tutorialState;
  delete v5.minimapState;
  delete v5.inventory.pickaxeInstanceId;
  const migrated = migrateVersionFiveSaveData(v5);
  assert.equal(migrated.ok, true);
  assert.equal(migrated.migrated, true);
  assert.equal(migrated.data.inventory.ownedEquipmentIds.includes('starter-pickaxe'), true);
  assert.equal(migrated.data.inventory.pickaxeInstanceId, 'legacy-starter-pickaxe');
  assert.equal(migrated.data.tutorialState.completed, true);
  assert.deepEqual(migrated.data.minimapState, DEFAULT_MINIMAP_SNAPSHOT);
  assert.equal(createCompletedLegacyTutorialSnapshot().completed, true);

  // The world has 25 distinct townsfolk, six active per zone at once, and one dog globally.
  assert.equal(CIVILIAN_DEFINITIONS.length, 25);
  assert.equal(new Set(CIVILIAN_DEFINITIONS.map((civilian) => civilian.id)).size, 25);
  assert.equal(new Set(CIVILIAN_DEFINITIONS.map((civilian) => civilian.name)).size, 25);
  assert.equal(CIVILIAN_CAP_PER_ZONE, 6);
  assert.equal(ACTIVE_DOG_CAP, 1);
  for (const zone of ['starter-quarry', 'molten-caves', 'crystal-peaks']) {
    assert.ok(CIVILIAN_DEFINITIONS.filter((civilian) => civilian.zoneId === zone).length >= CIVILIAN_CAP_PER_ZONE);
  }

  const j7Manifest = JSON.parse(readFileSync(join(root, 'public/assets/j7-model-manifest.json'), 'utf8'));
  const animationManifest = JSON.parse(readFileSync(join(root, 'public/assets/animation-manifest.json'), 'utf8'));
  assert.equal(j7Manifest.modelCount, 41);
  assert.equal(j7Manifest.models.length, 41);
  assert.equal(animationManifest.phase, 'J7');
  assert.equal(animationManifest.actors.civilians.length, 25);
  assert.equal(animationManifest.actors.namedNpcCount, 22);
  assert.equal(animationManifest.actors.namedNpcs.length, 22);
  assert.equal(animationManifest.actors.namedNpcModels.length, 22);
  assert.equal(animationManifest.actors.gearModels.length, 13);
  assert.equal(animationManifest.clips.every((clip) => clip.source === 'procedural-runtime'), true);
  const indexHtml = readFileSync(join(root, 'index.html'), 'utf8');
  assert.match(indexHtml, /id="tutorial-subtitle"[^>]*role="status"[^>]*aria-live="polite"/);
  const gameAppSource = readFileSync(join(root, 'src/core/GameApp.ts'), 'utf8');
  assert.match(gameAppSource, /Complete Ben’s mandatory tutorial before travelling to another zone/);
  assert.match(gameAppSource, /smeltRecipeId === 'smelt-copper'/);
  assert.match(gameAppSource, /Math.PI - this.player.bodyMesh.rotation.y/);
  const minimapSource = readFileSync(join(root, 'src/systems/MinimapRenderer.ts'), 'utf8');
  assert.match(minimapSource, /if \(this.northLocked\) ctx.rotate\(this.heading\)/);
  const animatedActors = new Set(animationManifest.clips.map((clip) => clip.actor));
  for (const actor of ['player', 'ben', 'pet-dog', ...animationManifest.actors.civilians.map((file) => file.replace(/\.glb$/, ''))]) assert.ok(animatedActors.has(actor));
  assert.ok(animationManifest.clips.some((clip) => clip.actor === 'ben' && clip.clip === 'gift-pickaxe'));
  assert.ok(animationManifest.clips.some((clip) => clip.actor === 'pet-dog' && clip.clip === 'pet-reaction'));

  console.log('Phase J7 systems passed: 13 gear types, four ingot materials, ingot-only trades, persisted fourth-attempt pity, sequential tutorial and unique pickaxe custody, v5→v6 migration, 25 civilians, six-per-zone cap, one global dog, 41 GLBs and 340 procedural animation manifest entries.');
} finally {
  rmSync(output, { recursive: true, force: true });
}
