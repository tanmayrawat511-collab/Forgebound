import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outputDirectory = mkdtempSync(join(tmpdir(), 'forgebound-phase-e-'));

try {
  const sourceFiles = [
    'src/types/zones.ts',
    'src/types/resources.ts',
    'src/types/combat.ts',
    'src/data/zone-data.ts',
    'src/data/portal-data.ts',
    'src/data/mining-data.ts',
    'src/data/enemy-data.ts',
    'src/world/world-config.ts',
    'src/systems/ZoneProgressionSystem.ts',
  ];
  execFileSync(process.platform === 'win32' ? 'tsc.cmd' : 'tsc', [
    '--strict',
    '--target', 'ES2022',
    '--module', 'commonjs',
    '--moduleResolution', 'node',
    '--skipLibCheck',
    '--typeRoots', outputDirectory,
    '--outDir', outputDirectory,
    ...sourceFiles,
  ], { cwd: projectRoot, stdio: 'inherit', shell: process.platform === 'win32' });
  writeFileSync(join(outputDirectory, 'package.json'), '{"type":"commonjs"}');

  const require = createRequire(import.meta.url);
  const { ZONE_DEFINITIONS, ZONE_ORDER } = require(join(outputDirectory, 'data/zone-data.js'));
  const { ORE_NODE_DEFINITIONS } = require(join(outputDirectory, 'data/mining-data.js'));
  const { ZONE_GATES } = require(join(outputDirectory, 'data/portal-data.js'));
  const { ENEMY_DEFINITIONS, ENEMY_SPAWN_ORDER } = require(join(outputDirectory, 'data/enemy-data.js'));
  const { ARENA_LAYOUTS, getStaticBoxes } = require(join(outputDirectory, 'world/world-config.js'));
  const { ZoneProgressionSystem } = require(join(outputDirectory, 'systems/ZoneProgressionSystem.js'));

  assert.deepEqual(ZONE_ORDER, ['starter-quarry', 'molten-caves', 'crystal-peaks']);
  assert.equal(ARENA_LAYOUTS.length, 3);
  assert.equal(new Set(ARENA_LAYOUTS.map((arena) => arena.zoneId)).size, 3);
  assert.equal(ZONE_GATES.length, 4);
  const gateEdges = ZONE_GATES.map((gate) => `${gate.sourceZoneId}->${gate.targetZoneId}`);
  assert.deepEqual(new Set(gateEdges), new Set([
    'starter-quarry->molten-caves',
    'molten-caves->starter-quarry',
    'molten-caves->crystal-peaks',
    'crystal-peaks->molten-caves',
  ]));
  for (const gate of ZONE_GATES) {
    assert.equal(gate.requiredLevel, ZONE_DEFINITIONS[gate.targetZoneId].requiredLevel);
    assert.ok(Math.abs(gate.position.x - ZONE_DEFINITIONS[gate.sourceZoneId].center.x) < 14);
    assert.ok(Math.abs(gate.position.z - ZONE_DEFINITIONS[gate.sourceZoneId].center.z) < 14);
  }
  assert.equal(getStaticBoxes().filter((box) => box.tone === 'wall').length, 12);
  assert.equal(getStaticBoxes().filter((box) => box.tone === 'obstacle').length, 6);

  const nodesByZone = new Map(ZONE_ORDER.map((zoneId) => [zoneId, ORE_NODE_DEFINITIONS.filter((node) => node.zoneId === zoneId)]));
  assert.ok(nodesByZone.get('starter-quarry').length >= 2);
  assert.ok(nodesByZone.get('molten-caves').length >= 2);
  assert.ok(nodesByZone.get('crystal-peaks').length >= 2);
  assert.ok(nodesByZone.get('starter-quarry').some((node) => node.resourceId === 'copper-ore'));
  assert.ok(nodesByZone.get('starter-quarry').some((node) => node.resourceId === 'iron-ore'));
  assert.ok(nodesByZone.get('molten-caves').some((node) => node.resourceId === 'iron-ore'));
  assert.ok(nodesByZone.get('molten-caves').some((node) => node.resourceId === 'gold-ore'));
  assert.ok(nodesByZone.get('crystal-peaks').some((node) => node.resourceId === 'gold-ore'));
  assert.ok(nodesByZone.get('crystal-peaks').some((node) => node.resourceId === 'crystal'));

  assert.equal(ENEMY_SPAWN_ORDER.length, 3);
  const enemyZones = ENEMY_SPAWN_ORDER.map((enemyId) => ENEMY_DEFINITIONS[enemyId].zoneId);
  assert.deepEqual(new Set(enemyZones), new Set(ZONE_ORDER));
  for (const enemyId of ENEMY_SPAWN_ORDER) {
    const enemy = ENEMY_DEFINITIONS[enemyId];
    assert.ok(enemy.spawn.x >= ZONE_DEFINITIONS[enemy.zoneId].center.x - 14);
    assert.ok(enemy.spawn.x <= ZONE_DEFINITIONS[enemy.zoneId].center.x + 14);
  }

  const zones = new ZoneProgressionSystem();
  assert.deepEqual(zones.getUnlockedZoneIds(1), ['starter-quarry']);
  assert.deepEqual(zones.getUnlockedZoneIds(2), ['starter-quarry']);
  assert.deepEqual(zones.getUnlockedZoneIds(3), ['starter-quarry', 'molten-caves']);
  assert.deepEqual(zones.getUnlockedZoneIds(5), ZONE_ORDER);
  assert.deepEqual(zones.getUnlockedZoneIds(Number.NaN), ['starter-quarry']);
  assert.deepEqual(zones.getUnlockedZoneIds(Number.POSITIVE_INFINITY), ['starter-quarry']);
  assert.deepEqual(zones.getNewlyUnlocked(2, 3), ['molten-caves']);
  assert.deepEqual(zones.getNewlyUnlocked(4, 5), ['crystal-peaks']);

  assert.deepEqual(zones.travelTo('molten-caves', Number.NaN), {
    ok: false,
    reason: 'locked',
    requiredLevel: 3,
  });
  assert.deepEqual(zones.travelTo('molten-caves', 2), {
    ok: false,
    reason: 'locked',
    requiredLevel: 3,
  });
  assert.deepEqual(zones.travelTo('unknown-region', 99), { ok: false, reason: 'unknown-zone' });
  const enteredMolten = zones.travelTo('molten-caves', 3);
  assert.deepEqual(enteredMolten, { ok: true, from: 'starter-quarry', to: 'molten-caves' });
  assert.deepEqual(zones.travelTo('molten-caves', 3), { ok: false, reason: 'already-here' });
  assert.equal(zones.getCurrentZoneId(), 'molten-caves');
  assert.equal(zones.setCurrentZone('crystal-peaks', 4), false);
  assert.equal(zones.setCurrentZone('crystal-peaks', 5), true);
  assert.equal(zones.getCurrentZoneId(), 'crystal-peaks');

  console.log('Phase E domain tests passed: three arena layouts, regional resources and creatures, level-gated unlocks, safe zone travel, and regional checkpoints.');
} finally {
  rmSync(outputDirectory, { recursive: true, force: true });
}
