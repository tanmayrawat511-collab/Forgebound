import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

// Compiled output must sit inside the project so that `require('three')` resolves node_modules.
const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outputDirectory = mkdtempSync(join(projectRoot, '.phase-g-'));

try {
  const sourceFiles = [
    'src/render/qualityTiers.ts',
    'src/render/AdaptiveResolution.ts',
    'src/render/intersectVisible.ts',
    'src/render/sharedResources.ts',
    'src/ui/domWrites.ts',
    'src/interaction/InteractionProbe.ts',
    'src/entities/ZonePortal.ts',
    'src/entities/OreNode.ts',
    'src/entities/Enemy.ts',
    'src/entities/ForgeStation.ts',
    'src/world/world-config.ts',
    'src/data/portal-data.ts',
    'src/data/mining-data.ts',
    'src/data/enemy-data.ts',
    'src/data/zone-data.ts',
  ];
  execFileSync(process.platform === 'win32' ? 'tsc.cmd' : 'tsc', [
    '--strict',
    '--target', 'ES2022',
    '--module', 'commonjs',
    '--moduleResolution', 'node',
    '--skipLibCheck',
    '--typeRoots', outputDirectory,
    '--outDir', outputDirectory,
    ...sourceFiles,
  ], { cwd: projectRoot, stdio: 'inherit', shell: process.platform === 'win32' });
  writeFileSync(join(outputDirectory, 'package.json'), '{"type":"commonjs"}');

  const require = createRequire(import.meta.url);
  const out = (path) => require(join(outputDirectory, path));
  const {
    selectQualityTier,
    resolveRenderQuality,
    initialPixelRatio,
  } = out('render/qualityTiers.js');
  const { AdaptiveResolution } = out('render/AdaptiveResolution.js');
  const { intersectVisible, hasVisibleHit } = out('render/intersectVisible.js');
  const { sharedGeometry, sharedMaterial, disposeSharedRenderResources } = out('render/sharedResources.js');
  const { setText, setHidden, setWidth, setDataAttribute } = out('ui/domWrites.js');
  const { InteractionProbe } = out('interaction/InteractionProbe.js');
  const { ZonePortal } = out('entities/ZonePortal.js');
  const { OreNode } = out('entities/OreNode.js');
  const { Enemy } = out('entities/Enemy.js');
  const { ForgeStation } = out('entities/ForgeStation.js');
  const THREE = require('three');
  const { ARENA_LAYOUTS, getStaticBoxes } = out('world/world-config.js');
  const { ZONE_GATES } = out('data/portal-data.js');
  const { ORE_NODE_DEFINITIONS } = out('data/mining-data.js');
  const { ENEMY_DEFINITIONS, ENEMY_SPAWN_ORDER } = out('data/enemy-data.js');

  // ---------------------------------------------------------------------------------------------
  // 1. Render quality tiers
  // ---------------------------------------------------------------------------------------------
  const phone = { touchPrimary: true, mobileUserAgent: true, logicalCores: 8, deviceMemoryGb: 8, devicePixelRatio: 3 };
  assert.equal(selectQualityTier(phone), 'medium', 'capable phone gets medium');
  assert.equal(selectQualityTier({ ...phone, deviceMemoryGb: 4 }), 'low', 'low-memory phone gets low');
  assert.equal(selectQualityTier({ ...phone, deviceMemoryGb: null }), 'low', 'unreported memory on a phone gets low');
  assert.equal(selectQualityTier({ ...phone, logicalCores: 4 }), 'low', 'few cores on a phone gets low');
  const desktop = { touchPrimary: false, mobileUserAgent: false, logicalCores: 12, deviceMemoryGb: 16, devicePixelRatio: 1 };
  assert.equal(selectQualityTier(desktop), 'high', 'capable desktop gets high');
  assert.equal(selectQualityTier({ ...desktop, logicalCores: 4 }), 'medium', 'four-core desktop gets medium');
  assert.equal(selectQualityTier({ ...desktop, logicalCores: null, deviceMemoryGb: null }), 'high', 'unknown desktop gets high');

  const lowQuality = resolveRenderQuality(desktop, 'low');
  assert.equal(lowQuality.tier, 'low');
  assert.equal(lowQuality.antialias, false, 'low tier drops multisampling');
  assert.equal(resolveRenderQuality(desktop, 'ultra').tier, 'high', 'unknown override falls back to detection');
  assert.equal(resolveRenderQuality(phone, 'high').tier, 'high', 'valid override wins over detection');
  assert.equal(initialPixelRatio(lowQuality, 3), 1.25, 'pixel ratio is capped by the tier');
  assert.equal(initialPixelRatio(resolveRenderQuality(desktop, 'high'), 1.5), 1.5, 'device ratio below the cap is kept');
  assert.equal(initialPixelRatio(lowQuality, Number.NaN), 1, 'invalid device ratio falls back to 1');
  console.log('Phase G render tiers: detection, overrides and pixel-ratio caps are correct.');

  // ---------------------------------------------------------------------------------------------
  // 2. Adaptive resolution governor
  // ---------------------------------------------------------------------------------------------
  const governorOptions = { initialRatio: 1.25, minimumRatio: 0.75, maximumRatio: 1.25, targetFrameMs: 1000 / 60 };

  {
    const governor = new AdaptiveResolution(governorOptions);
    let changes = 0;
    for (let t = 0; t < 60000; t += 1000 / 60) if (governor.recordFrame(8) !== null) changes += 1;
    assert.equal(changes, 0, 'a device with headroom never changes resolution');
    assert.equal(governor.currentRatio, 1.25);
  }

  {
    // Cost grows with the square of the pixel ratio: 14 ms at 1.0, so 1.25 takes ~22 ms (overloaded)
    // and 1.125 takes ~17.7 ms (within budget). The governor should settle around 1.125.
    const governor = new AdaptiveResolution(governorOptions);
    const frameCost = (ratio) => 14 * ratio * ratio;
    const minutes = (m) => m * 60 * 1000;
    const ratios = [];
    let elapsed = 0;
    let lateOverloadedMs = 0;
    let lateMs = 0;
    while (elapsed < minutes(25)) {
      const frameMs = frameCost(governor.currentRatio);
      if (elapsed >= minutes(15)) {
        lateMs += frameMs;
        if (frameMs > 20) lateOverloadedMs += frameMs;
      }
      const next = governor.recordFrame(frameMs);
      if (next !== null) ratios.push({ at: elapsed, ratio: next });
      elapsed += frameMs;
    }
    for (const { ratio } of ratios) {
      assert.ok(ratio >= 0.75 && ratio <= 1.25, `ratio ${ratio} stayed within bounds`);
    }
    assert.ok(ratios.some((change) => change.ratio === 1.125), 'governor steps down to the sustainable ratio');
    const lateChanges = ratios.filter((change) => change.at >= minutes(15));
    assert.ok(lateChanges.length <= 4, `once settled, the governor changes at most a few times in ten minutes (saw ${lateChanges.length})`);
    assert.ok(lateChanges.every((change) => change.ratio === 1.125 || change.ratio === 1.25), 'settles between the two adjacent steps');
    const overloadedShare = lateOverloadedMs / lateMs;
    assert.ok(overloadedShare < 0.02, `time spent overloaded after settling is under 2% (was ${(overloadedShare * 100).toFixed(2)}%)`);
  }

  {
    // A frame gap of several seconds means the tab was hidden. It must not count as load.
    const governor = new AdaptiveResolution(governorOptions);
    for (let i = 0; i < 1000; i += 1) assert.equal(governor.recordFrame(5000), null);
    assert.equal(governor.currentRatio, 1.25, 'hidden-tab gaps are ignored');
  }

  {
    const governor = new AdaptiveResolution({ ...governorOptions, initialRatio: 0.5 });
    assert.equal(governor.currentRatio, 0.75, 'initial ratio is clamped to the minimum');
    assert.throws(() => new AdaptiveResolution({ ...governorOptions, maximumRatio: 0.5 }));
  }
  console.log('Phase G adaptive resolution: headroom, overload, settling, hidden-tab gaps and bounds behave as designed.');

  // ---------------------------------------------------------------------------------------------
  // 3. DOM write helpers only touch elements that change
  // ---------------------------------------------------------------------------------------------
  function countingElement(initial) {
    const element = { writes: 0, dataset: {}, style: {} };
    let text = initial.text;
    Object.defineProperty(element, 'textContent', {
      get: () => text,
      set: (value) => { element.writes += 1; text = value; },
    });
    let hidden = initial.hidden;
    Object.defineProperty(element, 'hidden', {
      get: () => hidden,
      set: (value) => { element.writes += 1; hidden = value; },
    });
    let width = initial.width;
    Object.defineProperty(element.style, 'width', {
      get: () => width,
      set: (value) => { element.writes += 1; width = value; },
    });
    return element;
  }
  {
    const el = countingElement({ text: 'same', hidden: false, width: '10%' });
    setText(el, 'same');
    setHidden(el, false);
    setWidth(el, '10%');
    assert.equal(el.writes, 0, 'unchanged values cause no DOM writes');
    setText(el, 'changed');
    setHidden(el, true);
    setWidth(el, '20%');
    assert.equal(el.writes, 3, 'changed values are written exactly once each');
    setDataAttribute(el, 'low', 'true');
    setDataAttribute(el, 'low', 'true');
    assert.equal(el.dataset.low, 'true');
  }
  console.log('Phase G DOM writes: unchanged values are not written, changed values are.');

  // ---------------------------------------------------------------------------------------------
  // 4. Visibility-aware raycasting and shared resources
  // ---------------------------------------------------------------------------------------------
  {
    const scene = new THREE.Scene();
    const front = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshBasicMaterial());
    front.position.set(0, 0, -3);
    front.visible = false;
    const back = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshBasicMaterial());
    back.position.set(0, 0, -6);
    scene.add(front, back);
    scene.updateMatrixWorld(true);
    const ray = new THREE.Raycaster(new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 0, -1), 0, 100);

    assert.equal(ray.intersectObjects([front, back], true)[0].object, front, 'stock Raycaster still tests hidden meshes');
    // A ray through a solid box reports entry and exit, so count objects rather than hits.
    const out = intersectVisible(ray, [front, back], []);
    assert.ok(out.length >= 1, 'visible-only traversal still reports the visible box');
    assert.ok(out.every((hit) => hit.object === back), 'visible-only traversal skips the hidden front mesh');
    assert.ok(out.every((hit, index) => index === 0 || out[index - 1].distance <= hit.distance), 'hits are nearest first');
    assert.equal(hasVisibleHit(ray, [front]), false, 'hidden-only roots never block');
    assert.equal(hasVisibleHit(ray, [back]), true);
  }
  {
    const a = sharedGeometry('phase-g-test', () => new THREE.BoxGeometry(1, 1, 1));
    const b = sharedGeometry('phase-g-test', () => new THREE.BoxGeometry(2, 2, 2));
    assert.equal(a, b, 'same key returns one shared geometry');
    const m = sharedMaterial('phase-g-test-m', () => new THREE.MeshBasicMaterial());
    assert.equal(sharedMaterial('phase-g-test-m', () => new THREE.MeshBasicMaterial()), m);
    disposeSharedRenderResources();
    assert.notEqual(sharedGeometry('phase-g-test', () => new THREE.BoxGeometry(1, 1, 1)), a, 'disposal clears the cache');
  }
  console.log('Phase G raycasting: hidden meshes are skipped; shared resources are reused and released.');

  // ---------------------------------------------------------------------------------------------
  // 5. Entity construction: no procedural fallback when a model is supplied; no portal lights
  // ---------------------------------------------------------------------------------------------
  const physicsStub = {
    createFixedBox: () => ({}),
    removeRigidBody() {},
    createCharacterCapsule: () => ({
      body: { translation: () => ({ x: 0, y: 0.9, z: 0 }), setNextKinematicTranslation() {}, setTranslation() {} },
      collider: {},
      controller: {
        computeColliderMovement() {},
        computedMovement: () => ({ x: 0, y: 0, z: 0 }),
        computedGrounded: () => false,
        setSlideEnabled() {},
      },
    }),
    removeCharacter() {},
  };
  const countMeshes = (root) => {
    let count = 0;
    root.traverse((object) => { if (object.isMesh) count += 1; });
    return count;
  };
  const countLights = (root) => {
    let count = 0;
    root.traverse((object) => { if (object.isLight) count += 1; });
    return count;
  };

  {
    const withoutModel = new OreNode(ORE_NODE_DEFINITIONS[0], physicsStub, null);
    const withModel = new OreNode(ORE_NODE_DEFINITIONS[0], physicsStub, new THREE.Group());
    assert.ok(countMeshes(withoutModel.visualRoot) > countMeshes(withModel.visualRoot), 'ore node skips procedural rock when a model is supplied');
    assert.equal(withModel.visualRoot.getObjectByName('procedural-ore-fallback'), undefined);
  }
  {
    const withoutModel = new Enemy(ENEMY_DEFINITIONS[ENEMY_SPAWN_ORDER[0]], physicsStub, null);
    const withModel = new Enemy(ENEMY_DEFINITIONS[ENEMY_SPAWN_ORDER[0]], physicsStub, new THREE.Group());
    assert.ok(countMeshes(withoutModel.visualRoot) > countMeshes(withModel.visualRoot), 'enemy skips procedural body when a model is supplied');
  }
  {
    const withoutModel = new ForgeStation(physicsStub, null);
    const withModel = new ForgeStation(physicsStub, new THREE.Group());
    assert.ok(countMeshes(withoutModel.visualRoot) > countMeshes(withModel.visualRoot), 'forge skips procedural body when a model is supplied');
    assert.equal(countLights(withModel.visualRoot), 1, 'forge keeps its one glow light');
  }
  for (const gate of ZONE_GATES) {
    const portal = new ZonePortal(gate);
    assert.equal(countLights(portal.visualRoot), 0, `gate ${gate.id} no longer adds a point light`);
    portal.setUnlocked(false);
    portal.setUnlocked(false);
    portal.setUnlocked(true);
    assert.equal(portal.visualRoot.children.some((child) => child.isSprite), true, 'gate has its glow sprite');
  }
  console.log('Phase G entities: GLB models replace procedural fallbacks, gates carry no point lights, forge keeps its glow.');

  // ---------------------------------------------------------------------------------------------
  // 6. Probe equivalence: one shared centre-ray cast must answer exactly what the old raycasts did
  // ---------------------------------------------------------------------------------------------
  const arenaFloors = ARENA_LAYOUTS.map((arena) => arena.floor);
  const scene = new THREE.Scene();
  const boxMaterial = new THREE.MeshStandardMaterial();
  const cameraOccluders = [];
  for (const box of getStaticBoxes()) {
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(box.halfExtents.x * 2, box.halfExtents.y * 2, box.halfExtents.z * 2),
      boxMaterial,
    );
    mesh.position.set(box.center.x, box.center.y, box.center.z);
    scene.add(mesh);
    cameraOccluders.push(mesh);
  }
  for (const floor of arenaFloors) {
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(floor.halfExtents.x * 2, 0.6, floor.halfExtents.z * 2),
      boxMaterial,
    );
    mesh.position.set(floor.center.x, floor.center.y, floor.center.z);
    scene.add(mesh);
    cameraOccluders.push(mesh);
  }
  const forge = new ForgeStation(physicsStub, null);
  scene.add(forge.visualRoot);
  cameraOccluders.push(forge.visualRoot);
  const portals = ZONE_GATES.map((gate) => new ZonePortal(gate));
  for (const portal of portals) {
    scene.add(portal.visualRoot);
    cameraOccluders.push(portal.visualRoot);
  }
  const oreNodes = ORE_NODE_DEFINITIONS.map((definition) => new OreNode(definition, physicsStub, null));
  for (const node of oreNodes) scene.add(node.visualRoot);
  const enemies = ENEMY_SPAWN_ORDER.map((id) => new Enemy(ENEMY_DEFINITIONS[id], physicsStub, null));
  for (const enemy of enemies) scene.add(enemy.visualRoot);
  const combatOccluders = [...cameraOccluders, ...oreNodes.map((node) => node.visualRoot)];

  // Mirror GameApp's registration order: portals first, so they keep their portal owner.
  const probe = new InteractionProbe();
  for (const portal of portals) probe.register(portal.visualRoot, { kind: 'portal', portal });
  for (const node of oreNodes) probe.register(node.visualRoot, { kind: 'ore', node });
  for (const enemy of enemies) probe.register(enemy.visualRoot, { kind: 'enemy', enemy });
  for (const occluder of cameraOccluders) probe.register(occluder, { kind: 'static' });

  const zones = ARENA_LAYOUTS.map((arena) => arena.zoneId);
  const portalRoots = new Set(portals.map((portal) => portal.visualRoot));

  function visibleChain(object) {
    for (let current = object; current; current = current.parent) {
      if (!current.visible) return false;
    }
    return true;
  }

  // The original per-system candidate lists, reproduced from the code that GameApp and the
  // systems built before this change. Hidden objects are removed, which is the intended fix.
  function referenceFirstHit(target, zone, camera) {
    const reach = { mining: 36, combat: 40, portal: 36, forge: 36 }[target];
    const oreActive = oreNodes.filter((node) => node.zoneId === zone && node.isAvailable()).map((node) => node.visualRoot);
    const enemiesAlive = enemies.filter((enemy) => enemy.definition.zoneId === zone && enemy.isAlive()).map((enemy) => enemy.visualRoot);
    const enemiesInZone = enemies.filter((enemy) => enemy.definition.zoneId === zone).map((enemy) => enemy.visualRoot);
    const portalsActive = portals.filter((portal) => portal.sourceZoneId === zone).map((portal) => portal.visualRoot);
    let candidates;
    switch (target) {
      case 'mining': candidates = [...cameraOccluders, ...oreActive]; break;
      case 'combat': candidates = [...combatOccluders, ...enemiesAlive]; break;
      case 'portal': candidates = [
        ...cameraOccluders.filter((object) => !portalRoots.has(object)),
        ...portalsActive,
        ...oreActive,
        ...enemiesAlive,
      ]; break;
      case 'forge': candidates = [...cameraOccluders, ...oreActive, ...enemiesInZone]; break;
      default: throw new Error(target);
    }
    const ray = new THREE.Raycaster(camera.position.clone(), new THREE.Vector3(), 0, reach);
    ray.setFromCamera(new THREE.Vector2(0, 0), camera);
    ray.far = reach;
    const hit = ray.intersectObjects(candidates, true).find((h) => visibleChain(h.object) && h.distance <= reach);
    return hit ?? null;
  }

  // Deterministic PRNG so failures are reproducible.
  let seed = 0x9e3779b9;
  const random = () => {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const pick = (items) => items[Math.floor(random() * items.length)];
  const arenaFor = (zone) => ARENA_LAYOUTS.find((arena) => arena.zoneId === zone);

  const camera = new THREE.PerspectiveCamera(58, 16 / 9, 0.1, 100);
  const counts = { mining: 0, combat: 0, portal: 0, forge: 0 };
  const TRIALS = 500;
  for (let trial = 0; trial < TRIALS; trial += 1) {
    // Restore every ore node, then deplete a random subset so hidden nodes are exercised.
    for (const node of oreNodes) node.update(1e6);
    for (const node of oreNodes) if (random() < 0.4) node.mine(1e6);
    // Randomise enemy positions across the arenas.
    for (const enemy of enemies) {
      const arena = arenaFor(enemy.definition.zoneId);
      enemy.visualRoot.position.set(
        arena.floor.center.x + (random() - 0.5) * 20,
        0,
        arena.floor.center.z + (random() - 0.5) * 20,
      );
    }
    const zone = pick(zones);
    const arena = arenaFor(zone);
    camera.position.set(
      arena.floor.center.x + (random() - 0.5) * 22,
      1.2 + random() * 4,
      arena.floor.center.z + (random() - 0.5) * 22,
    );
    camera.lookAt(
      arena.floor.center.x + (random() - 0.5) * 30,
      random() * 2.5,
      arena.floor.center.z + (random() - 0.5) * 30,
    );
    camera.updateMatrixWorld(true);
    scene.updateMatrixWorld(true);

    probe.beginFrame(camera);
    for (const target of ['mining', 'combat', 'portal', 'forge']) {
      const expected = referenceFirstHit(target, zone, camera);
      const actual = probe.firstHit(target, zone);
      assert.equal(actual?.object ?? null, expected?.object ?? null, `trial ${trial} ${target}: same object`);
      if (expected) assert.ok(Math.abs(actual.distance - expected.distance) < 1e-9, `trial ${trial} ${target}: same distance`);
      if (expected) counts[target] += 1;
    }
  }
  for (const [target, hits] of Object.entries(counts)) {
    assert.ok(hits >= 30, `${target} produced ${hits} hits; the randomised scenes must exercise it`);
  }
  console.log(`Phase G probe equivalence: ${TRIALS} randomised scenes match the original per-system raycasts `
    + `(hits: mining ${counts.mining}, combat ${counts.combat}, portal ${counts.portal}, forge ${counts.forge}).`);

  // ---------------------------------------------------------------------------------------------
  // 7. The bug the visibility fix removes: a depleted node in front of a creature must not hide it
  // ---------------------------------------------------------------------------------------------
  {
    // Isolate the interaction: hide the static scenery so only the node and the creature are on the ray.
    const staticScenery = [...cameraOccluders];
    const sceneryVisibility = staticScenery.map((object) => object.visible);
    for (const object of staticScenery) object.visible = false;

    const enemy = enemies[0];
    const zone = enemy.definition.zoneId;
    const arena = arenaFor(zone);
    const node = oreNodes.find((candidate) => candidate.zoneId === zone);
    const cx = arena.floor.center.x;
    const cz = arena.floor.center.z;
    enemy.visualRoot.position.set(cx, 0, cz - 8);
    node.visualRoot.position.set(cx, 0, cz - 4);
    // A sightline that crosses the rock (which spans the ground to about y 1.3) and then the
    // creature's body (whose bounds reach about y 0.64 at z = cz - 8).
    camera.position.set(cx, 0.9, cz);
    camera.lookAt(cx, 0.3, cz - 8);
    camera.updateMatrixWorld(true);
    scene.updateMatrixWorld(true);

    node.update(1e6);
    probe.beginFrame(camera);
    assert.equal(probe.firstHit('combat', zone)?.object.userData['oreNodeId'], node.id, 'a live node in front blocks the creature');

    node.mine(1e6);
    scene.updateMatrixWorld(true);
    probe.beginFrame(camera);
    const hit = probe.firstHit('combat', zone);
    assert.ok(hit, 'after depletion the creature is targetable');
    assert.equal(hit.object.userData['enemyId'], enemy.id, 'the hidden depleted node no longer blocks the creature');
    node.update(1e6);

    staticScenery.forEach((object, index) => { object.visible = sceneryVisibility[index]; });
  }
  console.log('Phase G targeting: hidden depleted ore no longer blocks creatures.');

  console.log('Phase G tests passed: render tiers, adaptive resolution, DOM write dedupe, visible-only picking, '
    + 'GLB-first entity construction, gate lights removed, and single-ray probe equivalence.');
} finally {
  rmSync(outputDirectory, { recursive: true, force: true });
}
