import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outputDirectory = mkdtempSync(join(tmpdir(), 'forgebound-phase-j2-'));

try {
  const sourceFiles = [
    'src/types/resources.ts',
    'src/types/equipment.ts',
    'src/types/combat.ts',
    'src/types/zones.ts',
    'src/assets/asset-manifest.ts',
    'src/data/equipment-data.ts',
    'src/data/zone-data.ts',
    'src/data/quest-data.ts',
    'src/data/quest-world-data.ts',
    'src/data/npc-data.ts',
    'src/data/shop-data.ts',
    'src/world/open-world-config.ts',
    'src/world/terrain-height.ts',
    'src/systems/Inventory.ts',
    'src/systems/ProgressionSystem.ts',
    'src/systems/ZoneProgressionSystem.ts',
    'src/systems/QuestSystem.ts',
    'src/systems/MiniGameSystem.ts',
    'src/systems/ShopSystem.ts',
    'src/systems/WeaponRefinementSystem.ts',
    'src/systems/SaveSystem.ts',
  ];
  execFileSync(process.platform === 'win32' ? 'tsc.cmd' : 'tsc', [
'--strict', '--target', 'ES2022', '--module', 'commonjs',
    '--moduleResolution', 'node', '--skipLibCheck', '--typeRoots', outputDirectory,
    '--outDir', outputDirectory, ...sourceFiles,
  ], { cwd: projectRoot, stdio: 'inherit', shell: process.platform === 'win32' });
  writeFileSync(join(outputDirectory, 'package.json'), '{"type":"commonjs"}');

  const require = createRequire(import.meta.url);
  const { NPC_DEFINITIONS } = require(join(outputDirectory, 'data/npc-data.js'));
  const { QUEST_DEFINITIONS, QUEST_BY_ID } = require(join(outputDirectory, 'data/quest-data.js'));
  const { QUEST_WORLD_OBJECTS } = require(join(outputDirectory, 'data/quest-world-data.js'));
  const { ShopSystem } = require(join(outputDirectory, 'systems/ShopSystem.js'));
  const { WeaponRefinementSystem } = require(join(outputDirectory, 'systems/WeaponRefinementSystem.js'));
  const { QuestSystem, createEmptyQuestSnapshot, validateQuestSnapshot } = require(join(outputDirectory, 'systems/QuestSystem.js'));
  const { createEmptyMiniGameSnapshot } = require(join(outputDirectory, 'systems/MiniGameSystem.js'));
  const { createEmptyDungeonSnapshot } = require(join(outputDirectory, 'systems/DungeonProgressSystem.js'));
  const { Inventory } = require(join(outputDirectory, 'systems/Inventory.js'));
  const { ProgressionSystem } = require(join(outputDirectory, 'systems/ProgressionSystem.js'));
  const { ZoneProgressionSystem } = require(join(outputDirectory, 'systems/ZoneProgressionSystem.js'));
  const { SaveSystem, SAVE_SCHEMA_VERSION, SAVE_STORAGE_KEY, PREVIOUS_SAVE_STORAGE_KEY, createSaveData, validateSaveData } = require(join(outputDirectory, 'systems/SaveSystem.js'));

  assert.equal(NPC_DEFINITIONS.length, 23, 'the 22 legacy NPCs plus Ben must be present');
  assert.equal(new Set(NPC_DEFINITIONS.map((npc) => npc.id)).size, 23, 'NPC ids must be unique');
  assert.equal(new Set(NPC_DEFINITIONS.map((npc) => npc.name)).size, 23, 'NPC names must be unique');
  for (const zoneId of ['starter-quarry', 'molten-caves', 'crystal-peaks']) {
    const zoneNpcs = NPC_DEFINITIONS.filter((npc) => npc.zoneId === zoneId);
    assert.equal(zoneNpcs.filter((npc) => ['combat', 'mining', 'blacksmith', 'pickaxe-shop', 'weapon-refiner'].includes(npc.role)).length, 5, `${zoneId} must have all five dedicated service roles`);
  }
  assert.equal(NPC_DEFINITIONS.filter((npc) => npc.role === 'secondary').length, 7, 'all seven requested secondary NPCs must be present');
  assert.equal(QUEST_DEFINITIONS.length, 22, 'all authored NPC quests must be present');
  assert.equal(new Set(QUEST_DEFINITIONS.map((quest) => quest.id)).size, 22, 'quest ids must be unique');
  for (const npc of NPC_DEFINITIONS.filter((entry) => entry.role !== 'tutorial')) {
    assert.ok(QUEST_BY_ID[npc.questId], `${npc.name} must have a registered quest`);
    assert.equal(QUEST_BY_ID[npc.questId].npcId, npc.id, `${npc.name}'s quest must point back to its giver`);
  }
  assert.ok(QUEST_WORLD_OBJECTS.some((object) => object.id === 'timber-pile-8'), 'Timberline must provide eight collectible bundles so concurrent timber quests can both be turned in');
  assert.equal(QUEST_WORLD_OBJECTS.filter((object) => object.collectResource === 'timber').length, 8);
  assert.equal(QUEST_WORLD_OBJECTS.filter((object) => object.objectId === 'billy-clutter').length, 5);
  assert.equal(QUEST_WORLD_OBJECTS.filter((object) => object.objectId === 'geothermal-vent-control').length, 3);
  assert.equal(QUEST_WORLD_OBJECTS.filter((object) => object.objectId === 'magma-corn-plant').length, 6);

  const quests = new QuestSystem();
  const mainQuest = 'zone1-main-quarry-wakes';
  assert.equal(quests.getStatus(mainQuest, 'starter-quarry', 1), 'available');
  assert.equal(quests.accept(mainQuest, 'starter-quarry', 1).ok, true);
  assert.equal(quests.canProgress({ type: 'mine', resourceId: 'copper-ore', amount: 4 }), true);
  quests.record({ type: 'mine', resourceId: 'copper-ore', amount: 4 });
  quests.record({ type: 'mine', resourceId: 'iron-ore', amount: 2 });
  quests.record({ type: 'defeat', enemyId: 'quarry-crawler' });
  assert.equal(quests.getStatus(mainQuest, 'starter-quarry', 1), 'active');
  assert.equal(quests.canProgress({ type: 'interact', objectId: 'quarry-relay' }), true);
  quests.record({ type: 'interact', objectId: 'quarry-relay' });
  assert.equal(quests.getStatus(mainQuest, 'starter-quarry', 1), 'ready-to-turn-in');
  let mainRewardCommits = 0;
  assert.equal(quests.complete(mainQuest, () => { mainRewardCommits += 1; return true; }).ok, true);
  assert.equal(quests.complete(mainQuest, () => { mainRewardCommits += 1; return true; }).ok, false);
  assert.equal(mainRewardCommits, 1, 'quest rewards must commit once');
  assert.equal(quests.isCompleted(mainQuest), true);
  assert.equal(quests.getStatus('zone2-main-heart-furnace', 'molten-caves', 3), 'available');
  assert.equal(quests.getStatus('zone3-main-crown-peaks', 'crystal-peaks', 5), 'locked');

  // Michael's message must be delivered to Jason before the player reports back to Michael.
  const messageQuest = 'zone2-michael-sealed-word';
  assert.equal(quests.accept(messageQuest, 'molten-caves', 3).ok, true);
  quests.record({ type: 'talk', npcId: 'michael' });
  assert.equal(quests.getObjectiveViews(messageQuest)[0].complete, false);
  quests.record({ type: 'talk', npcId: 'jason' });
  assert.equal(quests.getObjectiveViews(messageQuest)[0].complete, true);
  quests.record({ type: 'talk', npcId: 'michael' });
  assert.equal(quests.getStatus(messageQuest, 'molten-caves', 3), 'ready-to-turn-in');

  // Objects cannot be consumed before an accepted quest has an objective that uses them.
  const objectQuest = 'zone1-billy-backyard';
  const clutterEvent = { type: 'interact', objectId: 'billy-clutter' };
  const cleanQuestSystem = new QuestSystem();
  assert.equal(cleanQuestSystem.canProgress(clutterEvent), false);
  assert.equal(cleanQuestSystem.accept(objectQuest, 'starter-quarry', 1).ok, true);
  assert.equal(cleanQuestSystem.canProgress(clutterEvent), true);
  for (let index = 0; index < 5; index += 1) cleanQuestSystem.record(clutterEvent);
  assert.equal(cleanQuestSystem.getStatus(objectQuest, 'starter-quarry', 1), 'ready-to-turn-in');
  assert.equal(cleanQuestSystem.complete(objectQuest, () => false).ok, false, 'failed reward transaction must leave the quest ready to turn in');
  assert.equal(cleanQuestSystem.getStatus(objectQuest, 'starter-quarry', 1), 'ready-to-turn-in');

  const usedObjectId = 'billy-clutter-1';
  cleanQuestSystem.markWorldObjectUsed(usedObjectId);
  const snapshot = cleanQuestSystem.snapshot();
  assert.equal(validateQuestSnapshot(snapshot), true);
  assert.deepEqual(snapshot.usedWorldObjectIds, [usedObjectId]);
  const restoredQuests = new QuestSystem();
  assert.equal(restoredQuests.restore(JSON.parse(JSON.stringify(snapshot))), true);
  assert.equal(restoredQuests.isWorldObjectUsed(usedObjectId), true);
  assert.equal(restoredQuests.getStatus(objectQuest, 'starter-quarry', 1), 'ready-to-turn-in');
  assert.equal(validateQuestSnapshot({ ...snapshot, acceptedQuestIds: ['unknown-quest'] }), false);
  const incompleteObjectives = JSON.parse(JSON.stringify(snapshot));
  delete incompleteObjectives.progress[objectQuest].clutter;
  assert.equal(validateQuestSnapshot(incompleteObjectives), false, 'save validation must reject truncated objective state');
  assert.deepEqual(createEmptyQuestSnapshot(), { acceptedQuestIds: [], completedQuestIds: [], progress: {}, usedWorldObjectIds: [] });

  // Save/load preserves accepted quest progress and used world-object state.
  const inventory = new Inventory();
  const progression = new ProgressionSystem();
  const zones = new ZoneProgressionSystem();
  const capture = {
    playerHealth: 100,
    progression: progression.snapshot(),
    inventory: inventory.snapshot(),
    currentZoneId: zones.getCurrentZoneId(),
    questState: snapshot,
    miniGameState: createEmptyMiniGameSnapshot(),
    dungeonState: createEmptyDungeonSnapshot(),
  };
  const data = createSaveData(capture, 1_700_000_000_000);
  assert.equal(data.schemaVersion, SAVE_SCHEMA_VERSION);
  assert.equal(validateSaveData(data).ok, true);
  assert.deepEqual(validateSaveData(JSON.parse(JSON.stringify(data))).data.questState, snapshot);
  const storage = new Map();
  const storageAdapter = {
    getItem: (key) => storage.get(key) ?? null,
    setItem: (key, value) => storage.set(key, value),
    removeItem: (key) => storage.delete(key),
  };
  const saveSystem = new SaveSystem(storageAdapter);
  assert.equal(saveSystem.save(data).ok, true);
  const loaded = saveSystem.load();
  assert.equal(loaded.status, 'loaded');
  assert.deepEqual(loaded.data.questState, snapshot);
  assert.equal(storage.has(SAVE_STORAGE_KEY), true);

  // Schema-v2 save migration retains old resources/Coins and creates empty quest progress.
  const v2 = JSON.parse(JSON.stringify(data));
  v2.schemaVersion = 2;
  delete v2.questState;
  delete v2.inventory.weaponRefinementRank;
  v2.inventory.resources = Object.fromEntries(Object.entries(v2.inventory.resources).filter(([id]) =>
    ['copper-ore', 'iron-ore', 'gold-ore', 'crystal', 'copper-ingot', 'iron-ingot', 'gold-ingot'].includes(id)));
  storage.clear();
  storage.set(PREVIOUS_SAVE_STORAGE_KEY, JSON.stringify(v2));
  const migrated = saveSystem.load();
  assert.equal(migrated.status, 'migrated');
  assert.equal(migrated.data.inventory.coins, data.inventory.coins);
  assert.equal(migrated.data.inventory.weaponRefinementRank, 0);
  assert.deepEqual(migrated.data.questState, createEmptyQuestSnapshot());
  assert.equal(migrated.data.inventory.resources.timber, 0);

  // The quest supply reward unlocks Tovin's pickaxe stock; Coins are charged exactly once.
  const commerceInventory = new Inventory(500);
  const shop = new ShopSystem(commerceInventory);
  const supplyQuestSystem = new QuestSystem();
  assert.equal(shop.getStock('starter-quarry', 1, (id) => supplyQuestSystem.isCompleted(id)).length, 0);
  assert.equal(shop.purchase('copper-pickaxe', 'starter-quarry', 1, (id) => supplyQuestSystem.isCompleted(id)).ok, false);
  assert.equal(commerceInventory.getCoins(), 500, 'blocked stock must not charge Coins');
  assert.equal(supplyQuestSystem.accept('zone1-pickaxe-better-bite', 'starter-quarry', 1).ok, true);
  supplyQuestSystem.record({ type: 'collect', resourceId: 'timber', amount: 2 });
  supplyQuestSystem.record({ type: 'smelt', resourceId: 'copper-ingot', amount: 1 });
  assert.equal(commerceInventory.add('timber', 2).ok, true);
  assert.equal(commerceInventory.add('copper-ingot', 1).ok, true);
  assert.equal(supplyQuestSystem.complete('zone1-pickaxe-better-bite', () => commerceInventory.transactResourcesAndCoins(
    { timber: 2, 'copper-ingot': 1 }, {}, 25,
  ).ok).ok, true);
  assert.equal(shop.getStock('starter-quarry', 1, (id) => supplyQuestSystem.isCompleted(id)).some((item) => item.equipmentId === 'copper-pickaxe'), true);
  const beforePurchase = commerceInventory.getCoins();
  assert.equal(shop.purchase('copper-pickaxe', 'starter-quarry', 1, (id) => supplyQuestSystem.isCompleted(id)).ok, true);
  assert.equal(commerceInventory.getCoins(), beforePurchase - 180);
  assert.equal(shop.purchase('copper-pickaxe', 'starter-quarry', 1, (id) => supplyQuestSystem.isCompleted(id)).ok, false, 'shop must reject duplicate ownership');

  // Weapon refinement consumes both materials and Coins, then increases equipped weapon damage.
  const refinementInventory = new Inventory(500);
  const refiner = new WeaponRefinementSystem(refinementInventory);
  const starterDamage = refinementInventory.getEquippedWeapon().attackDamage;
  assert.equal(refiner.refine().ok, false, 'refinement must reject missing materials');
  assert.equal(refinementInventory.getCoins(), 500, 'failed refinement must not charge Coins');
  assert.equal(refinementInventory.add('copper-ingot', 1).ok, true);
  assert.equal(refinementInventory.add('iron-ingot', 1).ok, true);
  const refined = refiner.refine();
  assert.equal(refined.ok, true);
  assert.equal(refined.rank, 1);
  assert.equal(refinementInventory.getEquippedWeapon().attackDamage, starterDamage + 2);
  assert.equal(refinementInventory.getCoins(), 475);

  console.log('Phase J2 tests passed: NPC roster, quest progression, dialogue order, world-object persistence, save migration, Coins shop gating, purchases, and weapon refinement.');
} finally {
  rmSync(outputDirectory, { recursive: true, force: true });
}
