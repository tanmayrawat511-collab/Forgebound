import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const readJson = (relativePath) => JSON.parse(readFileSync(join(root, relativePath), 'utf8'));
const fileSize = (relativePath) => statSync(join(root, relativePath)).size;
const modelManifest = readJson('public/assets/model-manifest.json');
const terrainManifest = readJson('public/assets/terrain/manifest.json');
const dungeonManifest = readJson('public/assets/dungeons/manifest.json');
const assetHashes = readJson('release/asset-sha256.json');
const releaseManifest = readJson('release/release-manifest.json');
const j7ModelManifest = readJson('public/assets/j7-model-manifest.json');
const pkg = readJson('package.json');
const lock = readJson('package-lock.json');

assert.equal(modelManifest.generator, 'tools/generate_assets.py');
assert.equal(modelManifest.generatorRuntime, 'Python + trimesh + numpy');
assert.equal(modelManifest.all3DModelsGeneratedByPython, true);
assert.equal(modelManifest.modelCount, 49);
assert.equal(modelManifest.models.length, modelManifest.modelCount);
for (const model of modelManifest.models) {
  assert.ok(model.path.startsWith('/assets/models/'), `${model.file} must use a local public asset path`);
  const relativePath = `public${model.path}`;
  assert.ok(existsSync(join(root, relativePath)), `Missing model: ${relativePath}`);
  assert.equal(fileSize(relativePath), model.bytes, `Model byte count mismatch: ${model.file}`);
}

assert.equal(terrainManifest.generator, 'tools/generate_assets.py');
assert.equal(terrainManifest.format, 'glb');
assert.equal(terrainManifest.playableAreaSquareMeters, 7_000_000);
assert.equal(terrainManifest.playableAreaSquareKilometers, 7);
assert.equal(terrainManifest.chunksPerAxis, 11);
assert.equal(terrainManifest.chunks.length, 363);
const expectedZones = ['starter-quarry', 'molten-caves', 'crystal-peaks'];
for (const zoneId of expectedZones) {
  const chunks = terrainManifest.chunks.filter((chunk) => chunk.zoneId === zoneId);
  assert.equal(chunks.length, 121, `${zoneId} must have 121 terrain chunks`);
  assert.equal(new Set(chunks.map((chunk) => `${chunk.x},${chunk.z}`)).size, 121);
  assert.deepEqual(new Set(chunks.map((chunk) => chunk.x)), new Set(Array.from({ length: 11 }, (_, i) => i)));
  assert.deepEqual(new Set(chunks.map((chunk) => chunk.z)), new Set(Array.from({ length: 11 }, (_, i) => i)));
  const coveredArea = chunks.reduce((area, chunk) => area + chunk.width * chunk.depth, 0);
  assert.ok(Math.abs(coveredArea - 7_000_000) < 0.1, `${zoneId} tile bounds must cover exactly 7 km²`);
  for (const chunk of chunks) {
    assert.ok(chunk.width > 0 && chunk.width <= 256);
    assert.ok(chunk.depth > 0 && chunk.depth <= 256);
    const relativePath = `public${chunk.file}`;
    assert.ok(chunk.file.startsWith(`/assets/terrain/${zoneId}/`));
    assert.ok(existsSync(join(root, relativePath)), `Missing terrain chunk: ${relativePath}`);
    assert.equal(fileSize(relativePath), chunk.bytes, `Terrain byte count mismatch: ${chunk.file}`);
  }
}

assert.equal(dungeonManifest.generator, 'tools/generate_dungeons.py');
assert.equal(dungeonManifest.allInteriorGeometryGeneratedByPython, true);
assert.equal(dungeonManifest.interiorCount, 7);
assert.equal(dungeonManifest.interiors.length, 7);
assert.equal(dungeonManifest.interiors.reduce((sum, interior) => sum + interior.poiIds.length, 0), 21);
for (const interior of dungeonManifest.interiors) {
  const relativePath = `public/assets/dungeons/${interior.file}`;
  assert.ok(existsSync(join(root, relativePath)), `Missing dungeon: ${relativePath}`);
  assert.equal(fileSize(relativePath), interior.bytes, `Dungeon byte count mismatch: ${interior.file}`);
  assert.equal(interior.poiIds.length, 3, `${interior.id} must have three exploration points`);
}

// Check every shipped GLB header and ensure all shipped assets are accounted for by manifests.
function walk(directory) {
  return readdirSync(join(root, directory), { withFileTypes: true }).flatMap((entry) => {
    const relative = join(directory, entry.name);
    return entry.isDirectory() ? walk(relative) : [relative.replaceAll('\\', '/')];
  });
}
const glbFiles = walk('public/assets').filter((path) => path.toLowerCase().endsWith('.glb'));
const j7Paths = new Set(j7ModelManifest.models.map((model) => `public${model.path}`));
const j6GlbFiles = glbFiles.filter((path) => !j7Paths.has(path));
assert.equal(glbFiles.length, 460, 'J7 adds 41 GLBs to the 419-file J6 asset pack');
assert.equal(j6GlbFiles.length, 419, 'All 419 legacy GLBs must remain present');
assert.equal(j7ModelManifest.phase, 'J7');
assert.equal(j7ModelManifest.modelCount, 41);
assert.equal(j7ModelManifest.models.length, 41);
for (const model of j7ModelManifest.models) {
  const relativePath = `public${model.path}`;
  assert.ok(existsSync(join(root, relativePath)), `Missing J7 model: ${relativePath}`);
  assert.equal(fileSize(relativePath), model.bytes, `J7 model byte count mismatch: ${model.file}`);
  const bytes = readFileSync(join(root, relativePath));
  assert.equal(bytes.toString('ascii', 0, 4), 'glTF');
  assert.equal(bytes.readUInt32LE(4), 2);
  assert.equal(bytes.readUInt32LE(8), bytes.length);
}
assert.equal(assetHashes.algorithm, 'SHA-256');
assert.equal(assetHashes.assetCount, 419);
assert.equal(assetHashes.assets.length, 419);
assert.equal(assetHashes.geometryAudit.failedFiles.length, 0);
assert.equal(releaseManifest.game, 'ForgeBound');
assert.equal(releaseManifest.phase, 'J6');
assert.equal(releaseManifest.releaseStatus, 'candidate-not-release-ready');
assert.equal(releaseManifest.releaseGate.canShip, false, 'A candidate must not be labelled shippable while runtime gates are blocked');
assert.equal(releaseManifest.assetInventory.totalGlbFiles, 419);
assert.equal(releaseManifest.checks.offlineRegressionSuites.status, 'passed');
assert.ok(releaseManifest.releaseGate.remainingRequirements.length > 0);
const manifested = new Set([
  ...modelManifest.models.map((model) => `public${model.path}`),
  ...terrainManifest.chunks.map((chunk) => `public${chunk.file}`),
  ...dungeonManifest.interiors.map((interior) => `public/assets/dungeons/${interior.file}`),
]);
assert.equal(manifested.size, 419, 'Every GLB path must be represented exactly once in a manifest');
const digestByPath = new Map(assetHashes.assets.map((asset) => [asset.path, asset]));
for (const path of j6GlbFiles) {
  assert.ok(manifested.has(path), `Unmanifested GLB: ${path}`);
  const bytes = readFileSync(join(root, path));
  assert.equal(bytes.toString('ascii', 0, 4), 'glTF', `Invalid GLB magic: ${path}`);
  assert.equal(bytes.readUInt32LE(4), 2, `Unsupported GLB version: ${path}`);
  assert.equal(bytes.readUInt32LE(8), bytes.length, `GLB header byte length mismatch: ${path}`);
  const digest = digestByPath.get(path);
  assert.ok(digest, `Missing SHA-256 entry for ${path}`);
  assert.equal(digest.bytes, bytes.length, `Integrity manifest size mismatch: ${path}`);
  assert.equal(createHash('sha256').update(bytes).digest('hex'), digest.sha256, `SHA-256 mismatch: ${path}`);
}

// Save schema and legacy migration entry points must remain present in the release branch.
const saveSystem = readFileSync(join(root, 'src/systems/SaveSystem.ts'), 'utf8');
assert.match(saveSystem, /SAVE_SCHEMA_VERSION\s*=\s*6/);
for (const version of [0, 1, 2, 3, 4, 5]) {
  assert.match(saveSystem, new RegExp(`schemaVersion[^\\n]{0,80}=== ${version}`), `Load path for save schema ${version} is missing`);
}
assert.match(saveSystem, /SAVE_STORAGE_KEY\s*=\s*'forgebound\.save\.v6'/);
assert.match(saveSystem, /migrateVersionFiveSaveData/);

// The Options menu must expose Animations and never retain the superseded OpenGL setting.
const html = readFileSync(join(root, 'index.html'), 'utf8');
const gameSettings = readFileSync(join(root, 'src/systems/GameSettings.ts'), 'utf8');
const gameApp = readFileSync(join(root, 'src/core/GameApp.ts'), 'utf8');
assert.match(html, />Animations</);
assert.doesNotMatch(html, /Advanced OpenGL/i);
assert.match(gameSettings, /animations:\s*boolean/);
assert.match(gameApp, /setAnimationsEnabled\(/);
const ids = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map((match) => match[1]);
assert.equal(new Set(ids).size, ids.length, 'HTML IDs must be unique');

// Dependency declarations and lockfile must be synchronized and exact-pinned.
for (const group of ['dependencies', 'devDependencies']) {
  for (const [name, version] of Object.entries(pkg[group] ?? {})) {
    assert.equal(lock.packages[`node_modules/${name}`]?.version, version, `${name} lockfile version mismatch`);
    assert.match(version, /^\d+\.\d+\.\d+$/, `${name} must remain exact-pinned`);
  }
}
for (const scriptName of ['test:phase-j6', 'test:offline', 'verify:offline', 'assets:verify', 'typecheck', 'build', 'test']) {
  assert.ok(pkg.scripts[scriptName], `Missing package script: ${scriptName}`);
}

console.log('Phase J6 compatibility and J7 asset integrity passed: 49 Python gameplay models, 363 terrain tiles covering 21 km², 7 interiors, 21 POIs, 419 legacy GLBs with SHA-256 digests, 41 J7 GLBs, save schema v6 migrations, Animations setting wiring, unique UI IDs, synchronized pinned dependencies, and an explicit blocked release-candidate manifest.');
