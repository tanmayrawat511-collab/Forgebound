import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync, existsSync } from 'node:fs';
import { createRequire } from 'node:module';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outputDirectory = mkdtempSync(join(tmpdir(), 'forgebound-phase-f-'));

try {
  const sourceFiles = [
    'src/types/resources.ts',
    'src/types/equipment.ts',
    'src/types/zones.ts',
    'src/types/combat.ts',
    'src/data/equipment-data.ts',
    'src/data/zone-data.ts',
    'src/systems/Inventory.ts',
    'src/systems/ProgressionSystem.ts',
    'src/systems/ZoneProgressionSystem.ts',
    'src/systems/SaveSystem.ts',
  ];
  execFileSync(process.platform === 'win32' ? 'tsc.cmd' : 'tsc', [
    '--strict',
    '--target', 'ES2022',
    '--module', 'commonjs',
    '--moduleResolution', 'node',
    '--skipLibCheck',
    '--typeRoots', outputDirectory,
    '--outDir', outputDirectory,
    ...sourceFiles,
  ], { cwd: projectRoot, stdio: 'inherit', shell: process.platform === 'win32' });
  writeFileSync(join(outputDirectory, 'package.json'), '{"type":"commonjs"}');

  const require = createRequire(import.meta.url);
  const { Inventory } = require(join(outputDirectory, 'systems/Inventory.js'));
  const { ProgressionSystem } = require(join(outputDirectory, 'systems/ProgressionSystem.js'));
  const { ZoneProgressionSystem } = require(join(outputDirectory, 'systems/ZoneProgressionSystem.js'));
  const { createEmptyQuestSnapshot } = require(join(outputDirectory, 'systems/QuestSystem.js'));
  const { createEmptyMiniGameSnapshot } = require(join(outputDirectory, 'systems/MiniGameSystem.js'));
  const { createEmptyDungeonSnapshot } = require(join(outputDirectory, 'systems/DungeonProgressSystem.js'));
  const {
    SAVE_SCHEMA_VERSION,
    SAVE_STORAGE_KEY,
    SaveSystem,
    createSaveData,
    validateSaveData,
  } = require(join(outputDirectory, 'systems/SaveSystem.js'));

  const inventory = new Inventory();
  assert.equal(inventory.add('copper-ore', 14).ok, true);
  assert.equal(inventory.add('iron-ingot', 3).ok, true);
  assert.equal(inventory.craftEquipment({ 'copper-ingot': 0 }, 'copper-pickaxe').ok, true);
  assert.equal(inventory.equip('copper-pickaxe').ok, true);

  const progression = new ProgressionSystem();
  progression.awardXp(145);
  assert.equal(progression.snapshot().level, 3);
  assert.equal(progression.snapshot().currentXp, 10);
  const zones = new ZoneProgressionSystem();
  assert.equal(zones.setCurrentZone('molten-caves', 3), true);

  const capture = {
    playerHealth: 73,
    progression: progression.snapshot(),
    inventory: inventory.snapshot(),
    currentZoneId: zones.getCurrentZoneId(),
    questState: createEmptyQuestSnapshot(),
    miniGameState: createEmptyMiniGameSnapshot(),
    dungeonState: createEmptyDungeonSnapshot(),
  };
  const data = createSaveData(capture, 1_700_000_000_000);
  assert.equal(data.schemaVersion, SAVE_SCHEMA_VERSION);
  assert.equal(data.checkpointId, 'molten-caves');
  assert.deepEqual(data.unlockedZoneIds, ['starter-quarry', 'molten-caves']);
  assert.equal(validateSaveData(data).ok, true);
  assert.equal(validateSaveData(JSON.parse(JSON.stringify(data))).ok, true, 'serialized save must round-trip');

  const restoredInventory = new Inventory();
  assert.equal(restoredInventory.restore(data.inventory).ok, true);
  assert.deepEqual(restoredInventory.snapshot(), inventory.snapshot());
  const oldSnapshot = restoredInventory.snapshot();
  const invalidInventory = {
    ...data.inventory,
    resources: { ...data.inventory.resources, 'copper-ore': -1 },
  };
  assert.equal(restoredInventory.restore(invalidInventory).ok, false);
  assert.deepEqual(restoredInventory.snapshot(), oldSnapshot, 'failed restore must not partially mutate inventory');

  const restoredProgression = new ProgressionSystem();
  assert.equal(restoredProgression.restore(data.progression), true);
  assert.deepEqual(restoredProgression.snapshot(), progression.snapshot());
  assert.equal(restoredProgression.restore({ level: 5, currentXp: 1, totalXp: 1 }), false);
  const restoredZones = new ZoneProgressionSystem();
  assert.equal(restoredZones.setCurrentZone(data.currentZoneId, data.progression.level), true);
  assert.equal(restoredZones.getCurrentZoneId(), 'molten-caves');

  const legacy = {
    ...data,
    schemaVersion: 0,
  };
  delete legacy.checkpointId;
  delete legacy.unlockedZoneIds;
  const migrated = validateSaveData(legacy);
  assert.equal(migrated.ok, false, 'current-schema validator must not silently accept legacy data');
  const { migrateSaveData } = require(join(outputDirectory, 'systems/SaveSystem.js'));
  const migration = migrateSaveData(legacy);
  assert.equal(migration.ok, true);
  assert.equal(migration.migrated, true);
  assert.equal(migration.data.checkpointId, 'molten-caves');
  assert.deepEqual(migration.data.unlockedZoneIds, ['starter-quarry', 'molten-caves']);

  const badHealth = { ...data, playerHealth: 0 };
  assert.equal(validateSaveData(badHealth).ok, false);
  const badStack = {
    ...data,
    inventory: {
      ...data.inventory,
      resources: { ...data.inventory.resources, 'gold-ore': 10_000 },
    },
  };
  assert.equal(validateSaveData(badStack).ok, false);
  const badZone = { ...data, currentZoneId: 'crystal-peaks', checkpointId: 'crystal-peaks' };
  assert.equal(validateSaveData(badZone).ok, false, 'level 3 cannot restore into level 5 zone');
  assert.equal(validateSaveData({ ...data, schemaVersion: 88 }).ok, false);

  const map = new Map();
  const storage = {
    getItem(key) { return map.has(key) ? map.get(key) : null; },
    setItem(key, value) { map.set(key, value); },
    removeItem(key) { map.delete(key); },
  };
  const saves = new SaveSystem(storage);
  assert.deepEqual(saves.load(), { status: 'new' });
  assert.equal(saves.save(data).ok, true);
  assert.equal(map.has(SAVE_STORAGE_KEY), true);
  const loaded = saves.load();
  assert.equal(loaded.status, 'loaded');
  assert.deepEqual(loaded.data.inventory.resources, data.inventory.resources);
  assert.equal(saves.clear().ok, true);
  assert.equal(saves.load().status, 'new');
  map.set(SAVE_STORAGE_KEY, '{broken json');
  assert.equal(saves.load().status, 'invalid', 'malformed JSON should be recoverable, not fatal');
  map.set(SAVE_STORAGE_KEY, JSON.stringify({ ...data, schemaVersion: 73 }));
  assert.equal(saves.load().status, 'invalid', 'unsupported schema versions should be rejected');
  map.delete(SAVE_STORAGE_KEY);

  const throwingStorage = {
    getItem() { throw new Error('blocked'); },
    setItem() { throw new Error('blocked'); },
    removeItem() { throw new Error('blocked'); },
  };
  const unavailable = new SaveSystem(throwingStorage);
  assert.equal(unavailable.load().status, 'unavailable');
  assert.equal(unavailable.save(data).ok, false);
  assert.equal(unavailable.clear().ok, false);

  const assetFiles = [
    'player.glb', 'ore-copper.glb', 'ore-iron.glb', 'ore-gold.glb', 'ore-crystal.glb',
    'pickaxe.glb', 'weapon-sword.glb', 'weapon-hammer.glb', 'enemy-crawler.glb',
    'enemy-ember.glb', 'enemy-guardian.glb', 'forge.glb',
  ];
  for (const filename of assetFiles) {
    const assetPath = join(projectRoot, 'public/assets/models', filename);
    assert.equal(existsSync(assetPath), true, `${filename} should be generated and included`);
    const bytes = readFileSync(assetPath);
    assert.equal(bytes.subarray(0, 4).toString('ascii'), 'glTF', `${filename} should have GLB magic`);
    assert.equal(bytes.readUInt32LE(4), 2, `${filename} should be glTF 2.0`);
    assert.equal(bytes.readUInt32LE(8), bytes.length, `${filename} binary length header should match`);
  }
  assert.equal(existsSync(join(projectRoot, 'tools/generate_assets.py')), true);

  const html = readFileSync(join(projectRoot, 'index.html'), 'utf8');
  assert.match(html, /id="save-status"/);
  assert.match(html, /id="reset-save"/);

  console.log('Phase F tests passed: validated save/load, schema migration, corrupted data rejection, inventory/progression/zone restoration, storage failures, reset persistence, and all 12 generated local GLB assets.');
} finally {
  rmSync(outputDirectory, { recursive: true, force: true });
}
