import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { existsSync, readFileSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const out = mkdtempSync(join(tmpdir(), 'forgebound-phase-j5-'));
try {
  const sources = [
    'src/systems/SaveSystem.ts',
    'src/systems/GameSettings.ts',
    'src/render/cameraObstruction.ts',
    'src/render/AdaptiveResolution.ts',
    'src/render/qualityTiers.ts',
    'src/render/performancePolicy.ts',
    'src/world/worldPopulationPolicy.ts',
    'src/world/open-world-config.ts',
    'src/world/asyncBatch.ts',
    'src/data/quest-data.ts',
    'src/systems/MiniGameSystem.ts',
    'src/data/dungeon-data.ts',
    'src/data/shop-data.ts',
    'src/data/enemy-data.ts',
    'src/systems/WeaponRefinementSystem.ts',
  ];
  execFileSync('tsc', [
    '--strict', '--noUncheckedIndexedAccess', '--noUnusedLocals', '--noUnusedParameters',
    '--target', 'ES2022', '--module', 'commonjs', '--moduleResolution', 'node',
    '--skipLibCheck', '--typeRoots', out, '--outDir', out, ...sources,
  ], { cwd: projectRoot, stdio: 'inherit' });
  writeFileSync(join(out, 'package.json'), '{"type":"commonjs"}');
  const require = createRequire(import.meta.url);
  const { resolveCameraDistance, approachCameraDistance, DEFAULT_CAMERA_DISTANCE_POLICY } = require(join(out, 'render/cameraObstruction.js'));
  const { AdaptiveResolution } = require(join(out, 'render/AdaptiveResolution.js'));
  const { streamingRadiusForDistance, resolvePerformancePolicy, renderDistanceFarPlane, renderDistanceFogFar } = require(join(out, 'render/performancePolicy.js'));
  const { partitionPlacementsByCell, WORLD_PROP_CELL_SIZE_METRES } = require(join(out, 'world/worldPopulationPolicy.js'));
  const { getTerrainChunkWindow } = require(join(out, 'world/open-world-config.js'));
  const { runBounded } = require(join(out, 'world/asyncBatch.js'));
  const { difficultyCombatProfile, parseGameSettings, DEFAULT_GAME_SETTINGS } = require(join(out, 'systems/GameSettings.js'));
  const { QUEST_DEFINITIONS } = require(join(out, 'data/quest-data.js'));
  const { MINI_GAME_DEFINITIONS } = require(join(out, 'systems/MiniGameSystem.js'));
  const { DUNGEON_DEFINITIONS } = require(join(out, 'data/dungeon-data.js'));
  const { SHOP_STOCK } = require(join(out, 'data/shop-data.js'));
  const { ENEMY_DEFINITIONS } = require(join(out, 'data/enemy-data.js'));
  const { WEAPON_REFINEMENT_PLANS } = require(join(out, 'systems/WeaponRefinementSystem.js'));

  // Camera collision clamps before the near clip plane and chooses the closest finite hit.
  assert.equal(resolveCameraDistance([]), DEFAULT_CAMERA_DISTANCE_POLICY.maximumDistance);
  assert.equal(resolveCameraDistance([{ distance: 4 }, { distance: 2.1 }, { distance: Number.NaN }]), 1.82);
  assert.equal(resolveCameraDistance([{ distance: 0.1 }]), DEFAULT_CAMERA_DISTANCE_POLICY.minimumDistance);
  assert.ok(approachCameraDistance(8.8, 1, 0.05) < approachCameraDistance(8.8, 1, 0.01));
  const inward = approachCameraDistance(8.8, 1, 0.05);
  const outward = approachCameraDistance(1, 8.8, 0.05);
  assert.ok(8.8 - inward > outward - 1, 'camera should contract faster than it expands');
  assert.ok(approachCameraDistance(2, 5, -1) === 2, 'negative delta should not move the camera');

  // Draw distance is an actual terrain streaming budget, not just fog/camera clipping.
  assert.deepEqual(['tiny', 'short', 'normal', 'far'].map(streamingRadiusForDistance), [0, 1, 3, 10]);
  assert.deepEqual(['tiny', 'short', 'normal', 'far'].map(renderDistanceFarPlane), [180, 520, 1300, 4200]);
  assert.deepEqual(['tiny', 'short', 'normal', 'far'].map(renderDistanceFogFar), [160, 470, 1180, 4000]);
  assert.deepEqual([0, 1, 3, 10].map((radius) => getTerrainChunkWindow('starter-quarry', 5, 5, radius).length), [1, 9, 49, 121]);
  assert.equal(getTerrainChunkWindow('starter-quarry', 0, 0, 3).length, 16, 'streaming windows are clipped at zone edges');
  assert.equal(getTerrainChunkWindow('starter-quarry', 0, 0, 10).length, 121, 'Far streams the full zone even at a boundary');
  assert.equal(getTerrainChunkWindow('starter-quarry', 5, 5, Number.NaN).length, 1, 'invalid streaming radius falls back safely');
  assert.throws(() => getTerrainChunkWindow('starter-quarry', 1.5, 2, 1), /integer chunk coordinates/);
  let activeLoads = 0;
  let maximumActiveLoads = 0;
  const loadedChunks = [];
  await runBounded(Array.from({ length: 121 }, (_, index) => index), 6, async (item) => {
    activeLoads += 1;
    maximumActiveLoads = Math.max(maximumActiveLoads, activeLoads);
    await new Promise((resolve) => setTimeout(resolve, 1));
    loadedChunks.push(item);
    activeLoads -= 1;
  });
  assert.equal(loadedChunks.length, 121);
  assert.equal(maximumActiveLoads, 6, 'the Far preset must not start 121 chunk loads concurrently');
  await assert.rejects(() => runBounded([1], 0, async () => {}), /positive integer/);
  const fps = resolvePerformancePolicy('fps', 'high', 'high', 2.5);
  const balance = resolvePerformancePolicy('balance', 'high', 'high', 2.5);
  const saver = resolvePerformancePolicy('power-saver', 'low', 'low', 2.5);
  assert.equal(fps.frameIntervalMs, 0);
  assert.equal(fps.targetFps, 60);
  assert.equal(balance.targetFps, 45);
  assert.equal(saver.targetFps, 30);
  assert.equal(saver.pixelRatioCap, 0.85);
  assert.ok(saver.minimumPixelRatio <= saver.pixelRatioCap && saver.minimumPixelRatio >= 0.6);
  const scaler = new AdaptiveResolution({ initialRatio: 1.5, minimumRatio: 1, maximumRatio: 2, targetFrameMs: 1000 / 60 });
  scaler.reconfigure({ initialRatio: 0.85, minimumRatio: 0.6, maximumRatio: 0.85, targetFrameMs: 1000 / 30 });
  assert.equal(scaler.currentRatio, 0.85, 'changing graphics presets must reset adaptive bounds and ratio');
  assert.equal(scaler.recordFrame(5), null, 'short frames should not immediately change the ratio');

  // World instances retain every placement but are partitioned into bounded spatial batches.
  const placements = Array.from({ length: 400 }, (_, index) => ({
    x: -1250 + (index % 20) * 131,
    z: -1200 + Math.floor(index / 20) * 126,
    id: index,
  }));
  const cells = partitionPlacementsByCell(placements, 3000);
  const flattened = [...cells.values()].flat();
  assert.equal(flattened.length, placements.length);
  assert.equal(new Set(flattened.map((item) => item.id)).size, placements.length);
  assert.ok(cells.size > 1 && cells.size < placements.length);
  for (const cell of cells.values()) {
    const cellX = Math.floor((3000 + cell[0].x) / WORLD_PROP_CELL_SIZE_METRES);
    const cellZ = Math.floor(cell[0].z / WORLD_PROP_CELL_SIZE_METRES);
    for (const item of cell) {
      assert.equal(Math.floor((3000 + item.x) / WORLD_PROP_CELL_SIZE_METRES), cellX);
      assert.equal(Math.floor(item.z / WORLD_PROP_CELL_SIZE_METRES), cellZ);
    }
  }
  assert.throws(() => partitionPlacementsByCell(placements, 0, 0), /cell size/);

  // Difficulty adjusts both player output and enemy pressure while preserving Normal as baseline.
  const easy = difficultyCombatProfile('Easy');
  const cake = difficultyCombatProfile("Piece o' Cake");
  const normal = difficultyCombatProfile('Normal');
  const hard = difficultyCombatProfile('Hard');
  assert.deepEqual(normal, { playerDamageMultiplier: 1, enemyDamageMultiplier: 1, enemyHealthMultiplier: 1 });
  assert.ok(cake.playerDamageMultiplier > easy.playerDamageMultiplier && cake.enemyDamageMultiplier < easy.enemyDamageMultiplier);
  assert.ok(easy.playerDamageMultiplier > 1 && easy.enemyHealthMultiplier < 1);
  assert.ok(hard.playerDamageMultiplier < 1 && hard.enemyDamageMultiplier > 1 && hard.enemyHealthMultiplier > 1);
  const settings = parseGameSettings({ ...DEFAULT_GAME_SETTINGS, difficulty: 'Hard' });
  assert.equal(settings.difficulty, 'Hard');

  // A full-clear maximum-reward run should fund every shop item and all three refinements.
  const questCoins = QUEST_DEFINITIONS.reduce((sum, quest) => sum + quest.rewards.coins, 0);
  const miniGameBestCoins = MINI_GAME_DEFINITIONS.reduce((sum, game) => sum + game.rewards.gold.coins, 0);
  const dungeonCoins = DUNGEON_DEFINITIONS.reduce((sum, dungeon) => sum + dungeon.discoveryReward.coins
    + dungeon.completionReward.coins
    + dungeon.points.reduce((pointSum, point) => pointSum + point.reward.coins, 0), 0);
  const enemyCoins = Object.values(ENEMY_DEFINITIONS).reduce((sum, enemyDefinition) => sum + enemyDefinition.coinReward, 0);
  const fullClearCoins = questCoins + miniGameBestCoins + dungeonCoins + enemyCoins;
  const completeGearCost = SHOP_STOCK.reduce((sum, item) => sum + item.priceCoins, 0);
  const completeRefinementCost = WEAPON_REFINEMENT_PLANS.reduce((sum, plan) => sum + plan.coinCost, 0);
  assert.equal(fullClearCoins, 2804);
  assert.equal(completeGearCost, 2570);
  assert.equal(completeRefinementCost, 175);
  assert.ok(fullClearCoins >= completeGearCost + completeRefinementCost,
    '100% one-time content completion at Gold tier should fund all listed gear and refinement Coin costs');
  assert.equal(fullClearCoins - completeGearCost - completeRefinementCost, 59);

  // Static wiring assertions prevent a pure helper from passing while remaining unused in runtime.
  const gameApp = readFileSync(join(projectRoot, 'src/core/GameApp.ts'), 'utf8');
  const streamer = readFileSync(join(projectRoot, 'src/world/WorldChunkStreamer.ts'), 'utf8');
  const population = readFileSync(join(projectRoot, 'src/world/WorldPopulation.ts'), 'utf8');
  const enemy = readFileSync(join(projectRoot, 'src/entities/Enemy.ts'), 'utf8');
  const combat = readFileSync(join(projectRoot, 'src/systems/CombatSystem.ts'), 'utf8');
  const styles = readFileSync(join(projectRoot, 'src/styles/main.css'), 'utf8');
  assert.match(gameApp, /streamingRadiusForDistance\(settings\.video\.drawDistance\)/);
  assert.match(gameApp, /intersectVisible\(this\.cameraRaycaster/);
  assert.match(gameApp, /approachCameraDistance\(/);
  assert.match(gameApp, /classList\.toggle\('animations-disabled'/);
  assert.match(gameApp, /const followFactor = this\.gameSettings\.video\.animations/);
  assert.match(styles, /html\.animations-disabled \*/);
  assert.match(styles, /#loading-panel\.loading-fade-out[\s\S]*transition: opacity 480ms/);
  assert.match(styles, /#main-menu\.menu-enter[\s\S]*animation: menu-arrive/);
  assert.match(gameApp, /adaptiveResolution\.reconfigure\(/);
  assert.match(streamer, /setStreamingRadiusChunks/);
  assert.match(streamer, /getTerrainChunkWindow/);
  assert.match(streamer, /TERRAIN_LOAD_CONCURRENCY = 6/);
  assert.match(streamer, /loadChunksBounded\(/);
  assert.match(streamer, /runBounded\(chunks, TERRAIN_LOAD_CONCURRENCY/);
  assert.match(streamer, /unloadOutside\(zoneId, center\.x, center\.z, safeRadius\)/);
  assert.match(streamer, /this\.streamEpoch === epoch && this\.currentCenterKey === centerKey/);
  assert.match(streamer, /appendLoadedRoots/);
  assert.match(population, /partitionPlacementsByCell/);
  assert.match(population, /frustumCulled = true/);
  assert.match(enemy, /setHealthMultiplier/);
  assert.match(combat, /setPlayerDamageMultiplier/);
  assert.match(readFileSync(join(projectRoot, 'src/systems/WeaponRefinementSystem.ts'), 'utf8'), /WEAPON_REFINEMENT_PLANS/);

  // Every user-facing option has a concrete runtime consumer; touch-layout editing stays callable.
  const applySettingsBody = gameApp.slice(gameApp.indexOf('applySettings(settings:'), gameApp.indexOf('private fogFarDistance'));
  for (const effect of [
    'audioManager.configure(settings.audio)',
    'lookSensitivity: settings.camera.sensitivity / 100',
    'invertLookY: settings.camera.inverted',
    'this.camera.fov = settings.camera.fov',
    'renderDistanceFarPlane(settings.video.drawDistance)',
    'setStreamingRadiusChunks(streamingRadiusForDistance(settings.video.drawDistance))',
    'toneMappingExposure = 1.15 * (settings.video.brightness / 100)',
    'invertedColors ?',
    'shadowMap.enabled = settings.video.graphics',
    'flatShading = !settings.video.smoothLighting',
    'resolvePerformancePolicy(',
    'this.frameIntervalMs = performancePolicy.frameIntervalMs',
    'adaptiveResolution.reconfigure(',
    'guiZoom[settings.video.guiScale]',
    'this.screenShakeEnabled = settings.video.screenShake',
    "classList.toggle('animations-disabled', !settings.video.animations)",
    'difficultyCombatProfile(settings.difficulty)',
    'updateKeyBindings(settings.controls.keyboard)',
    'updateGamepadBindings(settings.controls.gamepad)',
  ]) assert.ok(applySettingsBody.includes(effect), `Options setting has no runtime effect: ${effect}`);
  assert.match(gameApp, /openTouchLayoutEditor\(\): boolean[\s\S]*this\.input\.openTouchLayoutEditor\(\)/);

  console.log('Phase J5 polish tests passed: camera obstruction, performance policy, bounded-concurrency terrain streaming (6 simultaneous loads max), zone-bounded windows, spatial culling partition, difficulty balance, full-clear Coin affordability, full settings-effect audit, global animation disable, and runtime wiring.');
} finally {
  rmSync(out, { recursive: true, force: true });
}
