import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { existsSync, readFileSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outputDirectory = mkdtempSync(join(tmpdir(), 'forgebound-phase-j4-'));

try {
  const sourceFiles = [
    'src/types/resources.ts',
    'src/types/equipment.ts',
    'src/types/combat.ts',
    'src/types/zones.ts',
    'src/assets/asset-manifest.ts',
    'src/data/equipment-data.ts',
    'src/data/zone-data.ts',
    'src/data/quest-data.ts',
    'src/data/quest-world-data.ts',
    'src/data/npc-data.ts',
    'src/data/shop-data.ts',
    'src/data/mini-game-data.ts',
    'src/data/dungeon-data.ts',
    'src/world/open-world-config.ts',
    'src/world/terrain-height.ts',
    'src/systems/Inventory.ts',
    'src/systems/ProgressionSystem.ts',
    'src/systems/ZoneProgressionSystem.ts',
    'src/systems/QuestSystem.ts',
    'src/systems/ShopSystem.ts',
    'src/systems/WeaponRefinementSystem.ts',
    'src/systems/MiniGameSystem.ts',
    'src/systems/ChessGame.ts',
    'src/systems/DungeonProgressSystem.ts',
    'src/systems/SaveSystem.ts',
  ];
  execFileSync(process.platform === 'win32' ? 'tsc.cmd' : 'tsc', [
    '--strict', '--noUncheckedIndexedAccess', '--noUnusedLocals', '--noUnusedParameters',
    '--target', 'ES2022', '--module', 'commonjs', '--moduleResolution', 'node',
    '--skipLibCheck', '--typeRoots', outputDirectory, '--outDir', outputDirectory, ...sourceFiles,
  ], { cwd: projectRoot, stdio: 'inherit', shell: process.platform === 'win32' });
  writeFileSync(join(outputDirectory, 'package.json'), '{"type":"commonjs"}');
  const require = createRequire(import.meta.url);
  const { DUNGEON_DEFINITIONS, DUNGEON_BY_ID } = require(join(outputDirectory, 'data/dungeon-data.js'));
  const { OPEN_WORLD_ZONES } = require(join(outputDirectory, 'world/open-world-config.js'));
  const { DungeonProgressSystem, createEmptyDungeonSnapshot, validateDungeonSnapshot } = require(join(outputDirectory, 'systems/DungeonProgressSystem.js'));
  const { Inventory } = require(join(outputDirectory, 'systems/Inventory.js'));
  const { ProgressionSystem } = require(join(outputDirectory, 'systems/ProgressionSystem.js'));
  const { ZoneProgressionSystem } = require(join(outputDirectory, 'systems/ZoneProgressionSystem.js'));
  const { QuestSystem, createEmptyQuestSnapshot } = require(join(outputDirectory, 'systems/QuestSystem.js'));
  const { MiniGameSystem, createEmptyMiniGameSnapshot } = require(join(outputDirectory, 'systems/MiniGameSystem.js'));
  const { SaveSystem, SAVE_SCHEMA_VERSION, SAVE_STORAGE_KEY, PREVIOUS_SAVE_STORAGE_KEY, createSaveData, validateSaveData } = require(join(outputDirectory, 'systems/SaveSystem.js'));

  // Seven interiors cover all three zones, and every physical entrance lies inside its 7 km² playable square.
  assert.equal(DUNGEON_DEFINITIONS.length, 7);
  assert.deepEqual(
    Object.fromEntries(['starter-quarry', 'molten-caves', 'crystal-peaks'].map((zoneId) => [zoneId, DUNGEON_DEFINITIONS.filter((dungeon) => dungeon.zoneId === zoneId).length])),
    { 'starter-quarry': 2, 'molten-caves': 2, 'crystal-peaks': 3 },
  );
  const dungeonIds = new Set();
  const pointIds = new Set();
  const uniqueLandmarkNodes = {
    'forgotten-mine': 'ore-cart-bed',
    'old-stonewatch': 'stonewatch-parapet',
    'deep-ember-caverns': 'ember-fissure',
    'forgotten-furnace': 'furnace-hearth',
    'luminous-caverns': 'crystal-cluster-0-0',
    'ancient-observatory': 'observatory-armillary-ring-a',
    'summit-temple': 'temple-beacon-altar',
  };
  for (const dungeon of DUNGEON_DEFINITIONS) {
    assert.equal(dungeonIds.has(dungeon.id), false);
    dungeonIds.add(dungeon.id);
    const zone = OPEN_WORLD_ZONES[dungeon.zoneId];
    assert.equal(zone.playableAreaSquareMetres, 7_000_000);
    assert.ok(Math.abs(dungeon.entranceOffset.x) <= zone.sideLengthMetres / 2, `${dungeon.id} entrance x inside playable area`);
    assert.ok(Math.abs(dungeon.entranceOffset.z) <= zone.sideLengthMetres / 2, `${dungeon.id} entrance z inside playable area`);
    assert.ok(Math.abs(dungeon.instanceOrigin.x) >= 10_000 || Math.abs(dungeon.instanceOrigin.z) >= 10_000, `${dungeon.id} interior is isolated from the overworld`);
    assert.equal(dungeon.points.length, 3);
    assert.ok(dungeon.discoveryReward.xp > 0 && dungeon.discoveryReward.coins > 0);
    assert.ok(dungeon.completionReward.xp > 0 && dungeon.completionReward.coins > 0);
    for (const point of dungeon.points) {
      assert.equal(pointIds.has(point.id), false, `point ${point.id} must be globally unique`);
      pointIds.add(point.id);
      assert.ok(point.reward.xp > 0 && point.reward.coins > 0);
    }

    const glbPath = join(projectRoot, 'public', dungeon.assetFile.replace(/^\//, ''));
    assert.ok(existsSync(glbPath), `${dungeon.id} GLB file exists`);
    const glb = readFileSync(glbPath);
    assert.equal(glb.toString('utf8', 0, 4), 'glTF', `${dungeon.id} has GLB magic`);
    const jsonLength = glb.readUInt32LE(12);
    const jsonType = glb.readUInt32LE(16);
    assert.equal(jsonType, 0x4e4f534a, `${dungeon.id} starts with a JSON chunk`);
    const gltf = JSON.parse(glb.toString('utf8', 20, 20 + jsonLength));
    const nodeNames = new Set((gltf.nodes ?? []).map((node) => node.name));
    for (const point of dungeon.points) assert.ok(nodeNames.has(point.meshName), `${dungeon.id} contains ${point.meshName}`);
    assert.ok(nodeNames.has(dungeon.exitMeshName), `${dungeon.id} contains a return exit`);
    assert.ok(nodeNames.has(uniqueLandmarkNodes[dungeon.id]), `${dungeon.id} contains its distinctive landmark dressing`);
  }
  assert.equal(pointIds.size, 21);
  assert.equal(Object.keys(DUNGEON_BY_ID).length, 7);
  const manifest = JSON.parse(readFileSync(join(projectRoot, 'public/assets/dungeons/manifest.json'), 'utf8'));
  assert.equal(manifest.allInteriorGeometryGeneratedByPython, true);
  assert.equal(manifest.interiorCount, 7);
  assert.equal(manifest.interiors.length, 7);

  // Exploration claims are one-time and completion is only recorded after all three POIs.
  const progress = new DungeonProgressSystem();
  assert.deepEqual(progress.snapshot(), createEmptyDungeonSnapshot());
  assert.equal(progress.discover('forgotten-mine'), true);
  assert.equal(progress.discover('forgotten-mine'), false);
  assert.equal(progress.discover('unknown-dungeon'), false);
  const mine = DUNGEON_BY_ID['forgotten-mine'];
  for (const [index, point] of mine.points.entries()) {
    const result = progress.claimPoint('forgotten-mine', point.id);
    assert.equal(result.ok, true);
    assert.equal(result.newlyCompleted, index === 2);
  }
  assert.equal(progress.isCompleted('forgotten-mine'), true);
  assert.equal(progress.isPointClaimed(mine.points[0].id), true);
  assert.equal(progress.claimPoint('forgotten-mine', mine.points[0].id).ok, false, 'claimed POIs cannot pay out twice');
  assert.equal(progress.getPointCount('forgotten-mine').claimed, 3);
  assert.equal(validateDungeonSnapshot(progress.snapshot()), true);
  assert.equal(validateDungeonSnapshot({ ...progress.snapshot(), completedDungeonIds: ['summit-temple'] }), false, 'cannot complete a dungeon before discovery/POIs');
  const restored = new DungeonProgressSystem();
  assert.equal(restored.restore(JSON.parse(JSON.stringify(progress.snapshot()))), true);
  assert.equal(restored.isCompleted('forgotten-mine'), true);
  assert.equal(restored.getCompletedCount(), 1);

  // v4 migration retains both J2 quest progress and J3 mini-game medals while adding empty J4 exploration state.
  const inventory = new Inventory(75);
  const progression = new ProgressionSystem();
  const zones = new ZoneProgressionSystem();
  const quests = new QuestSystem();
  assert.equal(quests.accept('zone1-billy-backyard', 'starter-quarry', 1).ok, true);
  quests.record({ type: 'interact', objectId: 'billy-clutter', amount: 2 });
  const miniGames = new MiniGameSystem();
  miniGames.recordCompletion('quarry-cart-rally', 'silver');
  const data = createSaveData({
    playerHealth: 100,
    progression: progression.snapshot(),
    inventory: inventory.snapshot(),
    currentZoneId: zones.getCurrentZoneId(),
    questState: quests.snapshot(),
    miniGameState: miniGames.snapshot(),
    dungeonState: restored.snapshot(),
  }, 1_700_000_000_000);
  assert.equal(data.schemaVersion, SAVE_SCHEMA_VERSION);
  assert.equal(validateSaveData(data).ok, true);
  const v4 = JSON.parse(JSON.stringify(data));
  v4.schemaVersion = 4;
  delete v4.dungeonState;
  const storage = new Map([[PREVIOUS_SAVE_STORAGE_KEY, JSON.stringify(v4)]]);
  const adapter = {
    getItem: (key) => storage.get(key) ?? null,
    setItem: (key, value) => storage.set(key, value),
    removeItem: (key) => storage.delete(key),
  };
  const saves = new SaveSystem(adapter);
  const migrated = saves.load();
  assert.equal(migrated.status, 'migrated');
  assert.equal(migrated.data.schemaVersion, 6);
  assert.deepEqual(migrated.data.questState, quests.snapshot());
  assert.deepEqual(migrated.data.miniGameState, miniGames.snapshot());
  assert.deepEqual(migrated.data.dungeonState, createEmptyDungeonSnapshot());
  assert.equal(migrated.data.inventory.coins, 75);
  assert.equal(saves.save(migrated.data).ok, true);
  assert.equal(storage.has(SAVE_STORAGE_KEY), true);

  // The shipped UI has an accessible exploration log, and the runtime contains real entrance/exit/POI handlers.
  const html = readFileSync(join(projectRoot, 'index.html'), 'utf8');
  const gameApp = readFileSync(join(projectRoot, 'src/core/GameApp.ts'), 'utf8');
  const manager = readFileSync(join(projectRoot, 'src/world/DungeonInteriorManager.ts'), 'utf8');
  assert.match(html, /id="open-exploration-log"/);
  assert.match(html, /id="exploration-panel"[^>]*role="dialog"/);
  assert.match(gameApp, /new DungeonInteriorManager/);
  assert.match(gameApp, /private enterDungeon\(/);
  assert.match(gameApp, /private claimDungeonPoint\(/);
  assert.match(gameApp, /private exitDungeon\(/);
  assert.match(manager, /createColliders\(/);
  assert.match(manager, /addStaticTrimesh/);
  assert.match(manager, /for \(const body of bodies\) this\.physics\.removeRigidBody\(body\)/, 'partial collider creation must roll back safely');
  const frameStart = gameApp.indexOf('private readonly frame');
  const frameText = gameApp.slice(frameStart);
  assert.ok(frameText.indexOf('this.updateNpcTarget();') < frameText.indexOf('this.updateDungeonEntranceTarget();'), 'NPC prompt/action priority must be evaluated before dungeon entrances');
  const promptText = gameApp.slice(gameApp.indexOf('private resolveInteractionPrompt()'), gameApp.indexOf('private handleInteractionAction()'));
  assert.ok(promptText.indexOf('if (this.npcTarget)') < promptText.indexOf('if (this.dungeonEntranceTarget)'), 'prompt priority matches NPC action priority');
  const actionText = gameApp.slice(gameApp.indexOf('private handleInteractionAction()'), gameApp.indexOf('private handleWeaponAttackAction()'));
  assert.ok(actionText.indexOf('if (this.npcTarget)') < actionText.indexOf('if (this.dungeonEntranceTarget)'), 'interact key targets what the prompt describes');
  assert.ok(actionText.indexOf('this.dungeonPointTarget') < actionText.indexOf('this.dungeonExitTarget'), 'POI action priority matches the active-dungeon prompt');

  console.log('Phase J4 tests passed: seven Python GLB interiors, 21 POIs, playable-area entrances, isolated instances, collision wiring, exploration progress, one-time rewards, and v4 save migration.');
} finally {
  rmSync(outputDirectory, { recursive: true, force: true });
}
