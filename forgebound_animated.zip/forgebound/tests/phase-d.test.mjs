import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outputDirectory = mkdtempSync(join(tmpdir(), 'forgebound-phase-d-'));

try {
  const sourceFiles = [
    'src/types/resources.ts',
    'src/types/equipment.ts',
    'src/types/combat.ts',
    'src/data/equipment-data.ts',
    'src/data/enemy-data.ts',
    'src/systems/Inventory.ts',
    'src/systems/ProgressionSystem.ts',
    'src/systems/CombatRules.ts',
  ];
  execFileSync(process.platform === 'win32' ? 'tsc.cmd' : 'tsc', [
    '--strict',
    '--target', 'ES2022',
    '--module', 'commonjs',
    '--moduleResolution', 'node',
    '--skipLibCheck',
    '--typeRoots', outputDirectory,
    '--outDir', outputDirectory,
    ...sourceFiles,
  ], { cwd: projectRoot, stdio: 'inherit', shell: process.platform === 'win32' });
  writeFileSync(join(outputDirectory, 'package.json'), '{"type":"commonjs"}');

  const require = createRequire(import.meta.url);
  const { ProgressionSystem, xpRequiredForLevel } = require(join(outputDirectory, 'systems/ProgressionSystem.js'));
  const { canPacifyTarget, rollLootTable } = require(join(outputDirectory, 'systems/CombatRules.js'));
  const { Inventory } = require(join(outputDirectory, 'systems/Inventory.js'));
  const { ENEMY_DEFINITIONS, ENEMY_SPAWN_ORDER } = require(join(outputDirectory, 'data/enemy-data.js'));

  assert.equal(xpRequiredForLevel(1), 50);
  assert.equal(xpRequiredForLevel(2), 85);
  assert.equal(xpRequiredForLevel(0), 0);
  assert.equal(xpRequiredForLevel(100), 0);

  assert.equal(ENEMY_SPAWN_ORDER.length, 3);
  assert.equal(new Set(ENEMY_SPAWN_ORDER).size, 3);
  for (const enemyId of ENEMY_SPAWN_ORDER) {
    const enemy = ENEMY_DEFINITIONS[enemyId];
    assert.ok(enemy.moveSpeed > 0 && enemy.attackDamage > 0 && enemy.attackRange > 0);
    assert.ok(enemy.attackCooldownSeconds > 0 && enemy.detectionRange >= enemy.attackRange);
    assert.ok(enemy.xpReward > 0 && enemy.pacifiedSeconds > 0);
    assert.ok(Number.isFinite(enemy.spawn.x) && Number.isFinite(enemy.spawn.z));
    for (const drop of enemy.loot) {
      assert.ok(drop.chance >= 0 && drop.chance <= 1);
      assert.ok(drop.minimumQuantity > 0 && drop.maximumQuantity >= drop.minimumQuantity);
    }
  }

  const progression = new ProgressionSystem();
  const invalidAward = progression.awardXp(0);
  assert.equal(invalidAward.ok, false);
  assert.equal(invalidAward.snapshot.level, 1);
  assert.equal(progression.awardXp(24).levelsGained, 0);
  const levelUp = progression.awardXp(26);
  assert.equal(levelUp.ok, true);
  assert.equal(levelUp.levelsGained, 1);
  assert.equal(levelUp.snapshot.level, 2);
  assert.equal(levelUp.snapshot.currentXp, 0);
  assert.equal(progression.awardXp(90).snapshot.level, 3);
  assert.equal(progression.snapshot().totalXp, 140);

  assert.equal(canPacifyTarget({ cooldownSeconds: 0, inRange: true, targetCanBePacified: true }), true);
  assert.equal(canPacifyTarget({ cooldownSeconds: 0.1, inRange: true, targetCanBePacified: true }), false);
  assert.equal(canPacifyTarget({ cooldownSeconds: 0, inRange: false, targetCanBePacified: true }), false);
  assert.equal(canPacifyTarget({ cooldownSeconds: 0, inRange: true, targetCanBePacified: false }), false);

  const lootTable = [
    { resourceId: 'copper-ore', chance: 0.72, minimumQuantity: 1, maximumQuantity: 2 },
    { resourceId: 'iron-ore', chance: 0.16, minimumQuantity: 1, maximumQuantity: 1 },
  ];
  const rolls = [0.2, 0.99, 0.8];
  let rollIndex = 0;
  const loot = rollLootTable(lootTable, () => rolls[rollIndex++] ?? 1);
  assert.deepEqual(loot, [{ resourceId: 'copper-ore', quantity: 2 }]);

  const inventory = new Inventory();
  for (const drop of loot) assert.equal(inventory.add(drop.resourceId, drop.quantity).ok, true);
  assert.equal(inventory.count('copper-ore'), 2);

  const fullInventory = new Inventory();
  assert.equal(fullInventory.add('gold-ore', 9999).ok, true);
  const overflowDrop = rollLootTable([
    { resourceId: 'gold-ore', chance: 1, minimumQuantity: 1, maximumQuantity: 1 },
  ], () => 0);
  assert.equal(fullInventory.add(overflowDrop[0].resourceId, overflowDrop[0].quantity).ok, false);
  assert.equal(fullInventory.count('gold-ore'), 9999, 'loot stack overflow must not change inventory');

  const safeRandomLoot = rollLootTable([
    { resourceId: 'crystal', chance: 1.4, minimumQuantity: 1, maximumQuantity: 2 },
    { resourceId: 'gold-ore', chance: 0.5, minimumQuantity: 0, maximumQuantity: 2 },
  ], () => 0);
  assert.deepEqual(safeRandomLoot, [], 'invalid loot entries must be ignored');

  console.log('Phase D domain tests passed: creature configuration, XP curve, level-up carry, pacification gating, deterministic loot rolls, and stack-cap handling.');
} finally {
  rmSync(outputDirectory, { recursive: true, force: true });
}
