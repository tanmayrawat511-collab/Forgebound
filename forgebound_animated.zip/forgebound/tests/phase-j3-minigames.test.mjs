import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { readFileSync, existsSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outputDirectory = mkdtempSync(join(tmpdir(), 'forgebound-phase-j3-'));

try {
  const sourceFiles = [
    'src/types/resources.ts',
    'src/types/equipment.ts',
    'src/types/combat.ts',
    'src/types/zones.ts',
    'src/assets/asset-manifest.ts',
    'src/data/equipment-data.ts',
    'src/data/zone-data.ts',
    'src/data/quest-data.ts',
    'src/data/quest-world-data.ts',
    'src/data/npc-data.ts',
    'src/data/shop-data.ts',
    'src/data/mini-game-data.ts',
    'src/world/open-world-config.ts',
    'src/world/terrain-height.ts',
    'src/systems/Inventory.ts',
    'src/systems/ProgressionSystem.ts',
    'src/systems/ZoneProgressionSystem.ts',
    'src/systems/QuestSystem.ts',
    'src/systems/ShopSystem.ts',
    'src/systems/WeaponRefinementSystem.ts',
    'src/systems/MiniGameSystem.ts',
    'src/systems/ChessGame.ts',
    'src/ui/MiniGamePanel.ts',
    'src/systems/SaveSystem.ts',
  ];
  execFileSync(process.platform === 'win32' ? 'tsc.cmd' : 'tsc', [
    '--strict', '--noUncheckedIndexedAccess', '--noUnusedLocals', '--noUnusedParameters',
    '--target', 'ES2022', '--module', 'commonjs', '--moduleResolution', 'node',
    '--skipLibCheck', '--typeRoots', outputDirectory, '--outDir', outputDirectory, ...sourceFiles,
  ], { cwd: projectRoot, stdio: 'inherit', shell: process.platform === 'win32' });
  writeFileSync(join(outputDirectory, 'package.json'), '{"type":"commonjs"}');
  const require = createRequire(import.meta.url);
  const { MINI_GAME_DEFINITIONS, MINI_GAME_BY_ID, createEmptyMiniGameSnapshot, MiniGameSystem, validateMiniGameSnapshot } = require(join(outputDirectory, 'systems/MiniGameSystem.js'));
  const { MINI_GAME_STATIONS } = require(join(outputDirectory, 'data/mini-game-data.js'));
  const { createEmptyDungeonSnapshot } = require(join(outputDirectory, 'systems/DungeonProgressSystem.js'));
  const { ASSET_FILENAMES } = require(join(outputDirectory, 'assets/asset-manifest.js'));
  const { RESOURCE_IDS } = require(join(outputDirectory, 'types/resources.js'));
  const { ChessGame } = require(join(outputDirectory, 'systems/ChessGame.js'));
  const { Inventory } = require(join(outputDirectory, 'systems/Inventory.js'));
  const { ProgressionSystem } = require(join(outputDirectory, 'systems/ProgressionSystem.js'));
  const { ZoneProgressionSystem } = require(join(outputDirectory, 'systems/ZoneProgressionSystem.js'));
  const { QuestSystem, createEmptyQuestSnapshot } = require(join(outputDirectory, 'systems/QuestSystem.js'));
  const { SaveSystem, SAVE_SCHEMA_VERSION, SAVE_STORAGE_KEY, PREVIOUS_SAVE_STORAGE_KEY, createSaveData, validateSaveData } = require(join(outputDirectory, 'systems/SaveSystem.js'));

  // The authored activity catalog is complete and every activity has a matching in-world station.
  assert.equal(MINI_GAME_DEFINITIONS.length, 9);
  assert.equal(MINI_GAME_STATIONS.length, 9);
  for (const zoneId of ['starter-quarry', 'molten-caves', 'crystal-peaks']) {
    assert.equal(MINI_GAME_DEFINITIONS.filter((game) => game.zoneId === zoneId).length, 3, `${zoneId} should contain three activities`);
  }
  assert.equal(new Set(MINI_GAME_DEFINITIONS.map((game) => game.id)).size, 9);
  for (const station of MINI_GAME_STATIONS) {
    assert.ok(MINI_GAME_BY_ID[station.gameId], `${station.id} must refer to a defined activity`);
    assert.ok(Object.hasOwn(ASSET_FILENAMES, station.assetId), `${station.id} must use a registered GLB asset`);
    assert.ok(existsSync(join(projectRoot, 'public/assets/models', ASSET_FILENAMES[station.assetId])), `${station.id} GLB file must exist`);
  }
  for (const game of MINI_GAME_DEFINITIONS) {
    for (const tier of ['bronze', 'silver', 'gold']) {
      const reward = game.rewards[tier];
      assert.ok(Number.isSafeInteger(reward.xp) && reward.xp >= 0);
      assert.ok(Number.isSafeInteger(reward.coins) && reward.coins >= 0);
      for (const resourceId of Object.keys(reward.resources)) assert.ok(RESOURCE_IDS.includes(resourceId), `${resourceId} is a valid item reward`);
    }
  }

  // Best-tier reward deltas prevent repeat reward farming.
  const activities = new MiniGameSystem();
  const firstBronze = activities.previewPayout('quarry-cart-rally', 'bronze');
  assert.equal(firstBronze.xp, 25);
  assert.equal(firstBronze.coins, 10);
  assert.deepEqual(firstBronze.resources, { 'copper-ore': 1 });
  activities.recordCompletion('quarry-cart-rally', 'bronze');
  const bronzeReplay = activities.previewPayout('quarry-cart-rally', 'bronze');
  assert.equal(bronzeReplay.improvedTier, false);
  assert.equal(bronzeReplay.xp, 0);
  assert.equal(bronzeReplay.coins, 0);
  assert.deepEqual(bronzeReplay.resources, {});
  const silverUpgrade = activities.previewPayout('quarry-cart-rally', 'silver');
  assert.equal(silverUpgrade.xp, 20);
  assert.equal(silverUpgrade.coins, 10);
  assert.deepEqual(silverUpgrade.resources, { 'copper-ore': 1 });
  activities.recordCompletion('quarry-cart-rally', 'silver');
  const goldUpgrade = activities.previewPayout('quarry-cart-rally', 'gold');
  assert.equal(goldUpgrade.xp, 25);
  assert.equal(goldUpgrade.coins, 15);
  assert.deepEqual(goldUpgrade.resources, { 'copper-ore': 1 });
  activities.recordCompletion('quarry-cart-rally', 'gold');
  assert.equal(activities.getBestTier('quarry-cart-rally'), 'gold');
  assert.equal(activities.getCompletionCount('quarry-cart-rally'), 3);
  assert.equal(activities.previewPayout('quarry-cart-rally', 'silver').improvedTier, false);

  const fishRewards = new MiniGameSystem();
  let fishTotal = 0;
  for (const tier of ['bronze', 'silver', 'gold']) {
    const payout = fishRewards.previewPayout('crystal-fishing', tier);
    fishTotal += payout.resources['crystal-cod'] ?? 0;
    fishRewards.recordCompletion('crystal-fishing', tier);
  }
  assert.equal(fishTotal, 3, 'bronze → silver → gold improvements collectively pay the three cod needed by James');

  const chessRewards = new MiniGameSystem();
  assert.deepEqual(chessRewards.previewPayout('summit-chess', 'gold').newUnlocks, ['chessmaster-crest']);
  chessRewards.recordCompletion('summit-chess', 'gold');
  assert.equal(chessRewards.hasUnlock('chessmaster-crest'), true);
  assert.equal(validateMiniGameSnapshot(chessRewards.snapshot()), true);
  assert.equal(validateMiniGameSnapshot({ ...chessRewards.snapshot(), bestTierByGame: { 'not-a-game': 'gold' } }), false);
  assert.deepEqual(createEmptyMiniGameSnapshot(), { bestTierByGame: {}, completionCounts: {}, unlockedRewards: [] });
  const restoredActivities = new MiniGameSystem();
  assert.equal(restoredActivities.restore(JSON.parse(JSON.stringify(chessRewards.snapshot()))), true);
  assert.equal(restoredActivities.hasUnlock('chessmaster-crest'), true);

  // Chess engine starts with the standard 20 legal moves, rejects an illegal move,
  // and supports a legal human move followed by a legal computer reply.
  const chess = new ChessGame();
  assert.equal(chess.currentTurn, 'w');
  assert.equal(chess.getLegalMoves().length, 20);
  const e2Moves = chess.getLegalMoves(52).map((move) => move.to).sort((a, b) => a - b);
  assert.deepEqual(e2Moves, [36, 44]);
  assert.equal(chess.playHumanMove(52, 28), false, 'a pawn cannot jump three squares');
  assert.equal(chess.playHumanMove(52, 36), true, 'e2-e4 is legal');
  const blackReply = chess.playComputerMove();
  assert.ok(blackReply, 'Frank must make a legal response');
  assert.equal(chess.currentTurn, 'w');
  assert.equal(chess.moveHistory.length, 2);
  assert.equal(chess.result, 'playing');

  // Castling is legal only while the original rook is present and has not moved.
  const castleTest = new ChessGame();
  castleTest.board.fill(null);
  castleTest.board[60] = 'K';
  castleTest.board[4] = 'k';
  castleTest.board[63] = 'R';
  castleTest.side = 'w';
  castleTest.castling = 'K';
  assert.ok(castleTest.getLegalMoves(60).some((move) => move.to === 62), 'white kingside castling should be legal on a clear, unattacked path');
  assert.equal(castleTest.playHumanMove(63, 55), true, 'the rook can move from h1 to h2');
  assert.equal(castleTest.getLegalMoves(60).some((move) => move.to === 62), false, 'moving the h1 rook must revoke white kingside castling');

  // Save v4 persists medals; v3 migration preserves J2 quest and refinement progress.
  const inventory = new Inventory();
  const progression = new ProgressionSystem();
  const zones = new ZoneProgressionSystem();
  const quests = new QuestSystem();
  quests.accept('zone1-billy-backyard', 'starter-quarry', 1);
  quests.record({ type: 'interact', objectId: 'billy-clutter', amount: 2 });
  const capture = {
    playerHealth: 100,
    progression: progression.snapshot(),
    inventory: inventory.snapshot(),
    currentZoneId: zones.getCurrentZoneId(),
    questState: quests.snapshot(),
    miniGameState: chessRewards.snapshot(),
    dungeonState: createEmptyDungeonSnapshot(),
  };
  const v4 = createSaveData(capture, 1_700_000_000_000);
  assert.equal(v4.schemaVersion, SAVE_SCHEMA_VERSION);
  assert.equal(validateSaveData(v4).ok, true);
  const storage = new Map();
  const adapter = { getItem: (key) => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value), removeItem: (key) => storage.delete(key) };
  const saves = new SaveSystem(adapter);
  assert.equal(saves.save(v4).ok, true);
  const loadedV4 = saves.load();
  assert.equal(loadedV4.status, 'loaded');
  assert.deepEqual(loadedV4.data.miniGameState, chessRewards.snapshot());

  const v3 = JSON.parse(JSON.stringify(v4));
  v3.schemaVersion = 3;
  delete v3.miniGameState;
  v3.inventory.weaponRefinementRank = 2;
  storage.clear();
  storage.set(PREVIOUS_SAVE_STORAGE_KEY, JSON.stringify(v3));
  const migrated = saves.load();
  assert.equal(migrated.status, 'migrated');
  assert.equal(migrated.data.inventory.weaponRefinementRank, 2);
  assert.deepEqual(migrated.data.questState, v4.questState, 'J2 quest progress must survive v3-to-v4 migration');
  assert.deepEqual(migrated.data.miniGameState, createEmptyMiniGameSnapshot());
  assert.equal(storage.has(SAVE_STORAGE_KEY), false, 'migration is not written until the next regular save');

  // Frank and James are both wired to their named mini-games and quests.
  const { NPC_DEFINITIONS } = require(join(outputDirectory, 'data/npc-data.js'));
  const { QUEST_BY_ID } = require(join(outputDirectory, 'data/quest-data.js'));
  const frank = NPC_DEFINITIONS.find((npc) => npc.id === 'frank');
  const james = NPC_DEFINITIONS.find((npc) => npc.id === 'james');
  assert.equal(frank.service, 'minigame');
  assert.equal(frank.miniGameId, 'summit-chess');
  assert.equal(james.service, 'minigame');
  assert.equal(james.miniGameId, 'crystal-fishing');
  assert.equal(QUEST_BY_ID['zone3-frank-checkmate-lookout'].objectives[0].gameId, 'summit-chess');
  assert.equal(QUEST_BY_ID['zone3-james-cold-catch'].objectives[0].resourceId, 'crystal-cod');
  const frankQuest = new QuestSystem();
  assert.equal(frankQuest.restore({ acceptedQuestIds: ['zone3-frank-checkmate-lookout'], completedQuestIds: ['zone1-main-quarry-wakes', 'zone2-main-heart-furnace'], progress: { 'zone3-frank-checkmate-lookout': { chess: 0 } }, usedWorldObjectIds: [] }), true);
  frankQuest.record({ type: 'minigame', gameId: 'summit-chess' });
  assert.equal(frankQuest.getStatus('zone3-frank-checkmate-lookout', 'crystal-peaks', 5), 'ready-to-turn-in');
  const jamesQuest = new QuestSystem();
  assert.equal(jamesQuest.restore({ acceptedQuestIds: ['zone3-james-cold-catch'], completedQuestIds: ['zone1-main-quarry-wakes', 'zone2-main-heart-furnace'], progress: { 'zone3-james-cold-catch': { cod: 0 } }, usedWorldObjectIds: [] }), true);
  jamesQuest.record({ type: 'collect', resourceId: 'crystal-cod', amount: fishTotal });
  assert.equal(jamesQuest.getStatus('zone3-james-cold-catch', 'crystal-peaks', 5), 'ready-to-turn-in');

  const indexHtml = readFileSync(join(projectRoot, 'index.html'), 'utf8');
  const panelSource = readFileSync(join(projectRoot, 'src/ui/MiniGamePanel.ts'), 'utf8');
  const appSource = readFileSync(join(projectRoot, 'src/core/GameApp.ts'), 'utf8');
  for (const id of ['minigame-panel', 'minigame-title', 'minigame-subtitle', 'minigame-description', 'minigame-status', 'minigame-content', 'close-minigame']) {
    assert.match(indexHtml, new RegExp(`id=["']${id}["']`), `missing #${id} markup`);
  }
  for (const method of ['startCartRally', 'startTimberRelay', 'startVeinfinder', 'startMagmaHarvest', 'startSequencePuzzle', 'startBasaltSprint', 'startChess', 'startFishing']) {
    assert.ok(panelSource.includes(method), `${method} must be implemented`);
  }
  assert.ok(appSource.includes('handleMiniGameComplete'));
  assert.ok(appSource.includes('this.miniGameSystem.snapshot()'));
  console.log('Phase J3 minigames passed: 9 stations, tiered reward anti-farming, chess rules, quest hooks, and save migration.');
} finally {
  rmSync(outputDirectory, { recursive: true, force: true });
}
