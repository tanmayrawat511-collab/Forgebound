# ForgeBound — Phase J7: The Living Frontier

ForgeBound is an original browser-based third-person mining-and-forging RPG built with Three.js, strict TypeScript, Vite, and Rapier 3D physics. This project bundle includes the original A–F foundations and the Phase I and Phase J1–J7 systems.

## Current implementation scope — Phase J7

The current implementation has three ordered open-world zones with 7 km² of playable terrain each, streamed Python-generated terrain GLBs, 22 existing named NPCs plus tutorial NPC Ben, 25 civilians, one wandering dog, 22 quests, nine mini-games, seven explorable cave/ruin interiors, 21 one-time exploration landmarks, a persistent Exploration Log, 13 ingot-traded gear types, five-tier gear refinement, a north-locked minimap, and save schema version 6. Phase J7 adds a mandatory Ben tutorial and returns the exact pickaxe instance he lost. The project contains 460 GLBs, including 41 new J7 models.

Phase J7 is an implementation candidate: offline domain/regression tests and GLB hash/geometry validation pass, but full TypeScript typecheck, Vite build and browser playthrough remain blocked by unavailable npm dependencies. Character animation clip entries currently use procedural runtime motion; articulated rigs and embedded skeletal tracks remain unfinished. See [`PHASE_J7_IMPLEMENTATION_NOTES.md`](PHASE_J7_IMPLEMENTATION_NOTES.md) and [`release/j7-release-manifest.json`](release/j7-release-manifest.json). Earlier Phase A–F notes below describe historical foundations and are superseded where they conflict with later Phase J functionality.

## Features

### Historical foundation and gathering (Phases A–B)

- Three.js renderer, scene, third-person camera, lights, resize handling, loading UI, and recoverable startup errors.
- Asynchronous Rapier 3D initialization and a fixed `1 / 60` second physics timestep.
- Position-based kinematic capsule player with camera-relative WASD movement, mouse orbit, jumping, grounded detection, and collision-resolved movement.
- Shared physics world with floor, boundary walls, and collision obstacles for all three arenas.
- Ore nodes have typed resource IDs, durability, mining range checks, cooldown, exactly-once depletion rewards, and respawn delays.
- Typed inventory with resource stacks, add/remove/count operations, atomic exchanges, and a 9,999 stack limit.

### Historical forge and equipment foundation (Phase C)

- Physical Quarry Forge with Rapier collider and aim/range-based interaction in Starter Quarry.
- Atomic smelting for copper, iron, and gold ore.
- Atomic crafting, unique equipment ownership, equip/unequip, and pickaxe/weapon slots.
- Copperhead Pickaxe improves mining power from `1.0×` to `2.0×`.
- Emberline Sword and Deepdelver Maul have distinct displayed attack metadata. These values are not connected to a creature damage action in this build.

### Historical creature encounter foundation (Phase D)

- Quarry Crawler in Starter Quarry, Ember Stalker in Molten Caves, and Crystal Sentinel in Crystal Peaks.
- Data-driven creature movement, detection, leash, strike damage/range/cooldown, XP, appearance, pacification duration, and loot.
- AI states: `idle`, `detect`, `chase`, `attack`, `return`, and `pacified`.
- Creature movement is resolved through Rapier character controllers against arena and obstacle colliders.
- Aim at an active-zone creature and press `E` within range to send a non-weapon resonance pulse.
- Pacification grants XP and performs independent loot-table rolls once for each successful calming event. A creature cannot reward twice while it is already pacified.
- Player vitality starts at `100`; creature strikes cause non-graphic damage feedback. At zero vitality, a `2.6` second recovery returns the player to the current region's checkpoint while keeping inventory.
- XP thresholds are `50` for level 2, `85` for level 3, and then increase by `35` per level. Maximum level is 99.

### Historical persistence and release assets (Phase F)

- Versioned `localStorage` saves use the key `forgebound.save.v1` and schema version `1`.
- Save contents include player vitality, XP/level, all resource quantities, owned equipment, equipped pickaxe/weapon IDs, unlocked zone IDs, current zone, and a safe checkpoint identifier.
- Save input is validated for finite safe integers, stack limits, known resource/equipment/zone IDs, duplicate equipment, equipment slot ownership, XP/level consistency, and level-derived zone unlocks.
- A version-0 migration path fills the checkpoint and derived unlock list, and supplies safe defaults for absent health/timestamp fields.
- Inventory changes, successful creature pacification/XP awards, vitality changes, and zone transitions trigger saves; no writes occur per animation frame.
- The **Reset Save** control confirms before deleting the local save and reloading to a clean expedition.
- Twelve local low-poly GLB placeholders are included under `public/assets/models`. `AssetRegistry` uses `GLTFLoader` and retains procedural Three.js visuals whenever a model fails to load.
- `tools/generate_assets.py` regenerates the GLBs with `trimesh` and `numpy`; it does not download third-party assets.

### Historical three-zone arena frontier (Phase E; expanded in Phase J)

| Zone | Theme | Mineable resources | Creature | Gate requirement |
|---|---|---|---|---:|
| Starter Quarry | Green/brown open quarry, stone, timber | Copper, iron | Quarry Crawler | Level 1 |
| Molten Caves | Dark basalt, emissive orange fissure accents | Iron, gold | Ember Stalker | Level 3 |
| Crystal Peaks | Cold stone, blue/purple crystal formations | Gold, crystal | Crystal Sentinel | Level 5 |

- Three separate arenas are arranged along the world X axis at centers `0`, `36`, and `72`; portals handle region-to-region travel.
- Each region has a floor collider, four boundary wall colliders, two obstacle colliders, a spawn/checkpoint, at least two resource nodes, and one creature encounter.
- Starter Quarry has a forward gate to Molten Caves. Molten Caves has gates back to Starter Quarry and forward to Crystal Peaks. Crystal Peaks has a return gate to Molten Caves.
- Locked gates remain visible and report their required level. Unlock access is derived from the current XP level and is not trusted from a stored flag.
- Transitioning changes the active zone, moves the player to the destination spawn, changes ambient/key/fill lighting and fog, and clears previous interaction targets.
- Only the current zone's ore timers/targeting and creature AI are active. All zones' static collision geometry remains in the same Rapier world.
- Player defeat returns to the current zone's spawn rather than always returning to Starter Quarry.

## Requirements

- Node.js 22 or a compatible current LTS release.
- npm.
- A current desktop browser with WebGL support.
- Python 3.10+ and `trimesh`/`numpy` only when regenerating the optional GLB assets.

The game does not require an account, backend, paid service, or remote runtime models, textures, or fonts. Procedural Three.js meshes provide the current art.

## Install, run, and verify

```bash
npm install
npm run dev
```

Open the Vite URL printed in the terminal. For production:

```bash
npm run typecheck
npm test
npm run build
npm run preview
```

`npm test` runs four deterministic domain suites using Node assertions and the TypeScript compiler. Phase C covers inventory transactions, smelting/crafting atomicity, unique equipment, and stats. Phase D covers creature configuration, XP, pacification gating, loot rolls, and stack caps. Phase E covers region layouts, regional content, level-gated unlocks, safe travel, and checkpoints. Phase F covers save validation, legacy migration, corrupt-data rejection, inventory/progression/zone restoration, storage failures, reset behavior, and GLB binary integrity. These tests do not replace browser-based physics/gameplay testing or a GLTFLoader runtime test.

## Controls

| Input | Action |
|---|---|
| Click the 3D world | Capture the mouse for camera orbit |
| Mouse movement | Orbit the third-person camera while captured |
| `W`, `A`, `S`, `D` | Move relative to camera facing |
| `Space` | Jump when grounded |
| Aim at nearby ore + `E` | Apply one mining hit |
| Aim at a creature + `E` | Send a resonance pulse when in range |
| Aim at the forge + `E` | Open smelting/crafting panel |
| Aim at a portal + `E` | Enter its destination if unlocked |
| `I` | Toggle field satchel |
| `Esc` | Close a panel or release pointer lock |
| **Reset Save** button (bottom-right) | Confirm and erase local progress, then restart |

When a satchel or forge panel is open, movement and creature updates pause. Focused UI controls do not pass game actions through to the world.

## Gathering and regional resources

The Starter Quarry contains four copper and three iron nodes. Molten Caves contains one iron and two gold nodes. Crystal Peaks contains one gold and two crystal nodes. Aim at a node with the center reticle; the first visible object on the aim ray must be the node, and the player must be within `4.6` world units. Each `E` applies one mining hit, subject to the pickaxe-driven mining cooldown. Node data includes maximum health, base quantity, independent bonus chance/quantity, respawn delay, position, and collider extents.

## Forge recipes

### Smelting

| Recipe | Input | Output |
|---|---:|---:|
| Copper Ingot | 2 Copper Ore | 1 Copper Ingot |
| Iron Ingot | 2 Iron Ore | 1 Iron Ingot |
| Gold Ingot | 2 Gold Ore | 1 Gold Ingot |

### Crafting

| Equipment | Cost | Effect |
|---|---|---|
| Copperhead Pickaxe | 3 Copper Ingots + 1 Iron Ingot | `2.0×` mining power |
| Emberline Sword | 2 Copper Ingots + 1 Iron Ingot | 8 attack metadata, 1.20 actions/s |
| Deepdelver Maul | 3 Iron Ingots + 1 Copper Ingot | 13 attack metadata, 0.72 actions/s |

All smelting and crafting validates the full transaction before mutating inventory. Output stack capacity and unique equipment ownership are validated before input resources are consumed.

## Progression and gate rules

- Level 1 begins with Starter Quarry unlocked.
- Level 3 unlocks Molten Caves.
- Level 5 unlocks Crystal Peaks.
- Gates are usable only when the progression level meets the destination's requirement. A locked gate reports the exact required level.
- XP is awarded when a creature is successfully pacified. The XP curve makes level requirements deterministic; each successful award is validated as a positive safe integer.
- The current zone is the active checkpoint. Entering another zone updates the checkpoint and its visual lighting/fog treatment.

## Persistence details

- Browser storage key: `forgebound.save.v1`.
- Current schema: `schemaVersion: 1`.
- The stored checkpoint is a zone ID, not the last free-roam world position. Reloads return the player to the configured safe spawn for that zone.
- If the saved vitality is zero because the player refreshed during a defeat sequence, the save stores maximum vitality as a safe recovery value.
- Resource stacks must be between `0` and `9,999`. Unknown resources, equipment, zones, duplicate equipment IDs, invalid slot assignments, inconsistent XP totals, or zone unlocks beyond the saved level invalidate the save.
- Version `0` saves are migrated by deriving `checkpointId` from `currentZoneId` and deriving unlocked zones from the saved level. If older fields are absent, health defaults to `100` and the timestamp is replaced with the migration time.
- Invalid JSON, unsupported schemas, and blocked/quota-exceeded storage are handled without crashing the game. A reset control is available in the footer; it uses a confirmation dialog and reloads after successful deletion.
- Ore depletion timers and temporary creature pacification states are intentionally session state. They reset on reload; gathered resources, crafted equipment, XP, vitality, and zone checkpoint persist.

## GLB asset pipeline

The project includes these generated files in `public/assets/models`:

`player.glb`, `ore-copper.glb`, `ore-iron.glb`, `ore-gold.glb`, `ore-crystal.glb`, `pickaxe.glb`, `weapon-sword.glb`, `weapon-hammer.glb`, `enemy-crawler.glb`, `enemy-ember.glb`, `enemy-guardian.glb`, and `forge.glb`.

Regenerate them from the project root:

```bash
python -m pip install trimesh numpy
python tools/generate_assets.py
```

The script uses system Python (not Blender's bundled Python) and `trimesh`'s GLB exporter. It creates the output folder, writes deterministic low-poly primitive models, reopens each file, and verifies that it contains mesh geometry. The included generated files were actually produced and checked with `trimesh` in this build environment. `GLTFLoader` loads these local files at startup. If a model is unavailable or corrupt, the asset registry logs a warning and the corresponding procedural visual remains enabled. The pickaxe and weapon GLBs are included as assets for equipment presentation; the current HUD still presents equipment stats as text.

## Architecture

The project retains a small component-based architecture rather than introducing an ECS for this vertical slice.

- `src/core/GameApp.ts`: renderer/scene, fixed-step scheduling, camera, input routing, target selection, zone transitions, persistence orchestration, asset assignment, and HUD/panels.
- `src/assets/AssetRegistry.ts`: local GLTFLoader registry, clone-safe model instances, and procedural fallback handling.
- `src/systems/SaveSystem.ts`: schema validation, version-0 migration, storage access, and save/reset operations.
- `src/physics/PhysicsWorld.ts`: asynchronous Rapier initialization, arena floors/walls/obstacles, character controllers, collider factories, and fixed timestep.
- `src/world/world-config.ts`: three arena centers, floor shapes, obstacle definitions, and boundary collider generation.
- `src/data/zone-data.ts`: zone identity, unlock levels, checkpoints, and visual palettes.
- `src/data/portal-data.ts`: validated source/destination gate definitions for the Quarry ↔ Molten ↔ Peaks route.
- `src/data/mining-data.ts`: zone-assigned ore node definitions and mining balance.
- `src/data/enemy-data.ts`: zone-assigned enemy spawn/configuration and loot data.
- `src/entities/ZonePortal.ts`: portal visuals and target/access feedback.
- `src/systems/ZoneProgressionSystem.ts`: level-derived unlocks and safe zone travel validation.
- `src/entities/OreNode.ts`: ore visuals, durability, depletion, collider lifecycle, and respawn.
- `src/entities/Enemy.ts`: procedural creature visuals, Rapier character controller, AI state machine, and pacification/strike timing.
- `src/systems/MiningSystem.ts`: active-zone node updates, targeting, range/cooldown, and inventory rewards.
- `src/systems/CombatSystem.ts`: active-zone creature targeting, resonance gating, XP/loot rewards, player vitality, and checkpoint recovery.
- `src/systems/ProgressionSystem.ts`: level thresholds, XP carry, and safe XP awards.
- `src/systems/Inventory.ts` and `src/systems/ForgeSystem.ts`: resource transactions, equipment ownership, restore/reset, and recipes.
- `src/player/PlayerController.ts`: movement intent, Rapier-resolved transform, checkpoint teleports, and visual synchronization.

### Rapier and Three.js transform authority

Rendering uses `requestAnimationFrame`; physics advances on a fixed `1 / 60` second timestep. The render loop clamps large frame deltas, accumulates time, and runs up to five catch-up physics steps per rendered frame. Input becomes movement intent, Rapier computes collision-resolved character translation, the kinematic body receives the next translation, `world.step()` advances the state, and the Three.js visual copies the resulting Rapier body transform. Zone travel is an explicit checkpoint teleport applied to the kinematic body; it does not independently animate the visual mesh.

### Collider strategy

- Player and creatures: position-based kinematic rigid bodies with capsule colliders and Rapier character controllers.
- Every region: one fixed cuboid floor, four fixed boundary wall boxes, and two fixed obstacle boxes.
- Ore nodes and forge: fixed colliders created from the same world transforms as their visuals; depleted ore colliders are removed and restored on respawn.
- Portals: targetable interaction volumes/visual gates; the player must aim at the gate and be within `5.4` world units. Entering a gate teleports the player to the destination checkpoint.
- Creature movement and player movement resolve against the same Rapier world. Creature AI is simple pursuit/return rather than navmesh pathfinding.

## Project structure

```text
forgebound/
├── public/assets/models/              # 12 local GLB assets
├── tools/generate_assets.py
├── src/
│   ├── assets/AssetRegistry.ts
│   ├── core/GameApp.ts
│   ├── data/{enemy-data,equipment-data,forge-data,mining-data,portal-data,zone-data}.ts
│   ├── entities/{Enemy,ForgeStation,OreNode,ZonePortal}.ts
│   ├── input/InputManager.ts
│   ├── physics/PhysicsWorld.ts
│   ├── player/PlayerController.ts
│   ├── systems/{CombatRules,CombatSystem,ForgeSystem,Inventory,MiningSystem,ProgressionSystem,SaveSystem,ZoneProgressionSystem}.ts
│   ├── types/{combat,equipment,resources,zones}.ts
│   ├── styles/main.css
│   ├── world/world-config.ts
│   └── main.ts
├── tests/{phase-c,phase-d,phase-e,phase-f}.test.mjs
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
├── README.md
└── .gitignore
```

## Phase E manual smoke test

1. Run `npm install` and `npm run dev`; confirm loading completes and the physics readout reports three arenas.
2. In Starter Quarry, aim at the forward portal near the north side of the arena. Confirm the prompt reports that Molten Caves is sealed until level 3.
3. Gather copper/iron and calm the Quarry Crawler to earn XP. Confirm the HUD level/XP updates and the gate prompt changes when level 3 is reached.
4. Aim at the same gate and press `E`; confirm the player arrives at Molten Caves and the active-zone readout, fog, and lighting change.
5. Confirm Molten Caves contains iron/gold nodes and the Ember Stalker, and that ore mining and resonance still work there.
6. Use the return gate to go back to Starter Quarry; confirm the player returns to its spawn and the active region changes back.
7. Reach level 5 and enter Crystal Peaks from the Molten Caves gate. Confirm gold/crystal nodes and the Crystal Sentinel are present.
8. Use the Crystal Peaks return gate to travel back to Molten Caves.
9. Allow vitality to reach zero in each area and confirm checkpoint recovery returns to the current zone's spawn, preserving inventory.
10. Open the satchel/forge and confirm movement and creature updates pause as in earlier phases.
11. Run `npm test` and confirm all four Phase C, D, E, and F deterministic suites pass.

## Phase F manual smoke test

1. Run `npm install` and `npm run dev`; confirm the loading panel reports local models and the physics readout reports the loaded GLB count.
2. Gather ore, smelt it, and craft/equip an upgrade. Confirm the resource HUD and equipment panel update.
3. Calm a creature and confirm XP, vitality, and any loot reward update.
4. Travel to Molten Caves at level 3 or higher and Crystal Peaks at level 5 or higher.
5. Refresh the page. Confirm resource counts, equipment ownership/equipped slots, XP/level, vitality, unlocked zones, and the current-zone checkpoint are restored.
6. Open browser developer tools and inspect `localStorage` key `forgebound.save.v1`; confirm it contains schema version 1 and plain JSON data only.
7. Temporarily corrupt the stored JSON and refresh. Confirm the game starts a fresh expedition with a recoverable warning rather than crashing.
8. Remove one `.glb` file from `public/assets/models` and refresh. Confirm the console logs a warning and the procedural model remains visible.
9. Use **Reset Save**, confirm the dialog, and verify the game reloads to level 1 in Starter Quarry with default inventory and starter equipment.
10. Run `npm test` and confirm all four deterministic suites pass.

## Performance and render quality

The renderer now chooses a quality tier at startup. Phones and low-memory or few-core machines get `low`, mid-range machines get `medium`, and everything else gets `high`. Add `?quality=low`, `?quality=medium`, or `?quality=high` to the URL to override the choice. The HUD shows the active tier and the current render scale.

- `low`: no multisampling, pixel ratio capped at 1.25, 1024 shadow map, 60 fps cap.
- `medium`: multisampling on, pixel ratio capped at 1.5, 1024 shadow map, 60 fps cap.
- `high`: multisampling on, pixel ratio capped at 2, 2048 soft shadow map, uncapped.

Within each tier, sustained overload steps the pixel ratio down (never below the tier minimum) and sustained headroom steps it back up. While the inventory or forge panel is open the scene is drawn once and then held still, redrawing only when the panel closes or the window resizes.

Targeting uses one centre-of-screen ray per frame, shared by the mining, combat, portal, and forge checks. Hidden objects do not block targeting. Line of sight to creatures is recomputed every six fixed steps.

Tests: `npm test` runs the domain suites (Phases C–F), the render and targeting suite (Phase G), and a runtime harness that drives the real game loop with a fake renderer and DOM (Phase H). Phase H checks boot, the frame cap, adaptive resolution, render pausing, aiming, and zone travel.

## Input devices (Phase I)

- **Touch.** A move stick, ACT, JUMP, and PACK buttons, plus a layout panel that repositions or hides them.
  Drag the world to look and tap the world to act on the reticle. Layouts are saved per orientation.
- **DualSense.** The Gamepad API maps buttons, sticks, and rumble. Prompts switch to PlayStation button names.
  Adaptive triggers and extra haptics need WebHID: Chromium, USB, and https or localhost.
- **Feedback.** Named gameplay events drive rumble and trigger profiles. The Haptics toggle switches both off.
- Keyboard and mouse are unchanged.

See `docs/INPUT_INTEGRATION.md` for platform requirements, the integration steps, the DualSense hardware
checks that are still needed, and the testing checklist. `tests/phase-i-input.test.mjs` covers the input layer
without a browser.

## Current known limitations (Phase J7)

- Seven interiors are explorable and collision-backed, but the browser/physics runtime walkthrough has not yet been completed in this environment. Visual quality, door clearance, camera occlusion, and real Rapier contact need in-browser QA.
- Interior interaction uses named inspection points and one-time rewards; bespoke dungeon combat encounters and multi-stage interior puzzles are not included in J4.
- Enemy navigation is still based on the existing chase/leash behavior rather than a full navmesh.
- Save data records a safe zone checkpoint rather than a free-roam transform. A reload during an interior visit restores the zone checkpoint and preserves the exploration ledger.
- Full strict project typecheck, Vite production build, Phase G renderer harness, and Phase H `GameApp` runtime harness are blocked until Three.js, Rapier, Vite, and their declarations are restored. `npm ci` timed out in this execution environment.
- J7 civilian, dog, Ben and gear GLBs are low-poly static meshes. The 340-entry animation manifest identifies procedural runtime controllers; authored skeletal rigs and embedded GLB animation tracks are not complete.
- Gear material multipliers, refinement probabilities/stat bonuses, ingot trade quantities and refinement costs are initial balance defaults and require combat/economy playtesting.
- Browser playtesting is still required for civilian navigation/collisions, gear model fit, minimap readability, tutorial subtitle timing, the pickaxe custody handover, and save/resume behavior.

## Verification report (19 November 2026)

| Check | Result | Details |
|---|---|---|
| `npm test` | Passed | All Phase C, D, E, and F domain tests executed successfully. |
| `python tools/generate_assets.py` | Passed | Generated 12 local GLB files; each was reopened and verified to contain mesh geometry using `trimesh`. |
| Phase F TypeScript subset compilation | Passed | Save, inventory, progression, zone, and data modules compiled under strict TypeScript settings in the Phase F test. |
| `npm install --no-audit --no-fund --fetch-retries=0 --fetch-timeout=20000` | Blocked | npm registry DNS lookup failed with `EAI_AGAIN` for `registry.npmjs.org`. |
| `npm run typecheck` | Blocked | External package declarations for `three`, `@dimforge/rapier3d-compat`, and `vite` were unavailable. The Phase F-only TypeScript diagnostics found on the first pass were corrected; the final output was limited to missing dependency declarations. |
| `npm run build` | Blocked | The TypeScript stage stopped on missing external package declarations; Vite bundling was not reached. |
| GLTFLoader runtime parse | Not run | The Three.js package could not be installed in this environment. GLB binary format and mesh presence were verified with `trimesh`, not Three.js. |
| Browser gameplay smoke test | Not run | Dependencies could not be installed, so the Vite app could not be launched here. |
| Source/import/UI audit | Passed | 30 TypeScript files parsed with zero syntax diagnostics; 81 relative imports resolved; 60 unique HTML IDs and 32 required GameApp UI hooks verified; all 12 runtime asset paths exist. |

Once registry access is restored, run `npm install`, `npm run typecheck`, `npm test`, and `npm run build`, then complete the Phase F manual smoke test above. This report distinguishes deterministic tests and local asset validation from the still-unverified integrated browser build.


## Current verification report — Phase J4 (21 November 2026)

| Check | Result | Evidence |
|---|---|---|
| Phase C–F domain tests | Passed | Existing deterministic suites |
| Phase I inputs/touch/controller tests | Passed | Existing input suite |
| Phase J2 quest/commerce/refinement tests | Passed | NPC/quest roster, rewards, Coins, migration |
| Phase J3 mini-game tests | Passed | Nine activities, chess legality, reward anti-farming and quest hooks |
| Phase J4 exploration tests | Passed | Seven interiors, 21 POIs, entrance bounds, isolated origins, one-time claims, v4→v5 migration |
| TypeScript source syntax | Passed | 75 source files, zero syntax diagnostics |
| GLB validation | Passed | 419/419 files; 49 model + 363 terrain + 7 interior; 1,215 finite non-empty mesh objects |
| Phase G/H browser runtime tests | Blocked | Three.js and Rapier packages unavailable |
| `npm run typecheck` / Vite build | Not verified | npm dependency restoration timed out |

Run `npm ci`, then `npm run assets:generate:all`, `npm run typecheck`, `npm test`, and `npm run build` when package-registry access is available.

## Phase J6 release-candidate verification

Run the offline regression and Python-generated GLB integrity checks with:

```bash
python -m pip install -r requirements-assets.txt
npm run verify:offline
```

`release/release-manifest.json` records the current release-gate status. This Phase J6 archive is a candidate, not an approved final release: dependency installation, strict project typecheck, Phase G/H runtime tests, Vite build, and browser/device playtesting must pass before shipping.


## Phase J7 implementation and verification (21 November 2026)

- `npm run test:offline` — passed all included offline suites, including J7 domain, save migration, tutorial custody, per-item refinement pity, population caps and asset manifest checks.
- `npm run test:phase-j7` — passed.
- `npm run assets:verify` — passed 460 GLBs: 1,532 mesh objects, 265,018 vertices and 489,242 faces; byte lengths and SHA-256 checksums match `release/j7-asset-sha256.json`.
- Strict project typecheck / Vite build — blocked by the incomplete npm dependency installation; no successful browser build is claimed.
- Browser runtime / playthrough — not run.

See [`PHASE_J7_IMPLEMENTATION_NOTES.md`](PHASE_J7_IMPLEMENTATION_NOTES.md) for details, balance defaults and remaining work. The J7 release gate remains closed until the runtime checks and skeletal animation work are complete.
