import * as THREE from 'three';
import { AnimationController } from '../assets/AnimationController';
import type { NpcDefinition } from '../data/npc-data';

export type NpcQuestMarker = 'locked' | 'available' | 'active' | 'ready-to-turn-in' | 'completed';

export class Npc {
  readonly visualRoot = new THREE.Group();
  private readonly targetRing: THREE.Mesh;
  private readonly label: THREE.Sprite;
  private readonly questMarker: THREE.Sprite;
  private readonly questMarkerMaterial: THREE.SpriteMaterial;
  private readonly markerTextures = new Map<NpcQuestMarker, THREE.CanvasTexture>();
  private modelRoot: THREE.Group | null = null;
  private anim: AnimationController | null = null;
  private animationClock = 0;
  private reactionRemaining = 0;

  constructor(
    readonly definition: NpcDefinition,
    model: THREE.Group | null,
    position: THREE.Vector3,
    clips: readonly THREE.AnimationClip[] = [],
  ) {
    this.visualRoot.name = `npc-${definition.id}`;
    this.visualRoot.position.copy(position);
    this.visualRoot.userData['npcId'] = definition.id;

    if (model) {
      this.modelRoot = new THREE.Group();
      this.modelRoot.name = `npc-animation-root-${definition.id}`;
      this.modelRoot.add(model);
      model.name = `npc-model-${definition.id}`;
      model.scale.setScalar(1.0);
      model.position.y = 0;
      model.traverse((object: THREE.Object3D) => {
        object.userData['npcId'] = definition.id;
        if (object instanceof THREE.Mesh) {
          object.castShadow = true;
          object.receiveShadow = true;
        }
      });
      this.visualRoot.add(this.modelRoot);
      if (clips.length > 0) {
        this.anim = new AnimationController(model, clips);
        const defaultLoop = definition.id.includes('blacksmith') && this.anim.hasClip('work-smith') ? 'work-smith' : 'idle';
        this.anim.playLoop(defaultLoop, 0);
      }
    }

    this.targetRing = new THREE.Mesh(
      new THREE.TorusGeometry(0.85, 0.045, 8, 28),
      new THREE.MeshBasicMaterial({ color: 0xe0b66e, transparent: true, opacity: 0.82 }),
    );
    this.targetRing.rotation.x = Math.PI / 2;
    this.targetRing.position.y = 0.06;
    this.targetRing.visible = false;
    this.targetRing.userData['npcId'] = definition.id;
    this.visualRoot.add(this.targetRing);

    this.label = new THREE.Sprite(new THREE.SpriteMaterial({ map: createNpcLabel(definition.name), transparent: true, depthWrite: false }));
    this.label.scale.set(3.2, 0.62, 1);
    this.label.position.y = 2.65;
    this.label.userData['npcId'] = definition.id;
    this.visualRoot.add(this.label);

    this.questMarkerMaterial = new THREE.SpriteMaterial({ map: this.getQuestMarkerTexture('available'), transparent: true, depthWrite: false });
    this.questMarker = new THREE.Sprite(this.questMarkerMaterial);
    this.questMarker.scale.set(0.58, 0.58, 1);
    this.questMarker.position.set(0.98, 2.67, 0);
    this.questMarker.visible = false;
    this.questMarker.userData['npcId'] = definition.id;
    this.visualRoot.add(this.questMarker);
  }

  updateAnimations(deltaSeconds: number): void {
    const dt = Math.max(0, Math.min(deltaSeconds, 0.1));
    if (this.anim) {
      this.anim.update(dt);
      return;
    }
    this.animationClock += dt;
    this.reactionRemaining = Math.max(0, this.reactionRemaining - dt);
    if (!this.modelRoot) return;
    const greet = this.reactionRemaining > 0 ? 1 - this.reactionRemaining / 0.72 : 0;
    this.modelRoot.position.y = 0.04 + Math.sin(this.animationClock * 2.1) * 0.012 + Math.sin(greet * Math.PI) * 0.08;
    this.modelRoot.rotation.z = Math.sin(greet * Math.PI) * -0.09;
    this.modelRoot.rotation.y = Math.sin(this.animationClock * 0.75) * 0.025;
  }

  playGreetingReaction(): void {
    this.reactionRemaining = 0.72;
    this.anim?.playOneShot('greet', { fadeSeconds: 0.1 });
  }

  setTargeted(targeted: boolean): void {
    this.targetRing.visible = targeted;
    this.label.scale.set(3.2 * (targeted ? 1.06 : 1), 0.62 * (targeted ? 1.06 : 1), 1);
  }

  setQuestMarker(status: NpcQuestMarker): void {
    const visible = status === 'available' || status === 'active' || status === 'ready-to-turn-in';
    this.questMarker.visible = visible;
    if (visible) this.questMarkerMaterial.map = this.getQuestMarkerTexture(status);
    this.questMarkerMaterial.needsUpdate = true;
  }

  dispose(): void {
    this.anim?.dispose();
    this.label.material.map?.dispose();
    this.label.material.dispose();
    this.questMarkerMaterial.dispose();
    for (const texture of this.markerTextures.values()) texture.dispose();
    this.markerTextures.clear();
    this.targetRing.geometry.dispose();
    const ringMaterials = Array.isArray(this.targetRing.material)
      ? this.targetRing.material
      : [this.targetRing.material];
    for (const material of ringMaterials) material.dispose();
  }

  private getQuestMarkerTexture(status: NpcQuestMarker): THREE.CanvasTexture {
    const cached = this.markerTextures.get(status);
    if (cached) return cached;
    const canvas = document.createElement('canvas');
    canvas.width = 96;
    canvas.height = 96;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('NPC quest marker canvas is unavailable.');

    const fill = status === 'ready-to-turn-in' ? '#f5b942' : status === 'available' ? '#62d18c' : '#6cb4ee';
    const glyph = status === 'ready-to-turn-in' ? '?' : status === 'available' ? '!' : '•';

    ctx.fillStyle = 'rgba(13, 21, 21, 0.88)';
    ctx.beginPath();
    ctx.arc(48, 48, 38, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = fill;
    ctx.lineWidth = 6;
    ctx.stroke();

    ctx.fillStyle = fill;
    ctx.font = 'bold 54px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(glyph, 48, 51);

    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    this.markerTextures.set(status, texture);
    return texture;
  }
}

function createNpcLabel(name: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 384;
  canvas.height = 72;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('NPC label canvas is unavailable.');
  ctx.fillStyle = 'rgba(12, 20, 20, 0.84)';
  ctx.beginPath();
  ctx.roundRect(4, 4, 376, 64, 14);
  ctx.fill();
  ctx.strokeStyle = 'rgba(224, 182, 110, 0.45)';
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = '#f0dec0';
  ctx.font = '600 30px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(name, 192, 37);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}
