import * as THREE from 'three';
import type { QuestWorldObjectDefinition } from '../data/quest-world-data';

export class QuestWorldObject {
  readonly visualRoot = new THREE.Group();
  private readonly targetRing: THREE.Mesh;
  private used = false;

  constructor(readonly definition: QuestWorldObjectDefinition, model: THREE.Group | null, position: THREE.Vector3) {
    this.visualRoot.name = `quest-object-${definition.id}`;
    this.visualRoot.position.copy(position);
    this.visualRoot.userData['questObjectInstanceId'] = definition.id;
    this.visualRoot.userData['questObjectId'] = definition.objectId;
    if (model) {
      model.name = `quest-object-model-${definition.id}`;
      model.scale.setScalar(definition.objectId === 'magma-corn-plant' ? 0.82 : 0.95);
      model.traverse((object: THREE.Object3D) => {
        object.userData['questObjectInstanceId'] = definition.id;
        object.userData['questObjectId'] = definition.objectId;
        if (object instanceof THREE.Mesh) { object.castShadow = true; object.receiveShadow = true; }
      });
      this.visualRoot.add(model);
    }
    this.targetRing = new THREE.Mesh(
      new THREE.TorusGeometry(0.55, 0.035, 8, 24),
      new THREE.MeshBasicMaterial({ color: 0x9ec8a0, transparent: true, opacity: 0.8 }),
    );
    this.targetRing.rotation.x = Math.PI / 2;
    this.targetRing.position.y = 0.05;
    this.targetRing.visible = false;
    this.targetRing.userData['questObjectInstanceId'] = definition.id;
    this.visualRoot.add(this.targetRing);
  }

  isAvailable(): boolean { return !this.used; }
  setTargeted(targeted: boolean): void { this.targetRing.visible = targeted && this.isAvailable(); }
  consume(): boolean {
    if (!this.isAvailable()) return false;
    if (this.definition.oneTime) {
      this.used = true;
      this.visualRoot.visible = false;
    }
    return true;
  }
  restoreUsed(used: boolean): void { this.used = used; this.visualRoot.visible = !used; }

  dispose(): void {
    this.targetRing.geometry.dispose();
    const materials = Array.isArray(this.targetRing.material) ? this.targetRing.material : [this.targetRing.material];
    for (const material of materials) material.dispose();
  }
}
