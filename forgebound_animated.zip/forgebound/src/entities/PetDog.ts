import * as THREE from 'three';
import type { CharacterPhysicsBody } from '../physics/PhysicsWorld';
import { PhysicsWorld } from '../physics/PhysicsWorld';
import type { ZoneId } from '../types/zones';
import { getZoneTerrainHeight } from '../world/terrain-height';
import { ZONE_DEFINITIONS } from '../data/zone-data';

/** One wandering dog actor for the entire world; petting plays a procedural reaction. */
export class PetDog {
  readonly visualRoot = new THREE.Group();
  readonly body: CharacterPhysicsBody;
  private readonly tail = new THREE.Group();
  private readonly destination = new THREE.Vector3();
  private timer = 0;
  private phase = 0;
  private happyRemaining = 0;
  private petCooldownRemaining = 0;

  constructor(private readonly physics: PhysicsWorld, model: THREE.Group | null, private readonly homeZone: ZoneId, position: THREE.Vector3) {
    this.visualRoot.name = 'pet-dog-singleton';
    this.visualRoot.position.copy(position);
    this.body = physics.createCharacterCapsule({ x: position.x, y: position.y + 0.42, z: position.z }, 0.2, 0.22, 0.55);
    if (model) {
      model.position.y = 0;
      model.scale.setScalar(0.52);
      this.visualRoot.add(model);
    } else {
      const bodyMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.42, 4, 8), new THREE.MeshStandardMaterial({ color: 0xb98758, roughness: 0.9 }));
      bodyMesh.rotation.z = Math.PI / 2; bodyMesh.position.y = 0.26; this.visualRoot.add(bodyMesh);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 8), new THREE.MeshStandardMaterial({ color: 0xc99867 })); head.position.set(0, 0.45, 0.25); this.visualRoot.add(head);
      for (const side of [-1, 1]) { const ear = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.2, 6), new THREE.MeshStandardMaterial({ color: 0x83583a })); ear.position.set(side * 0.12, 0.61, 0.28); this.visualRoot.add(ear); }
    }
    const tailMesh = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.36, 7), new THREE.MeshStandardMaterial({ color: 0x8d5f3e }));
    tailMesh.rotation.x = Math.PI / 2; tailMesh.position.set(0, 0.35, -0.34); this.tail.add(tailMesh); this.visualRoot.add(this.tail);
    this.chooseDestination(position);
  }

  update(deltaSeconds: number, activeZone: ZoneId): void {
    const dt = Math.max(0, Math.min(deltaSeconds, 0.1)); this.phase += dt * (this.happyRemaining > 0 ? 15 : 6);
    this.happyRemaining = Math.max(0, this.happyRemaining - dt); this.petCooldownRemaining = Math.max(0, this.petCooldownRemaining - dt); this.timer -= dt;
    const current = this.body.body.translation();
    if (activeZone === this.homeZone && (this.timer <= 0 || Math.hypot(this.destination.x - current.x, this.destination.z - current.z) < 0.45)) {
      this.chooseDestination(new THREE.Vector3(current.x, current.y - 0.42, current.z));
    }
    if (activeZone === this.homeZone && this.happyRemaining <= 0) {
      const dx = this.destination.x - current.x; const dz = this.destination.z - current.z; const distance = Math.hypot(dx, dz);
      if (distance > 0.08) {
        const step = Math.min(distance, dt * 0.82);
        const next = { x: dx / distance * step, y: 0, z: dz / distance * step };
        this.body.controller.computeColliderMovement(this.body.collider, next);
        const corrected = this.body.controller.computedMovement();
        this.body.body.setNextKinematicTranslation({ x: current.x + corrected.x, y: getZoneTerrainHeight(this.homeZone, current.x - ZONE_DEFINITIONS[this.homeZone].spawn.x, current.z - ZONE_DEFINITIONS[this.homeZone].spawn.z) + 0.42, z: current.z + corrected.z });
        this.visualRoot.rotation.y = Math.atan2(dx, dz);
      }
    }
    const pos = this.body.body.translation(); this.visualRoot.position.set(pos.x, pos.y - 0.42 + (this.happyRemaining > 0 ? Math.abs(Math.sin(this.phase)) * 0.12 : 0), pos.z);
    this.tail.rotation.x = Math.sin(this.phase * 2.4) * (this.happyRemaining > 0 ? 0.9 : 0.35);
  }

  setActive(active: boolean): void { this.visualRoot.visible = active; this.body.collider.setEnabled(active); }
  pet(): boolean { if (this.petCooldownRemaining > 0) return false; this.happyRemaining = 2.1; this.petCooldownRemaining = 3.0; this.timer = 2.1; return true; }
  isPetReady(): boolean { return this.petCooldownRemaining <= 0; }
  distanceTo(position: THREE.Vector3): number { return this.visualRoot.position.distanceTo(position); }
  dispose(): void { this.physics.removeCharacter(this.body.body, this.body.controller); }
  private chooseDestination(origin: THREE.Vector3): void {
    const angle = Math.random() * Math.PI * 2; const radius = 1 + Math.random() * 4.5;
    this.destination.set(origin.x + Math.cos(angle) * radius, origin.y, origin.z + Math.sin(angle) * radius);
    this.timer = 3 + Math.random() * 4;
  }
}
