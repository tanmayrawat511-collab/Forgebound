import * as THREE from 'three';
import type RAPIER from '@dimforge/rapier3d-compat';
import type { PhysicsWorld } from '../physics/PhysicsWorld';
import { getZoneTerrainHeight } from '../world/terrain-height';

export class ForgeStation {
  readonly visualRoot = new THREE.Group();
  readonly position = new THREE.Vector3(-8, 0, 8.5);
  private readonly body: RAPIER.RigidBody;

  /**
   * `model` is the GLB forge. When it is supplied the procedural fallback is never built,
   * so no hidden meshes are allocated.
   */
  constructor(private readonly physics: PhysicsWorld, model: THREE.Object3D | null = null) {
    this.visualRoot.name = 'starter-quarry-forge';
    this.position.y = getZoneTerrainHeight('starter-quarry', this.position.x, this.position.z);
    this.visualRoot.position.copy(this.position);

    if (model) {
      model.name = 'forge-local-glb';
      model.traverse((object: THREE.Object3D) => { object.userData['forgeStation'] = true; });
      this.visualRoot.add(model);
    } else {
      this.buildFallback();
    }

    // The forge's glow is one of the scene's two remaining point lights.
    const glow = new THREE.PointLight(0xff6a2f, 15, 7, 2);
    glow.position.set(0.12, 1.5, 0.7);
    this.visualRoot.add(glow);

    this.body = this.physics.createFixedBox(
      { x: this.position.x, y: this.position.y + 0.83, z: this.position.z },
      { x: 1.65, y: 0.83, z: 1.02 },
      0.9,
    );
  }

  dispose(): void {
    this.physics.removeRigidBody(this.body);
    this.visualRoot.traverse((object: THREE.Object3D) => {
      if (!(object instanceof THREE.Mesh)) return;
      object.geometry.dispose();
      const materials = Array.isArray(object.material) ? object.material : [object.material];
      for (const material of materials) material.dispose();
    });
  }

  private buildFallback(): void {
    const fallbackVisualRoot = new THREE.Group();
    fallbackVisualRoot.name = 'procedural-forge-fallback';
    this.visualRoot.add(fallbackVisualRoot);

    const stone = new THREE.MeshStandardMaterial({ color: 0x414b49, roughness: 0.96 });
    const darkIron = new THREE.MeshStandardMaterial({ color: 0x222b2b, roughness: 0.56, metalness: 0.72 });
    const copper = new THREE.MeshStandardMaterial({ color: 0xa76b43, roughness: 0.45, metalness: 0.58 });
    const ember = new THREE.MeshStandardMaterial({
      color: 0xff8a37,
      emissive: 0xf05a18,
      emissiveIntensity: 2.2,
      roughness: 0.3,
    });

    this.addBox(fallbackVisualRoot, 2.35, 0.45, 1.95, stone, 0, 0.24, 0);
    this.addBox(fallbackVisualRoot, 1.55, 1.1, 1.32, darkIron, 0, 0.91, 0);
    this.addBox(fallbackVisualRoot, 1.2, 0.2, 1.08, copper, 0, 1.58, 0);

    const chimney = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.5, 1.55, 7), stone);
    chimney.position.set(-0.47, 2.0, -0.28);
    chimney.castShadow = true;
    this.tag(chimney);
    fallbackVisualRoot.add(chimney);

    const chimneyCap = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.38, 0.18, 7), darkIron);
    chimneyCap.position.set(-0.47, 2.81, -0.28);
    chimneyCap.castShadow = true;
    this.tag(chimneyCap);
    fallbackVisualRoot.add(chimneyCap);

    const opening = new THREE.Mesh(new THREE.SphereGeometry(0.38, 9, 7), ember);
    opening.scale.set(1.05, 0.72, 0.28);
    opening.position.set(0.12, 1.45, 0.69);
    opening.castShadow = true;
    this.tag(opening);
    fallbackVisualRoot.add(opening);

    const anvilBase = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.48, 0.33, 6), darkIron);
    anvilBase.position.set(0.96, 0.67, -0.24);
    anvilBase.castShadow = true;
    this.tag(anvilBase);
    fallbackVisualRoot.add(anvilBase);

    this.addBox(fallbackVisualRoot, 0.92, 0.3, 0.55, darkIron, 0.96, 0.96, -0.24);
    this.addBox(fallbackVisualRoot, 0.38, 0.24, 0.42, darkIron, 1.54, 1.06, -0.24);
  }

  private addBox(
    parent: THREE.Object3D,
    width: number,
    height: number,
    depth: number,
    material: THREE.Material,
    x: number,
    y: number,
    z: number,
  ): void {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), material);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    this.tag(mesh);
    parent.add(mesh);
  }

  private tag(mesh: THREE.Object3D): void {
    mesh.userData['forgeStation'] = true;
  }
}
