import * as THREE from 'three';
import { AnimationController } from '../assets/AnimationController';
import { sharedGlowTexture } from '../render/sharedResources';
import type { CharacterPhysicsBody, PhysicsWorld } from '../physics/PhysicsWorld';
import type { EnemyDefinition, EnemyState } from '../types/combat';
import { OPEN_WORLD_ZONES } from '../world/open-world-config';
import { getZoneTerrainHeight } from '../world/terrain-height';

export class Enemy {
  readonly visualRoot = new THREE.Group();
  readonly id: string;
  readonly name: string;
  readonly definition: EnemyDefinition;

  private readonly physics: PhysicsWorld;
  private readonly spawn: Readonly<{ x: number; y: number; z: number }>;
  private readonly creature = new THREE.Group();
  private readonly fallbackCreature = new THREE.Group();
  private readonly targetRing: THREE.Sprite;
  private character: CharacterPhysicsBody | null = null;
  private state: EnemyState = 'idle';
  private active = true;
  private currentHealth: number;
  private maximumHealth: number;
  private respawnRemaining = 0;
  private pacifiedRemaining = 0;
  private attackCooldownRemaining = 0.45;
  private damageMultiplier = 1;
  private animationsEnabled = true;
  private anim: AnimationController | null = null;
  private visualClock = 0;
  private detectRemaining = 0;
  private verticalVelocity = 0;
  private readonly desiredMovement = { x: 0, y: 0, z: 0 };
  private readonly nextTranslation = { x: 0, y: 0, z: 0 };
  private readonly positionCache = new THREE.Vector3();

  /**
   * `model` is the GLB creature. When supplied, the procedural body is never built.
   */
  constructor(definition: EnemyDefinition, physics: PhysicsWorld, model: THREE.Object3D | null = null, clips: readonly THREE.AnimationClip[] = []) {
    this.definition = definition;
    this.id = definition.id;
    this.name = definition.name;
    this.physics = physics;
    const zoneOriginX = OPEN_WORLD_ZONES[definition.zoneId].originX;
    const groundY = getZoneTerrainHeight(definition.zoneId, definition.spawn.x - zoneOriginX, definition.spawn.z);
    this.spawn = { x: definition.spawn.x, y: groundY + 0.88, z: definition.spawn.z };
    this.maximumHealth = definition.maximumHealth;
    this.currentHealth = this.maximumHealth;

    this.visualRoot.name = `enemy-${definition.id}`;
    this.visualRoot.userData['enemyId'] = definition.id;
    this.visualRoot.add(this.creature);
    this.creature.add(this.fallbackCreature);
    if (model) {
      this.attachModel(model);
      if (clips.length > 0) {
        this.anim = new AnimationController(model, clips);
        this.anim.playLoop('idle', 0);
      }
    } else {
      this.buildCreature();
    }

    this.targetRing = new THREE.Sprite(new THREE.SpriteMaterial({
      map: sharedGlowTexture(),
      color: 0xe6bd77,
      transparent: true,
      opacity: 0.78,
      depthWrite: false,
    }));
    this.targetRing.scale.set(1.75, 1.75, 1);
    this.targetRing.position.y = -0.77;
    this.targetRing.visible = false;
    // Tagged so that a ray grazing the highlight still resolves to this creature.
    this.targetRing.userData['enemyId'] = definition.id;
    this.visualRoot.add(this.targetRing);

    this.spawnCharacter();
    this.syncFromPhysics();
  }

  private attachModel(model: THREE.Object3D): void {
    model.name = `creature-local-${this.id}`;
    model.traverse((object: THREE.Object3D) => { object.userData['enemyId'] = this.id; });
    model.scale.setScalar(this.definition.bodyScale > 0.78 ? 1 : 0.92);
    this.creature.add(model);
  }

  getCurrentState(): EnemyState {
    return this.state;
  }

  isAlive(): boolean {
    return this.active;
  }

  setDamageMultiplier(multiplier: number): void {
    this.damageMultiplier = Number.isFinite(multiplier) ? Math.max(0.1, Math.min(3, multiplier)) : 1;
  }

  /** Changes maximum health while preserving the creature's current health percentage. */
  setHealthMultiplier(multiplier: number): void {
    const safeMultiplier = Number.isFinite(multiplier) ? Math.max(0.5, Math.min(2, multiplier)) : 1;
    const nextMaximum = Math.max(1, Math.round(this.definition.maximumHealth * safeMultiplier));
    const ratio = this.maximumHealth > 0 ? this.currentHealth / this.maximumHealth : 1;
    this.maximumHealth = nextMaximum;
    if (this.active) this.currentHealth = Math.max(1, Math.min(nextMaximum, Math.round(nextMaximum * ratio)));
  }

  setAnimationsEnabled(enabled: boolean): void {
    this.animationsEnabled = enabled;
    this.anim?.setEnabled(enabled);
    if (!enabled) {
      this.creature.position.y = 0;
      this.creature.rotation.z = 0;
    }
  }

  updateVisualAnimations(deltaSeconds: number): void {
    if (!this.active || !this.animationsEnabled) return;
    if (this.anim) {
      const clip = this.state === 'attack' ? 'attack' : (this.state === 'chase' || this.state === 'return') ? 'chase' : 'idle';
      if (clip === 'attack') this.anim.playOneShot('attack', { fadeSeconds: 0.08 });
      else this.anim.playLoop(clip, 0.14);
      this.anim.update(deltaSeconds);
      return;
    }
    this.visualClock += deltaSeconds;
    const moving = this.state === 'chase' || this.state === 'return';
    this.creature.position.y = Math.sin(this.visualClock * (moving ? 8 : 2.2)) * (moving ? 0.035 : 0.018);
    this.creature.rotation.z = this.state === 'attack' ? Math.sin(this.visualClock * 18) * 0.045 : 0;
  }

  getHealth(): number {
    return this.currentHealth;
  }

  getHealthRatio(): number {
    return this.maximumHealth > 0
      ? Math.max(0, this.currentHealth / this.maximumHealth)
      : 0;
  }

  takeDamage(amount: number): { readonly applied: number; readonly remainingHealth: number; readonly defeated: boolean } {
    if (!this.active || !Number.isFinite(amount) || amount <= 0) {
      return { applied: 0, remainingHealth: this.currentHealth, defeated: false };
    }
    const applied = Math.min(this.currentHealth, Math.max(1, Math.floor(amount)));
    this.currentHealth = Math.max(0, this.currentHealth - applied);
    if (this.currentHealth === 0) {
      this.active = false;
      this.state = 'defeated';
      this.targetRing.visible = false;
      this.respawnRemaining = Math.max(5, this.definition.respawnSeconds);
      this.visualRoot.visible = false;
      this.removeCharacter();
      return { applied, remainingHealth: 0, defeated: true };
    }
    return { applied, remainingHealth: this.currentHealth, defeated: false };
  }

  isPacified(): boolean {
    return this.state === 'pacified';
  }

  canBePacified(): boolean {
    return this.active && this.state !== 'pacified';
  }

  setTargeted(targeted: boolean): void {
    this.targetRing.visible = targeted && this.active && !this.isPacified();
  }

  getWorldPosition(target = this.positionCache): THREE.Vector3 {
    if (this.character) {
      const position = this.character.body.translation();
      return target.set(position.x, position.y, position.z);
    }
    return target.copy(this.visualRoot.position);
  }

  /** A non-weapon resonance action calms the creature for a short recovery interval. */
  pacify(): boolean {
    if (!this.canBePacified()) return false;
    this.state = 'pacified';
    this.pacifiedRemaining = this.definition.pacifiedSeconds;
    this.detectRemaining = 0;
    this.targetRing.visible = false;
    return true;
  }

  /** Advances the AI and prepares a collision-resolved next kinematic transform. */
  fixedUpdate(
    playerPosition: THREE.Vector3,
    deltaSeconds: number,
    hasLineOfSight: boolean,
  ): number | null {
    if (!this.active) {
      if (this.respawnRemaining > 0) {
        this.respawnRemaining = Math.max(0, this.respawnRemaining - deltaSeconds);
        if (this.respawnRemaining === 0) {
          this.currentHealth = this.maximumHealth;
          this.active = true;
          this.state = 'idle';
          this.visualRoot.visible = true;
          this.spawnCharacter();
          this.syncFromPhysics();
        }
      }
      return null;
    }
    if (!this.character) return null;

    this.attackCooldownRemaining = Math.max(0, this.attackCooldownRemaining - deltaSeconds);
    const position = this.character.body.translation();
    const dx = playerPosition.x - position.x;
    const dz = playerPosition.z - position.z;
    const playerDistance = Math.hypot(dx, dz);
    const homeDx = this.spawn.x - position.x;
    const homeDz = this.spawn.z - position.z;
    const homeDistance = Math.hypot(homeDx, homeDz);

    let moveX = 0;
    let moveZ = 0;
    let attackDamage: number | null = null;

    if (this.state === 'pacified') {
      this.pacifiedRemaining = Math.max(0, this.pacifiedRemaining - deltaSeconds);
      if (homeDistance > 0.65) {
        const direction = normalize2D(homeDx, homeDz);
        moveX = direction.x * this.definition.moveSpeed * 0.8;
        moveZ = direction.z * this.definition.moveSpeed * 0.8;
      } else if (this.pacifiedRemaining === 0) {
        this.state = 'idle';
      }
    } else if (homeDistance > this.definition.leashRange) {
      this.state = 'return';
      const direction = normalize2D(homeDx, homeDz);
      moveX = direction.x * this.definition.moveSpeed;
      moveZ = direction.z * this.definition.moveSpeed;
    } else if (playerDistance <= this.definition.detectionRange) {
      if (playerDistance <= this.definition.attackRange && hasLineOfSight) {
        this.state = 'attack';
        if (this.attackCooldownRemaining <= 0) {
          this.attackCooldownRemaining = this.definition.attackCooldownSeconds;
          attackDamage = this.definition.attackDamage * this.damageMultiplier;
        }
      } else {
        if (this.state === 'idle' || this.state === 'return' || this.state === 'attack') {
          this.state = 'detect';
          this.detectRemaining = 0.38;
        }
        if (this.state === 'detect') {
          this.detectRemaining = Math.max(0, this.detectRemaining - deltaSeconds);
          if (this.detectRemaining === 0) this.state = 'chase';
        } else {
          this.state = 'chase';
        }
        if (this.state === 'chase') {
          const direction = normalize2D(dx, dz);
          moveX = direction.x * this.definition.moveSpeed;
          moveZ = direction.z * this.definition.moveSpeed;
        }
      }
    } else if (homeDistance > 0.9) {
      this.state = 'return';
      const direction = normalize2D(homeDx, homeDz);
      moveX = direction.x * this.definition.moveSpeed;
      moveZ = direction.z * this.definition.moveSpeed;
    } else {
      this.state = 'idle';
    }

    this.verticalVelocity = Math.max(this.verticalVelocity - 22 * deltaSeconds, -24);
    this.desiredMovement.x = moveX * deltaSeconds;
    this.desiredMovement.y = this.verticalVelocity * deltaSeconds;
    this.desiredMovement.z = moveZ * deltaSeconds;
    this.character.controller.computeColliderMovement(
      this.character.collider,
      this.desiredMovement,
    );

    const resolved = this.character.controller.computedMovement();
    this.nextTranslation.x = position.x + resolved.x;
    this.nextTranslation.y = position.y + resolved.y;
    this.nextTranslation.z = position.z + resolved.z;
    this.character.body.setNextKinematicTranslation(this.nextTranslation);
    const grounded = this.character.controller.computedGrounded();
    if (grounded && this.verticalVelocity < 0) this.verticalVelocity = 0;

    if (Math.abs(moveX) + Math.abs(moveZ) > 0.05) {
      this.creature.rotation.y = Math.atan2(moveX, moveZ);
    }
    return attackDamage;
  }

  syncFromPhysics(): void {
    if (!this.character) return;
    const position = this.character.body.translation();
    this.visualRoot.position.set(position.x, position.y, position.z);
  }

  disengage(): void {
    if (this.active && this.state !== 'pacified') this.state = 'return';
  }

  dispose(): void {
    this.active = false;
    this.removeCharacter();
    const geometries = new Set<THREE.BufferGeometry>();
    const materials = new Set<THREE.Material>();
    this.visualRoot.traverse((object: THREE.Object3D) => {
      if (!(object instanceof THREE.Mesh)) return;
      geometries.add(object.geometry);
      const objectMaterials = Array.isArray(object.material) ? object.material : [object.material];
      for (const material of objectMaterials) materials.add(material);
    });
    for (const geometry of geometries) geometry.dispose();
    for (const material of materials) material.dispose();
    this.targetRing.material.dispose();
  }

  private spawnCharacter(): void {
    this.character = this.physics.createCharacterCapsule(this.spawn, 0.43, 0.43, 0.05);
  }

  private removeCharacter(): void {
    if (!this.character) return;
    this.physics.removeCharacter(this.character.body, this.character.controller);
    this.character = null;
  }

  private buildCreature(): void {
    const bodyMaterial = new THREE.MeshStandardMaterial({
      color: this.definition.bodyColor,
      roughness: 0.74,
      metalness: 0.16,
      emissive: this.definition.emissiveColor,
      emissiveIntensity: 0.15,
    });
    const accentMaterial = new THREE.MeshStandardMaterial({
      color: this.definition.accentColor,
      roughness: 0.48,
      metalness: 0.28,
      emissive: this.definition.emissiveColor,
      emissiveIntensity: 0.42,
    });
    const darkMaterial = new THREE.MeshStandardMaterial({ color: 0x202928, roughness: 0.62, metalness: 0.22 });
    const eyeMaterial = new THREE.MeshStandardMaterial({
      color: 0xffb36b,
      emissive: 0xf45a26,
      emissiveIntensity: 1.25,
      roughness: 0.28,
    });

    let bodyGeometry: THREE.BufferGeometry;
    if (this.id === 'quarry-crawler') bodyGeometry = new THREE.DodecahedronGeometry(this.definition.bodyScale, 0);
    else if (this.id === 'ember-stalker') bodyGeometry = new THREE.IcosahedronGeometry(this.definition.bodyScale, 0);
    else bodyGeometry = new THREE.OctahedronGeometry(this.definition.bodyScale, 0);

    const body = this.makeMesh(bodyGeometry, bodyMaterial);
    body.position.y = -0.08;
    body.scale.set(1.05, 0.86, 1.16);
    this.fallbackCreature.add(body);

    const head = this.makeMesh(
      this.id === 'crystal-sentinel'
        ? new THREE.OctahedronGeometry(0.31, 0)
        : new THREE.SphereGeometry(0.28, 10, 8),
      this.id === 'crystal-sentinel' ? accentMaterial : bodyMaterial,
    );
    head.position.set(0, 0.36, 0.36);
    this.fallbackCreature.add(head);

    for (const side of [-1, 1]) {
      const eye = this.makeMesh(new THREE.SphereGeometry(0.065, 8, 6), eyeMaterial);
      eye.position.set(side * 0.13, 0.4, 0.59);
      eye.scale.set(1, 0.78, 0.72);
      this.fallbackCreature.add(eye);
    }

    if (this.id === 'quarry-crawler') {
      for (const side of [-1, 1]) {
        for (const frontBack of [-1, 1]) {
          const leg = this.makeMesh(new THREE.CylinderGeometry(0.075, 0.11, 0.5, 5), darkMaterial);
          leg.position.set(side * 0.43, -0.37, frontBack * 0.34);
          leg.rotation.z = side * 0.48;
          leg.rotation.x = frontBack * 0.24;
          this.fallbackCreature.add(leg);
        }
      }
      const shell = this.makeMesh(new THREE.DodecahedronGeometry(0.22, 0), accentMaterial);
      shell.position.set(0, 0.4, -0.12);
      shell.scale.set(1.2, 0.72, 1.3);
      this.fallbackCreature.add(shell);
    } else if (this.id === 'ember-stalker') {
      for (let index = 0; index < 5; index += 1) {
        const spike = this.makeMesh(new THREE.ConeGeometry(0.13, 0.45, 5), accentMaterial);
        spike.position.set(-0.42 + index * 0.21, 0.48 + (index % 2) * 0.08, -0.22);
        spike.rotation.z = -0.22 + index * 0.11;
        this.fallbackCreature.add(spike);
      }
      const core = this.makeMesh(new THREE.SphereGeometry(0.18, 9, 7), eyeMaterial);
      core.position.set(0, -0.04, 0.55);
      this.fallbackCreature.add(core);
    } else {
      for (const side of [-1, 1]) {
        const crystal = this.makeMesh(new THREE.OctahedronGeometry(0.3, 0), accentMaterial);
        crystal.position.set(side * 0.53, 0.1, -0.03);
        crystal.scale.set(0.72, 1.65, 0.72);
        crystal.rotation.z = side * -0.24;
        this.fallbackCreature.add(crystal);
      }
      const crest = this.makeMesh(new THREE.OctahedronGeometry(0.34, 0), accentMaterial);
      crest.position.set(0, 0.72, -0.06);
      crest.scale.set(0.76, 1.4, 0.76);
      this.fallbackCreature.add(crest);
    }
  }

  private makeMesh(geometry: THREE.BufferGeometry, material: THREE.Material): THREE.Mesh {
    const mesh = new THREE.Mesh(geometry, material);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.userData['enemyId'] = this.id;
    return mesh;
  }
}

function normalize2D(x: number, z: number): { readonly x: number; readonly z: number } {
  const length = Math.hypot(x, z);
  if (length <= 0.0001) return { x: 0, z: 0 };
  return { x: x / length, z: z / length };
}
