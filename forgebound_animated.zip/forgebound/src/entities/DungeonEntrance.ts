import * as THREE from 'three';
import type { DungeonDefinition } from '../data/dungeon-data';

/** A visible, zone-local entrance to one authored Python-generated interior. */
export class DungeonEntrance {
  readonly visualRoot: THREE.Group;
  private targeted = false;

  constructor(
    readonly definition: DungeonDefinition,
    model: THREE.Group | null,
    position: THREE.Vector3,
  ) {
    this.visualRoot = new THREE.Group();
    this.visualRoot.name = `dungeon-entrance-${definition.id}`;
    this.visualRoot.position.copy(position);
    this.visualRoot.userData['dungeonEntranceId'] = definition.id;
    this.visualRoot.userData['dungeonEntranceZoneId'] = definition.zoneId;
    this.visualRoot.scale.setScalar(definition.kind === 'cave' ? 2.25 : 2.55);
    if (model) {
      model.traverse((object) => { object.userData['dungeonEntranceId'] = definition.id; });
      this.visualRoot.add(model);
    }
  }

  setTargeted(targeted: boolean): void {
    if (this.targeted === targeted) return;
    this.targeted = targeted;
    this.visualRoot.scale.multiplyScalar(targeted ? 1.045 : 1 / 1.045);
  }

  dispose(): void {
    this.visualRoot.removeFromParent();
  }
}
