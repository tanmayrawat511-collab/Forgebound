import * as THREE from 'three';
import type { MiniGameStationDefinition } from '../data/mini-game-data';

export class MiniGameStation {
  readonly visualRoot = new THREE.Group();
  private readonly targetRing: THREE.Mesh;
  private readonly label: THREE.Sprite;

  constructor(readonly definition: MiniGameStationDefinition, model: THREE.Group | null, position: THREE.Vector3) {
    this.visualRoot.name = `minigame-station-${definition.id}`;
    this.visualRoot.position.copy(position);
    this.visualRoot.userData['miniGameStationId'] = definition.id;
    this.visualRoot.userData['miniGameId'] = definition.gameId;
    if (model) {
      model.name = `minigame-station-model-${definition.id}`;
      const scale = definition.gameId === 'crystal-fishing' ? 2.2 : definition.gameId === 'quarry-cart-rally' ? 1.2 : 0.95;
      model.scale.setScalar(scale);
      model.traverse((object) => {
        object.userData['miniGameStationId'] = definition.id;
        object.userData['miniGameId'] = definition.gameId;
        if (object instanceof THREE.Mesh) { object.castShadow = true; object.receiveShadow = true; }
      });
      this.visualRoot.add(model);
    }
    this.targetRing = new THREE.Mesh(
      new THREE.TorusGeometry(1.15, 0.055, 8, 32),
      new THREE.MeshBasicMaterial({ color: 0xe6bd70, transparent: true, opacity: 0.78 }),
    );
    this.targetRing.rotation.x = Math.PI / 2;
    this.targetRing.position.y = 0.06;
    this.targetRing.visible = false;
    this.visualRoot.add(this.targetRing);
    this.label = new THREE.Sprite(new THREE.SpriteMaterial({ map: makeLabel(definition.label), transparent: true, depthWrite: false }));
    this.label.scale.set(3.8, 0.65, 1);
    this.label.position.y = 3.05;
    this.visualRoot.add(this.label);
  }

  setTargeted(targeted: boolean): void { this.targetRing.visible = targeted; }
  dispose(): void {
    this.targetRing.geometry.dispose();
    const materials = Array.isArray(this.targetRing.material) ? this.targetRing.material : [this.targetRing.material];
    for (const material of materials) material.dispose();
    this.label.material.map?.dispose(); this.label.material.dispose();
  }
}

function makeLabel(label: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas'); canvas.width = 512; canvas.height = 96;
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Activity label canvas is unavailable.');
  context.fillStyle = 'rgba(13, 21, 25, 0.9)'; context.beginPath(); context.roundRect(4, 4, 504, 88, 18); context.fill();
  context.strokeStyle = 'rgba(230, 189, 112, 0.9)'; context.lineWidth = 4; context.stroke();
  context.fillStyle = '#fff0d2'; context.font = '700 42px system-ui, sans-serif'; context.textAlign = 'center'; context.textBaseline = 'middle'; context.fillText(label, 256, 49, 480);
  const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace; texture.needsUpdate = true; return texture;
}
