import * as THREE from 'three';
import type { ZoneGateDefinition } from '../types/zones';
import { sharedGeometry, sharedGlowTexture, sharedMaterial } from '../render/sharedResources';
import { getZoneTerrainHeight } from '../world/terrain-height';
import { OPEN_WORLD_ZONES } from '../world/open-world-config';

const UNLOCKED_GLOW_OPACITY = 0.35;
const LOCKED_GLOW_OPACITY = 0.1;

/** Sprites are raycast-tested by default. The glow is decorative and must not affect targeting. */
const ignoreRaycast = (): void => undefined;

/**
 * A zone gate. Earlier versions gave each gate a PointLight. Forward rendering evaluates
 * every light for every lit pixel, so four gate lights cost more than the rest of the scene
 * lighting combined. The glow is now an additive sprite, which costs one textured quad.
 */
export class ZonePortal {
  readonly visualRoot = new THREE.Group();
  readonly position: THREE.Vector3;
  readonly id: string;
  readonly sourceZoneId: ZoneGateDefinition['sourceZoneId'];
  readonly targetZoneId: ZoneGateDefinition['targetZoneId'];
  readonly label: string;
  readonly requiredLevel: number;

  private readonly frameMaterial: THREE.MeshStandardMaterial;
  private readonly discMaterial: THREE.MeshBasicMaterial;
  private readonly glowMaterial: THREE.SpriteMaterial;
  private readonly targetRing: THREE.Sprite;
  private unlocked: boolean | null = null;

  constructor(definition: ZoneGateDefinition, model: THREE.Object3D | null = null) {
    this.id = definition.id;
    this.sourceZoneId = definition.sourceZoneId;
    this.targetZoneId = definition.targetZoneId;
    this.label = definition.label;
    this.requiredLevel = definition.requiredLevel;
    const zoneOriginX = OPEN_WORLD_ZONES[definition.sourceZoneId].originX;
    const groundY = getZoneTerrainHeight(definition.sourceZoneId, definition.position.x - zoneOriginX, definition.position.z);
    this.position = new THREE.Vector3(definition.position.x, groundY, definition.position.z);
    this.visualRoot.name = `zone-portal-${definition.id}`;
    this.visualRoot.position.copy(this.position);
    this.visualRoot.userData['zonePortalId'] = this.id;

    const stone = sharedMaterial('portal-stone', () => new THREE.MeshStandardMaterial({
      color: 0x333c3c,
      roughness: 0.9,
      metalness: 0.12,
    }));
    // Per-gate state (unlock emissive, disc opacity) means these two cannot be shared.
    this.frameMaterial = new THREE.MeshStandardMaterial({
      color: definition.color,
      emissive: definition.color,
      emissiveIntensity: 1.0,
      roughness: 0.36,
      metalness: 0.52,
    });
    this.discMaterial = new THREE.MeshBasicMaterial({
      color: definition.color,
      transparent: true,
      opacity: 0.16,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.glowMaterial = new THREE.SpriteMaterial({
      map: sharedGlowTexture(),
      color: definition.color,
      transparent: true,
      opacity: LOCKED_GLOW_OPACITY,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    if (model) {
      model.name = `portal-python-glb-${definition.id}`;
      model.traverse((object: THREE.Object3D) => {
        if (!(object instanceof THREE.Mesh)) return;
        object.userData['zonePortalId'] = this.id;
        object.castShadow = true;
        object.receiveShadow = true;
        object.material = this.frameMaterial;
      });
      this.visualRoot.add(model);
    } else {
      const pillarGeometry = sharedGeometry('portal-pillar', () => new THREE.CylinderGeometry(0.19, 0.25, 3.5, 7));
      this.addTaggedMesh(
        new THREE.Mesh(sharedGeometry('portal-base', () => new THREE.BoxGeometry(3.25, 0.28, 1.4)), stone),
        0, 0.14, 0,
      );
      this.addTaggedMesh(new THREE.Mesh(pillarGeometry, stone), -1.38, 1.75, 0);
      this.addTaggedMesh(new THREE.Mesh(pillarGeometry, stone), 1.38, 1.75, 0);
      this.addTaggedMesh(
        new THREE.Mesh(sharedGeometry('portal-arch', () => new THREE.TorusGeometry(1.38, 0.13, 9, 40)), this.frameMaterial),
        0, 2.0, 0,
      );
      this.addTaggedMesh(
        new THREE.Mesh(sharedGeometry('portal-disc', () => new THREE.CircleGeometry(1.19, 32)), this.discMaterial),
        0, 2.0, -0.035,
      );
      const runeMaterial = sharedMaterial(`portal-rune:${definition.color}`, () => new THREE.MeshStandardMaterial({
        color: 0xf2e3be, emissive: definition.color, emissiveIntensity: 1.7, roughness: 0.3,
      }));
      this.addTaggedMesh(
        new THREE.Mesh(sharedGeometry('portal-rune', () => new THREE.OctahedronGeometry(0.23, 0)), runeMaterial),
        0, 3.72, 0,
      );
    }

    const glow = new THREE.Sprite(this.glowMaterial);
    glow.scale.set(4.2, 4.2, 1);
    glow.position.set(0, 2.0, 0.2);
    glow.raycast = ignoreRaycast;
    this.visualRoot.add(glow);

    this.targetRing = new THREE.Sprite(new THREE.SpriteMaterial({
      map: sharedGlowTexture(),
      color: 0xffedbf,
      transparent: true,
      opacity: 0.82,
      depthWrite: false,
    }));
    this.targetRing.scale.set(3.6, 3.6, 1);
    this.targetRing.position.y = 0.04;
    this.targetRing.visible = false;
    // Tagged so that a ray grazing the highlight still resolves to this gate.
    this.targetRing.userData['zonePortalId'] = this.id;
    this.visualRoot.add(this.targetRing);
  }

  setTargeted(targeted: boolean): void {
    this.targetRing.visible = targeted;
  }

  /** Idempotent: state is only written when it changes. */
  setUnlocked(unlocked: boolean): void {
    if (this.unlocked === unlocked) return;
    this.unlocked = unlocked;
    this.frameMaterial.emissiveIntensity = unlocked ? 1.0 : 0.22;
    this.discMaterial.opacity = unlocked ? 0.2 : 0.07;
    this.glowMaterial.opacity = unlocked ? UNLOCKED_GLOW_OPACITY : LOCKED_GLOW_OPACITY;
  }

  dispose(): void {
    // Shared geometry, materials and the glow texture are released by disposeSharedRenderResources().
    this.frameMaterial.dispose();
    this.discMaterial.dispose();
    this.glowMaterial.dispose();
    this.targetRing.material.dispose();
  }

  private addTaggedMesh(mesh: THREE.Mesh, x: number, y: number, z: number): void {
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.userData['zonePortalId'] = this.id;
    this.visualRoot.add(mesh);
  }
}
