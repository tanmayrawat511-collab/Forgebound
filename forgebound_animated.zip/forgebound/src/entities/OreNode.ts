import * as THREE from 'three';
import type RAPIER from '@dimforge/rapier3d-compat';
import type { OreNodeDefinition } from '../data/mining-data';
import { RESOURCE_DEFINITIONS } from '../types/resources';
import type { ResourceId } from '../types/resources';
import type { ZoneId } from '../types/zones';
import type { PhysicsWorld } from '../physics/PhysicsWorld';
import { sharedGlowTexture, sharedGeometry, sharedMaterial } from '../render/sharedResources';
import { OPEN_WORLD_ZONES } from '../world/open-world-config';
import { getZoneTerrainHeight } from '../world/terrain-height';

export interface OreNodeHitResult {
  readonly depleted: boolean;
  readonly remainingHealth: number;
  readonly dropQuantity: number;
}

export class OreNode {
  readonly visualRoot = new THREE.Group();
  readonly id: string;
  readonly zoneId: ZoneId;
  readonly resourceId: ResourceId;
  readonly displayName: string;
  readonly position: THREE.Vector3;

  private readonly definition: OreNodeDefinition;
  private readonly physics: PhysicsWorld;
  private readonly ring: THREE.Sprite;
  private body: RAPIER.RigidBody | null = null;
  private currentHealth: number;
  private respawnRemaining = 0;
  private available = true;

  /**
   * `model` is the GLB instance for this node. When it is provided the procedural rock is
   * never built, which avoids allocating meshes that would only be hidden.
   */
  constructor(definition: OreNodeDefinition, physics: PhysicsWorld, model: THREE.Object3D | null = null) {
    this.definition = definition;
    this.physics = physics;
    this.id = definition.id;
    this.zoneId = definition.zoneId;
    this.resourceId = definition.resourceId;
    this.displayName = RESOURCE_DEFINITIONS[definition.resourceId].name;
    const zoneOriginX = OPEN_WORLD_ZONES[definition.zoneId].originX;
    const groundY = getZoneTerrainHeight(definition.zoneId, definition.position.x - zoneOriginX, definition.position.z);
    this.position = new THREE.Vector3(definition.position.x, groundY + 0.62, definition.position.z);
    this.currentHealth = definition.maximumHealth;

    this.visualRoot.name = `ore-node-${definition.id}`;
    this.visualRoot.position.set(definition.position.x, groundY, definition.position.z);
    this.visualRoot.userData['oreNodeId'] = this.id;

    this.ring = new THREE.Sprite(new THREE.SpriteMaterial({
      map: sharedGlowTexture(),
      color: 0xe8c17a,
      transparent: true,
      opacity: 0.72,
      depthWrite: false,
    }));
    this.ring.scale.set(1.8, 1.8, 1);
    this.ring.position.y = 0.045;
    this.ring.visible = false;
    // Tagged so that a ray grazing the highlight still resolves to this node.
    this.ring.userData['oreNodeId'] = this.id;
    this.visualRoot.add(this.ring);

    if (model) {
      this.attachModel(model);
    } else {
      this.buildFallback();
    }

    this.createCollider();
  }

  isAvailable(): boolean {
    return this.available;
  }

  getHealth(): number {
    return this.currentHealth;
  }

  getHealthRatio(): number {
    return this.currentHealth / this.definition.maximumHealth;
  }

  setTargeted(targeted: boolean): void {
    this.ring.visible = targeted && this.available;
  }

  mine(power: number): OreNodeHitResult | null {
    if (!this.available || !Number.isFinite(power) || power <= 0) return null;

    this.currentHealth = Math.max(0, this.currentHealth - power);
    if (this.currentHealth > 0) {
      return {
        depleted: false,
        remainingHealth: this.currentHealth,
        dropQuantity: 0,
      };
    }

    // The node becomes unavailable before the reward is returned, preventing duplicate drops.
    this.available = false;
    this.ring.visible = false;
    this.visualRoot.visible = false;
    this.respawnRemaining = this.definition.respawnSeconds;
    if (this.body) {
      this.physics.removeRigidBody(this.body);
      this.body = null;
    }

    const bonusQuantity = Math.random() < this.definition.bonusDropChance
      ? this.definition.bonusDropQuantity
      : 0;
    return {
      depleted: true,
      remainingHealth: 0,
      dropQuantity: this.definition.baseDropQuantity + bonusQuantity,
    };
  }

  update(deltaSeconds: number): void {
    if (this.available) return;
    this.respawnRemaining = Math.max(0, this.respawnRemaining - deltaSeconds);
    if (this.respawnRemaining > 0) return;

    this.currentHealth = this.definition.maximumHealth;
    this.available = true;
    this.visualRoot.visible = true;
    this.createCollider();
  }

  dispose(): void {
    if (this.body) {
      this.physics.removeRigidBody(this.body);
      this.body = null;
    }
    this.ring.material.dispose();
    // Shared GLB geometry and shared materials are released with the asset registry.
  }

  private attachModel(model: THREE.Object3D): void {
    model.name = `ore-local-${this.id}`;
    model.traverse((object: THREE.Object3D) => { object.userData['oreNodeId'] = this.id; });
    model.scale.setScalar(this.resourceId === 'crystal' ? 1.1 : 1);
    this.visualRoot.add(model);
  }

  private buildFallback(): void {
    const resource = RESOURCE_DEFINITIONS[this.definition.resourceId];
    const rockMaterial = sharedMaterial(
      `ore-rock:${this.definition.resourceId === 'iron-ore' ? 'iron' : 'stone'}`,
      () => new THREE.MeshStandardMaterial({
        color: this.definition.resourceId === 'iron-ore' ? 0x535f61 : 0x665a4a,
        roughness: 0.98,
        metalness: 0.03,
      }),
    );
    const oreMaterial = sharedMaterial(`ore-crystal:${this.resourceId}`, () => new THREE.MeshStandardMaterial({
      color: resource.color,
      emissive: resource.color,
      emissiveIntensity: 0.12,
      roughness: 0.42,
      metalness: this.resourceId === 'iron-ore' ? 0.52 : 0.28,
    }));

    const fallbackVisualRoot = new THREE.Group();
    fallbackVisualRoot.name = 'procedural-ore-fallback';
    this.visualRoot.add(fallbackVisualRoot);

    const rock = new THREE.Mesh(
      sharedGeometry('ore-rock-geometry', () => new THREE.DodecahedronGeometry(0.72, 0)),
      rockMaterial,
    );
    rock.position.y = 0.56;
    rock.scale.set(1.03, 0.88, 0.92);
    rock.rotation.set(0.12, 0.36, -0.08);
    rock.castShadow = true;
    rock.receiveShadow = true;
    this.tagMesh(rock);
    fallbackVisualRoot.add(rock);

    const shardGeometry = sharedGeometry('ore-shard-geometry', () => new THREE.OctahedronGeometry(0.32, 0));
    const shardLayout = [
      { x: -0.27, y: 0.71, z: 0.31, sx: 0.72, sy: 1.25, sz: 0.78 },
      { x: 0.31, y: 0.66, z: -0.23, sx: 0.82, sy: 1.1, sz: 0.76 },
      { x: 0.04, y: 0.92, z: 0.16, sx: 0.62, sy: 1.42, sz: 0.68 },
    ];
    for (const shard of shardLayout) {
      const mesh = new THREE.Mesh(shardGeometry, oreMaterial);
      mesh.position.set(shard.x, shard.y, shard.z);
      mesh.scale.set(shard.sx, shard.sy, shard.sz);
      mesh.rotation.set(0.18 + shard.x, 0.38 + shard.z, -0.16);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.tagMesh(mesh);
      fallbackVisualRoot.add(mesh);
    }
  }

  private createCollider(): void {
    const extents = this.definition.colliderHalfExtents;
    this.body = this.physics.createFixedBox(
      {
        x: this.definition.position.x,
        y: this.visualRoot.position.y + extents.y,
        z: this.definition.position.z,
      },
      extents,
      0.82,
    );
  }

  private tagMesh(mesh: THREE.Mesh): void {
    mesh.userData['oreNodeId'] = this.id;
  }
}
