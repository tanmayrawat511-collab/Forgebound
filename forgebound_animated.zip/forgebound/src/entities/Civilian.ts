import * as THREE from 'three';
import { AnimationController } from '../assets/AnimationController';
import type { CivilianDefinition } from '../data/civilian-data';
import type { ZoneId } from '../types/zones';
import { PhysicsWorld, type CharacterPhysicsBody } from '../physics/PhysicsWorld';
import { getZoneTerrainHeight } from '../world/terrain-height';
import { ZONE_DEFINITIONS } from '../data/zone-data';

export class Civilian {
  readonly visualRoot = new THREE.Group();
  readonly body: CharacterPhysicsBody;
  private readonly label: THREE.Sprite;
  private readonly anim: AnimationController | null = null;
  private readonly destination = new THREE.Vector3();
  private readonly move = new THREE.Vector3();
  private idleTimer = 0;
  private phase = 0;
  private greetRemaining = 0;
  private readonly spawnPosition: THREE.Vector3;

  constructor(
    readonly definition: CivilianDefinition,
    private readonly physics: PhysicsWorld,
    model: THREE.Group | null,
    start: THREE.Vector3,
    clips: readonly THREE.AnimationClip[] = [],
  ) {
    this.spawnPosition = start.clone();
    this.visualRoot.name = `civilian-${definition.id}`;
    this.visualRoot.position.copy(start);
    this.visualRoot.userData['civilianId'] = definition.id;
    this.body = physics.createCharacterCapsule({ x: start.x, y: start.y + 0.88, z: start.z }, 0.48, 0.28, 0.5);
    if (model) {
      model.position.y = 0;
      model.scale.setScalar(1.0);
      model.traverse((object) => { if (object instanceof THREE.Mesh) { object.castShadow = true; object.receiveShadow = true; object.userData['civilianId'] = definition.id; } });
      this.visualRoot.add(model);
      if (clips.length > 0) {
        this.anim = new AnimationController(model, clips);
        this.anim.playLoop('idle', 0);
      }
    }
    this.label = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.createLabel(definition.name), transparent: true, depthWrite: false }));
    this.label.scale.set(2.2, 0.45, 1); this.label.position.y = 2.35; this.visualRoot.add(this.label);
    this.chooseDestination();
  }

  update(deltaSeconds: number, activeZone: ZoneId): void {
    const dt = Math.max(0, Math.min(deltaSeconds, 0.1));
    this.phase += dt * (this.greetRemaining > 0 ? 9 : 2.2);
    this.greetRemaining = Math.max(0, this.greetRemaining - dt);
    this.idleTimer -= dt;
    const current = this.body.body.translation();
    const currentPosition = new THREE.Vector3(current.x, current.y - 0.88, current.z);
    if (this.idleTimer <= 0 || currentPosition.distanceTo(this.destination) < 0.6) this.chooseDestination();
    const dx = this.destination.x - current.x;
    const dz = this.destination.z - current.z;
    const distance = Math.hypot(dx, dz);
    let nextY = getZoneTerrainHeight(this.definition.zoneId, this.destination.x - ZONE_DEFINITIONS[this.definition.zoneId].spawn.x, this.destination.z - ZONE_DEFINITIONS[this.definition.zoneId].spawn.z) + 0.88;
    if (activeZone !== this.definition.zoneId) nextY = current.y;
    const isMoving = distance > 0.08 && activeZone === this.definition.zoneId;
    if (isMoving) {
      const step = Math.min(distance, this.definition.walkSpeed * dt);
      this.move.set(dx / distance * step, nextY - current.y, dz / distance * step);
      this.body.controller.computeColliderMovement(this.body.collider, this.move);
      const corrected = this.body.controller.computedMovement();
      this.body.body.setNextKinematicTranslation({ x: current.x + corrected.x, y: current.y + corrected.y, z: current.z + corrected.z });
      this.visualRoot.rotation.y = Math.atan2(dx, dz);
    }
    const updated = this.body.body.translation();
    if (this.anim) {
      this.visualRoot.position.set(updated.x, updated.y - 0.88, updated.z);
      this.visualRoot.rotation.z = 0;
      this.anim.playLoop(isMoving ? 'walk' : 'idle', 0.16);
      this.anim.update(dt);
    } else {
      this.visualRoot.position.set(updated.x, updated.y - 0.88 + Math.sin(this.phase) * 0.012, updated.z);
      this.visualRoot.rotation.z = this.greetRemaining > 0 ? Math.sin(this.phase * 1.6) * 0.08 : 0;
    }
  }

  greet(): void {
    this.greetRemaining = 1.2;
    this.idleTimer = 1.2;
    this.anim?.playOneShot('greet', { fadeSeconds: 0.1 });
  }

  distanceTo(position: THREE.Vector3): number { return this.visualRoot.position.distanceTo(position); }
  setActive(active: boolean): void { this.visualRoot.visible = active; this.body.collider.setEnabled(active); }
  dispose(): void {
    this.anim?.dispose();
    this.physics.removeCharacter(this.body.body, this.body.controller);
    this.label.material.map?.dispose(); this.label.material.dispose();
  }

  private chooseDestination(): void {
    const angle = Math.random() * Math.PI * 2;
    const radius = Math.random() * this.definition.walkRadius;
    this.destination.set(this.spawnPosition.x + Math.cos(angle) * radius, this.spawnPosition.y, this.spawnPosition.z + Math.sin(angle) * radius);
    this.idleTimer = 2.5 + Math.random() * 4.5;
  }

  private createLabel(name: string): THREE.CanvasTexture {
    const canvas = document.createElement('canvas'); canvas.width = 256; canvas.height = 64;
    const ctx = canvas.getContext('2d'); if (!ctx) throw new Error('Civilian label canvas is unavailable.');
    ctx.fillStyle = 'rgba(14,22,22,.82)'; ctx.beginPath(); ctx.roundRect(2, 2, 252, 60, 12); ctx.fill();
    ctx.fillStyle = '#dbe5d4'; ctx.font = '600 27px system-ui'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(name, 128, 32);
    const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace; return texture;
  }
}
