import type { DrawDistance, GraphicsPreset, PerformancePreset } from '../systems/GameSettings';
import type { QualityTier } from './qualityTiers';

export interface PerformancePolicy {
  readonly targetFps: number;
  /** rAF frame cap; zero means render as often as the display permits. */
  readonly frameIntervalMs: number;
  readonly targetFrameMs: number;
  readonly pixelRatioCap: number;
  readonly minimumPixelRatio: number;
}

export function streamingRadiusForDistance(distance: DrawDistance): number {
  switch (distance) {
    case 'tiny': return 0;
    case 'short': return 1;
    case 'normal': return 3;
    case 'far': return 10;
  }
}

export function resolvePerformancePolicy(
  preset: PerformancePreset,
  graphics: GraphicsPreset,
  tier: QualityTier,
  devicePixelRatio: number,
): PerformancePolicy {
  const targetFps = preset === 'power-saver' ? 30 : preset === 'balance' ? 45 : 60;
  const reportedRatio = Number.isFinite(devicePixelRatio) && devicePixelRatio > 0 ? devicePixelRatio : 1;
  const tierCap = tier === 'high' ? 2 : tier === 'medium' ? 1.5 : 1.25;
  const highCap = Math.min(reportedRatio, tierCap);
  const pixelRatioCap = graphics === 'high' ? highCap : Math.min(0.85, highCap);
  const minimumPixelRatio = Math.min(pixelRatioCap, graphics === 'high' ? (tier === 'low' ? 0.75 : 1) : 0.6);
  return {
    targetFps,
    frameIntervalMs: preset === 'fps' ? 0 : 1000 / targetFps,
    targetFrameMs: 1000 / targetFps,
    pixelRatioCap,
    minimumPixelRatio,
  };
}

export function renderDistanceFarPlane(distance: DrawDistance): number {
  switch (distance) {
    case 'far': return 4200;
    case 'normal': return 1300;
    case 'short': return 520;
    case 'tiny': return 180;
  }
}

export function renderDistanceFogFar(distance: DrawDistance): number {
  switch (distance) {
    case 'far': return 4000;
    case 'normal': return 1180;
    case 'short': return 470;
    case 'tiny': return 160;
  }
}

export function renderDistanceFogNear(distance: DrawDistance): number {
  return renderDistanceFogFar(distance) * 0.72;
}
