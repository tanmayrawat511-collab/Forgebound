import * as THREE from 'three';

/**
 * Three.js raycasting ignores `visible`, so hidden meshes are still tested and can still
 * block a ray. These helpers skip hidden subtrees entirely. Hidden ore nodes, target rings
 * and fallback meshes therefore neither cost triangle tests nor occlude targets.
 */

/** All intersections against visible objects under `roots`, nearest first. Fills `out`. */
export function intersectVisible(
  raycaster: THREE.Raycaster,
  roots: readonly THREE.Object3D[],
  out: THREE.Intersection[],
): THREE.Intersection[] {
  out.length = 0;
  for (const root of roots) collectVisible(root, raycaster, out);
  if (out.length > 1) out.sort(byDistance);
  return out;
}

const scratch: THREE.Intersection[] = [];

/** True when any visible object under `roots` is hit. Stops at the first hit. */
export function hasVisibleHit(raycaster: THREE.Raycaster, roots: readonly THREE.Object3D[]): boolean {
  for (const root of roots) {
    scratch.length = 0;
    collectVisible(root, raycaster, scratch);
    if (scratch.length > 0) {
      scratch.length = 0;
      return true;
    }
  }
  return false;
}

function collectVisible(object: THREE.Object3D, raycaster: THREE.Raycaster, out: THREE.Intersection[]): void {
  if (!object.visible) return;
  if (object.layers.test(raycaster.layers)) object.raycast(raycaster, out);
  for (const child of object.children) collectVisible(child, raycaster, out);
}

function byDistance(a: THREE.Intersection, b: THREE.Intersection): number {
  return a.distance - b.distance;
}
