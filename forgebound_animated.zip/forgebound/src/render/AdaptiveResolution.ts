/**
 * Steps renderer pixel ratio down when frames run long and back up when they have
 * sustained headroom. Only the pixel ratio changes, because antialiasing is fixed when
 * the WebGL context is created. Pure logic: feed it frame intervals, act on the result.
 */

export interface AdaptiveResolutionOptions {
  readonly initialRatio: number;
  readonly minimumRatio: number;
  readonly maximumRatio: number;
  /** Frame interval the device should sustain, e.g. 1000 / 60. */
  readonly targetFrameMs: number;
}

const STEP_RATIO = 0.125;
/** A frame counts as overloaded when it takes longer than this multiple of the target. */
const OVERLOAD_FACTOR = 1.2;
/** Sustained overload required before stepping down. */
const OVERLOAD_WINDOW_MS = 1500;
/**
 * Sustained headroom required before stepping up. Doubles if a step-up is reversed quickly.
 * The cap is five minutes: a marginal device then probes the higher step about once every
 * five minutes, and each failed probe costs about 1.5 s of overload (under 1% of the time).
 */
const RECOVERY_WINDOW_MS = 8000;
const MAXIMUM_RECOVERY_WINDOW_MS = 300000;
/** Minimum time between any two changes, so the scaler cannot flicker. */
const COOLDOWN_MS = 2000;
/** Gaps longer than this are treated as a hidden tab rather than as load. */
const MAXIMUM_FRAME_GAP_MS = 1000;

export class AdaptiveResolution {
  private ratio: number;
  private minimumRatio: number;
  private maximumRatio: number;
  private targetFrameMs: number;
  private overloadedMs = 0;
  private healthyMs = 0;
  private cooldownMs = 0;
  private recoveryWindowMs = RECOVERY_WINDOW_MS;
  private sinceStepUpMs = Number.POSITIVE_INFINITY;

  constructor(options: AdaptiveResolutionOptions) {
    if (!(options.minimumRatio > 0) || options.maximumRatio < options.minimumRatio) {
      throw new Error('AdaptiveResolution requires 0 < minimumRatio <= maximumRatio.');
    }
    if (!(options.targetFrameMs > 0)) {
      throw new Error('AdaptiveResolution requires a positive targetFrameMs.');
    }
    this.minimumRatio = options.minimumRatio;
    this.maximumRatio = options.maximumRatio;
    this.targetFrameMs = options.targetFrameMs;
    this.ratio = clamp(options.initialRatio, this.minimumRatio, this.maximumRatio);
  }

  get currentRatio(): number {
    return this.ratio;
  }

  /** Reconfigure the scaler when the player changes graphics or performance settings. */
  reconfigure(options: AdaptiveResolutionOptions): void {
    if (!(options.minimumRatio > 0) || options.maximumRatio < options.minimumRatio) {
      throw new Error('AdaptiveResolution requires 0 < minimumRatio <= maximumRatio.');
    }
    if (!(options.targetFrameMs > 0)) throw new Error('AdaptiveResolution requires a positive targetFrameMs.');
    this.minimumRatio = options.minimumRatio;
    this.maximumRatio = options.maximumRatio;
    this.targetFrameMs = options.targetFrameMs;
    this.ratio = clamp(options.initialRatio, this.minimumRatio, this.maximumRatio);
    this.overloadedMs = 0;
    this.healthyMs = 0;
    this.cooldownMs = COOLDOWN_MS;
    this.recoveryWindowMs = RECOVERY_WINDOW_MS;
    this.sinceStepUpMs = Number.POSITIVE_INFINITY;
  }

  /**
   * Records the interval between two rendered frames. Returns the new pixel ratio when it
   * changes, or null when it stays the same.
   */
  recordFrame(frameMs: number): number | null {
    if (!Number.isFinite(frameMs) || frameMs <= 0 || frameMs > MAXIMUM_FRAME_GAP_MS) {
      this.overloadedMs = 0;
      this.healthyMs = 0;
      return null;
    }
    this.cooldownMs = Math.max(0, this.cooldownMs - frameMs);
    this.sinceStepUpMs += frameMs;

    if (frameMs > this.targetFrameMs * OVERLOAD_FACTOR) {
      this.overloadedMs += frameMs;
      this.healthyMs = 0;
      if (this.overloadedMs >= OVERLOAD_WINDOW_MS && this.cooldownMs === 0 && this.ratio > this.minimumRatio) {
        // A step-up that is reversed quickly was premature: wait longer before trying again.
        if (this.sinceStepUpMs < this.recoveryWindowMs) {
          this.recoveryWindowMs = Math.min(MAXIMUM_RECOVERY_WINDOW_MS, this.recoveryWindowMs * 2);
        }
        return this.changeRatio(-STEP_RATIO);
      }
      return null;
    }

    this.healthyMs += frameMs;
    this.overloadedMs = 0;
    if (this.healthyMs >= this.recoveryWindowMs && this.cooldownMs === 0 && this.ratio < this.maximumRatio) {
      this.sinceStepUpMs = 0;
      return this.changeRatio(STEP_RATIO);
    }
    return null;
  }

  private changeRatio(delta: number): number {
    this.ratio = clamp(Math.round((this.ratio + delta) * 1000) / 1000, this.minimumRatio, this.maximumRatio);
    this.overloadedMs = 0;
    this.healthyMs = 0;
    this.cooldownMs = COOLDOWN_MS;
    return this.ratio;
  }
}

function clamp(value: number, minimum: number, maximum: number): number {
  return Math.min(maximum, Math.max(minimum, value));
}
