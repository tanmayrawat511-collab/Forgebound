import type { DeviceProfile } from './qualityTiers';

interface NavigatorWithHints extends Navigator {
  readonly deviceMemory?: number;
  readonly userAgentData?: { readonly mobile?: boolean };
}

/** Reads the browser facts used to choose a render tier. Never throws. */
export function detectDeviceProfile(win: Window = window): DeviceProfile {
  const nav = win.navigator as NavigatorWithHints;
  const touchPrimary = typeof win.matchMedia === 'function'
    && win.matchMedia('(pointer: coarse)').matches;
  const mobileUserAgent = nav.userAgentData?.mobile === true
    || /Android|iPhone|iPad|iPod|Mobile/i.test(nav.userAgent ?? '');
  const cores = nav.hardwareConcurrency;
  const memory = nav.deviceMemory;
  return {
    touchPrimary,
    mobileUserAgent,
    logicalCores: typeof cores === 'number' && cores > 0 ? cores : null,
    deviceMemoryGb: typeof memory === 'number' && memory > 0 ? memory : null,
    devicePixelRatio: win.devicePixelRatio || 1,
  };
}
