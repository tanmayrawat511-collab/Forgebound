/** Pure camera collision policy shared by the third-person camera and tests. */
export interface CameraHit {
  readonly distance: number;
}

export interface CameraDistancePolicy {
  readonly minimumDistance: number;
  readonly padding: number;
  readonly maximumDistance: number;
  readonly contractionRate: number;
  readonly expansionRate: number;
}

export const DEFAULT_CAMERA_DISTANCE_POLICY: CameraDistancePolicy = {
  minimumDistance: 0.85,
  padding: 0.28,
  maximumDistance: 8.8,
  contractionRate: 26,
  expansionRate: 5.5,
};

/** Resolve the closest finite obstruction hit into a camera-safe target distance. */
export function resolveCameraDistance(
  hits: readonly CameraHit[],
  policy: CameraDistancePolicy = DEFAULT_CAMERA_DISTANCE_POLICY,
): number {
  let nearest = Number.POSITIVE_INFINITY;
  for (const hit of hits) {
    if (Number.isFinite(hit.distance) && hit.distance >= 0 && hit.distance < nearest) nearest = hit.distance;
  }
  if (!Number.isFinite(nearest)) return policy.maximumDistance;
  return Math.min(policy.maximumDistance, Math.max(policy.minimumDistance, nearest - policy.padding));
}

/** Move the camera inward quickly to avoid clipping; recover outward more gently. */
export function approachCameraDistance(
  current: number,
  target: number,
  deltaSeconds: number,
  policy: CameraDistancePolicy = DEFAULT_CAMERA_DISTANCE_POLICY,
): number {
  if (!Number.isFinite(current)) current = policy.maximumDistance;
  if (!Number.isFinite(target)) target = policy.maximumDistance;
  const delta = Math.max(0, Math.min(deltaSeconds, 0.25));
  const rate = target < current ? policy.contractionRate : policy.expansionRate;
  const factor = 1 - Math.exp(-rate * delta);
  const next = current + (target - current) * factor;
  return Math.min(policy.maximumDistance, Math.max(policy.minimumDistance, next));
}
