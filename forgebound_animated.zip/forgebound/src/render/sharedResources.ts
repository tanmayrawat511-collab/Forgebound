import * as THREE from 'three';

/**
 * Process-wide cache for geometry, materials and textures that many entities use with
 * identical parameters. Sharing one copy avoids duplicate GPU buffers. Only use it for
 * resources that are never mutated after creation; per-instance state stays per-instance.
 */

const geometries = new Map<string, THREE.BufferGeometry>();
const materials = new Map<string, THREE.Material>();
let glowTexture: THREE.DataTexture | null = null;

export function sharedGeometry<T extends THREE.BufferGeometry>(key: string, create: () => T): T {
  let geometry = geometries.get(key);
  if (!geometry) {
    geometry = create();
    geometries.set(key, geometry);
  }
  return geometry as T;
}

export function sharedMaterial<T extends THREE.Material>(key: string, create: () => T): T {
  let material = materials.get(key);
  if (!material) {
    material = create();
    materials.set(key, material);
  }
  return material as T;
}

/** A 64x64 radial falloff used for portal glow sprites. Generated in code, no image file. */
export function sharedGlowTexture(): THREE.DataTexture {
  if (!glowTexture) {
    const size = 64;
    const data = new Uint8Array(size * size * 4);
    for (let y = 0; y < size; y += 1) {
      for (let x = 0; x < size; x += 1) {
        const dx = (x + 0.5) / size * 2 - 1;
        const dy = (y + 0.5) / size * 2 - 1;
        const falloff = Math.max(0, 1 - Math.sqrt(dx * dx + dy * dy));
        const offset = (y * size + x) * 4;
        data[offset] = 255;
        data[offset + 1] = 255;
        data[offset + 2] = 255;
        data[offset + 3] = Math.round(falloff * falloff * 255);
      }
    }
    glowTexture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
    glowTexture.needsUpdate = true;
  }
  return glowTexture;
}

/** Disposes every shared resource. Call only when the whole scene is being torn down. */
export function disposeSharedRenderResources(): void {
  for (const geometry of geometries.values()) geometry.dispose();
  for (const material of materials.values()) material.dispose();
  glowTexture?.dispose();
  geometries.clear();
  materials.clear();
  glowTexture = null;
}
