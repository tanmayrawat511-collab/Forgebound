/**
 * Render quality selection. Pure functions only, so the decision logic can be
 * covered by the deterministic Node suite without a browser or GPU.
 */

export type QualityTier = 'low' | 'medium' | 'high';
export type ShadowFilter = 'pcf' | 'pcf-soft';

/** Browser facts that influence the default tier. Gathered by render/deviceProfile.ts. */
export interface DeviceProfile {
  /** True when the primary pointer is touch (phones and most tablets). */
  readonly touchPrimary: boolean;
  /** True when the user agent reports a mobile platform. */
  readonly mobileUserAgent: boolean;
  /** navigator.hardwareConcurrency, or null when the browser does not report it. */
  readonly logicalCores: number | null;
  /** navigator.deviceMemory in GiB (Chromium only), or null when unavailable. */
  readonly deviceMemoryGb: number | null;
  readonly devicePixelRatio: number;
}

export interface RenderQuality {
  readonly tier: QualityTier;
  readonly antialias: boolean;
  /** Upper bound for renderer pixel ratio; the adaptive scaler never exceeds it. */
  readonly maximumPixelRatio: number;
  /** Lower bound for renderer pixel ratio when the adaptive scaler steps down. */
  readonly minimumPixelRatio: number;
  readonly shadowMapSize: 1024 | 2048;
  readonly shadowFilter: ShadowFilter;
  /** Rendered frames per second, or null for the display's native refresh. */
  readonly frameRateCap: number | null;
}

type TierSettings = Omit<RenderQuality, 'tier'>;

const TIER_SETTINGS: Readonly<Record<QualityTier, TierSettings>> = {
  high: {
    antialias: true,
    maximumPixelRatio: 2,
    minimumPixelRatio: 1,
    shadowMapSize: 2048,
    shadowFilter: 'pcf-soft',
    frameRateCap: null,
  },
  medium: {
    antialias: true,
    maximumPixelRatio: 1.5,
    minimumPixelRatio: 1,
    shadowMapSize: 1024,
    shadowFilter: 'pcf',
    frameRateCap: 60,
  },
  low: {
    // Multisampling allocates four samples per pixel in both colour and depth, which is
    // the largest single GPU-memory cost on phones. Low tier trades it for pixel ratio.
    antialias: false,
    maximumPixelRatio: 1.25,
    minimumPixelRatio: 0.75,
    shadowMapSize: 1024,
    shadowFilter: 'pcf',
    frameRateCap: 60,
  },
};

export function isQualityTier(value: string | null | undefined): value is QualityTier {
  return value === 'low' || value === 'medium' || value === 'high';
}

/**
 * Chooses a default tier. Mobile devices get 'medium' only when both memory and core
 * count are reported and sufficient; otherwise 'low'. Desktop machines get 'medium' when
 * their reported memory or core count is small, and 'high' otherwise, including when the
 * browser reports neither value.
 */
export function selectQualityTier(profile: DeviceProfile): QualityTier {
  const mobile = profile.touchPrimary || profile.mobileUserAgent;
  if (mobile) {
    const capable = profile.deviceMemoryGb !== null
      && profile.logicalCores !== null
      && profile.deviceMemoryGb >= 8
      && profile.logicalCores >= 8;
    return capable ? 'medium' : 'low';
  }
  const constrained = (profile.deviceMemoryGb !== null && profile.deviceMemoryGb <= 4)
    || (profile.logicalCores !== null && profile.logicalCores <= 4);
  return constrained ? 'medium' : 'high';
}

/**
 * Resolves the render settings. A valid `override` (for example from `?quality=low`)
 * takes precedence over detection; an unrecognised override is ignored.
 */
export function resolveRenderQuality(profile: DeviceProfile, override: string | null): RenderQuality {
  const tier = isQualityTier(override) ? override : selectQualityTier(profile);
  return { tier, ...TIER_SETTINGS[tier] };
}

/** Starting renderer pixel ratio: the device ratio, capped by the tier. */
export function initialPixelRatio(quality: RenderQuality, devicePixelRatio: number): number {
  const reported = Number.isFinite(devicePixelRatio) && devicePixelRatio > 0 ? devicePixelRatio : 1;
  return Math.min(reported, quality.maximumPixelRatio);
}
