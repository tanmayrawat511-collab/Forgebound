import { ChessGame, chessPieceGlyph, type ChessOutcome } from '../systems/ChessGame';
import { MINI_GAME_BY_ID, type MiniGameDefinition, type MiniGameId, type RewardTier } from '../systems/MiniGameSystem';

export interface MiniGameRecord {
  readonly bestTier: RewardTier | null;
  readonly completionCount: number;
}

export interface MiniGameRunResult {
  readonly gameId: MiniGameId;
  readonly tier: RewardTier;
  readonly score: number;
  readonly chessWon: boolean;
  readonly fishCaught: number;
}

interface PanelElements {
  readonly title: HTMLElement;
  readonly subtitle: HTMLElement;
  readonly description: HTMLElement;
  readonly content: HTMLElement;
  readonly status: HTMLElement;
  readonly close: HTMLButtonElement;
}

const SYMBOLS = ['◆', '●', '▲', '✦'];

/** DOM-only playable mini-games. The caller owns rewards and persistence. */
export class MiniGamePanel {
  private active: MiniGameDefinition | null = null;
  private timers = new Set<number>();
  private interval: number | null = null;
  private completed = false;
  private selectedChessSquare: number | null = null;
  private chess: ChessGame | null = null;
  private readonly elements: PanelElements;
  private readonly onComplete: (result: MiniGameRunResult) => void;
  private readonly onClose: () => void;
  private startedAt = 0;
  private remainingSeconds = 0;

  constructor(container: HTMLElement, onComplete: (result: MiniGameRunResult) => void, onClose: () => void) {
    this.onComplete = onComplete;
    this.onClose = onClose;
    this.elements = {
      title: required(container, 'minigame-title'),
      subtitle: required(container, 'minigame-subtitle'),
      description: required(container, 'minigame-description'),
      content: required(container, 'minigame-content'),
      status: required(container, 'minigame-status'),
      close: required(container, 'close-minigame') as HTMLButtonElement,
    };
    container.addEventListener('click', this.handleClick);
    this.elements.close.addEventListener('click', this.close);
  }

  open(gameId: MiniGameId, record: MiniGameRecord = { bestTier: null, completionCount: 0 }): void {
    this.stopTimers();
    this.active = MINI_GAME_BY_ID[gameId];
    this.completed = false;
    this.chess = null;
    this.selectedChessSquare = null;
    this.elements.title.textContent = this.active.name;
    this.elements.subtitle.textContent = this.active.zoneId.replaceAll('-', ' ').toUpperCase();
    this.elements.description.textContent = this.active.description;
    this.elements.status.textContent = `${this.active.instructions} Personal best: ${record.bestTier ? record.bestTier.toUpperCase() : '—'} · Completed: ${record.completionCount}.`;
    this.elements.content.replaceChildren(this.makeStartButton());
    this.elements.content.dataset['gameId'] = gameId;
    this.container().hidden = false;
    this.container().setAttribute('aria-hidden', 'false');
  }

  setAnimationsEnabled(enabled: boolean): void {
    this.container().classList.toggle('animations-disabled', !enabled);
  }

  updateRecord(record: MiniGameRecord): void {
    const best = record.bestTier ? record.bestTier.toUpperCase() : '—';
    this.elements.status.textContent = `Personal best: ${best} · Completed: ${record.completionCount}.`;
  }

  close = (): void => {
    this.dismiss();
    this.onClose();
  };

  dismiss(): void {
    this.stopTimers();
    this.active = null;
    this.chess = null;
    this.container().hidden = true;
    this.container().setAttribute('aria-hidden', 'true');
  }

  dispose(): void {
    this.stopTimers();
    this.container().removeEventListener('click', this.handleClick);
    this.elements.close.removeEventListener('click', this.close);
  }

  private container(): HTMLElement { return this.elements.title.closest('#minigame-panel') as HTMLElement; }

  private makeStartButton(): HTMLButtonElement {
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'action-button'; button.dataset['miniAction'] = 'start';
    button.textContent = 'Start Activity';
    return button;
  }

  private readonly handleClick = (event: MouseEvent): void => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const button = target.closest('button');
    if (!(button instanceof HTMLButtonElement) || button.disabled || !this.active) return;
    const action = button.dataset['miniAction'];
    if (action === 'start') { this.startActivity(); return; }
    if (action === 'checkpoint') this.cartCheckpoint(button);
    else if (action === 'bundle') this.timberBundle();
    else if (action === 'vein') this.veinGuess(Number(button.dataset['tile']));
    else if (action === 'corn') this.harvestCorn(Number(button.dataset['plant']));
    else if (action === 'vent') this.sequenceInput(Number(button.dataset['signal']));
    else if (action === 'dodge') this.dodgeHazard();
    else if (action === 'chess-square') this.chessSquare(Number(button.dataset['square']));
    else if (action === 'cast') this.castLine();
    else if (action === 'hook') this.hookFish();
    else if (action === 'echo') this.sequenceInput(Number(button.dataset['signal']));
    else if (action === 'retry') this.open(this.active.id);
    else if (action === 'close') this.close();
  };

  private startActivity(): void {
    if (!this.active) return;
    this.stopTimers(); this.completed = false; this.startedAt = performance.now();
    switch (this.active.id) {
      case 'quarry-cart-rally': this.startCartRally(); break;
      case 'timberline-relay': this.startTimberRelay(); break;
      case 'veinfinder-challenge': this.startVeinfinder(); break;
      case 'magma-corn-harvest': this.startMagmaHarvest(); break;
      case 'vent-tuning': this.startSequencePuzzle('vent'); break;
      case 'basalt-sprint': this.startBasaltSprint(); break;
      case 'summit-chess': this.startChess(); break;
      case 'crystal-fishing': this.startFishing(); break;
      case 'glacier-echo': this.startSequencePuzzle('echo'); break;
    }
  }

  private startCartRally(): void {
    let cleared = 0;
    this.renderTimedStatus('30.0s remaining · Checkpoint 1/6');
    const track = this.makeProgress('0/6 checkpoints');
    const checkpoint = this.makeButton('Drive through checkpoint 1', 'checkpoint');
    this.elements.content.replaceChildren(track, checkpoint);
    this.startCountdown(30, () => this.finishByProgress('quarry-cart-rally', cleared / 6, cleared > 0));
    checkpoint.addEventListener('click', () => {
      cleared += 1; track.textContent = `${cleared}/6 checkpoints`;
      checkpoint.textContent = cleared < 6 ? `Drive through checkpoint ${cleared + 1}` : 'Course complete';
      if (cleared >= 6) this.finishTimed('quarry-cart-rally', this.elapsedTier(16, 23, 30));
    });
  }

  private cartCheckpoint(button: HTMLButtonElement): void {
    // The button's own listener performs the checkpoint advance.
    void button;
  }

  private startTimberRelay(): void {
    let bundles = 0;
    const progress = this.makeProgress('0/8 timber bundles');
    const collect = this.makeButton('Collect timber bundle', 'bundle');
    this.elements.content.replaceChildren(progress, collect);
    this.startCountdown(28, () => this.finishByProgress('timberline-relay', bundles / 8, bundles >= 2));
    collect.addEventListener('click', () => {
      bundles += 1; progress.textContent = `${Math.min(8, bundles)}/8 timber bundles`;
      collect.textContent = bundles >= 8 ? 'Relay complete' : 'Collect next bundle';
      if (bundles >= 8) this.finishTimed('timberline-relay', this.elapsedTier(12, 20, 28));
    });
  }

  private timberBundle(): void { /* The dynamically bound button handles each delivery. */ }

  private startVeinfinder(): void {
    let round = 0, hits = 0, attempts = 0, target = 0;
    const clue = document.createElement('p'); clue.className = 'minigame-clue';
    const progress = this.makeProgress('Seam 1/3');
    const grid = document.createElement('div'); grid.className = 'minigame-grid vein-grid';
    const cells: HTMLButtonElement[] = [];
    for (let tile = 0; tile < 9; tile += 1) {
      const cell = this.makeButton(`${Math.floor(tile / 3) + 1}-${tile % 3 + 1}`, 'vein');
      cell.dataset['tile'] = String(tile); cells.push(cell); grid.append(cell);
    }
    const beginRound = (): void => {
      round += 1; attempts = 0; target = Math.floor(Math.random() * 9);
      clue.textContent = `Survey clue: the strongest signal is in row ${Math.floor(target / 3) + 1}. Find the exact cell.`;
      progress.textContent = `Seam ${round}/3 · ${hits} located`;
      cells.forEach((cell) => { cell.disabled = false; cell.classList.remove('is-correct', 'is-wrong'); });
    };
    this.elements.content.replaceChildren(progress, clue, grid);
    const listener = (event: MouseEvent): void => {
      const targetElement = event.target;
      if (!(targetElement instanceof HTMLElement)) return;
      const cell = targetElement.closest('button[data-mini-action="vein"]') as HTMLButtonElement | null;
      if (!cell || cell.disabled) return;
      const guess = Number(cell.dataset['tile']); attempts += 1;
      if (guess === target) {
        hits += 1; cell.classList.add('is-correct'); cell.textContent = '✓';
        if (round === 3) this.finishTimed('veinfinder-challenge', hits / 3 >= 1 ? 'gold' : hits >= 2 ? 'silver' : 'bronze');
        else this.schedule(beginRound, 450);
      } else {
        cell.classList.add('is-wrong'); cell.disabled = true;
        if (attempts >= 2) {
          if (round === 3) this.finishTimed('veinfinder-challenge', hits >= 2 ? 'silver' : 'bronze');
          else this.schedule(beginRound, 450);
        } else {
          const rowText = Math.floor(guess / 3) === Math.floor(target / 3) ? 'The row is right. Search another column.' : 'The signal is in a different row.';
          this.elements.status.textContent = rowText;
        }
      }
    };
    grid.addEventListener('click', listener);
    this.startCountdown(60, () => this.finishByProgress('veinfinder-challenge', hits / 3, hits >= 1));
    beginRound();
  }

  private startMagmaHarvest(): void {
    const progress = this.makeProgress('0/6 ripe plants');
    const grid = document.createElement('div'); grid.className = 'minigame-grid harvest-grid';
    const ripe = new Set<number>();
    while (ripe.size < 6) ripe.add(Math.floor(Math.random() * 12));
    let picked = 0;
    for (let index = 0; index < 12; index += 1) {
      const button = this.makeButton('🌽', 'corn'); button.dataset['plant'] = String(index); grid.append(button);
    }
    this.elements.content.replaceChildren(progress, grid);
    grid.addEventListener('click', (event) => {
      const element = event.target;
      if (!(element instanceof HTMLElement)) return;
      const button = element.closest('button[data-mini-action="corn"]') as HTMLButtonElement | null;
      if (!button || button.disabled) return;
      const index = Number(button.dataset['plant']); button.disabled = true;
      if (ripe.has(index)) { picked += 1; button.textContent = '✓'; button.classList.add('is-correct'); }
      else { button.textContent = '×'; button.classList.add('is-wrong'); this.remainingSeconds = Math.max(0, this.remainingSeconds - 2); }
      progress.textContent = `${picked}/6 ripe plants`;
      if (picked >= 6) this.finishTimed('magma-corn-harvest', 'gold');
    });
    this.startCountdown(25, () => this.finishByProgress('magma-corn-harvest', picked / 6, picked >= 2));
  }

  private startSequencePuzzle(kind: 'vent' | 'echo'): void {
    const sequence: number[] = [];
    const progress = this.makeProgress(kind === 'vent' ? 'Vent sequence 1/3' : 'Echo sequence 1/3');
    const status = document.createElement('p'); status.className = 'minigame-clue';
    const buttons = document.createElement('div'); buttons.className = 'minigame-signal-row';
    const signalButtons: HTMLButtonElement[] = [];
    for (let index = 0; index < 4; index += 1) {
      const button = this.makeButton(SYMBOLS[index] ?? '?', kind); button.dataset['signal'] = String(index); signalButtons.push(button); buttons.append(button);
    }
    let round = 0, inputIndex = 0, wins = 0, playback = false;
    const flash = (index: number): void => {
      const button = signalButtons[index]; if (!button) return;
      button.classList.add('is-lit'); this.schedule(() => button.classList.remove('is-lit'), 320);
    };
    const showSequence = (): void => {
      playback = true; inputIndex = 0; progress.textContent = `${kind === 'vent' ? 'Vent' : 'Echo'} sequence ${round + 1}/3`;
      status.textContent = 'Watch the signal…'; signalButtons.forEach((button) => { button.disabled = true; });
      sequence.forEach((signal, index) => this.schedule(() => flash(signal), 500 + index * 620));
      this.schedule(() => { playback = false; signalButtons.forEach((button) => { button.disabled = false; }); status.textContent = 'Repeat the sequence.'; }, 500 + sequence.length * 620);
    };
    const beginRound = (): void => {
      round += 1; sequence.push(Math.floor(Math.random() * 4)); showSequence();
    };
    buttons.addEventListener('click', (event) => {
      const element = event.target;
      if (!(element instanceof HTMLElement) || playback) return;
      const button = element.closest('button[data-mini-action]') as HTMLButtonElement | null;
      if (!button || button.disabled) return;
      const chosen = Number(button.dataset['signal']); flash(chosen);
      if (sequence[inputIndex] !== chosen) {
        status.textContent = 'Sequence missed. The signal resets.';
        wins = Math.max(0, wins - 1);
        this.schedule(() => this.finishTimed(kind === 'vent' ? 'vent-tuning' : 'glacier-echo', wins >= 2 ? 'silver' : 'bronze'), 500);
        return;
      }
      inputIndex += 1;
      if (inputIndex >= sequence.length) {
        wins += 1;
        if (round >= 3) this.finishTimed(kind === 'vent' ? 'vent-tuning' : 'glacier-echo', wins >= 3 ? 'gold' : wins === 2 ? 'silver' : 'bronze');
        else this.schedule(beginRound, 650);
      }
    });
    this.elements.content.replaceChildren(progress, status, buttons);
    beginRound();
  }

  private startBasaltSprint(): void {
    let cleared = 0, active = false;
    const progress = this.makeProgress('0/6 hazards cleared');
    const hazard = document.createElement('p'); hazard.className = 'minigame-clue';
    const dodge = this.makeButton('DODGE', 'dodge'); dodge.disabled = true;
    this.elements.content.replaceChildren(progress, hazard, dodge);
    const next = (): void => {
      if (cleared >= 6) { this.finishTimed('basalt-sprint', cleared >= 6 ? 'gold' : cleared >= 4 ? 'silver' : 'bronze'); return; }
      active = false; dodge.disabled = true;
      hazard.textContent = `Hazard ${cleared + 1}/6 · Watch the trail…`;
      this.schedule(() => {
        active = true; dodge.disabled = false; hazard.textContent = 'ROCKFALL! Dodge now!';
        this.schedule(() => {
          if (!active || this.completed) return;
          active = false; dodge.disabled = true; hazard.textContent = 'Too late! The next hazard is approaching.';
          this.schedule(next, 350);
        }, 1300);
      }, 350 + Math.random() * 750);
    };
    dodge.addEventListener('click', () => {
      if (!active || this.completed) return;
      active = false; cleared += 1; dodge.disabled = true;
      progress.textContent = `${cleared}/6 hazards cleared`; hazard.textContent = 'Clean dodge!';
      if (cleared >= 6) this.finishTimed('basalt-sprint', 'gold'); else this.schedule(next, 350);
    });
    this.startCountdown(25, () => this.finishByProgress('basalt-sprint', cleared / 6, cleared >= 2));
    next();
  }

  private startChess(): void {
    this.chess = new ChessGame();
    this.selectedChessSquare = null;
    this.renderChessBoard();
  }

  private renderChessBoard(): void {
    if (!this.chess) return;
    const board = document.createElement('div'); board.className = 'chess-board';
    const legal = this.selectedChessSquare === null ? [] : this.chess.getLegalMoves(this.selectedChessSquare);
    for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
      const square = row * 8 + col, piece = this.chess.getPiece(square);
      const button = this.makeButton(piece ? chessPieceGlyph(piece) : '', 'chess-square');
      button.dataset['square'] = String(square);
      button.classList.add((row + col) % 2 === 0 ? 'light-square' : 'dark-square');
      if (this.selectedChessSquare === square) button.classList.add('is-selected');
      if (legal.some((move) => move.to === square)) button.classList.add('is-legal-move');
      if (piece && piece === piece.toUpperCase()) button.classList.add('white-piece');
      board.append(button);
    }
    const info = document.createElement('p'); info.className = 'minigame-clue';
    info.textContent = this.chess.result === 'playing'
      ? `Turn: ${this.chess.currentTurn === 'w' ? 'You (White)' : 'Frank (Black)'}${this.chess.isCheck() ? ' · CHECK' : ''}`
      : this.chess.result === 'white-won' ? 'Checkmate — you defeated Frank!'
      : this.chess.result === 'draw' ? 'The game is a draw.' : 'Frank wins this round.';
    this.elements.content.replaceChildren(info, board);
    if (this.chess.result !== 'playing') {
      const tier: RewardTier = this.chess.result === 'white-won' ? 'gold' : this.chess.result === 'draw' ? 'silver' : 'bronze';
      this.finish(tier, this.chess.result === 'white-won', 0, this.chess.result);
    }
  }

  private chessSquare(square: number): void {
    if (!this.chess || this.chess.result !== 'playing') return;
    const piece = this.chess.getPiece(square);
    if (this.selectedChessSquare === null) {
      if (piece && piece === piece.toUpperCase() && this.chess.currentTurn === 'w') this.selectedChessSquare = square;
      this.renderChessBoard(); return;
    }
    const from = this.selectedChessSquare;
    if (piece && piece === piece.toUpperCase()) { this.selectedChessSquare = square; this.renderChessBoard(); return; }
    const moved = this.chess.playHumanMove(from, square);
    this.selectedChessSquare = null;
    if (!moved) { this.renderChessBoard(); return; }
    if (this.chess.result === 'playing') this.chess.playComputerMove();
    this.renderChessBoard();
  }

  private startFishing(): void {
    let casts = 0, catches = 0, waiting = false, biting = false;
    const progress = this.makeProgress('Crystal Cod 0/3 · Cast 1/3');
    const clue = document.createElement('p'); clue.className = 'minigame-clue'; clue.textContent = 'The lake is still. Cast your line.';
    const cast = this.makeButton('Cast Line', 'cast');
    const hook = this.makeButton('HOOK!', 'hook'); hook.hidden = true;
    this.elements.content.replaceChildren(progress, clue, cast, hook);
    cast.addEventListener('click', () => {
      if (waiting || biting || casts >= 3) return;
      casts += 1; waiting = true; cast.disabled = true;
      progress.textContent = `Crystal Cod ${catches}/3 · Cast ${casts}/3`;
      clue.textContent = 'Line cast. Watch the float…';
      this.schedule(() => {
        waiting = false; biting = true; hook.hidden = false; cast.hidden = true;
        clue.textContent = 'A bite! Hook the fish before it escapes!';
        this.schedule(() => {
          if (!biting || this.completed) return;
          biting = false; hook.hidden = true; cast.hidden = false;
          clue.textContent = 'The fish got away. Cast again.';
          cast.disabled = casts >= 3;
          afterCast();
        }, 1050);
      }, 1200 + Math.random() * 1800);
    });
    hook.addEventListener('click', () => {
      if (!biting) return;
      biting = false; catches += 1; hook.hidden = true; cast.hidden = false;
      cast.disabled = casts >= 3;
      clue.textContent = 'Crystal Cod caught!';
      afterCast();
    });
    const afterCast = (): void => {
      progress.textContent = `Crystal Cod ${catches}/3 · Cast ${casts}/3`;
      if (casts < 3) return;
      this.schedule(() => {
        if (catches === 0) {
          clue.textContent = 'No cod caught this time. Try another session.';
          const retry = this.makeButton('Try Again', 'retry'); this.elements.content.append(retry);
        } else {
          this.finish(catches >= 3 ? 'gold' : catches === 2 ? 'silver' : 'bronze', false, catches, 'completed');
        }
      }, 300);
    };
  }

  private veinGuess(_tile: number): void { /* Grid clicks are delegated inside the active board. */ }
  private harvestCorn(_plant: number): void { /* Harvest-grid clicks are delegated inside the active grid. */ }
  private sequenceInput(_signal: number): void { /* Sequence buttons are handled by their board listener. */ }
  private dodgeHazard(): void { /* Dodge button owns the timed hazard state. */ }
  private castLine(): void { /* Fishing button owns cast state. */ }
  private hookFish(): void { /* Fishing button owns hook state. */ }

  private startCountdown(seconds: number, onExpire: () => void): void {
    this.remainingSeconds = seconds;
    this.renderTimedStatus(`${seconds.toFixed(1)}s remaining`);
    this.interval = window.setInterval(() => {
      this.remainingSeconds = Math.max(0, this.remainingSeconds - 0.1);
      this.renderTimedStatus(`${this.remainingSeconds.toFixed(1)}s remaining`);
      if (this.remainingSeconds <= 0 && !this.completed) { this.stopTimers(); onExpire(); }
    }, 100);
  }

  private renderTimedStatus(text: string): void { this.elements.status.textContent = text; }
  private elapsedTier(goldSeconds: number, silverSeconds: number, _bronzeSeconds: number): RewardTier {
    const elapsed = (performance.now() - this.startedAt) / 1000;
    return elapsed <= goldSeconds ? 'gold' : elapsed <= silverSeconds ? 'silver' : 'bronze';
  }
  private finishByProgress(_id: MiniGameId, progress: number, anyProgress: boolean): void {
    if (!anyProgress) { this.elements.status.textContent = 'Challenge not completed. You can try again.'; this.showRetry(); return; }
    this.finish(progress >= 0.85 ? 'gold' : progress >= 0.55 ? 'silver' : 'bronze', false, 0, 'completed');
  }
  private finishTimed(id: MiniGameId, tier: RewardTier): void { if (this.active?.id === id) this.finish(tier, false, 0, 'completed'); }

  private finish(tier: RewardTier, chessWon: boolean, fishCaught: number, outcome: ChessOutcome | 'completed'): void {
    if (!this.active || this.completed) return;
    this.completed = true; this.stopTimers();
    const resultText = tier === 'gold' ? 'Gold medal' : tier === 'silver' ? 'Silver medal' : 'Bronze medal';
    this.elements.status.textContent = `${resultText} · ${outcome === 'white-won' ? 'You beat Frank.' : outcome === 'draw' ? 'Draw.' : outcome === 'black-won' ? 'Frank won.' : 'Challenge complete.'}`;
    const summary = document.createElement('p'); summary.className = 'minigame-result'; summary.textContent = `${resultText} achieved. Rewards are paid only for a new personal-best tier and when your inventory can accept them.`;
    const retry = this.makeButton('Play Again', 'retry');
    const done = this.makeButton('Done', 'close');
    this.elements.content.append(summary, retry, done);
    this.onComplete({ gameId: this.active.id, tier, score: tier === 'gold' ? 100 : tier === 'silver' ? 70 : 40, chessWon, fishCaught });
  }

  private showRetry(): void {
    this.completed = true; this.stopTimers();
    this.elements.content.append(this.makeButton('Try Again', 'retry'));
  }

  private makeProgress(text: string): HTMLElement {
    const progress = document.createElement('p'); progress.className = 'minigame-progress'; progress.textContent = text; return progress;
  }

  private makeButton(text: string, action: string): HTMLButtonElement {
    const button = document.createElement('button'); button.type = 'button'; button.className = 'minigame-action';
    button.dataset['miniAction'] = action; button.textContent = text; return button;
  }

  private schedule(callback: () => void, delay: number): void {
    const handle = window.setTimeout(() => { this.timers.delete(handle); callback(); }, delay);
    this.timers.add(handle);
  }

  private stopTimers(): void {
    if (this.interval !== null) { window.clearInterval(this.interval); this.interval = null; }
    for (const timer of this.timers) window.clearTimeout(timer);
    this.timers.clear();
  }
}

function required(root: HTMLElement, id: string): HTMLElement {
  const element = root.querySelector<HTMLElement>(`#${id}`);
  if (!element) throw new Error(`Missing mini-game interface element: #${id}`);
  return element;
}
