/**
 * Writes that only touch the DOM when the value actually changes. Each write can invalidate
 * style and layout, and the HUD is updated every frame, so unchanged writes are pure cost.
 */

export function setText(element: HTMLElement, value: string): void {
  if (element.textContent !== value) element.textContent = value;
}

export function setHidden(element: HTMLElement, hidden: boolean): void {
  if (element.hidden !== hidden) element.hidden = hidden;
}

export function setWidth(element: HTMLElement, value: string): void {
  if (element.style.width !== value) element.style.width = value;
}

export function setDataAttribute(element: HTMLElement, key: string, value: string): void {
  if (element.dataset[key] !== value) element.dataset[key] = value;
}
