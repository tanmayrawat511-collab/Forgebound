import * as THREE from 'three';
import { AssetRegistry, type AssetId } from '../assets/AssetRegistry';
import { ORE_NODE_DEFINITIONS } from '../data/mining-data';
import { ENEMY_DEFINITIONS, ENEMY_SPAWN_ORDER } from '../data/enemy-data';
import { ZONE_DEFINITIONS } from '../data/zone-data';
import { ZONE_GATES } from '../data/portal-data';
import { NPC_DEFINITIONS } from '../data/npc-data';
import { QUEST_WORLD_OBJECTS } from '../data/quest-world-data';
import { MINI_GAME_STATIONS } from '../data/mini-game-data';
import { DUNGEON_BY_ID, DUNGEON_DEFINITIONS, type DungeonDefinition, type DungeonId, type DungeonPointDefinition } from '../data/dungeon-data';
import { QUEST_BY_ID, QUEST_DEFINITIONS, type QuestDefinition } from '../data/quest-data';
import { CRAFTING_RECIPES, SMELTING_RECIPES, type ResourceCosts } from '../data/forge-data';
import { EQUIPMENT_DEFINITIONS } from '../data/equipment-data';
import { GEAR_DEFINITIONS, GEAR_MATERIALS, getGearStats } from '../data/gear-data';
import { GEAR_IDS, type GearId, type GearMaterialId } from '../types/gear';
import { RESOURCE_DEFINITIONS, RESOURCE_IDS, type ResourceId } from '../types/resources';
import type { EquipmentId, EquipmentSlot } from '../types/equipment';
import { ForgeStation } from '../entities/ForgeStation';
import { Enemy } from '../entities/Enemy';
import { ZonePortal } from '../entities/ZonePortal';
import { OreNode } from '../entities/OreNode';
import { Npc } from '../entities/Npc';
import { QuestWorldObject } from '../entities/QuestWorldObject';
import { MiniGameStation } from '../entities/MiniGameStation';
import { DungeonEntrance } from '../entities/DungeonEntrance';
import { InputRouter } from '../input/InputRouter';
import { MenuNavigator } from '../input/menu/MenuNavigator';
import { inputLabel, panelCloseHint, type PromptAction } from '../input/prompts';
import { FeedbackSystem } from '../feedback/FeedbackSystem';
import { NO_TRIGGER_CONTEXT, type TriggerContext } from '../feedback/triggerProfiles';
import { FIXED_STEP_SECONDS, PhysicsWorld } from '../physics/PhysicsWorld';
import { PlayerController } from '../player/PlayerController';
import { Inventory, type InventorySnapshot } from '../systems/Inventory';
import { GearInventorySystem } from '../systems/GearInventorySystem';
import { BlacksmithSystem } from '../systems/BlacksmithSystem';
import { GearRefinementSystem } from '../systems/GearRefinementSystem';
import { BEN_PICKAXE_INSTANCE_ID, TutorialSystem, type TutorialStepId } from '../systems/TutorialSystem';
import { MinimapRenderer, type MinimapMarker } from '../systems/MinimapRenderer';
import { AudioManager } from '../systems/AudioManager';
import { DEFAULT_GAME_SETTINGS, difficultyCombatProfile, loadGameSettings, saveGameSettings, type GameSettings } from '../systems/GameSettings';
import { ForgeSystem } from '../systems/ForgeSystem';
import { QuestSystem, type QuestEvent } from '../systems/QuestSystem';
import { MiniGameSystem, type MiniGameId } from '../systems/MiniGameSystem';
import { DungeonProgressSystem } from '../systems/DungeonProgressSystem';
import { MiniGamePanel, type MiniGameRunResult } from '../ui/MiniGamePanel';
import { ShopSystem } from '../systems/ShopSystem';
import { WeaponRefinementSystem } from '../systems/WeaponRefinementSystem';
import { MiningSystem } from '../systems/MiningSystem';
import { CombatSystem, type CombatEvent } from '../systems/CombatSystem';
import { ProgressionSystem } from '../systems/ProgressionSystem';
import { ZoneProgressionSystem } from '../systems/ZoneProgressionSystem';
import { createSaveData, DEFAULT_MINIMAP_SNAPSHOT, SaveSystem, type MinimapSnapshot, type SaveLoadResult, type StorageLike } from '../systems/SaveSystem';
import { ARENA_LAYOUTS, getStaticBoxes } from '../world/world-config';
import { getZoneTerrainHeight } from '../world/terrain-height';
import { WorldChunkStreamer } from '../world/WorldChunkStreamer';
import { WorldPopulation } from '../world/WorldPopulation';
import { CivilianPopulation } from '../world/CivilianPopulation';
import { DungeonInteriorManager, type DungeonInteriorRuntime } from '../world/DungeonInteriorManager';
import { InteractionProbe } from '../interaction/InteractionProbe';
import { AdaptiveResolution } from '../render/AdaptiveResolution';
import { initialPixelRatio, type RenderQuality } from '../render/qualityTiers';
import { approachCameraDistance, resolveCameraDistance } from '../render/cameraObstruction';
import { renderDistanceFarPlane, renderDistanceFogFar, renderDistanceFogNear, resolvePerformancePolicy, streamingRadiusForDistance } from '../render/performancePolicy';
import { intersectVisible } from '../render/intersectVisible';
import { disposeSharedRenderResources, sharedGeometry } from '../render/sharedResources';
import { setDataAttribute, setHidden, setText, setWidth } from '../ui/domWrites';
import type { ZoneId } from '../types/zones';

const MAX_FRAME_DELTA = 0.25;
const MAX_CATCH_UP_STEPS = 5;
const MOUSE_SENSITIVITY = 0.0024;
// Frame-cap timing tolerance: rAF jitter of a few ms must not drop a frame at 60 fps.
const FRAME_CAP_TOLERANCE_MS = 2;
const MIN_CAMERA_PITCH = 0.12;
const MAX_CAMERA_PITCH = 0.82;
const CAMERA_DISTANCE = 8.8;

function resolveBrowserStorage(): StorageLike | null {
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

function oreAssetId(resourceId: ResourceId): AssetId {
  if (resourceId === 'copper-ore') return 'ore-copper';
  if (resourceId === 'iron-ore') return 'ore-iron';
  if (resourceId === 'gold-ore') return 'ore-gold';
  return 'ore-crystal';
}

interface LoadingUi {
  setStage(stage: number, message: string): void;
  finish(): void;
}

interface InteractionPrompt {
  readonly visible: boolean;
  readonly text: string;
  /** Width for the target health meter, or null to leave the meter as it is. */
  readonly healthWidth: string | null;
  readonly showHealthMeter: boolean;
}

const HIDDEN_PROMPT: InteractionPrompt = { visible: false, text: '', healthWidth: null, showHealthMeter: false };

function promptText(text: string, healthWidth: string): InteractionPrompt {
  return { visible: true, text, healthWidth, showHealthMeter: false };
}

export class GameApp {
  private readonly scene = new THREE.Scene();
  private readonly camera = new THREE.PerspectiveCamera(58, 1, 0.1, 100);
  private readonly desiredCameraPosition = new THREE.Vector3();
  private readonly cameraTarget = new THREE.Vector3();
  private readonly cameraDirection = new THREE.Vector3();
  private readonly cameraRaycaster = new THREE.Raycaster();
  private readonly cameraOccluderScratch: THREE.Object3D[] = [];
  private readonly cameraIntersectionScratch: THREE.Intersection[] = [];
  private cameraDistance = CAMERA_DISTANCE;
  private readonly interactionProbe = new InteractionProbe();
  private readonly quality: RenderQuality;
  private readonly adaptiveResolution: AdaptiveResolution;
  private frameIntervalMs: number;
  /** Set when something other than the simulation requires a fresh render, such as resize or a panel change. */
  private renderDirty = true;
  private lastRenderTime = 0;
  private readonly renderer: THREE.WebGLRenderer;
  private readonly input: InputRouter;
  private readonly feedback: FeedbackSystem;
  private readonly menuNavigator = new MenuNavigator();
  private readonly inventory = new Inventory();
  private readonly forgeSystem = new ForgeSystem(this.inventory);
  private readonly questSystem = new QuestSystem();
  private readonly miniGameSystem = new MiniGameSystem();
  private readonly dungeonProgress = new DungeonProgressSystem();
  private readonly shopSystem = new ShopSystem(this.inventory);
  private readonly refinementSystem = new WeaponRefinementSystem(this.inventory);
  private readonly gearInventory = new GearInventorySystem();
  private readonly blacksmithSystem = new BlacksmithSystem(this.inventory, this.gearInventory);
  private readonly gearRefinementSystem = new GearRefinementSystem(this.inventory, this.gearInventory);
  private readonly tutorial = new TutorialSystem();
  private minimapState: MinimapSnapshot = { ...DEFAULT_MINIMAP_SNAPSHOT };
  private readonly oreNodes: OreNode[] = [];
  private readonly enemies: Enemy[] = [];
  private readonly npcs: Npc[] = [];
  private readonly questWorldObjects: QuestWorldObject[] = [];
  private readonly miniGameStations: MiniGameStation[] = [];
  private readonly dungeonEntrances: DungeonEntrance[] = [];
  private readonly cameraOccluders: THREE.Object3D[] = [];
  private readonly combatOccluders: THREE.Object3D[] = [];
  private readonly progression = new ProgressionSystem();
  private readonly zoneProgression = new ZoneProgressionSystem();
  private readonly assetRegistry = new AssetRegistry();
  private readonly saveSystem: SaveSystem;
  private readonly audioManager = new AudioManager();
  private gameSettings: GameSettings = DEFAULT_GAME_SETTINGS;
  private screenShakeEnabled = true;
  private gameplayPaused = true;
  private shakeRemaining = 0;
  private readonly initialLoadResult: SaveLoadResult;
  private initialSavedHealth = 100;
  private persistenceReady = false;
  private readonly zonePortals: ZonePortal[] = [];
  private zonePortalTarget: ZonePortal | null = null;
  private zonePortalInRange = false;
  private hemisphereLight!: THREE.HemisphereLight;
  private keyLight!: THREE.DirectionalLight;
  private fillLight!: THREE.PointLight;
  private readonly inventorySummaryElements = new Map<ResourceId, HTMLElement>();
  private readonly inventoryPanelElements = new Map<ResourceId, HTMLElement>();

  private physics: PhysicsWorld | null = null;
  private terrainStreamer: WorldChunkStreamer | null = null;
  private worldPopulation: WorldPopulation | null = null;
  private civilianPopulation: CivilianPopulation | null = null;
  private minimap: MinimapRenderer | null = null;
  private benHouseRoot: THREE.Group | null = null;
  private benPickaxeRoot: THREE.Group | null = null;
  private tutorialMarker: THREE.Group | null = null;
  private benNpc: Npc | null = null;
  private readonly lastTutorialPosition = new THREE.Vector3();
  private dungeonInteriorManager: DungeonInteriorManager | null = null;
  private activeDungeonId: DungeonId | null = null;
  private activeDungeonRuntime: DungeonInteriorRuntime | null = null;
  private dungeonReturnPosition: THREE.Vector3 | null = null;
  private readonly dungeonLights: THREE.PointLight[] = [];
  private readonly dungeonCameraOccluders: THREE.Object3D[] = [];
  private hiddenOverworldVisibility: Map<THREE.Object3D, boolean> | null = null;
  private zoneTransitionInProgress = false;
  private player: PlayerController | null = null;
  private miningSystem: MiningSystem | null = null;
  private combatSystem: CombatSystem | null = null;
  private forgeStation: ForgeStation | null = null;
  private animationFrame = 0;
  private lastFrameTime = 0;
  private accumulator = 0;
  private running = false;
  private frameCounter = 0;
  private fpsElapsed = 0;
  private currentFps = 0;
  private cameraYaw = 0.58;
  private cameraPitch = 0.38;
  private inventoryOpen = false;
  private forgeOpen = false;
  private forgeTargeted = false;
  private forgeTargetInRange = false;
  private npcTarget: Npc | null = null;
  private npcTargetInRange = false;
  private questObjectTarget: QuestWorldObject | null = null;
  private questObjectTargetInRange = false;
  private miniGameTarget: MiniGameStation | null = null;
  private miniGameTargetInRange = false;
  private dungeonEntranceTarget: DungeonEntrance | null = null;
  private dungeonEntranceInRange = false;
  private dungeonPointTarget: DungeonPointDefinition | null = null;
  private dungeonPointInRange = false;
  private dungeonExitTarget: THREE.Object3D | null = null;
  private dungeonExitInRange = false;
  private activeNpc: Npc | null = null;
  private npcPanelOpen = false;
  private questJournalOpen = false;
  private explorationPanelOpen = false;
  private refinerPanelOpen = false;
  private miniGamePanelOpen = false;
  private deferInventoryPersist = false;
  private toastRemaining = 0;
  private damageFlashRemaining = 0;
  private readonly positionElement: HTMLElement;
  private readonly physicsElement: HTMLElement;
  private readonly simulationElement: HTMLElement;
  private readonly cameraStateElement: HTMLElement;
  private readonly interactionPrompt: HTMLElement;
  private readonly interactionPromptText: HTMLElement;
  private readonly targetHealthFill: HTMLElement;
  private readonly inventoryPanel: HTMLElement;
  private readonly closeInventoryButton: HTMLButtonElement;
  private readonly inventoryOwnedEquipment: HTMLElement;
  private readonly inventoryEquippedEquipment: HTMLElement;
  private readonly forgePanel: HTMLElement;
  private readonly forgePanelKicker: HTMLElement;
  private readonly forgePanelTitle: HTMLElement;
  private readonly closeForgeButton: HTMLButtonElement;
  private readonly smeltRecipesElement: HTMLElement;
  private readonly craftRecipesElement: HTMLElement;
  private readonly forgeFeedbackElement: HTMLElement;
  private readonly npcPanel: HTMLElement;
  private readonly closeNpcPanelButton: HTMLButtonElement;
  private readonly openQuestJournalButton: HTMLButtonElement;
  private readonly closeQuestJournalButton: HTMLButtonElement;
  private readonly closeRefinerButton: HTMLButtonElement;
  private readonly npcPanelTitle: HTMLElement;
  private readonly npcPanelKicker: HTMLElement;
  private readonly npcGreeting: HTMLElement;
  private readonly npcQuestTitle: HTMLElement;
  private readonly npcQuestDescription: HTMLElement;
  private readonly npcObjectiveList: HTMLElement;
  private readonly npcQuestStatus: HTMLElement;
  private readonly npcAcceptButton: HTMLButtonElement;
  private readonly npcTurnInButton: HTMLButtonElement;
  private readonly npcServiceButton: HTMLButtonElement;
  private readonly npcShopContent: HTMLElement;
  private readonly questJournalPanel: HTMLElement;
  private readonly questJournalList: HTMLElement;
  private readonly openExplorationButton: HTMLButtonElement;
  private readonly closeExplorationButton: HTMLButtonElement;
  private readonly explorationPanel: HTMLElement;
  private readonly explorationList: HTMLElement;
  private readonly explorationSummary: HTMLElement;
  private readonly miniGamePanel: MiniGamePanel;
  private readonly refinerPanel: HTMLElement;
  private readonly refinerTitle: HTMLElement;
  private readonly refinerKicker: HTMLElement;
  private readonly refinerSummary: HTMLElement;
  private readonly refinerPlanElement: HTMLElement;
  private readonly refinerFeedback: HTMLElement;
  private readonly refineWeaponButton: HTMLButtonElement;
  private readonly equippedPickaxeElement: HTMLElement;
  private readonly equippedWeaponElement: HTMLElement;
  private readonly pickaxePowerElement: HTMLElement;
  private readonly weaponDamageElement: HTMLElement;
  private readonly toastElement: HTMLElement;
  private readonly healthTextElement: HTMLElement;
  private readonly healthFillElement: HTMLElement;
  private readonly levelTextElement: HTMLElement;
  private readonly xpTextElement: HTMLElement;
  private readonly xpFillElement: HTMLElement;
  private readonly damageVignetteElement: HTMLElement;
  private readonly respawnBannerElement: HTMLElement;
  private readonly respawnCountdownElement: HTMLElement;
  private readonly activeZoneElement: HTMLElement;
  private readonly coinBalanceElement: HTMLElement;
  private readonly inventoryCoinsElement: HTMLElement;
  private readonly saveStatusElement: HTMLElement;
  private readonly resetSaveButton: HTMLButtonElement;
  private readonly gearInventoryList: HTMLElement;
  private readonly gearTradeList: HTMLElement;
  private readonly gearRefinerList: HTMLElement;
  private readonly tutorialPanel: HTMLElement;
  private readonly tutorialTitle: HTMLElement;
  private readonly tutorialDescription: HTMLElement;
  private readonly tutorialSubtitle: HTMLElement;
  private readonly minimapNorthButton: HTMLButtonElement;
  private readonly minimapZoomInButton: HTMLButtonElement;
  private readonly minimapZoomOutButton: HTMLButtonElement;
  private readonly loadingUi: LoadingUi;
  private readonly unsubscribeInventory: () => void;
  private readonly onResize = (): void => this.resize();
  private readonly onCloseInventory = (): void => this.setInventoryOpen(false);
  private readonly onInventoryPanelClick = (event: MouseEvent): void => this.handleInventoryPanelClick(event);
  private readonly onCloseForge = (): void => this.setForgeOpen(false);
  private readonly onForgePanelClick = (event: MouseEvent): void => this.handleForgePanelClick(event);
  private readonly onNpcPanelClick = (event: MouseEvent): void => this.handleNpcPanelClick(event);
  private readonly onCloseNpcPanel = (): void => this.setNpcPanelOpen(false);
  private readonly onQuestJournalClick = (): void => this.setQuestJournalOpen(!this.questJournalOpen);
  private readonly onCloseQuestJournal = (): void => this.setQuestJournalOpen(false);
  private readonly onExplorationClick = (): void => this.setExplorationPanelOpen(!this.explorationPanelOpen);
  private readonly onCloseExploration = (): void => this.setExplorationPanelOpen(false);
  private readonly onRefinerPanelClick = (event: MouseEvent): void => this.handleRefinerPanelClick(event);
  private readonly onCloseRefiner = (): void => this.setRefinerPanelOpen(false);
  private readonly onMiniGameComplete = (result: MiniGameRunResult): void => this.handleMiniGameComplete(result);
  private readonly onMiniGameClose = (): void => { this.miniGamePanelOpen = false; this.syncOverlayInputState(); };
  private readonly onResetSave = (): void => this.resetSave();

  constructor(canvasHost: HTMLElement, loadingUi: LoadingUi, quality: RenderQuality) {
    this.quality = quality;
    this.frameIntervalMs = quality.frameRateCap ? 1000 / quality.frameRateCap : 0;
    this.loadingUi = loadingUi;
    const browserStorage = resolveBrowserStorage();
    this.saveSystem = new SaveSystem(browserStorage);
    this.gameSettings = loadGameSettings(browserStorage);
    const loaded = this.saveSystem.load();
    if (loaded.status === 'loaded' || loaded.status === 'migrated') {
      const inventoryRestored = this.inventory.restore(loaded.data.inventory);
      const progressionRestored = this.progression.restore(loaded.data.progression);
      const zoneRestored = this.zoneProgression.setCurrentZone(loaded.data.currentZoneId, loaded.data.progression.level);
      const questsRestored = this.questSystem.restore(loaded.data.questState);
      const miniGamesRestored = this.miniGameSystem.restore(loaded.data.miniGameState);
      const dungeonsRestored = this.dungeonProgress.restore(loaded.data.dungeonState);
      const gearRestored = this.gearInventory.restore(loaded.data.gearInventory);
      const gearRefinementRestored = this.gearRefinementSystem.restore(loaded.data.gearRefinement);
      const tutorialRestored = this.tutorial.restore(loaded.data.tutorialState);
      this.minimapState = { ...loaded.data.minimapState };
      if (inventoryRestored.ok && progressionRestored && zoneRestored && questsRestored && miniGamesRestored && dungeonsRestored && gearRestored.ok && gearRefinementRestored && tutorialRestored) {
        this.initialSavedHealth = loaded.data.playerHealth;
        this.initialLoadResult = loaded;
      } else {
        this.initialLoadResult = { status: 'invalid', reason: 'Saved expedition failed an in-memory integrity check.' };
      }
    } else {
      this.initialLoadResult = loaded;
    }
    this.positionElement = this.getRequiredElement('player-position');
    this.physicsElement = this.getRequiredElement('physics-state');
    this.simulationElement = this.getRequiredElement('simulation-state');
    this.cameraStateElement = this.getRequiredElement('camera-state');
    this.interactionPrompt = this.getRequiredElement('interaction-prompt');
    this.interactionPromptText = this.getRequiredElement('interaction-prompt-text');
    this.targetHealthFill = this.getRequiredElement('target-health-fill');
    this.inventoryPanel = this.getRequiredElement('inventory-panel');
    this.closeInventoryButton = this.getRequiredElement('close-inventory') as HTMLButtonElement;
    this.inventoryOwnedEquipment = this.getRequiredElement('inventory-owned-equipment');
    this.inventoryEquippedEquipment = this.getRequiredElement('inventory-equipped-equipment');
    this.forgePanel = this.getRequiredElement('forge-panel');
    this.forgePanelKicker = this.getRequiredElement('forge-panel-kicker');
    this.forgePanelTitle = this.getRequiredElement('forge-title');
    this.closeForgeButton = this.getRequiredElement('close-forge') as HTMLButtonElement;
    this.smeltRecipesElement = this.getRequiredElement('smelt-recipes');
    this.craftRecipesElement = this.getRequiredElement('craft-recipes');
    this.forgeFeedbackElement = this.getRequiredElement('forge-feedback');
    this.npcPanel = this.getRequiredElement('npc-panel');
    this.closeNpcPanelButton = this.getRequiredElement('close-npc-panel') as HTMLButtonElement;
    this.openQuestJournalButton = this.getRequiredElement('open-quest-journal') as HTMLButtonElement;
    this.closeQuestJournalButton = this.getRequiredElement('close-quest-journal') as HTMLButtonElement;
    this.closeRefinerButton = this.getRequiredElement('close-refiner') as HTMLButtonElement;
    this.npcPanelTitle = this.getRequiredElement('npc-panel-title');
    this.npcPanelKicker = this.getRequiredElement('npc-panel-kicker');
    this.npcGreeting = this.getRequiredElement('npc-greeting');
    this.npcQuestTitle = this.getRequiredElement('npc-quest-title');
    this.npcQuestDescription = this.getRequiredElement('npc-quest-description');
    this.npcObjectiveList = this.getRequiredElement('npc-objective-list');
    this.npcQuestStatus = this.getRequiredElement('npc-quest-status');
    this.npcAcceptButton = this.getRequiredElement('npc-accept-quest') as HTMLButtonElement;
    this.npcTurnInButton = this.getRequiredElement('npc-turn-in-quest') as HTMLButtonElement;
    this.npcServiceButton = this.getRequiredElement('npc-open-service') as HTMLButtonElement;
    this.npcShopContent = this.getRequiredElement('npc-shop-content');
    this.miniGamePanel = new MiniGamePanel(this.getRequiredElement('minigame-panel'), this.onMiniGameComplete, this.onMiniGameClose);
    this.miniGamePanel.setAnimationsEnabled(this.gameSettings.video.animations);
    this.questJournalPanel = this.getRequiredElement('quest-journal-panel');
    this.questJournalList = this.getRequiredElement('quest-journal-list');
    this.openExplorationButton = this.getRequiredElement('open-exploration-log') as HTMLButtonElement;
    this.closeExplorationButton = this.getRequiredElement('close-exploration-log') as HTMLButtonElement;
    this.explorationPanel = this.getRequiredElement('exploration-panel');
    this.explorationList = this.getRequiredElement('exploration-list');
    this.explorationSummary = this.getRequiredElement('exploration-summary');
    this.refinerPanel = this.getRequiredElement('refiner-panel');
    this.refinerTitle = this.getRequiredElement('refiner-title');
    this.refinerKicker = this.getRequiredElement('refiner-kicker');
    this.refinerSummary = this.getRequiredElement('refiner-summary');
    this.refinerPlanElement = this.getRequiredElement('refiner-plan');
    this.refinerFeedback = this.getRequiredElement('refiner-feedback');
    this.refineWeaponButton = this.getRequiredElement('refine-weapon-action') as HTMLButtonElement;
    this.equippedPickaxeElement = this.getRequiredElement('equipped-pickaxe');
    this.equippedWeaponElement = this.getRequiredElement('equipped-weapon');
    this.pickaxePowerElement = this.getRequiredElement('pickaxe-power');
    this.weaponDamageElement = this.getRequiredElement('weapon-damage');
    this.toastElement = this.getRequiredElement('game-toast');
    this.healthTextElement = this.getRequiredElement('player-health-text');
    this.healthFillElement = this.getRequiredElement('player-health-fill');
    this.levelTextElement = this.getRequiredElement('player-level-text');
    this.xpTextElement = this.getRequiredElement('player-xp-text');
    this.xpFillElement = this.getRequiredElement('player-xp-fill');
    this.damageVignetteElement = this.getRequiredElement('damage-vignette');
    this.respawnBannerElement = this.getRequiredElement('respawn-banner');
    this.respawnCountdownElement = this.getRequiredElement('respawn-countdown');
    this.activeZoneElement = this.getRequiredElement('active-zone-label');
    this.coinBalanceElement = this.getRequiredElement('coin-balance');
    this.inventoryCoinsElement = this.getRequiredElement('inventory-coins');
    this.saveStatusElement = this.getRequiredElement('save-status');
    this.resetSaveButton = this.getRequiredElement('reset-save') as HTMLButtonElement;
    this.gearInventoryList = this.getRequiredElement('gear-inventory-items');
    this.gearTradeList = this.getRequiredElement('gear-trade-list');
    this.gearRefinerList = this.getRequiredElement('gear-refiner-items');
    this.tutorialPanel = this.getRequiredElement('tutorial-panel');
    this.tutorialTitle = this.getRequiredElement('tutorial-title');
    this.tutorialDescription = this.getRequiredElement('tutorial-description');
    this.tutorialSubtitle = this.getRequiredElement('tutorial-subtitle');
    this.minimapNorthButton = this.getRequiredElement('minimap-north-lock') as HTMLButtonElement;
    this.minimapZoomInButton = this.getRequiredElement('minimap-zoom-in') as HTMLButtonElement;
    this.minimapZoomOutButton = this.getRequiredElement('minimap-zoom-out') as HTMLButtonElement;

    for (const resourceId of RESOURCE_IDS) {
      this.inventorySummaryElements.set(
        resourceId,
        this.getRequiredElement(`resource-${resourceId}`),
      );
      this.inventoryPanelElements.set(
        resourceId,
        this.getRequiredElement(`inventory-${resourceId}`),
      );
    }

    this.renderer = new THREE.WebGLRenderer({ antialias: quality.antialias, powerPreference: 'high-performance' });
    const startingRatio = initialPixelRatio(quality, window.devicePixelRatio);
    this.adaptiveResolution = new AdaptiveResolution({
      initialRatio: startingRatio,
      minimumRatio: quality.minimumPixelRatio,
      maximumRatio: quality.maximumPixelRatio,
      targetFrameMs: 1000 / (quality.frameRateCap ?? 60),
    });
    this.renderer.setPixelRatio(startingRatio);
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = quality.shadowFilter === 'pcf-soft' ? THREE.PCFSoftShadowMap : THREE.PCFShadowMap;
    this.renderer.domElement.setAttribute('aria-label', 'Forgebound 3D quarry scene');
    canvasHost.append(this.renderer.domElement);
    this.input = new InputRouter({
      canvas: this.renderer.domElement,
      shell: document.getElementById('game-shell'),
      touchLayer: document.getElementById('touch-layer'),
      storage: resolveBrowserStorage(),
      hidButton: document.getElementById('enable-dualsense') as HTMLButtonElement | null,
      hapticsButton: document.getElementById('haptics-toggle') as HTMLButtonElement | null,
      onNotice: (message) => this.showToast(message),
    });
    this.feedback = new FeedbackSystem({
      output: () => this.input.hapticOutput(),
      settings: () => this.input.settings,
    });
    this.input.updateKeyBindings(this.gameSettings.controls.keyboard);
    this.input.updateGamepadBindings(this.gameSettings.controls.gamepad);
    this.audioManager.configure(this.gameSettings.audio);

    this.minimap = new MinimapRenderer(this.getRequiredElement('minimap-canvas') as HTMLCanvasElement);
    this.minimap.setSettings(this.minimapState.northLocked, this.minimapState.zoom);
    this.minimapNorthButton.textContent = this.minimapState.northLocked ? 'North locked' : 'Player facing';

    this.closeInventoryButton.addEventListener('click', this.onCloseInventory);
    this.inventoryPanel.addEventListener('click', this.onInventoryPanelClick);
    this.closeForgeButton.addEventListener('click', this.onCloseForge);
    this.forgePanel.addEventListener('click', this.onForgePanelClick);
    this.npcPanel.addEventListener('click', this.onNpcPanelClick);
    this.closeNpcPanelButton.addEventListener('click', this.onCloseNpcPanel);
    this.openQuestJournalButton.addEventListener('click', this.onQuestJournalClick);
    this.closeQuestJournalButton.addEventListener('click', this.onCloseQuestJournal);
    this.openExplorationButton.addEventListener('click', this.onExplorationClick);
    this.closeExplorationButton.addEventListener('click', this.onCloseExploration);
    this.refinerPanel.addEventListener('click', this.onRefinerPanelClick);
    this.closeRefinerButton.addEventListener('click', this.onCloseRefiner);
    this.resetSaveButton.addEventListener('click', this.onResetSave);
    this.minimapNorthButton.addEventListener('click', () => this.setMinimapNorthLocked(!this.minimapState.northLocked));
    this.minimapZoomInButton.addEventListener('click', () => this.setMinimapZoom(this.minimapState.zoom + 0.2));
    this.minimapZoomOutButton.addEventListener('click', () => this.setMinimapZoom(this.minimapState.zoom - 0.2));
    this.renderTutorialPanel();
    this.unsubscribeInventory = this.inventory.subscribe((snapshot) => {
      this.updateInventoryUi(snapshot);
      this.syncWeaponVisual();
      if (this.npcPanelOpen) this.renderNpcPanel();
      if (this.refinerPanelOpen && this.activeNpc) this.renderRefinerPanel(this.activeNpc);
      if (!this.deferInventoryPersist) this.persist();
    });
    this.saveStatusElement.textContent = this.initialLoadResult.status === 'loaded'
      ? 'SAVE FOUND'
      : this.initialLoadResult.status === 'migrated' ? 'LEGACY SAVE FOUND' : 'NEW EXPEDITION';

    this.scene.background = new THREE.Color(0x142126);
    this.scene.fog = new THREE.Fog(0x142126, 24, 58);
    this.cameraRaycaster.near = 0;
    this.setupLights();
    this.buildVisualWorld();
    this.applySettings(this.gameSettings, false);
    window.addEventListener('resize', this.onResize);
    this.resize();
  }

  async start(): Promise<void> {
    this.loadingUi.setStage(1, 'Initializing Rapier physics…');
    this.physics = await PhysicsWorld.create();

    const activeZoneId = this.zoneProgression.getCurrentZoneId();
    this.loadingUi.setStage(2, 'Loading Python-generated GLB models and terrain manifest…');
    await this.assetRegistry.loadAll();
    this.assetRegistry.assertLoaded([
      'player', 'weapon-sword', 'weapon-hammer', 'ore-copper', 'ore-iron', 'ore-gold', 'ore-crystal', 'forge',
      'enemy-crawler', 'enemy-ember', 'enemy-guardian', 'portal',
      'tree-pine', 'tree-broadleaf', 'rock-outcrop', 'stone-arch', 'volcanic-vent',
      'crystal-spire', 'timber-stack', 'ore-cart', 'magma-corn', 'crystal-cod',
      'chessboard', 'cave-arch', 'water-plane', 'quest-cat',
      ...NPC_DEFINITIONS.map((definition) => definition.assetId),
      ...QUEST_WORLD_OBJECTS.map((definition) => definition.assetId),
      'pet-dog', 'ben-house', ...Array.from({ length: 25 }, (_, index) => `civilian-${String(index + 1).padStart(2, '0')}` as AssetId),
      ...GEAR_IDS.map((gearId) => `gear-${gearId}` as AssetId),
    ]);
    this.worldPopulation = new WorldPopulation(this.scene, this.assetRegistry);
    this.worldPopulation.build();
    this.worldPopulation.setActiveZone(activeZoneId);
    this.terrainStreamer = new WorldChunkStreamer(this.scene, this.physics);
    await this.terrainStreamer.initialize();
    this.terrainStreamer.setStreamingRadiusChunks(streamingRadiusForDistance(this.gameSettings.video.drawDistance));
    await this.terrainStreamer.loadAround(activeZoneId, ZONE_DEFINITIONS[activeZoneId].spawn);

    this.loadingUi.setStage(3, 'Streaming the starting zone and restoring your checkpoint…');
    const playerModel = this.assetRegistry.createInstance('player');
    this.player = new PlayerController(this.physics.player, playerModel);
    this.player.setAnimationsEnabled(this.gameSettings.video.animations);
    this.player.respawnAt(ZONE_DEFINITIONS[activeZoneId].spawn);
    this.scene.add(this.player.visualRoot);
    this.lastTutorialPosition.copy(this.player.visualRoot.position);
    this.syncWeaponVisual();

    for (const definition of ORE_NODE_DEFINITIONS) {
      const oreModel = this.assetRegistry.createInstance(oreAssetId(definition.resourceId));
      const node = new OreNode(definition, this.physics, oreModel);
      this.oreNodes.push(node);
      this.scene.add(node.visualRoot);
    }
    this.miningSystem = new MiningSystem(this.oreNodes, this.inventory);
    this.miningSystem.setActiveZone(activeZoneId);
    const forgeModel = this.assetRegistry.createInstance('forge');
    this.forgeStation = new ForgeStation(this.physics, forgeModel);
    this.scene.add(this.forgeStation.visualRoot);
    this.cameraOccluders.push(this.forgeStation.visualRoot);

    for (const enemyId of ENEMY_SPAWN_ORDER) {
      const enemyAsset: AssetId = enemyId === 'quarry-crawler'
        ? 'enemy-crawler'
        : enemyId === 'ember-stalker' ? 'enemy-ember' : 'enemy-guardian';
      const enemyModel = this.assetRegistry.createInstance(enemyAsset);
      const enemy = new Enemy(ENEMY_DEFINITIONS[enemyId], this.physics, enemyModel);
      enemy.setAnimationsEnabled(this.gameSettings.video.animations);
      const combatProfile = difficultyCombatProfile(this.gameSettings.difficulty);
      enemy.setDamageMultiplier(combatProfile.enemyDamageMultiplier);
      enemy.setHealthMultiplier(combatProfile.enemyHealthMultiplier);
      this.enemies.push(enemy);
      this.scene.add(enemy.visualRoot);
    }
    this.createZonePortals();
    this.createQuestWorldEntities(activeZoneId);
    this.createBenTutorialWorld();
    this.civilianPopulation = new CivilianPopulation(this.scene, this.physics, (assetId) => this.assetRegistry.createInstance(assetId as AssetId), (assetId) => this.assetRegistry.getAnimations(assetId as AssetId));
    this.civilianPopulation.setActiveZone(activeZoneId);
    this.createDungeonEntrances(activeZoneId);
    this.dungeonInteriorManager = new DungeonInteriorManager(this.scene, this.physics);
    this.registerInteractionRoots();
    this.combatOccluders.push(...this.cameraOccluders);
    for (const node of this.oreNodes) this.combatOccluders.push(node.visualRoot);
    this.combatSystem = new CombatSystem(this.enemies, this.inventory, this.progression);
    this.combatSystem.setPlayerDamageMultiplier(difficultyCombatProfile(this.gameSettings.difficulty).playerDamageMultiplier);
    this.combatSystem.setGearStatsResolver(() => {
      const item = this.gearInventory.getEquippedWeapon();
      return item ? getGearStats(item.gearId, item.materialId, item.refinementTier) : null;
    });
    this.combatSystem.setGearDefenseResolver(() => this.gearInventory.getEquippedArmor().reduce(
      (total, item) => total + getGearStats(item.gearId, item.materialId, item.refinementTier).defense, 0,
    ));
    this.combatSystem.setActiveZone(activeZoneId);
    this.combatSystem.restoreHealth(this.initialSavedHealth);
    // Re-apply after GLB assets, enemies, and player visuals exist so smooth-lighting,
    // shadow, animation, and graphics options affect the loaded content as well as future UI.
    this.applySettings(this.gameSettings, false);
    this.applyZoneAppearance(ZONE_DEFINITIONS[activeZoneId]);
    this.updateZoneReadout();
    this.refreshQuestJournal();
    this.refreshZonePortalAccess();
    this.refreshForgeUi();
    this.refreshGearInventoryUi();
    this.updateCombatHud();
    this.updateTutorialMarkerPosition();
    this.updateMinimap(performance.now(), true);

    this.physicsElement.textContent = `RAPIER ONLINE · ${this.assetRegistry.loadedCount()}/${this.assetRegistry.attemptedCount()} GLB`;
    this.persistenceReady = true;
    this.setGameplayPaused(true);
    this.persist();
    if (this.initialLoadResult.status === 'loaded') this.showToast('Expedition restored from your local save.');
    else if (this.initialLoadResult.status === 'migrated') this.showToast('Older expedition save migrated successfully.');
    else if (this.initialLoadResult.status === 'invalid') this.showToast('Saved data was invalid; a fresh expedition has started.');
    else if (this.initialLoadResult.status === 'unavailable') this.showToast('Browser saving is unavailable in this session.');
    this.updateCamera(1);
    this.loadingUi.finish();
    this.running = true;
    this.lastFrameTime = performance.now();
    this.animationFrame = window.requestAnimationFrame(this.frame);
  }

  /**
   * Hands every top-level object the interaction probe may hit to the probe, with its owner.
   * Portals are registered before the static occluders, which also list them; the probe
   * ignores the second registration.
   */
  private registerInteractionRoots(): void {
    for (const portal of this.zonePortals) this.interactionProbe.register(portal.visualRoot, { kind: 'portal', portal });
    for (const npc of this.npcs) this.interactionProbe.register(npc.visualRoot, { kind: 'npc', npc });
    for (const object of this.questWorldObjects) this.interactionProbe.register(object.visualRoot, { kind: 'quest-object', object });
    for (const station of this.miniGameStations) this.interactionProbe.register(station.visualRoot, { kind: 'activity', station });
    for (const entrance of this.dungeonEntrances) this.interactionProbe.register(entrance.visualRoot, { kind: 'dungeon-entrance', dungeonId: entrance.definition.id, zoneId: entrance.definition.zoneId });
    for (const node of this.oreNodes) this.interactionProbe.register(node.visualRoot, { kind: 'ore', node });
    for (const enemy of this.enemies) this.interactionProbe.register(enemy.visualRoot, { kind: 'enemy', enemy });
    for (const occluder of this.cameraOccluders) this.interactionProbe.register(occluder, { kind: 'static' });
  }

  private createQuestWorldEntities(activeZoneId: ZoneId): void {
    for (const definition of NPC_DEFINITIONS) {
      const zone = ZONE_DEFINITIONS[definition.zoneId];
      const x = zone.spawn.x + definition.offset.x;
      const z = zone.spawn.z + definition.offset.z;
      const y = getZoneTerrainHeight(definition.zoneId, definition.offset.x, definition.offset.z) + 0.92;
      const npc = new Npc(definition, this.assetRegistry.createInstance(definition.assetId), new THREE.Vector3(x, y, z), this.assetRegistry.getAnimations(definition.assetId));
      npc.visualRoot.visible = definition.zoneId === activeZoneId;
      this.npcs.push(npc);
      if (definition.id === 'ben') this.benNpc = npc;
      this.scene.add(npc.visualRoot);
    }

    for (const definition of QUEST_WORLD_OBJECTS) {
      const zone = ZONE_DEFINITIONS[definition.zoneId];
      const x = zone.spawn.x + definition.offset.x;
      const z = zone.spawn.z + definition.offset.z;
      const y = getZoneTerrainHeight(definition.zoneId, definition.offset.x, definition.offset.z);
      const object = new QuestWorldObject(definition, this.assetRegistry.createInstance(definition.assetId), new THREE.Vector3(x, y, z));
      object.restoreUsed(this.questSystem.isWorldObjectUsed(definition.id));
      object.visualRoot.visible = definition.zoneId === activeZoneId && object.isAvailable();
      this.questWorldObjects.push(object);
      this.scene.add(object.visualRoot);
    }

    for (const definition of MINI_GAME_STATIONS) {
      const zone = ZONE_DEFINITIONS[definition.zoneId];
      const x = zone.spawn.x + definition.offset.x;
      const z = zone.spawn.z + definition.offset.z;
      const y = getZoneTerrainHeight(definition.zoneId, definition.offset.x, definition.offset.z);
      const station = new MiniGameStation(definition, this.assetRegistry.createInstance(definition.assetId), new THREE.Vector3(x, y, z));
      station.visualRoot.visible = definition.zoneId === activeZoneId;
      this.miniGameStations.push(station);
      this.scene.add(station.visualRoot);
    }
  }

  private createBenTutorialWorld(): void {
    const zone = ZONE_DEFINITIONS['starter-quarry'];
    const houseOffset = { x: -29, z: 22 };
    const housePosition = new THREE.Vector3(
      zone.spawn.x + houseOffset.x,
      getZoneTerrainHeight('starter-quarry', houseOffset.x, houseOffset.z),
      zone.spawn.z + houseOffset.z,
    );
    this.benHouseRoot = new THREE.Group();
    this.benHouseRoot.name = 'ben-house-tutorial-landmark';
    const house = this.assetRegistry.createInstance('ben-house');
    house.scale.setScalar(1.35);
    this.benHouseRoot.add(house);
    this.benHouseRoot.position.copy(housePosition);
    this.benHouseRoot.visible = this.zoneProgression.getCurrentZoneId() === 'starter-quarry';
    this.scene.add(this.benHouseRoot);

    this.benPickaxeRoot = new THREE.Group();
    this.benPickaxeRoot.name = `tutorial-pickaxe-${BEN_PICKAXE_INSTANCE_ID}`;
    const pickaxe = this.assetRegistry.createInstance('pickaxe');
    pickaxe.scale.setScalar(0.72);
    pickaxe.rotation.z = -0.75;
    this.benPickaxeRoot.add(pickaxe);
    this.benPickaxeRoot.position.set(housePosition.x + 3.1, housePosition.y + 0.04, housePosition.z + 2.5);
    this.benPickaxeRoot.visible = this.tutorial.isPickaxeVisibleAtHouse() && this.zoneProgression.getCurrentZoneId() === 'starter-quarry';
    this.scene.add(this.benPickaxeRoot);

    this.tutorialMarker = new THREE.Group();
    this.tutorialMarker.name = 'tutorial-yellow-cross-marker';
    const gold = new THREE.MeshBasicMaterial({ color: 0xffdf32, toneMapped: false });
    const vertical = new THREE.Mesh(new THREE.BoxGeometry(0.22, 1.25, 0.22), gold);
    const horizontal = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.22, 0.22), gold);
    vertical.position.y = 0.56; horizontal.position.y = 0.56;
    vertical.castShadow = false; horizontal.castShadow = false;
    this.tutorialMarker.add(vertical, horizontal);
    this.tutorialMarker.visible = false;
    this.scene.add(this.tutorialMarker);
    this.updateTutorialMarkerPosition();
  }

  private isPickaxeInRange(): boolean {
    if (!this.player || !this.benPickaxeRoot || !this.benPickaxeRoot.visible || this.tutorial.getStep() !== 'find-pickaxe') return false;
    return this.player.visualRoot.position.distanceToSquared(this.benPickaxeRoot.position) <= 3.6 * 3.6;
  }

  private handlePickaxeWorldInteraction(): void {
    if (!this.benPickaxeRoot || !this.isPickaxeInRange()) {
      this.showToast('Move closer to the pickaxe at Ben’s house.'); return;
    }
    if (!this.tutorial.pickUpPickaxe(BEN_PICKAXE_INSTANCE_ID)) {
      this.showToast('That pickaxe is not available to collect right now.'); return;
    }
    this.benPickaxeRoot.visible = false;
    this.player?.playInteractionAnimation();
    this.renderTutorialPanel(); this.updateTutorialMarkerPosition(); this.persist();
    this.showToast('You found Ben’s pickaxe. Return it to Ben.');
  }

  private handleBenTutorialInteraction(): void {
    const step = this.tutorial.getStep();
    this.benNpc?.playGreetingReaction();
    this.player?.playInteractionAnimation();
    if (step === 'meet-ben') {
      if (!this.tutorial.snapshot().grantedTutorialSupplies) {
        this.deferInventoryPersist = true;
        const supplies = this.inventory.transactResourcesAndCoins({}, { 'copper-ore': 10 }, 0);
        this.deferInventoryPersist = false;
        if (!supplies.ok) { this.showToast(supplies.reason); return; }
        this.tutorial.grantTutorialSupplies();
      }
      this.tutorial.meetBen();
      this.showToast('Ben provided a tutorial supply of 10 Copper Ore. Take it to Branna and smelt your first ingots.');
    } else if (step === 'return-pickaxe') {
      if (!this.tutorial.handPickaxeToBen(BEN_PICKAXE_INSTANCE_ID)) {
        this.showToast('Ben can only accept the original pickaxe he lost.'); return;
      }
      this.showToast('Ben recognizes his original pickaxe and takes it back. Speak with him once more.');
    } else if (step === 'receive-pickaxe') {
      this.deferInventoryPersist = true;
      const existingId = this.inventory.snapshot().pickaxeInstanceId;
      let rewardSucceeded = true;
      let rewardReason = '';
      if (!this.inventory.hasEquipment('starter-pickaxe')) {
        const reward = this.inventory.grantEquipment('starter-pickaxe', true, BEN_PICKAXE_INSTANCE_ID);
        rewardSucceeded = reward.ok;
        if (!reward.ok) rewardReason = reward.reason;
      } else if (existingId !== BEN_PICKAXE_INSTANCE_ID) {
        this.deferInventoryPersist = false;
        this.showToast('A different pickaxe is already registered. Ben’s original cannot be duplicated.'); return;
      } else {
        const equipped = this.inventory.equip('starter-pickaxe');
        if (!equipped.ok) { this.deferInventoryPersist = false; this.showToast(equipped.reason); return; }
      }
      if (!rewardSucceeded || !this.tutorial.receiveGift(BEN_PICKAXE_INSTANCE_ID)) {
        this.deferInventoryPersist = false;
        this.showToast(rewardReason || 'The pickaxe handover could not be completed. No duplicate item was created.'); return;
      }
      this.deferInventoryPersist = false;
      this.player?.playInteractionAnimation();
      this.showToast('Ben gifts the exact same pickaxe back to you. Mining is now unlocked.');
      this.updateEquipmentUi(this.inventory.snapshot()); this.syncWeaponVisual();
    } else {
      this.showToast(step === 'movement' ? 'Walk a few metres to begin the tutorial.' : 'Follow the current tutorial instruction.');
    }
    this.renderTutorialPanel(); this.updateTutorialMarkerPosition(); this.persist();
  }

  private updateTutorialMarkerPosition(): void {
    if (!this.tutorialMarker || !this.player) return;
    const step = this.tutorial.getStep();
    const active = this.zoneProgression.getCurrentZoneId() === 'starter-quarry';
    if (this.benPickaxeRoot) this.benPickaxeRoot.visible = active && this.tutorial.isPickaxeVisibleAtHouse();
    const target = step === 'find-pickaxe' ? this.benPickaxeRoot?.position
      : step === 'meet-ben' || step === 'return-pickaxe' || step === 'receive-pickaxe' ? this.benNpc?.visualRoot.position
      : undefined;
    this.tutorialMarker.visible = Boolean(active && target);
    if (target && this.tutorialMarker.visible) {
      this.tutorialMarker.position.set(target.x, target.y + 2.25, target.z);
      const pulse = 1 + Math.sin(performance.now() / 210) * 0.08;
      this.tutorialMarker.scale.setScalar(pulse);
    }
  }

  private renderTutorialPanel(): void {
    const step = this.tutorial.getStep();
    if (this.tutorial.isComplete()) { this.tutorialPanel.hidden = true; return; }
    const instructions: Readonly<Record<TutorialStepId, { title: string; description: string; subtitle: string }>> = {
      movement: { title: '1 / Move around', description: 'Walk a few metres to get comfortable with movement and begin your mandatory tutorial.', subtitle: 'BEN: Take a moment to get your bearings. I’ll be waiting near the quarry path.' },
      'meet-ben': { title: '2 / Meet Ben', description: 'Find Ben in the Starter Quarry and speak with him. He will give you copper ore for the forge lesson.', subtitle: 'BEN: Glad you made it. Let’s get you started with the forge.' },
      'smelt-ingots': { title: '3 / Smelt ingots', description: 'Speak with Branna Forge, open her blacksmith station, and smelt Copper Ore into Copper Ingots.', subtitle: 'BEN: Branna can turn two Copper Ore into one Copper Ingot. I’ve given you enough ore for the lesson.' },
      'trade-gear': { title: '4 / Trade for gear', description: 'Use Branna’s J7 gear catalog. The blacksmith accepts Copper, Iron, Gold, or Crystal Ingots only — not Coins.', subtitle: 'BRANNA: Bring me ingots, not Coins. Pick the gear and material that suit your needs.' },
      'refine-gear': { title: '5 / Refine your gear', description: 'Visit Selka Edgewell and refine the gear instance you just traded for. Failed attempts consume their materials and Coins, while pity guarantees the fourth attempt.', subtitle: 'SELKA: Refinement is a risk. Your gear stays with you on failure, but the materials and Coins are spent.' },
      'use-minimap': { title: '6 / Use the minimap', description: 'Use one of the minimap controls to test its zoom or north-lock setting. North-locked orientation is the default.', subtitle: 'BEN: Check the minimap. North stays at the top by default; you can change the orientation whenever you like.' },
      'find-pickaxe': { title: '7 / Find Ben’s pickaxe', description: 'Follow the yellow cross to Ben’s house. Move close to the pickaxe on the ground and interact to pick it up.', subtitle: 'BEN: I left my pickaxe near my house. Please bring that very one back to me.' },
      'return-pickaxe': { title: '8 / Return the pickaxe', description: 'Bring the pickaxe back to Ben and interact with him to hand over the original item.', subtitle: 'BEN: That’s the pickaxe I lost! Hand it over and I’ll make sure it’s the same one.' },
      'receive-pickaxe': { title: '9 / Receive your gift', description: 'Speak to Ben once more. He will gift that same pickaxe instance back to you; mining unlocks after the handover.', subtitle: 'BEN: You went out of your way to return it. Keep it — I want you to have it.' },
      complete: { title: 'Tutorial complete', description: 'Your first expedition is ready.', subtitle: 'BEN: You’re ready. Good luck out there.' },
    };
    const current = instructions[step];
    this.tutorialTitle.textContent = current.title;
    this.tutorialDescription.textContent = current.description;
    this.tutorialSubtitle.textContent = current.subtitle;
    this.tutorialPanel.hidden = false;
  }

  private setMinimapNorthLocked(locked: boolean): void {
    this.minimapState = { ...this.minimapState, northLocked: locked };
    this.minimap?.setSettings(locked, this.minimapState.zoom);
    this.minimapNorthButton.textContent = locked ? 'North locked' : 'Player facing';
    if (this.tutorial.getStep() === 'use-minimap') this.tutorial.markMinimapOpened();
    this.renderTutorialPanel(); this.updateTutorialMarkerPosition(); this.updateMinimap(performance.now(), true); this.persist();
  }

  private setMinimapZoom(zoom: number): void {
    const clamped = THREE.MathUtils.clamp(zoom, 0.6, 2.5);
    this.minimapState = { ...this.minimapState, zoom: clamped };
    this.minimap?.setSettings(this.minimapState.northLocked, clamped);
    if (this.tutorial.getStep() === 'use-minimap') this.tutorial.markMinimapOpened();
    this.renderTutorialPanel(); this.updateTutorialMarkerPosition(); this.updateMinimap(performance.now(), true); this.persist();
  }

  private updateMinimap(now = performance.now(), force = false): void {
    if (!this.minimap || !this.player) return;
    const markers: MinimapMarker[] = [];
    const zone = this.zoneProgression.getCurrentZoneId();
    for (const marker of this.civilianPopulation?.getMinimapMarkers() ?? []) markers.push(marker);
    for (const npc of this.npcs) {
      if (!npc.visualRoot.visible || npc.definition.zoneId !== zone) continue;
      const kind = npc.definition.id === 'ben' ? 'ben'
        : npc.definition.role === 'blacksmith' ? 'blacksmith'
        : npc.definition.role === 'weapon-refiner' ? 'refiner' : null;
      if (kind) markers.push({ id: npc.definition.id, kind, x: npc.visualRoot.position.x, z: npc.visualRoot.position.z });
    }
    if (this.tutorial.getStep() === 'find-pickaxe' && this.benPickaxeRoot?.visible) {
      markers.push({ id: 'tutorial-pickaxe', kind: 'quest', x: this.benPickaxeRoot.position.x, z: this.benPickaxeRoot.position.z });
    }
    this.minimap.setSettings(this.minimapState.northLocked, this.minimapState.zoom);
    // PlayerController faces +Z at yaw 0; convert to a north-relative minimap heading (-Z north).
    const northRelativeHeading = Math.PI - this.player.bodyMesh.rotation.y;
    this.minimap.setWorld(zone, this.player.visualRoot.position, northRelativeHeading, markers);
    this.minimap.update(now, force);
    this.minimapNorthButton.textContent = this.minimapState.northLocked ? 'North locked' : 'Player facing';
  }

  private refreshGearTradeUi(): void {
    if (!this.gearTradeList) return;
    const cards: HTMLElement[] = [];
    for (const gearId of GEAR_IDS) {
      const definition = GEAR_DEFINITIONS[gearId];
      const required = definition.slot === 'weapon' ? (gearId === 'daggers' || gearId === 'gauntlet' ? 2 : 3) : 4;
      const card = document.createElement('article'); card.className = 'recipe-card gear-trade-card';
      const title = document.createElement('h3'); title.textContent = definition.name;
      const desc = document.createElement('p'); desc.className = 'recipe-description'; desc.textContent = `${definition.description} · ${definition.slot === 'weapon' ? 'Weapon' : 'Armor'}`;
      const select = document.createElement('select'); select.dataset['gearMaterial'] = 'true'; select.setAttribute('aria-label', `${definition.name} material`);
      let chosen: GearMaterialId = 'copper';
      for (const materialId of ['copper', 'iron', 'gold', 'crystal'] as const) {
        const material = GEAR_MATERIALS[materialId];
        const option = document.createElement('option'); option.value = materialId;
        option.textContent = `${material.label} · ${this.inventory.count(material.ingotId)} ingots`;
        if (this.inventory.count(material.ingotId) >= required && chosen === 'copper') chosen = materialId;
        select.append(option);
      }
      select.value = chosen;
      const cost = document.createElement('p'); cost.className = 'recipe-cost'; cost.textContent = `Cost: ${required} selected-material ingots · Coins not accepted`;
      const button = document.createElement('button'); button.type = 'button'; button.className = 'recipe-action';
      button.dataset['gearTrade'] = gearId;
      const update = (): void => {
        const material = GEAR_MATERIALS[select.value as GearMaterialId];
        const affordable = this.inventory.count(material.ingotId) >= required;
        button.disabled = !affordable;
        button.textContent = affordable ? `Trade ${material.label} Ingots` : `Need ${required} ${material.label} Ingots`;
      };
      select.addEventListener('change', update); update();
      card.append(title, desc, select, cost, button); cards.push(card);
    }
    this.gearTradeList.replaceChildren(...cards);
  }

  private refreshGearInventoryUi(): void {
    if (!this.gearInventoryList) return;
    const state = this.gearInventory.snapshot();
    const rows: HTMLElement[] = [];
    for (const item of this.gearInventory.getItems()) {
      const definition = GEAR_DEFINITIONS[item.gearId];
      const material = GEAR_MATERIALS[item.materialId];
      const stats = getGearStats(item.gearId, item.materialId, item.refinementTier);
      const row = document.createElement('article'); row.className = 'owned-equipment-row gear-inventory-row';
      const copy = document.createElement('div'); copy.className = 'owned-equipment-copy';
      const name = document.createElement('strong'); name.textContent = `${material.label} ${definition.name}`;
      const stat = document.createElement('span');
      stat.textContent = definition.slot === 'weapon'
        ? `${stats.damage} damage · ${stats.attackSpeed.toFixed(2)}/s · Tier ${item.refinementTier}/5`
        : `${stats.defense} defense · Tier ${item.refinementTier}/5`;
      copy.append(name, stat);
      const equipped = state.equippedWeaponInstanceId === item.instanceId || state.equippedArmorInstanceIds.includes(item.instanceId);
      const action = document.createElement('button'); action.type = 'button'; action.className = 'recipe-action compact-action';
      action.dataset['equipGear'] = item.instanceId; action.disabled = equipped; action.textContent = equipped ? 'Equipped' : 'Equip';
      row.append(copy, action); rows.push(row);
    }
    if (rows.length === 0) {
      const empty = document.createElement('p'); empty.className = 'inventory-description'; empty.textContent = 'No J7 gear yet. Trade ingots with a Blacksmith to receive a unique gear instance.'; rows.push(empty);
    }
    this.gearInventoryList.replaceChildren(...rows);
    this.updateGearEquipmentHud();
  }

  private refreshGearRefinerUi(): void {
    if (!this.gearRefinerList) return;
    const cards: HTMLElement[] = [];
    for (const item of this.gearInventory.getItems()) {
      const definition = GEAR_DEFINITIONS[item.gearId];
      const material = GEAR_MATERIALS[item.materialId];
      const plan = this.gearRefinementSystem.getPlan(item);
      const card = document.createElement('article'); card.className = 'recipe-card';
      const title = document.createElement('h3'); title.textContent = `${material.label} ${definition.name}`;
      const stats = getGearStats(item.gearId, item.materialId, item.refinementTier);
      const details = document.createElement('p'); details.className = 'recipe-description';
      details.textContent = `Current tier ${item.refinementTier}/5 · ${definition.slot === 'weapon' ? `${stats.damage} damage` : `${stats.defense} defense`}`;
      if (plan) {
        const streak = this.gearRefinementSystem.getFailureStreak(item.instanceId, plan.targetTier);
        const guaranteed = streak >= 3;
        const cost = document.createElement('p'); cost.className = 'recipe-cost';
        cost.textContent = `Next tier ${plan.targetTier} · ${(plan.chance * 100).toFixed(0)}% base chance${guaranteed ? ' · GUARANTEED' : ''} · ${plan.ingotCost} ${material.label} Ingot(s) + ${plan.coinCost} Coins · ${3 - streak} failure(s) until pity`;
        const button = document.createElement('button'); button.type = 'button'; button.className = 'recipe-action';
        button.dataset['refineGear'] = item.instanceId;
        button.disabled = this.inventory.count(plan.ingotId) < plan.ingotCost || this.inventory.getCoins() < plan.coinCost;
        button.textContent = guaranteed ? 'Guaranteed refine' : 'Attempt refinement';
        card.append(title, details, cost, button);
      } else {
        const max = document.createElement('p'); max.className = 'recipe-cost'; max.textContent = 'Maximum refinement tier reached.';
        card.append(title, details, max);
      }
      cards.push(card);
    }
    if (!cards.length) { const empty = document.createElement('p'); empty.className = 'inventory-description'; empty.textContent = 'Trade for gear before attempting refinement.'; cards.push(empty); }
    this.gearRefinerList.replaceChildren(...cards);
  }

  private updateGearEquipmentHud(): void {
    const item = this.gearInventory.getEquippedWeapon();
    const legacyWeapon = this.inventory.getEquippedWeapon();
    if (item) {
      const definition = GEAR_DEFINITIONS[item.gearId];
      const stats = getGearStats(item.gearId, item.materialId, item.refinementTier);
      this.equippedWeaponElement.textContent = `${GEAR_MATERIALS[item.materialId].label} ${definition.name}`;
      this.weaponDamageElement.textContent = `${stats.damage} power · ${stats.attackSpeed.toFixed(2)}/s · Tier ${item.refinementTier}/5`;
    } else {
      this.equippedWeaponElement.textContent = legacyWeapon?.name ?? 'No weapon equipped';
      this.weaponDamageElement.textContent = legacyWeapon ? `${legacyWeapon.attackDamage} power · ${legacyWeapon.attacksPerSecond.toFixed(2)}/s` : 'Equip a weapon';
    }
    const armor = this.gearInventory.getEquippedArmor();
    const armorDefense = armor.reduce((total, entry) => total + getGearStats(entry.gearId, entry.materialId, entry.refinementTier).defense, 0);
    const armorText = armor.length ? ` · Armor ${armorDefense.toFixed(1)} DEF` : '';
    const weaponName = item ? `${GEAR_MATERIALS[item.materialId].label} ${GEAR_DEFINITIONS[item.gearId].name}` : legacyWeapon?.name ?? 'None';
    this.inventoryEquippedEquipment.textContent = `Pickaxe: ${this.inventory.getEquippedPickaxe()?.name ?? 'None'} · Weapon: ${weaponName}${armorText}`;
  }

  private createDungeonEntrances(activeZoneId: ZoneId): void {
    for (const definition of DUNGEON_DEFINITIONS) {
      const zone = ZONE_DEFINITIONS[definition.zoneId];
      const x = zone.spawn.x + definition.entranceOffset.x;
      const z = zone.spawn.z + definition.entranceOffset.z;
      const y = getZoneTerrainHeight(definition.zoneId, definition.entranceOffset.x, definition.entranceOffset.z);
      const entrance = new DungeonEntrance(
        definition,
        this.assetRegistry.createInstance(definition.entranceAssetId),
        new THREE.Vector3(x, y, z),
      );
      entrance.visualRoot.visible = definition.zoneId === activeZoneId;
      this.dungeonEntrances.push(entrance);
      this.scene.add(entrance.visualRoot);
    }
  }

  /** Hides every overworld actor/prop as a single reversible visibility transaction. */
  private setOverworldVisible(visible: boolean): void {
    if (!visible) {
      if (this.hiddenOverworldVisibility) return;
      const roots: THREE.Object3D[] = [
        ...this.zonePortals.map((entry) => entry.visualRoot),
        ...this.npcs.map((entry) => entry.visualRoot),
        ...this.questWorldObjects.map((entry) => entry.visualRoot),
        ...this.miniGameStations.map((entry) => entry.visualRoot),
        ...this.dungeonEntrances.map((entry) => entry.visualRoot),
        ...this.oreNodes.map((entry) => entry.visualRoot),
        ...this.enemies.map((entry) => entry.visualRoot),
      ];
      if (this.forgeStation) roots.push(this.forgeStation.visualRoot);
      if (this.benHouseRoot) roots.push(this.benHouseRoot);
      if (this.benPickaxeRoot) roots.push(this.benPickaxeRoot);
      if (this.tutorialMarker) roots.push(this.tutorialMarker);
      this.hiddenOverworldVisibility = new Map(roots.map((root) => [root, root.visible]));
      for (const root of roots) root.visible = false;
      this.worldPopulation?.setWorldVisible(false);
      return;
    }

    if (this.hiddenOverworldVisibility) {
      for (const [root, wasVisible] of this.hiddenOverworldVisibility) root.visible = wasVisible;
      this.hiddenOverworldVisibility = null;
    }
    this.worldPopulation?.setWorldVisible(true);
  }

  private setZoneEntitiesActive(zoneId: ZoneId): void {
    for (const npc of this.npcs) npc.visualRoot.visible = npc.definition.zoneId === zoneId;
    for (const object of this.questWorldObjects) {
      object.visualRoot.visible = object.definition.zoneId === zoneId && object.isAvailable();
    }
    for (const station of this.miniGameStations) station.visualRoot.visible = station.definition.zoneId === zoneId;
    for (const entrance of this.dungeonEntrances) entrance.visualRoot.visible = entrance.definition.zoneId === zoneId;
    const inStarter = zoneId === 'starter-quarry';
    if (this.benHouseRoot) this.benHouseRoot.visible = inStarter;
    if (this.benPickaxeRoot) this.benPickaxeRoot.visible = inStarter && this.tutorial.isPickaxeVisibleAtHouse();
    if (this.tutorialMarker) this.tutorialMarker.visible = inStarter && this.tutorialMarker.visible;
    this.clearDungeonTargets();
    this.clearNpcTarget();
    this.clearQuestObjectTarget();
    this.clearMiniGameTarget();
  }

  private clearNpcTarget(): void {
    this.npcTarget?.setTargeted(false);
    this.npcTarget = null;
    this.npcTargetInRange = false;
  }

  private updateNpcTarget(): void {
    this.clearNpcTarget();
    if (!this.player || this.zonePortalTarget) return;
    const zoneId = this.zoneProgression.getCurrentZoneId();
    const hit = this.interactionProbe.firstHit('npc', zoneId);
    const npcId = hit?.object.userData['npcId'];
    if (typeof npcId !== 'string') return;
    const npc = this.npcs.find((candidate) => candidate.definition.id === npcId && candidate.visualRoot.visible);
    if (!npc) return;
    this.npcTarget = npc;
    npc.setTargeted(true);
    this.npcTargetInRange = this.player.visualRoot.position.distanceToSquared(npc.visualRoot.position) <= 5.6 ** 2;
  }

  private clearDungeonTargets(): void {
    this.dungeonEntranceTarget?.setTargeted(false);
    this.dungeonEntranceTarget = null;
    this.dungeonEntranceInRange = false;
    this.dungeonPointTarget = null;
    this.dungeonPointInRange = false;
    this.dungeonExitTarget = null;
    this.dungeonExitInRange = false;
  }

  private updateDungeonEntranceTarget(): void {
    this.dungeonEntranceTarget?.setTargeted(false);
    this.dungeonEntranceTarget = null;
    this.dungeonEntranceInRange = false;
    if (!this.player || this.activeDungeonId || this.zonePortalTarget || this.npcTarget) return;
    const hit = this.interactionProbe.firstHit('dungeon-entrance', this.zoneProgression.getCurrentZoneId());
    const dungeonId = hit?.object.userData['dungeonEntranceId'];
    if (typeof dungeonId !== 'string') return;
    const entrance = this.dungeonEntrances.find((candidate) => candidate.definition.id === dungeonId && candidate.visualRoot.visible);
    if (!entrance) return;
    this.dungeonEntranceTarget = entrance;
    entrance.setTargeted(true);
    this.dungeonEntranceInRange = this.player.visualRoot.position.distanceToSquared(entrance.visualRoot.position) <= 7.0 ** 2;
  }

  private updateDungeonPointTarget(): void {
    this.dungeonPointTarget = null;
    this.dungeonPointInRange = false;
    if (!this.player || !this.activeDungeonId || !this.activeDungeonRuntime) return;
    const hit = this.interactionProbe.firstHit('dungeon-point', this.zoneProgression.getCurrentZoneId());
    const pointId = hit?.object.userData['dungeonPointId'];
    if (typeof pointId !== 'string') return;
    const point = this.activeDungeonRuntime.definition.points.find((candidate) => candidate.id === pointId);
    const object = this.activeDungeonRuntime.points.get(pointId);
    if (!point || !object || this.dungeonProgress.isPointClaimed(pointId)) return;
    this.dungeonPointTarget = point;
    const worldPosition = object.getWorldPosition(new THREE.Vector3());
    this.dungeonPointInRange = this.player.visualRoot.position.distanceToSquared(worldPosition) <= 6.0 ** 2;
  }

  private updateDungeonExitTarget(): void {
    this.dungeonExitTarget = null;
    this.dungeonExitInRange = false;
    if (!this.player || !this.activeDungeonId || !this.activeDungeonRuntime) return;
    const hit = this.interactionProbe.firstHit('dungeon-exit', this.zoneProgression.getCurrentZoneId());
    const dungeonId = hit?.object.userData['dungeonExitDungeonId'];
    if (dungeonId !== this.activeDungeonId) return;
    this.dungeonExitTarget = this.activeDungeonRuntime.exit;
    const worldPosition = this.activeDungeonRuntime.exit.getWorldPosition(new THREE.Vector3());
    this.dungeonExitInRange = this.player.visualRoot.position.distanceToSquared(worldPosition) <= 6.0 ** 2;
  }

  private clearQuestObjectTarget(): void {
    this.questObjectTarget?.setTargeted(false);
    this.questObjectTarget = null;
    this.questObjectTargetInRange = false;
  }

  private updateQuestObjectTarget(): void {
    this.clearQuestObjectTarget();
    if (!this.player || this.zonePortalTarget || this.npcTarget || this.miniGameTarget) return;
    const zoneId = this.zoneProgression.getCurrentZoneId();
    const hit = this.interactionProbe.firstHit('quest-object', zoneId);
    const instanceId = hit?.object.userData['questObjectInstanceId'];
    if (typeof instanceId !== 'string') return;
    const object = this.questWorldObjects.find((candidate) => candidate.definition.id === instanceId && candidate.visualRoot.visible);
    if (!object) return;
    this.questObjectTarget = object;
    object.setTargeted(true);
    this.questObjectTargetInRange = this.player.visualRoot.position.distanceToSquared(object.visualRoot.position) <= 5.2 ** 2;
  }

  private clearMiniGameTarget(): void {
    this.miniGameTarget?.setTargeted(false);
    this.miniGameTarget = null;
    this.miniGameTargetInRange = false;
  }

  private updateMiniGameTarget(): void {
    this.clearMiniGameTarget();
    if (!this.player || this.zonePortalTarget || this.npcTarget) return;
    const zoneId = this.zoneProgression.getCurrentZoneId();
    const hit = this.interactionProbe.firstHit('activity', zoneId);
    const stationId = hit?.object.userData['miniGameStationId'];
    if (typeof stationId !== 'string') return;
    const station = this.miniGameStations.find((candidate) => candidate.definition.id === stationId && candidate.visualRoot.visible);
    if (!station) return;
    this.miniGameTarget = station;
    station.setTargeted(true);
    this.miniGameTargetInRange = this.player.visualRoot.position.distanceToSquared(station.visualRoot.position) <= 5.8 ** 2;
  }

  private handleMiniGameInteraction(): void {
    const station = this.miniGameTarget;
    if (!station) return;
    if (!this.miniGameTargetInRange) {
      this.showToast(`Move closer to ${station.definition.label.toLowerCase()}.`);
      return;
    }
    this.openMiniGame(station.definition.gameId);
  }

  private openMiniGame(gameId: MiniGameId): void {
    this.activeNpc = null;
    this.closeAllPanels();
    this.miniGamePanelOpen = true;
    this.miniGamePanel.open(gameId, { bestTier: this.miniGameSystem.getBestTier(gameId), completionCount: this.miniGameSystem.getCompletionCount(gameId) });
    this.syncOverlayInputState();
  }

  private handleMiniGameComplete(result: MiniGameRunResult): void {
    const payout = this.miniGameSystem.previewPayout(result.gameId, result.tier);
    this.deferInventoryPersist = true;
    const transaction = this.inventory.transactResourcesAndCoins({}, payout.resources, payout.coins);
    this.deferInventoryPersist = false;
    if (!transaction.ok) {
      this.showToast(`Reward not claimed: ${transaction.reason}. Make room and replay to claim the medal.`);
      return;
    }
    if (payout.xp > 0 && this.progression.getLevel() < 99) this.progression.awardXp(payout.xp);
    this.miniGameSystem.recordCompletion(result.gameId, result.tier);
    this.miniGamePanel.updateRecord({ bestTier: this.miniGameSystem.getBestTier(result.gameId), completionCount: this.miniGameSystem.getCompletionCount(result.gameId) });
    for (const [resourceId, amount] of Object.entries(payout.resources)) {
      if (amount && amount > 0) this.questSystem.record({ type: 'collect', resourceId: resourceId as ResourceId, amount });
    }
    if (result.chessWon) this.questSystem.record({ type: 'minigame', gameId: 'summit-chess' });
    const rewardParts = [`+${payout.xp} XP`, `+${payout.coins} Coins`];
    for (const [resourceId, amount] of Object.entries(payout.resources)) {
      if (amount && amount > 0) rewardParts.push(`+${amount} ${RESOURCE_DEFINITIONS[resourceId as ResourceId].shortName}`);
    }
    if (payout.newUnlocks.includes('chessmaster-crest')) rewardParts.push('Chessmaster Crest unlocked');
    this.showToast(`${result.tier.toUpperCase()} · ${payout.improvedTier ? rewardParts.join(' · ') : 'Personal best already reached; no repeat reward.'}`);
    if (result.gameId === 'summit-chess' && result.chessWon) this.showToast('Frank has been defeated. Return to him to complete the chess request.');
    this.refreshQuestJournal();
    this.updateCombatHud();
    this.persist();
  }

  private handleNpcInteraction(): void {
    const npc = this.npcTarget;
    if (!npc) return;
    if (!this.npcTargetInRange) {
      this.showToast(`Move closer to ${npc.definition.name}.`);
      return;
    }
    if (!this.tutorial.isComplete()) {
      const step = this.tutorial.getStep();
      if (npc.definition.id === 'ben') {
        this.handleBenTutorialInteraction();
        return;
      }
      const allowedBlacksmith = (step === 'smelt-ingots' || step === 'trade-gear') && npc.definition.role === 'blacksmith';
      const allowedRefiner = step === 'refine-gear' && npc.definition.role === 'weapon-refiner';
      if (!allowedBlacksmith && !allowedRefiner) {
        this.showToast('Ben’s mandatory tutorial comes first. Follow the yellow cross and complete the current step.');
        return;
      }
    }
    if (npc.definition.id === 'ben' && !this.tutorial.isComplete()) {
      this.handleBenTutorialInteraction();
      return;
    }
    npc.playGreetingReaction();
    this.questSystem.record({ type: 'talk', npcId: npc.definition.id });
    this.refreshQuestJournal();
    this.persist();
    this.openNpcPanel(npc);
  }

  private handleQuestObjectInteraction(): void {
    const object = this.questObjectTarget;
    if (!object || !this.player) return;
    if (!this.questObjectTargetInRange) {
      this.showToast(`Move closer to ${object.definition.title}.`);
      return;
    }

    const definition = object.definition;
    let event: QuestEvent;
    if (definition.collectResource) {
      event = { type: 'collect', resourceId: definition.collectResource, amount: 1 };
    } else if (definition.objectId === 'peakforge-alloy') {
      event = { type: 'craft', resourceId: 'frostglass-alloy', amount: 1 };
    } else {
      event = { type: 'interact', objectId: definition.objectId, amount: 1 };
    }

    if (!this.questSystem.canProgress(event)) {
      this.showToast('Accept the related request before using this quest item.');
      return;
    }

    if (definition.objectId === 'peakforge-alloy') {
      this.deferInventoryPersist = true;
      const result = this.inventory.transactResourcesAndCoins(
        { 'gold-ingot': 2, crystal: 3 },
        { 'frostglass-alloy': 1 },
        0,
      );
      this.deferInventoryPersist = false;
      if (!result.ok) { this.showToast(result.reason); return; }
      this.questSystem.record(event);
      this.showToast('Crafted 1 Frostglass Alloy at the Peakforge.');
    } else if (definition.collectResource) {
      this.deferInventoryPersist = true;
      const result = this.inventory.add(definition.collectResource, 1);
      this.deferInventoryPersist = false;
      if (!result.ok) { this.showToast(result.reason); return; }
      this.questSystem.record(event);
      object.consume();
      if (definition.oneTime) this.questSystem.markWorldObjectUsed(definition.id);
      this.showToast(`Collected 1 ${RESOURCE_DEFINITIONS[definition.collectResource].name}.`);
    } else {
      if (!object.consume()) { this.showToast('This location has already been cleared.'); return; }
      this.questSystem.record(event);
      if (definition.oneTime) this.questSystem.markWorldObjectUsed(definition.id);
      if (definition.objectId === 'tyler-missing-cat') {
        this.showToast('Cinder the cat found you. Tyler will be relieved.');
      } else {
        this.showToast(`${definition.title} activated.`);
      }
    }
    this.refreshQuestJournal();
    this.persist();
    this.clearQuestObjectTarget();
    this.renderDirty = true;
  }

  private openNpcPanel(npc: Npc): void {
    this.activeNpc = npc;
    this.setNpcPanelOpen(true);
    this.renderNpcPanel();
  }

  private renderNpcPanel(): void {
    const npc = this.activeNpc;
    if (!npc) return;
    const quest = QUEST_BY_ID[npc.definition.questId];
    const zoneId = this.zoneProgression.getCurrentZoneId();
    const status = this.questSystem.getStatus(quest.id, zoneId, this.progression.getLevel());
    this.npcPanelTitle.textContent = npc.definition.name;
    this.npcPanelKicker.textContent = `${ZONE_DEFINITIONS[zoneId].name.toUpperCase()} / ${npc.definition.title.toUpperCase()}`;
    this.npcGreeting.textContent = npc.definition.greeting;
    this.npcQuestTitle.textContent = quest.name;
    this.npcQuestDescription.textContent = quest.description;

    const objectiveRows = this.questSystem.getObjectiveViews(quest.id).map((objective) => {
      const row = document.createElement('div');
      row.className = `quest-objective${objective.complete ? ' is-complete' : ''}`;
      const marker = document.createElement('span');
      marker.className = 'quest-objective-marker';
      marker.textContent = objective.complete ? '✓' : '○';
      const label = document.createElement('span');
      label.textContent = objective.text;
      const count = document.createElement('strong');
      count.textContent = `${objective.progress}/${objective.target}`;
      row.append(marker, label, count);
      return row;
    });
    this.npcObjectiveList.replaceChildren(...objectiveRows);
    const missingTurnIn = Object.entries(quest.turnInCosts ?? {})
      .filter(([resourceId, amount]) => this.inventory.count(resourceId as ResourceId) < (amount ?? 0))
      .map(([resourceId, amount]) => `${Math.max(0, (amount ?? 0) - this.inventory.count(resourceId as ResourceId))} ${RESOURCE_DEFINITIONS[resourceId as ResourceId].shortName}`);
    const rewardText = `Reward: ${quest.rewards.xp} XP · ${quest.rewards.coins} Coins${quest.rewards.resources ? ` · ${this.formatCosts(quest.rewards.resources)}` : ''}`;
    const reasons: Record<string, string> = {
      locked: this.questLockReason(quest),
      available: `${rewardText}${quest.turnInCosts ? ` · Delivery: ${this.formatCosts(quest.turnInCosts)}` : ''}`,
      active: 'Request accepted. Complete the objectives below and return here.',
      'ready-to-turn-in': missingTurnIn.length > 0
        ? `Objectives complete. Delivery still required: ${missingTurnIn.join(' + ')}.`
        : `All objectives complete. ${quest.turnInCosts ? `Delivered: ${this.formatCosts(quest.turnInCosts)}. ` : ''}Return here to claim your reward.`,
      completed: 'Completed — rewards have already been claimed.',
    };
    this.npcQuestStatus.textContent = reasons[status];
    this.npcAcceptButton.hidden = status !== 'available';
    this.npcAcceptButton.dataset['questId'] = quest.id;
    this.npcTurnInButton.hidden = status !== 'ready-to-turn-in';
    this.npcTurnInButton.disabled = status === 'ready-to-turn-in' && missingTurnIn.length > 0;
    this.npcTurnInButton.dataset['questId'] = quest.id;
    this.npcServiceButton.hidden = npc.definition.service === 'none';
    this.npcServiceButton.textContent = npc.definition.service === 'shop' ? 'Open Pickaxe Shop'
      : npc.definition.service === 'forge' ? 'Use Blacksmith Forge'
      : npc.definition.service === 'minigame' ? (npc.definition.miniGameId === 'summit-chess' ? 'Play Chess with Frank' : 'Fish at Crystal Lake')
      : 'Refine Weapon';
    this.npcShopContent.hidden = true;
    this.npcShopContent.replaceChildren();
  }

  private questLockReason(quest: QuestDefinition): string {
    if (this.progression.getLevel() < quest.minimumLevel) return `Reach level ${quest.minimumLevel} to accept this request.`;
    const unmet = quest.prerequisites.find((id) => !this.questSystem.isCompleted(id));
    if (unmet) return `Complete “${QUEST_BY_ID[unmet].name}” first.`;
    if (quest.zoneId !== this.zoneProgression.getCurrentZoneId()) return `Travel to ${ZONE_DEFINITIONS[quest.zoneId].name} to accept this request.`;
    return 'This request is not currently available.';
  }

  private handleNpcPanelClick(event: MouseEvent): void {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const button = target.closest('button');
    if (!(button instanceof HTMLButtonElement) || button.disabled) return;
    const npc = this.activeNpc;
    if (!npc) return;
    const questId = button.dataset['questId'];
    if (button === this.npcAcceptButton && questId) {
      const result = this.questSystem.accept(questId, this.zoneProgression.getCurrentZoneId(), this.progression.getLevel());
      this.npcQuestStatus.textContent = result.reason;
      if (result.ok) this.showToast(result.reason);
      this.refreshQuestJournal();
      this.renderNpcPanel();
      this.persist();
      return;
    }
    if (button === this.npcTurnInButton && questId) {
      const quest = QUEST_BY_ID[questId];
      this.deferInventoryPersist = true;
      const result = this.questSystem.complete(questId, () => {
        const transaction = this.inventory.transactResourcesAndCoins(
          quest.turnInCosts ?? {},
          quest.rewards.resources ?? {},
          quest.rewards.coins,
        );
        if (!transaction.ok) {
          this.deferInventoryPersist = false;
          this.npcQuestStatus.textContent = transaction.reason;
          return false;
        }
        if (quest.rewards.xp > 0 && this.progression.getLevel() < 99) this.progression.awardXp(quest.rewards.xp);
        return true;
      });
      this.deferInventoryPersist = false;
      if (result.ok) {
        this.showToast(`${quest.name} completed · +${quest.rewards.xp} XP · +${quest.rewards.coins} Coins`);
        this.refreshZonePortalAccess();
        this.updateCombatHud();
      } else {
        this.npcQuestStatus.textContent = result.reason;
      }
      this.refreshQuestJournal();
      this.renderNpcPanel();
      this.persist();
      return;
    }
    if (button === this.npcServiceButton) {
      this.openNpcService(npc);
      return;
    }
    const equipmentId = button.dataset['shopEquipment'] as EquipmentId | undefined;
    if (equipmentId) {
      const result = this.shopSystem.purchase(
        equipmentId,
        this.zoneProgression.getCurrentZoneId(),
        this.progression.getLevel(),
        (id) => this.questSystem.isCompleted(id),
      );
      this.showToast(result.ok ? `Purchased ${result.item.stockLabel} · ${result.coinsRemaining} Coins remaining.` : result.reason);
      this.renderNpcShop(npc);
      this.persist();
    }
  }

  private openNpcService(npc: Npc): void {
    if (npc.definition.service === 'minigame' && npc.definition.miniGameId) {
      const gameId = npc.definition.miniGameId;
      this.setNpcPanelOpen(false);
      this.openMiniGame(gameId);
      return;
    }
    if (npc.definition.service === 'forge') {
      const zone = ZONE_DEFINITIONS[npc.definition.zoneId];
      const forgeNames: Record<ZoneId, string> = {
        'starter-quarry': 'The Quarry Forge',
        'molten-caves': 'The Basalt Forge',
        'crystal-peaks': 'The Peakforge',
      };
      this.forgePanelKicker.textContent = `${zone.name.toUpperCase()} / SMELTING & CRAFTING`;
      this.forgePanelTitle.textContent = forgeNames[npc.definition.zoneId];
      this.setNpcPanelOpen(false);
      this.setForgeOpen(true);
      return;
    }
    if (npc.definition.service === 'shop') {
      this.renderNpcShop(npc);
      this.npcShopContent.hidden = false;
      this.renderDirty = true;
      return;
    }
    if (npc.definition.service === 'refiner') {
      this.setNpcPanelOpen(false);
      this.setRefinerPanelOpen(true);
      this.renderRefinerPanel(npc);
    }
  }

  private renderNpcShop(npc: Npc): void {
    const zoneId = this.zoneProgression.getCurrentZoneId();
    const stock = this.shopSystem.getStock(zoneId, this.progression.getLevel(), (id) => this.questSystem.isCompleted(id))
      .filter((item) => EQUIPMENT_DEFINITIONS[item.equipmentId].slot === 'pickaxe');
    const cards: HTMLElement[] = [];
    for (const item of stock) {
      const definition = EQUIPMENT_DEFINITIONS[item.equipmentId];
      if (!('miningPower' in definition)) continue;
      const card = document.createElement('article');
      card.className = 'recipe-card';
      const heading = document.createElement('h3'); heading.textContent = item.stockLabel;
      const description = document.createElement('p'); description.className = 'recipe-description';
      description.textContent = `${definition.description} · ${definition.miningPower.toFixed(1)}× mining power`;
      const price = document.createElement('p'); price.className = 'recipe-cost'; price.textContent = `${item.priceCoins.toLocaleString()} Coins`;
      const buy = document.createElement('button'); buy.type = 'button'; buy.className = 'recipe-action';
      buy.dataset['shopEquipment'] = item.equipmentId;
      buy.disabled = this.inventory.hasEquipment(item.equipmentId) || this.inventory.getCoins() < item.priceCoins;
      buy.textContent = this.inventory.hasEquipment(item.equipmentId) ? 'Owned' : this.inventory.getCoins() < item.priceCoins ? 'Not enough Coins' : 'Purchase';
      card.append(heading, description, price, buy); cards.push(card);
    }
    if (cards.length === 0) {
      const message = document.createElement('p');
      message.className = 'inventory-description';
      message.textContent = 'No pickaxe stock is currently unlocked. Complete this shopkeeper’s supply quest to reveal the next tier.';
      cards.push(message);
    }
    this.npcShopContent.replaceChildren(...cards);
    this.npcShopContent.hidden = false;
  }

  private renderRefinerPanel(npc: Npc): void {
    this.refinerTitle.textContent = `${npc.definition.name} · Weapon Refinement`;
    this.refinerKicker.textContent = `${ZONE_DEFINITIONS[npc.definition.zoneId].name.toUpperCase()} / REFINERY`;
    this.refinerSummary.textContent = 'Upgrade your currently equipped weapon. Each rank permanently increases its attack damage.';
    const plan = this.refinementSystem.getNextPlan();
    const rankLimit = npc.definition.zoneId === 'starter-quarry' ? 1 : npc.definition.zoneId === 'molten-caves' ? 2 : 3;
    const currentRank = this.refinementSystem.getCurrentRank();
    if (!plan) {
      this.refinerPlanElement.textContent = `Maximum refinement reached · Rank ${currentRank}/3`;
      this.refineWeaponButton.disabled = true;
      this.refreshGearRefinerUi();
      return;
    }
    const weapon = this.inventory.getEquippedWeapon();
    this.refinerPlanElement.textContent = `${plan.name} · Rank ${plan.rank}\nMaterials: ${this.formatCosts(plan.costs)}\nPrice: ${plan.coinCost} Coins\nDamage increase: +${plan.damageBonus}`;
    const unlocked = plan.rank <= rankLimit;
    this.refineWeaponButton.disabled = !weapon || !unlocked;
    this.refineWeaponButton.textContent = !weapon ? 'Equip a weapon first' : !unlocked ? `Requires ${ZONE_DEFINITIONS[npc.definition.zoneId].name}` : 'Refine Equipped Weapon';
    this.refinerFeedback.textContent = weapon ? `Equipped: ${weapon.name} · Current refinement Rank ${currentRank}/3` : 'Equip a weapon before using the refinery.';
    this.refreshGearRefinerUi();
  }

  private handleRefinerPanelClick(event: MouseEvent): void {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const button = target.closest('button');
    if (!(button instanceof HTMLButtonElement) || button.disabled) return;
    const gearInstanceId = button.dataset['refineGear'];
    if (gearInstanceId) {
      this.deferInventoryPersist = true;
      const result = this.gearRefinementSystem.refine(gearInstanceId);
      this.deferInventoryPersist = false;
      if (result.ok) {
        const name = GEAR_DEFINITIONS[result.item.gearId].name;
        this.refinerFeedback.textContent = `${name} advanced to refinement tier ${result.item.refinementTier}.`;
        this.showToast(`${name} · refinement tier ${result.item.refinementTier}${result.pityGuaranteed ? ' · pity guarantee used' : ''}.`);
        if (this.tutorial.getStep() === 'refine-gear') {
          this.tutorial.markRefined(); this.renderTutorialPanel(); this.updateTutorialMarkerPosition();
        }
      } else {
        this.refinerFeedback.textContent = result.reason;
        if (result.failed) this.showToast(`${result.reason} All materials and Coins were consumed.`);
        else this.showToast(result.reason);
      }
      this.refreshGearInventoryUi(); this.refreshGearRefinerUi(); this.persist();
      return;
    }
    if (button !== this.refineWeaponButton) return;
    this.deferInventoryPersist = true;
    const result = this.refinementSystem.refine();
    this.deferInventoryPersist = false;
    if (result.ok) {
      this.questSystem.record({ type: 'refine', rank: result.rank });
      this.refinerFeedback.textContent = `${result.plan.name} applied. Weapon damage increased by ${result.plan.damageBonus}.`;
      this.showToast(`Weapon refined to Rank ${result.rank} · +${result.plan.damageBonus} damage.`);
      this.refreshQuestJournal();
      this.syncWeaponVisual();
      if (this.npcPanelOpen) this.renderNpcPanel();
      if (this.refinerPanelOpen && this.activeNpc) this.renderRefinerPanel(this.activeNpc);
      if (!this.deferInventoryPersist) this.persist();
    } else {
      this.refinerFeedback.textContent = result.reason;
    }
    if (this.activeNpc) this.renderRefinerPanel(this.activeNpc);
  }

  private setNpcPanelOpen(open: boolean): void {
    this.npcPanelOpen = open;
    if (open) {
      this.inventoryOpen = false; this.forgeOpen = false; this.questJournalOpen = false; this.refinerPanelOpen = false;
      this.inventoryPanel.hidden = true; this.forgePanel.hidden = true; this.questJournalPanel.hidden = true; this.refinerPanel.hidden = true;
      this.miningSystem?.clearTarget(); this.combatSystem?.clearTarget(); this.clearZonePortalTarget();
      this.clearNpcTarget(); this.clearQuestObjectTarget();
    }
    this.npcPanel.hidden = !open;
    this.syncOverlayInputState();
  }

  private setQuestJournalOpen(open: boolean): void {
    this.questJournalOpen = open;
    if (open) {
      this.inventoryOpen = false; this.forgeOpen = false; this.npcPanelOpen = false; this.refinerPanelOpen = false;
      this.inventoryPanel.hidden = true; this.forgePanel.hidden = true; this.npcPanel.hidden = true; this.refinerPanel.hidden = true;
      this.miningSystem?.clearTarget(); this.combatSystem?.clearTarget(); this.clearZonePortalTarget();
      this.refreshQuestJournal();
    }
    this.questJournalPanel.hidden = !open;
    this.syncOverlayInputState();
  }

  private setExplorationPanelOpen(open: boolean): void {
    this.explorationPanelOpen = open;
    if (open) {
      this.inventoryOpen = false; this.forgeOpen = false; this.npcPanelOpen = false;
      this.questJournalOpen = false; this.refinerPanelOpen = false; this.miniGamePanelOpen = false;
      this.inventoryPanel.hidden = true; this.forgePanel.hidden = true; this.npcPanel.hidden = true;
      this.questJournalPanel.hidden = true; this.explorationPanel.hidden = true; this.refinerPanel.hidden = true;
      this.miniGamePanel.dismiss();
      this.miningSystem?.clearTarget(); this.combatSystem?.clearTarget(); this.clearZonePortalTarget();
      this.clearDungeonTargets(); this.clearNpcTarget(); this.clearQuestObjectTarget(); this.clearMiniGameTarget();
      this.refreshExplorationLog();
    }
    this.explorationPanel.hidden = !open;
    this.syncOverlayInputState();
  }

  private setRefinerPanelOpen(open: boolean): void {
    this.refinerPanelOpen = open;
    if (open) {
      this.inventoryOpen = false; this.forgeOpen = false; this.npcPanelOpen = false; this.questJournalOpen = false;
      this.inventoryPanel.hidden = true; this.forgePanel.hidden = true; this.npcPanel.hidden = true; this.questJournalPanel.hidden = true;
      this.miningSystem?.clearTarget(); this.combatSystem?.clearTarget(); this.clearZonePortalTarget();
    }
    this.refinerPanel.hidden = !open;
    this.syncOverlayInputState();
  }

  private isAnyOverlayOpen(): boolean {
    return this.inventoryOpen || this.forgeOpen || this.npcPanelOpen || this.questJournalOpen || this.explorationPanelOpen || this.refinerPanelOpen || this.miniGamePanelOpen;
  }

  private closeAllPanels(): void {
    this.inventoryOpen = false; this.forgeOpen = false; this.npcPanelOpen = false; this.questJournalOpen = false; this.explorationPanelOpen = false; this.refinerPanelOpen = false; this.miniGamePanelOpen = false;
    this.inventoryPanel.hidden = true; this.forgePanel.hidden = true; this.npcPanel.hidden = true;
    this.questJournalPanel.hidden = true; this.explorationPanel.hidden = true; this.refinerPanel.hidden = true;
    this.miniGamePanel.dismiss();
    this.syncOverlayInputState();
  }

  private syncOverlayInputState(): void {
    this.input.setPointerLockEnabled(!this.gameplayPaused && !this.isAnyOverlayOpen());
    this.input.setMenuOpen(this.gameplayPaused || this.isAnyOverlayOpen());
    this.renderDirty = true;
  }

  private refreshQuestJournal(): void {
    if (!this.questJournalList) return;
    const zoneId = this.zoneProgression.getCurrentZoneId();
    const level = this.progression.getLevel();
    for (const npc of this.npcs) {
      const questStatus = this.questSystem.getStatus(npc.definition.questId, zoneId, level);
      npc.setQuestMarker(questStatus);
    }
    const rows = QUEST_DEFINITIONS.map((quest) => {
      const status = this.questSystem.getStatus(quest.id, zoneId, level);
      const card = document.createElement('article');
      card.className = `quest-journal-card status-${status}`;
      const title = document.createElement('h3'); title.textContent = `${quest.category === 'main' ? 'MAIN · ' : ''}${quest.name}`;
      const giver = document.createElement('p'); giver.className = 'quest-journal-meta';
      giver.textContent = `${ZONE_DEFINITIONS[quest.zoneId].name} · ${NPC_DEFINITIONS.find((npc) => npc.id === quest.npcId)?.name ?? quest.npcId} · ${status.replaceAll('-', ' ')}`;
      const description = document.createElement('p'); description.className = 'recipe-description'; description.textContent = quest.description;
      const objectiveList = document.createElement('ul'); objectiveList.className = 'quest-journal-objectives';
      if (status === 'active' || status === 'ready-to-turn-in' || status === 'completed') {
        for (const objective of this.questSystem.getObjectiveViews(quest.id)) {
          const item = document.createElement('li'); item.textContent = `${objective.complete ? '✓' : '○'} ${objective.text} (${objective.progress}/${objective.target})`; objectiveList.append(item);
        }
      } else if (status === 'locked') {
        const item = document.createElement('li'); item.textContent = this.questLockReason(quest); objectiveList.append(item);
      } else {
        const item = document.createElement('li'); item.textContent = 'Speak to the quest giver to accept this request.'; objectiveList.append(item);
      }
      card.append(title, giver, description, objectiveList);
      return card;
    });
    this.questJournalList.replaceChildren(...rows);
  }

  private refreshExplorationLog(): void {
    const discovered = this.dungeonProgress.getDiscoveryCount();
    const completed = this.dungeonProgress.getCompletedCount();
    this.explorationSummary.textContent = `${discovered}/${DUNGEON_DEFINITIONS.length} interiors discovered · ${completed}/${DUNGEON_DEFINITIONS.length} landmarks fully mapped. Each interior contains three one-time points of interest.`;
    const cards = DUNGEON_DEFINITIONS.map((definition) => {
      const progress = this.dungeonProgress.getPointCount(definition.id);
      const isDiscovered = this.dungeonProgress.isDiscovered(definition.id);
      const isComplete = this.dungeonProgress.isCompleted(definition.id);
      const card = document.createElement('article');
      card.className = `exploration-card${isComplete ? ' complete' : ''}`;
      const heading = document.createElement('h3');
      heading.textContent = definition.name;
      const meta = document.createElement('p');
      meta.className = 'exploration-meta';
      meta.textContent = `${ZONE_DEFINITIONS[definition.zoneId].name} · ${definition.kind} · ${isComplete ? 'Complete' : isDiscovered ? 'Discovered' : 'Undiscovered'}`;
      const description = document.createElement('p');
      description.textContent = definition.description;
      const count = document.createElement('p');
      count.textContent = isDiscovered ? `${progress.claimed}/${progress.total} landmarks investigated` : 'Find the entrance to add this interior to your atlas.';
      const bar = document.createElement('div');
      bar.className = 'exploration-progress';
      bar.setAttribute('role', 'progressbar');
      bar.setAttribute('aria-valuemin', '0');
      bar.setAttribute('aria-valuemax', String(progress.total));
      bar.setAttribute('aria-valuenow', String(progress.claimed));
      const fill = document.createElement('span');
      fill.style.width = `${(progress.claimed / progress.total) * 100}%`;
      bar.append(fill);
      card.append(heading, meta, description, count, bar);
      return card;
    });
    this.explorationList.replaceChildren(...cards);
  }

  private grantDungeonReward(reward: DungeonDefinition['discoveryReward']): string | null {
    const wasDeferred = this.deferInventoryPersist;
    this.deferInventoryPersist = true;
    const transaction = this.inventory.transactResourcesAndCoins({}, reward.resources, reward.coins);
    this.deferInventoryPersist = wasDeferred;
    if (!transaction.ok) return transaction.reason;
    if (reward.xp > 0) this.progression.awardXp(reward.xp);
    this.refreshZonePortalAccess();
    this.refreshQuestJournal();
    this.updateCombatHud();
    return null;
  }

  private registerDungeonInteractions(runtime: DungeonInteriorRuntime): void {
    this.interactionProbe.register(runtime.root, { kind: 'static' });
    runtime.root.traverse((object) => { if (object instanceof THREE.Mesh) this.dungeonCameraOccluders.push(object); });
    this.cameraOccluders.push(...this.dungeonCameraOccluders);
    for (const [pointId, object] of runtime.points) {
      object.traverse((child) => { child.userData['dungeonPointId'] = pointId; });
      this.interactionProbe.register(object, { kind: 'dungeon-point', dungeonId: runtime.definition.id, pointId });
    }
    runtime.exit.traverse((child) => { child.userData['dungeonExitDungeonId'] = runtime.definition.id; });
    this.interactionProbe.register(runtime.exit, { kind: 'dungeon-exit', dungeonId: runtime.definition.id });
  }

  private unregisterDungeonInteractions(runtime: DungeonInteriorRuntime): void {
    this.interactionProbe.unregister(runtime.root);
    for (const object of runtime.points.values()) this.interactionProbe.unregister(object);
    this.interactionProbe.unregister(runtime.exit);
    for (const object of this.dungeonCameraOccluders) {
      const index = this.cameraOccluders.indexOf(object);
      if (index >= 0) this.cameraOccluders.splice(index, 1);
    }
    this.dungeonCameraOccluders.length = 0;
    this.clearDungeonTargets();
  }

  private applyDungeonAppearance(definition: DungeonDefinition): void {
    const atmosphere = definition.atmosphere;
    this.scene.background = new THREE.Color(atmosphere.background);
    this.scene.fog = new THREE.Fog(atmosphere.fog, atmosphere.fogNear, atmosphere.fogFar);
    this.hemisphereLight.color.setHex(atmosphere.hemisphereSky);
    this.hemisphereLight.groundColor.setHex(atmosphere.hemisphereGround);
    this.hemisphereLight.intensity = atmosphere.hemisphereIntensity;
    this.keyLight.color.setHex(atmosphere.key);
    this.keyLight.intensity = atmosphere.keyIntensity;
    this.keyLight.position.set(definition.instanceOrigin.x - 10, 14, definition.instanceOrigin.z + 12);
    this.keyLight.target.position.set(definition.instanceOrigin.x, 0, definition.instanceOrigin.z);
    this.fillLight.color.setHex(atmosphere.fill);
    this.fillLight.intensity = atmosphere.fillIntensity;
    this.fillLight.position.set(definition.instanceOrigin.x - 5.5, 3.2, definition.instanceOrigin.z - 5.5);
    this.removeDungeonLights();
    for (const descriptor of atmosphere.lights) {
      const light = new THREE.PointLight(descriptor.color, descriptor.intensity, descriptor.distance, 2);
      light.position.set(
        definition.instanceOrigin.x + descriptor.x,
        descriptor.y,
        definition.instanceOrigin.z + descriptor.z,
      );
      this.scene.add(light);
      this.dungeonLights.push(light);
    }
    this.activeZoneElement.textContent = `${ZONE_DEFINITIONS[definition.zoneId].name} / ${definition.name}`;
    this.activeZoneElement.title = definition.lore;
  }

  private removeDungeonLights(): void {
    for (const light of this.dungeonLights) {
      this.scene.remove(light);
    }
    this.dungeonLights.length = 0;
  }

  private enterDungeon(entrance: DungeonEntrance): void {
    if (!this.player || !this.terrainStreamer || !this.dungeonInteriorManager || this.zoneTransitionInProgress || this.activeDungeonId) return;
    const definition = entrance.definition;
    const zoneId = this.zoneProgression.getCurrentZoneId();
    if (definition.zoneId !== zoneId) return;
    this.zoneTransitionInProgress = true;
    this.dungeonReturnPosition = this.player.visualRoot.position.clone();
    this.clearDungeonTargets();
    this.clearZonePortalTarget(); this.clearNpcTarget(); this.clearQuestObjectTarget(); this.clearMiniGameTarget();
    this.miningSystem?.clearTarget(); this.combatSystem?.clearTarget();
    this.showToast(`Opening ${definition.name}…`);
    void (async () => {
      try {
        this.setOverworldVisible(false);
        this.terrainStreamer?.suspend();
        const runtime = await this.dungeonInteriorManager!.activate(definition);
        this.activeDungeonRuntime = runtime;
        this.activeDungeonId = definition.id;
        this.registerDungeonInteractions(runtime);
        this.player?.respawnAt({
          x: definition.instanceOrigin.x + definition.playerSpawn.x,
          y: definition.playerSpawn.y,
          z: definition.instanceOrigin.z + definition.playerSpawn.z,
        });
        this.applyDungeonAppearance(definition);
        if (!this.dungeonProgress.isDiscovered(definition.id)) {
          const rewardError = this.grantDungeonReward(definition.discoveryReward);
          if (!rewardError && this.dungeonProgress.discover(definition.id)) {
            this.persist();
            this.showToast(`Discovered ${definition.name} · +${definition.discoveryReward.xp} XP · +${definition.discoveryReward.coins} Coins.`);
          } else if (rewardError) {
            this.showToast(`Entered ${definition.name}; discovery reward held: ${rewardError}`);
          }
        } else {
          this.showToast(`Entered ${definition.name}. Find all three landmarks and return through the entrance arch.`);
        }
        this.refreshExplorationLog();
        this.updateCamera(0.3);
      } catch (error) {
        const runtime = this.activeDungeonRuntime;
        if (runtime) this.unregisterDungeonInteractions(runtime);
        this.dungeonInteriorManager?.deactivate();
        this.activeDungeonRuntime = null;
        this.activeDungeonId = null;
        this.removeDungeonLights();
        this.setOverworldVisible(true);
        const returnPosition = this.dungeonReturnPosition;
        if (returnPosition) {
          try { await this.terrainStreamer?.loadAround(zoneId, returnPosition); } catch { /* retain the original loading error below */ }
          this.player?.respawnAt(returnPosition);
        }
        this.applyZoneAppearance(ZONE_DEFINITIONS[zoneId]);
        this.updateZoneReadout();
        this.showToast(error instanceof Error ? `Could not enter interior: ${error.message}` : 'Could not enter this interior.');
      } finally {
        this.zoneTransitionInProgress = false;
        this.dungeonReturnPosition = this.activeDungeonId ? this.dungeonReturnPosition : null;
      }
    })();
  }

  private claimDungeonPoint(): void {
    if (!this.activeDungeonId || !this.dungeonPointTarget || !this.dungeonPointInRange || !this.activeDungeonRuntime) {
      this.showToast('Move closer to the landmark to investigate it.');
      return;
    }
    const definition = this.activeDungeonRuntime.definition;
    const point = this.dungeonPointTarget;
    if (this.dungeonProgress.isPointClaimed(point.id)) return;
    const completes = this.dungeonProgress.wouldCompleteAfterClaim(definition.id, point.id);
    const outputs: Partial<Record<ResourceId, number>> = { ...point.reward.resources };
    const totalXp = point.reward.xp + (completes ? definition.completionReward.xp : 0);
    const totalCoins = point.reward.coins + (completes ? definition.completionReward.coins : 0);
    if (completes) {
      for (const [resourceId, quantity] of Object.entries(definition.completionReward.resources) as [ResourceId, number][]) {
        outputs[resourceId] = (outputs[resourceId] ?? 0) + quantity;
      }
    }
    const rewardError = this.grantDungeonReward({ xp: totalXp, coins: totalCoins, resources: outputs });
    if (rewardError) {
      this.showToast(`Landmark reward held: ${rewardError}`);
      return;
    }
    const claimed = this.dungeonProgress.claimPoint(definition.id, point.id);
    if (!claimed.ok) {
      this.showToast(claimed.reason);
      return;
    }
    this.persist();
    this.refreshExplorationLog();
    this.showToast(claimed.newlyCompleted
      ? `Landmark complete: ${definition.name} · ${point.label} · completion reward granted.`
      : `Recorded ${point.label} · +${totalXp} XP · +${totalCoins} Coins.`);
  }

  private exitDungeon(): void {
    if (!this.activeDungeonId || !this.activeDungeonRuntime || !this.dungeonReturnPosition || !this.player || !this.terrainStreamer || this.zoneTransitionInProgress) return;
    if (!this.dungeonExitInRange) {
      this.showToast('Move closer to the return arch.');
      return;
    }
    const definition = this.activeDungeonRuntime.definition;
    const runtime = this.activeDungeonRuntime;
    const zoneId = definition.zoneId;
    const returnPosition = this.dungeonReturnPosition.clone();
    this.zoneTransitionInProgress = true;
    this.showToast(`Returning to ${ZONE_DEFINITIONS[zoneId].name}…`);
    void (async () => {
      try {
        // Load the return area before removing the interior, so a failed stream never strands the player.
        await this.terrainStreamer?.loadAround(zoneId, returnPosition);
        this.unregisterDungeonInteractions(runtime);
        this.dungeonInteriorManager?.deactivate();
        this.activeDungeonRuntime = null;
        this.activeDungeonId = null;
        this.removeDungeonLights();
        this.player?.respawnAt(returnPosition);
        this.setOverworldVisible(true);
        this.worldPopulation?.setActiveZone(zoneId);
        this.worldPopulation?.setWorldVisible(true);
        this.setZoneEntitiesActive(zoneId);
        this.applyZoneAppearance(ZONE_DEFINITIONS[zoneId]);
        this.updateZoneReadout();
        this.refreshQuestJournal();
        this.refreshExplorationLog();
        this.persist();
        this.showToast(`Returned to ${ZONE_DEFINITIONS[zoneId].name}.`);
        this.updateCamera(0.3);
        this.dungeonReturnPosition = null;
      } catch (error) {
        // A failed return-area load may have attached only part of the overworld ring.
        // Re-suspend it so the player remains in a self-contained, collision-safe interior.
        this.terrainStreamer?.suspend();
        this.showToast(error instanceof Error ? `Return path unavailable: ${error.message}` : 'Return path unavailable. You remain inside.');
      } finally {
        this.zoneTransitionInProgress = false;
      }
    })();
  }

  private syncWeaponVisual(): void {
    if (!this.player) return;
    const gear = this.gearInventory.getEquippedWeapon();
    if (gear) {
      this.player.setWeaponModel(this.assetRegistry.createInstance(GEAR_DEFINITIONS[gear.gearId].modelAsset as AssetId));
    } else {
      const equipped = this.inventory.getEquippedWeapon();
      const assetId: AssetId | null = equipped?.id === 'iron-maul' ? 'weapon-hammer'
        : equipped ? 'weapon-sword' : null;
      this.player.setWeaponModel(assetId ? this.assetRegistry.createInstance(assetId) : null);
    }
    const armorModels = this.gearInventory.getEquippedArmor().map((item) => ({
      slot: GEAR_DEFINITIONS[item.gearId].slot as 'helmet' | 'chestplate' | 'leggings',
      model: this.assetRegistry.createInstance(GEAR_DEFINITIONS[item.gearId].modelAsset as AssetId),
    })).filter((entry): entry is { slot: 'helmet' | 'chestplate' | 'leggings'; model: THREE.Group } => entry.model !== null);
    this.player.setArmorModels(armorModels);
  }

  getSettings(): GameSettings {
    return this.gameSettings;
  }

  hasContinueSave(): boolean {
    return this.initialLoadResult.status === 'loaded' || this.initialLoadResult.status === 'migrated';
  }

  openTouchLayoutEditor(): boolean {
    return this.input.openTouchLayoutEditor();
  }

  setGameplayPaused(paused: boolean): void {
    this.gameplayPaused = paused;
    this.accumulator = 0;
    this.input.setPointerLockEnabled(!paused && !this.isAnyOverlayOpen());
    this.input.setMenuOpen(paused || this.isAnyOverlayOpen());
    if (paused && document.pointerLockElement) document.exitPointerLock();
    this.renderDirty = true;
  }

  async beginAdventure(): Promise<void> {
    await this.audioManager.start();
    this.setGameplayPaused(false);
    this.audioManager.playUi();
  }

  async startNewAdventure(): Promise<boolean> {
    if (this.hasContinueSave()) {
      const confirmed = window.confirm('Start a new ForgeBound adventure? Your current local adventure will be replaced.');
      if (!confirmed) return false;
      const cleared = this.saveSystem.clear();
      if (!cleared.ok) { this.showToast(cleared.reason); return false; }
      window.location.reload();
      return false;
    }
    await this.beginAdventure();
    return true;
  }

  applySettings(settings: GameSettings, persist = true): boolean {
    this.gameSettings = settings;
    const inputSettings = this.input.settings;
    this.input.updateSettings({
      ...inputSettings,
      lookSensitivity: settings.camera.sensitivity / 100,
      invertLookY: settings.camera.inverted,
    });
    this.input.updateKeyBindings(settings.controls.keyboard);
    this.input.updateGamepadBindings(settings.controls.gamepad);
    this.camera.fov = settings.camera.fov;
    this.camera.far = renderDistanceFarPlane(settings.video.drawDistance);
    this.camera.updateProjectionMatrix();
    this.terrainStreamer?.setStreamingRadiusChunks(streamingRadiusForDistance(settings.video.drawDistance));
    this.renderer.toneMappingExposure = 1.15 * (settings.video.brightness / 100);
    this.renderer.domElement.style.filter = settings.video.invertedColors ? 'invert(1) hue-rotate(180deg)' : '';
    this.renderer.shadowMap.enabled = settings.video.graphics === 'high';
    this.keyLight.castShadow = settings.video.graphics === 'high';
    this.scene.traverse((object) => {
      if (!(object instanceof THREE.Mesh)) return;
      const materials = Array.isArray(object.material) ? object.material : [object.material];
      for (const material of materials) {
        if (material instanceof THREE.MeshStandardMaterial || material instanceof THREE.MeshPhongMaterial) {
          material.flatShading = !settings.video.smoothLighting;
          material.needsUpdate = true;
        }
      }
    });
    const performancePolicy = resolvePerformancePolicy(
      settings.video.performance, settings.video.graphics, this.quality.tier, window.devicePixelRatio,
    );
    this.frameIntervalMs = performancePolicy.frameIntervalMs;
    this.adaptiveResolution.reconfigure({
      initialRatio: performancePolicy.pixelRatioCap,
      minimumRatio: performancePolicy.minimumPixelRatio,
      maximumRatio: performancePolicy.pixelRatioCap,
      targetFrameMs: performancePolicy.targetFrameMs,
    });
    this.renderer.setPixelRatio(performancePolicy.pixelRatioCap);
    // Scale each overlay independently so GUI size never changes the actual 3D viewport.
    // CSS px-based UI controls scale too (unlike changing the root font size alone).
    const guiZoom = { massive: 1.25, large: 1.12, normal: 1, small: 0.88 } as const;
    const shell = document.getElementById('game-shell');
    if (shell) {
      for (const child of Array.from(shell.children)) {
        if (child instanceof HTMLElement && child.id !== 'game-canvas') {
          child.style.zoom = String(guiZoom[settings.video.guiScale]);
        }
      }
    }
    this.screenShakeEnabled = settings.video.screenShake;
    document.documentElement.classList.toggle('animations-disabled', !settings.video.animations);
    this.player?.setAnimationsEnabled(settings.video.animations);
    this.miniGamePanel.setAnimationsEnabled(settings.video.animations);
    const combatProfile = difficultyCombatProfile(settings.difficulty);
    this.combatSystem?.setPlayerDamageMultiplier(combatProfile.playerDamageMultiplier);
    for (const enemy of this.enemies) {
      enemy.setAnimationsEnabled(settings.video.animations);
      enemy.setDamageMultiplier(combatProfile.enemyDamageMultiplier);
      enemy.setHealthMultiplier(combatProfile.enemyHealthMultiplier);
    }
    this.audioManager.configure(settings.audio);
    if (this.activeDungeonId) this.applyDungeonAppearance(DUNGEON_BY_ID[this.activeDungeonId]);
    else {
      const activeZone = ZONE_DEFINITIONS[this.zoneProgression.getCurrentZoneId()];
      this.scene.fog = new THREE.Fog(activeZone.palette.fog, this.fogNearDistance(), this.fogFarDistance());
    }
    const saved = persist ? saveGameSettings(resolveBrowserStorage(), settings) : true;
    if (persist) this.showToast(saved ? 'Settings saved.' : 'Settings apply for this session; browser storage is unavailable.');
    this.renderDirty = true;
    return saved;
  }

  private fogFarDistance(): number {
    return renderDistanceFogFar(this.gameSettings.video.drawDistance);
  }

  private fogNearDistance(): number {
    return renderDistanceFogNear(this.gameSettings.video.drawDistance);
  }

  dispose(): void {
    this.running = false;
    window.cancelAnimationFrame(this.animationFrame);
    window.removeEventListener('resize', this.onResize);
    this.closeInventoryButton.removeEventListener('click', this.onCloseInventory);
    this.inventoryPanel.removeEventListener('click', this.onInventoryPanelClick);
    this.closeForgeButton.removeEventListener('click', this.onCloseForge);
    this.forgePanel.removeEventListener('click', this.onForgePanelClick);
    this.npcPanel.removeEventListener('click', this.onNpcPanelClick);
    this.closeNpcPanelButton.removeEventListener('click', this.onCloseNpcPanel);
    this.openQuestJournalButton.removeEventListener('click', this.onQuestJournalClick);
    this.closeQuestJournalButton.removeEventListener('click', this.onCloseQuestJournal);
    this.openExplorationButton.removeEventListener('click', this.onExplorationClick);
    this.closeExplorationButton.removeEventListener('click', this.onCloseExploration);
    this.refinerPanel.removeEventListener('click', this.onRefinerPanelClick);
    this.closeRefinerButton.removeEventListener('click', this.onCloseRefiner);
    this.miniGamePanel.dispose();
    this.resetSaveButton.removeEventListener('click', this.onResetSave);
    this.unsubscribeInventory();
    this.dungeonInteriorManager?.dispose();
    this.removeDungeonLights();
    this.terrainStreamer?.dispose();
    this.worldPopulation?.dispose();
    this.civilianPopulation?.dispose();
    for (const node of this.oreNodes) node.dispose();
    for (const portal of this.zonePortals) portal.dispose();
    for (const npc of this.npcs) npc.dispose();
    for (const object of this.questWorldObjects) object.dispose();
    for (const station of this.miniGameStations) station.dispose();
    for (const entrance of this.dungeonEntrances) entrance.dispose();
    this.forgeStation?.dispose();
    this.combatSystem?.dispose();
    this.feedback.reset();
    this.audioManager.dispose();
    this.input.dispose();
    this.physics?.dispose();
    this.disposeSceneResources();
    this.assetRegistry.dispose();
    this.renderer.dispose();
    disposeSharedRenderResources();
  }

  private readonly frame = (now: number): void => {
    if (!this.running || !this.player || !this.physics || !this.miningSystem) return;
    // Frame cap: skip the whole frame, without consuming time, until the interval has elapsed.
    if (this.frameIntervalMs > 0 && now - this.lastFrameTime < this.frameIntervalMs - FRAME_CAP_TOLERANCE_MS) {
      this.animationFrame = window.requestAnimationFrame(this.frame);
      return;
    }

    const rawDelta = (now - this.lastFrameTime) / 1000;
    const frameDelta = Math.min(Math.max(rawDelta, 0), MAX_FRAME_DELTA);
    this.lastFrameTime = now;
    this.input.beginFrame(frameDelta);
    if (this.gameplayPaused) {
      this.accumulator = 0;
      this.input.consumeLook();
      this.input.consumeMenuIntent();
      this.input.snapshot(false);
      this.renderFrame(now);
      this.animationFrame = window.requestAnimationFrame(this.frame);
      return;
    }
    this.accumulator += frameDelta;

    const look = this.input.consumeLook();
    if (!this.isAnyOverlayOpen()) {
      this.cameraYaw -= look.x * MOUSE_SENSITIVITY;
      this.cameraPitch = THREE.MathUtils.clamp(
        this.cameraPitch - look.y * MOUSE_SENSITIVITY,
        MIN_CAMERA_PITCH,
        MAX_CAMERA_PITCH,
      );
    }
    const menuIntent = this.input.consumeMenuIntent();
    if (this.isAnyOverlayOpen()) {
      const focusPanel = this.inventoryOpen ? this.inventoryPanel : this.forgeOpen ? this.forgePanel : this.npcPanelOpen ? this.npcPanel : this.questJournalOpen ? this.questJournalPanel : this.explorationPanelOpen ? this.explorationPanel : this.refinerPanelOpen ? this.refinerPanel : this.getRequiredElement('minigame-panel');
      this.menuNavigator.apply(menuIntent, focusPanel);
    }

    let steps = 0;
    while (this.accumulator >= FIXED_STEP_SECONDS && steps < MAX_CATCH_UP_STEPS) {
      const sampledInput = this.input.snapshot(!this.isAnyOverlayOpen());
      if (sampledInput.inventoryTogglePressed) {
        if (this.forgeOpen) this.setForgeOpen(false);
        else this.setInventoryOpen(!this.inventoryOpen);
      }
      if (sampledInput.escapePressed) {
        const hadPanelOpen = this.isAnyOverlayOpen();
        this.closeAllPanels();
        if (!hadPanelOpen && this.input.isPointerLocked()) document.exitPointerLock();
      }

      const panelClosed = !this.isAnyOverlayOpen();
      const combatEvents = panelClosed && this.combatSystem && !this.activeDungeonId
        ? this.combatSystem.fixedUpdate(this.player.visualRoot.position, FIXED_STEP_SECONDS, this.combatOccluders)
        : [];
      this.handleCombatEvents(combatEvents);
      const playerCanMove = panelClosed && !this.zoneTransitionInProgress && !this.combatSystem?.isPlayerDefeated();
      this.player.fixedUpdate(
        {
          moveX: playerCanMove ? sampledInput.moveX : 0,
          moveZ: playerCanMove ? sampledInput.moveZ : 0,
          jumpPressed: playerCanMove && sampledInput.jumpPressed,
          interactPressed: playerCanMove && sampledInput.interactPressed,
          inventoryTogglePressed: false,
          escapePressed: false,
        },
        FIXED_STEP_SECONDS,
        this.cameraYaw,
      );
      this.physics.step();
      this.player.syncFromPhysics();
      this.combatSystem?.syncFromPhysics();
      this.terrainStreamer?.update(this.zoneProgression.getCurrentZoneId(), this.player.visualRoot.position);
      for (const enemy of this.enemies) enemy.updateVisualAnimations(FIXED_STEP_SECONDS);
      for (const npc of this.npcs) npc.updateAnimations(FIXED_STEP_SECONDS);
      if (!this.tutorial.isComplete() && this.tutorial.getStep() === 'movement') {
        const travelled = this.player.visualRoot.position.distanceTo(this.lastTutorialPosition);
        if (travelled > 0.002 && this.tutorial.recordMovement(travelled)) {
          this.lastTutorialPosition.copy(this.player.visualRoot.position);
          if (this.tutorial.getStep() !== 'movement') {
            this.renderTutorialPanel(); this.updateTutorialMarkerPosition(); this.persist();
            this.showToast('Lesson 1 complete · Find Ben near the quarry entrance.');
          }
        } else this.lastTutorialPosition.copy(this.player.visualRoot.position);
      }
      if (playerCanMove && sampledInput.interactPressed) this.handleInteractionAction();

      this.accumulator -= FIXED_STEP_SECONDS;
      steps += 1;
    }

    if (steps === MAX_CATCH_UP_STEPS && this.accumulator >= FIXED_STEP_SECONDS) {
      this.accumulator = 0;
    }

    this.miningSystem.update(frameDelta);
    this.civilianPopulation?.update(frameDelta, this.player.visualRoot.position);
    this.updateTutorialMarkerPosition();
    this.updateMinimap(now);
    this.updateCamera(frameDelta);
    if (this.isAnyOverlayOpen() || this.combatSystem?.isPlayerDefeated()) {
      this.miningSystem.clearTarget();
      this.combatSystem?.clearTarget();
      this.clearZonePortalTarget();
      this.clearMiniGameTarget();
      this.clearDungeonTargets();
      this.forgeTargeted = false;
      this.forgeTargetInRange = false;
    } else {
      // One centre-ray cast serves every targeting system this frame.
      this.interactionProbe.beginFrame(this.camera);
      const zoneId = this.zoneProgression.getCurrentZoneId();
      const playerPosition = this.player.visualRoot.position;
      if (this.activeDungeonId) {
        this.miningSystem.clearTarget();
        this.combatSystem?.clearTarget();
        this.clearZonePortalTarget();
        this.clearNpcTarget();
        this.clearMiniGameTarget();
        this.clearQuestObjectTarget();
        this.forgeTargeted = false; this.forgeTargetInRange = false;
        this.updateDungeonPointTarget();
        this.updateDungeonExitTarget();
      } else {
        this.miningSystem.updateTarget(this.interactionProbe.firstHit('mining', zoneId), playerPosition);
        this.combatSystem?.updateTarget(this.interactionProbe.firstHit('combat', zoneId), playerPosition);
        this.updateZonePortalTarget();
        this.updateNpcTarget();
        this.updateDungeonEntranceTarget();
        this.updateMiniGameTarget();
        this.updateQuestObjectTarget();
        this.updateForgeTarget();
      }
    }
    this.updateInteractionPrompt();
    this.updateCombatHud();
    this.refreshZonePortalAccess();
    this.updateDamageFlash(frameDelta);
    this.updateToast(frameDelta);
    this.feedback.setTriggerContext(this.buildTriggerContext());
    this.feedback.update(frameDelta);
    this.renderFrame(now);
    this.updateReadouts(frameDelta);
    this.animationFrame = window.requestAnimationFrame(this.frame);
  };

  /**
   * Renders unless a panel is open and nothing has changed. The scene is static while a panel
   * is up, so re-rendering it only spends GPU time. Rendered intervals also feed the adaptive
   * resolution governor; paused frames do not, because they are not measuring load.
   */
  private renderFrame(now: number): void {
    const paused = this.isAnyOverlayOpen() || this.gameplayPaused;
    if (paused && !this.renderDirty) {
      this.lastRenderTime = 0;
      return;
    }
    if (!paused && this.lastRenderTime > 0) {
      const nextRatio = this.adaptiveResolution.recordFrame(now - this.lastRenderTime);
      if (nextRatio !== null) this.renderer.setPixelRatio(nextRatio);
    }
    this.lastRenderTime = paused ? 0 : now;
    this.renderDirty = false;
    this.renderer.render(this.scene, this.camera);
  }

  private setupLights(): void {
    this.hemisphereLight = new THREE.HemisphereLight(0xb9d1c8, 0x3c3025, 1.55);
    this.scene.add(this.hemisphereLight);

    this.keyLight = new THREE.DirectionalLight(0xffdfad, 2.35);
    this.keyLight.position.set(-8, 15, 9);
    this.keyLight.castShadow = true;
    this.keyLight.shadow.mapSize.set(this.quality.shadowMapSize, this.quality.shadowMapSize);
    this.keyLight.shadow.camera.left = -22;
    this.keyLight.shadow.camera.right = 22;
    this.keyLight.shadow.camera.top = 22;
    this.keyLight.shadow.camera.bottom = -22;
    this.keyLight.shadow.camera.near = 0.5;
    this.keyLight.shadow.camera.far = 45;
    this.keyLight.shadow.bias = -0.00015;
    this.scene.add(this.keyLight);
    this.scene.add(this.keyLight.target);

    this.fillLight = new THREE.PointLight(0xd18a4d, 26, 18, 2);
    this.fillLight.position.set(-5.5, 3.2, -5.5);
    this.scene.add(this.fillLight);
  }

  private buildVisualWorld(): void {
    // Legacy arena geometry remains in world-config for save/test compatibility, but Phase J
    // renders only Python GLB terrain and population. Arena floors are intentionally disabled.
    return;
    const boxes = getStaticBoxes();
    for (const arena of ARENA_LAYOUTS) {
      const zone = ZONE_DEFINITIONS[arena.zoneId];
      const floorMaterial = new THREE.MeshStandardMaterial({
        color: zone.palette.floor,
        roughness: 0.98,
        metalness: arena.zoneId === 'crystal-peaks' ? 0.08 : 0.02,
      });
      const wallMaterial = new THREE.MeshStandardMaterial({
        color: zone.palette.wall,
        roughness: 0.94,
        metalness: arena.zoneId === 'molten-caves' ? 0.12 : 0.04,
      });
      const obstacleMaterial = new THREE.MeshStandardMaterial({
        color: zone.palette.obstacle,
        roughness: 0.92,
        metalness: arena.zoneId === 'crystal-peaks' ? 0.18 : 0.02,
      });

      this.addBox(arena.floor.center, arena.floor.halfExtents, floorMaterial, `${arena.zoneId}-floor`);
      for (const box of boxes.filter((candidate) => candidate.zoneId === arena.zoneId)) {
        this.addBox(
          box.center,
          box.halfExtents,
          box.tone === 'wall' ? wallMaterial : obstacleMaterial,
          box.id,
        );
      }

      const groundLines = new THREE.GridHelper(26, 26, zone.palette.accent, zone.palette.wall);
      groundLines.position.set(arena.center.x, 0.008, arena.center.z);
      const gridMaterials = Array.isArray(groundLines.material)
        ? groundLines.material
        : [groundLines.material];
      for (const material of gridMaterials) {
        material.transparent = true;
        material.opacity = 0.18;
      }
      this.scene.add(groundLines);

      if (arena.zoneId === 'starter-quarry') this.addQuarryMarkers();
      else if (arena.zoneId === 'molten-caves') this.addMoltenCaveProps(arena.center.x);
      else this.addCrystalPeakProps(arena.center.x);
    }
  }

  private addMoltenCaveProps(centerX: number): void {
    const fissureMaterial = new THREE.MeshStandardMaterial({
      color: 0x4c190d,
      emissive: 0xff4a17,
      emissiveIntensity: 1.75,
      roughness: 0.5,
    });
    const fissures = [
      { x: centerX - 8.2, z: -9.1, width: 5.2, depth: 0.5, rotation: 0.18 },
      { x: centerX + 7.8, z: -4.9, width: 4.2, depth: 0.42, rotation: -0.26 },
      { x: centerX - 6.5, z: 9.2, width: 4.8, depth: 0.5, rotation: -0.12 },
    ];
    for (const fissure of fissures) {
      const mesh = new THREE.Mesh(
        new THREE.BoxGeometry(fissure.width, 0.055, fissure.depth),
        fissureMaterial,
      );
      mesh.position.set(fissure.x, 0.026, fissure.z);
      mesh.rotation.y = fissure.rotation;
      mesh.receiveShadow = true;
      this.scene.add(mesh);
    }

    const basaltMaterial = new THREE.MeshStandardMaterial({ color: 0x302a2a, roughness: 0.94 });
    for (const position of [
      { x: centerX - 11.1, z: -2.8, height: 2.6 },
      { x: centerX + 10.8, z: -7.7, height: 2.1 },
      { x: centerX + 10.7, z: 8.2, height: 2.9 },
    ]) {
      const pillar = new THREE.Mesh(new THREE.ConeGeometry(0.9, position.height, 6), basaltMaterial);
      pillar.position.set(position.x, position.height / 2, position.z);
      pillar.rotation.y = 0.35;
      pillar.castShadow = true;
      this.scene.add(pillar);
    }
  }

  private addCrystalPeakProps(centerX: number): void {
    const crystalMaterials = [
      new THREE.MeshStandardMaterial({ color: 0x7b8fda, emissive: 0x3449b5, emissiveIntensity: 0.65, roughness: 0.27, metalness: 0.22 }),
      new THREE.MeshStandardMaterial({ color: 0xb2a5f0, emissive: 0x5b48bd, emissiveIntensity: 0.82, roughness: 0.25, metalness: 0.18 }),
    ];
    const formations = [
      { x: centerX - 10.4, z: -9.4, scale: 2.4, material: 0 },
      { x: centerX + 10.2, z: -9.2, scale: 2.0, material: 1 },
      { x: centerX - 10.6, z: 8.8, scale: 2.7, material: 1 },
      { x: centerX + 10.1, z: 8.7, scale: 2.3, material: 0 },
      { x: centerX + 2.5, z: -11.0, scale: 1.5, material: 1 },
    ];
    for (const formation of formations) {
      const spire = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.75, 0),
        crystalMaterials[formation.material],
      );
      spire.position.set(formation.x, formation.scale * 0.42, formation.z);
      spire.scale.set(0.75, formation.scale, 0.72);
      spire.rotation.set(0.1, formation.x * 0.07, 0.08);
      spire.castShadow = true;
      spire.receiveShadow = true;
      this.scene.add(spire);
    }
  }


  private createZonePortals(): void {
    for (const definition of ZONE_GATES) {
      const portal = new ZonePortal(definition, this.assetRegistry.createInstance('portal'));
      this.zonePortals.push(portal);
      this.scene.add(portal.visualRoot);
      this.cameraOccluders.push(portal.visualRoot);
    }
  }

  private applyZoneAppearance(zone: (typeof ZONE_DEFINITIONS)[ZoneId]): void {
    this.scene.background = new THREE.Color(zone.palette.background);
    this.scene.fog = new THREE.Fog(zone.palette.fog, this.fogNearDistance(), this.fogFarDistance());
    this.hemisphereLight.color.setHex(zone.palette.skyLight);
    this.hemisphereLight.groundColor.setHex(zone.palette.groundLight);
    this.hemisphereLight.intensity = 1.55;
    this.keyLight.color.setHex(zone.palette.keyLight);
    this.keyLight.intensity = 2.35;
    this.keyLight.position.set(zone.center.x - 8, 15, zone.center.z + 9);
    this.keyLight.target.position.set(zone.center.x, 0, zone.center.z);
    this.fillLight.color.setHex(zone.palette.fillLight);
    this.fillLight.intensity = 26;
    this.fillLight.position.set(zone.center.x - 5.5, 3.2, zone.center.z - 5.5);
  }

  private updateZoneReadout(): void {
    const zone = ZONE_DEFINITIONS[this.zoneProgression.getCurrentZoneId()];
    this.activeZoneElement.textContent = zone.name;
    this.activeZoneElement.title = zone.description;
  }

  private refreshZonePortalAccess(): void {
    const level = this.progression.getLevel();
    for (const portal of this.zonePortals) {
      const questGate = portal.targetZoneId === 'molten-caves'
        ? this.questSystem.isCompleted('zone1-main-quarry-wakes')
        : portal.targetZoneId === 'crystal-peaks'
          ? this.questSystem.isCompleted('zone2-main-heart-furnace')
          : true;
      portal.setUnlocked(level >= portal.requiredLevel && questGate);
    }
  }

  private clearZonePortalTarget(): void {
    this.zonePortalTarget?.setTargeted(false);
    this.zonePortalTarget = null;
    this.zonePortalInRange = false;
  }

  private updateZonePortalTarget(): void {
    this.clearZonePortalTarget();
    if (!this.player || this.inventoryOpen || this.forgeOpen) return;
    const hit = this.interactionProbe.firstHit('portal', this.zoneProgression.getCurrentZoneId());
    const portalId = hit?.object.userData['zonePortalId'];
    if (typeof portalId !== 'string') return;
    const portal = this.zonePortals.find((candidate) => candidate.id === portalId);
    if (!portal) return;
    this.zonePortalTarget = portal;
    portal.setTargeted(true);
    this.zonePortalInRange = this.player.visualRoot.position.distanceToSquared(portal.position) <= 5.4 ** 2;
  }

  private handleZonePortalAction(): void {
    const portal = this.zonePortalTarget;
    if (!portal || !this.player) return;
    if (!this.tutorial.isComplete()) { this.showToast('Complete Ben’s mandatory tutorial before travelling to another zone.'); return; }
    if (!this.zonePortalInRange) {
      this.showToast(`Move closer to the ${portal.label} gate.`);
      return;
    }

    const progression = this.progression.snapshot();
    const questGate = portal.targetZoneId === 'molten-caves'
      ? this.questSystem.isCompleted('zone1-main-quarry-wakes')
      : portal.targetZoneId === 'crystal-peaks' ? this.questSystem.isCompleted('zone2-main-heart-furnace') : true;
    if (!questGate) { this.showToast('Complete the previous zone main quest before entering this realm.'); return; }
    const result = this.zoneProgression.travelTo(portal.targetZoneId, progression.level);
    if (!result.ok) {
      if (result.reason === 'locked') {
        this.showToast(`${portal.label} remains sealed · reach level ${result.requiredLevel ?? portal.requiredLevel}.`);
      } else if (result.reason === 'already-here') {
        this.showToast(`You are already in ${portal.label}.`);
      } else {
        this.showToast('This gate is unstable.');
      }
      return;
    }

    const destination = ZONE_DEFINITIONS[result.to];
    this.zoneTransitionInProgress = true;
    this.showToast(`Opening the route to ${destination.name}…`);
    void (async () => {
      try {
        await this.terrainStreamer?.loadAround(result.to, destination.spawn);
        this.player?.respawnAt(destination.spawn);
        this.combatSystem?.setActiveZone(result.to);
        this.miningSystem?.setActiveZone(result.to);
        this.worldPopulation?.setActiveZone(result.to);
        this.civilianPopulation?.setActiveZone(result.to);
        this.setZoneEntitiesActive(result.to);
        this.applyZoneAppearance(destination);
        this.updateZoneReadout();
        this.refreshQuestJournal();
        this.refreshZonePortalAccess();
        this.showToast(`Entered ${destination.name} · ${destination.subtitle}.`);
        this.feedback.emit('zone-travel');
        this.persist();
        this.updateCamera(0.25);
      } catch (error) {
        this.zoneProgression.setCurrentZone(portal.sourceZoneId, this.progression.snapshot().level);
        const source = ZONE_DEFINITIONS[portal.sourceZoneId];
        this.combatSystem?.setActiveZone(portal.sourceZoneId);
        this.miningSystem?.setActiveZone(portal.sourceZoneId);
        this.worldPopulation?.setActiveZone(portal.sourceZoneId);
        this.civilianPopulation?.setActiveZone(portal.sourceZoneId);
        this.setZoneEntitiesActive(portal.sourceZoneId);
        this.applyZoneAppearance(source);
        this.updateZoneReadout();
        this.refreshQuestJournal();
        this.refreshZonePortalAccess();
        this.showToast(error instanceof Error ? `Zone transfer failed: ${error.message}` : 'Zone transfer failed.');
      } finally {
        this.zoneTransitionInProgress = false;
      }
    })();
    this.clearZonePortalTarget();
    this.forgeTargeted = false;
    this.forgeTargetInRange = false;
    return;
  }

  /** Adaptive-trigger context for this frame, using the same target order as the prompt. */
  private buildTriggerContext(): TriggerContext {
    const suppressed = this.isAnyOverlayOpen() || (this.combatSystem?.isPlayerDefeated() ?? false);
    if (suppressed) return { ...NO_TRIGGER_CONTEXT, suppressed: true };
    if (this.zonePortalTarget || this.dungeonEntranceTarget || this.dungeonPointTarget || this.dungeonExitTarget || this.npcTarget || this.miniGameTarget || this.questObjectTarget) return { ...NO_TRIGGER_CONTEXT, target: 'other' };
    const combat = this.combatSystem?.getTargetState() ?? null;
    if (combat) {
      return combat.enemy.isPacified()
        ? NO_TRIGGER_CONTEXT
        : { ...NO_TRIGGER_CONTEXT, target: 'creature', inRange: combat.inRange };
    }
    if (this.forgeTargeted) return { ...NO_TRIGGER_CONTEXT, target: 'other' };
    const mining = this.miningSystem?.getTargetState() ?? null;
    if (mining) {
      return {
        ...NO_TRIGGER_CONTEXT,
        target: 'ore',
        inRange: mining.inRange,
        cooldownActive: this.miningSystem?.isCoolingDown() ?? false,
      };
    }
    return NO_TRIGGER_CONTEXT;
  }

  /** Button name for the active input family, e.g. "E", "Cross", or "ACT". */
  private label(action: PromptAction): string {
    return inputLabel(this.input.activeFamily, action);
  }

  private addBox(
    center: Readonly<{ x: number; y: number; z: number }>,
    halfExtents: Readonly<{ x: number; y: number; z: number }>,
    material: THREE.Material,
    name: string,
  ): THREE.Mesh {
    const width = halfExtents.x * 2;
    const height = halfExtents.y * 2;
    const depth = halfExtents.z * 2;
    const geometry = sharedGeometry(`box:${width}:${height}:${depth}`, () => new THREE.BoxGeometry(width, height, depth));
    const mesh = new THREE.Mesh(geometry, material);
    mesh.name = name;
    mesh.position.set(center.x, center.y, center.z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    this.scene.add(mesh);
    this.cameraOccluders.push(mesh);
    return mesh;
  }

  private addQuarryMarkers(): void {
    const timberMaterial = new THREE.MeshStandardMaterial({ color: 0x725039, roughness: 0.9 });
    const brassMaterial = new THREE.MeshStandardMaterial({ color: 0xb8864c, metalness: 0.55, roughness: 0.5 });
    const markerPositions = [
      { x: -10.5, z: -8.5 },
      { x: 10.5, z: -8.5 },
      { x: -10.5, z: 8.5 },
      { x: 10.5, z: 8.5 },
    ];

    for (const position of markerPositions) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.28, 2.6, 0.28), timberMaterial);
      post.position.set(position.x, 1.3, position.z);
      post.castShadow = true;
      this.scene.add(post);

      const cap = new THREE.Mesh(new THREE.BoxGeometry(0.54, 0.16, 0.54), brassMaterial);
      cap.position.set(position.x, 2.62, position.z);
      cap.castShadow = true;
      this.scene.add(cap);
    }
  }

  private updateCamera(deltaSeconds: number): void {
    if (!this.player) return;
    const playerPosition = this.player.visualRoot.position;
    // Keep the player in the lower foreground and aim slightly ahead of their feet.
    this.cameraTarget.set(
      playerPosition.x - Math.sin(this.cameraYaw) * 1.5,
      playerPosition.y + 0.95,
      playerPosition.z - Math.cos(this.cameraYaw) * 1.5,
    );

    this.cameraDirection.set(
      Math.sin(this.cameraYaw) * Math.cos(this.cameraPitch),
      Math.sin(this.cameraPitch),
      Math.cos(this.cameraYaw) * Math.cos(this.cameraPitch),
    ).normalize();

    this.cameraOccluderScratch.length = 0;
    this.cameraOccluderScratch.push(...this.cameraOccluders);
    if (!this.activeDungeonId) {
      this.worldPopulation?.appendCameraOccluders(this.cameraOccluderScratch);
      this.terrainStreamer?.appendLoadedRoots(this.zoneProgression.getCurrentZoneId(), this.cameraOccluderScratch);
    }
    this.cameraRaycaster.set(this.cameraTarget, this.cameraDirection);
    this.cameraRaycaster.far = CAMERA_DISTANCE;
    intersectVisible(this.cameraRaycaster, this.cameraOccluderScratch, this.cameraIntersectionScratch);
    const targetCameraDistance = resolveCameraDistance(this.cameraIntersectionScratch);
    this.cameraDistance = approachCameraDistance(this.cameraDistance, targetCameraDistance, deltaSeconds);

    this.desiredCameraPosition.copy(this.cameraTarget)
      .addScaledVector(this.cameraDirection, this.cameraDistance);
    const followFactor = this.gameSettings.video.animations
      ? 1 - Math.exp(-7.0 * Math.max(deltaSeconds, 0))
      : 1;
    this.camera.position.lerp(this.desiredCameraPosition, followFactor);
    if (this.screenShakeEnabled && this.shakeRemaining > 0) {
      this.shakeRemaining = Math.max(0, this.shakeRemaining - Math.max(0, deltaSeconds));
      const strength = this.shakeRemaining / 0.18;
      this.camera.position.x += Math.sin(performance.now() * 0.075) * 0.075 * strength;
      this.camera.position.y += Math.cos(performance.now() * 0.09) * 0.05 * strength;
    }
    this.camera.lookAt(this.cameraTarget);
  }

  private updateReadouts(deltaSeconds: number): void {
    if (!this.player) return;
    setText(this.positionElement, this.player.getPositionText());
    setText(
      this.cameraStateElement,
      this.inventoryOpen ? 'PACK OPEN'
        : this.forgeOpen ? 'AT THE FORGE'
          : this.npcPanelOpen ? 'TALKING TO A LOCAL'
            : this.questJournalOpen ? 'QUEST JOURNAL'
              : this.explorationPanelOpen ? 'EXPLORATION LOG'
                : this.refinerPanelOpen ? 'WEAPON REFINERY' : this.input.lookLabel(),
    );

    this.fpsElapsed += deltaSeconds;
    this.frameCounter += 1;
    if (this.fpsElapsed >= 0.5) {
      this.currentFps = Math.round(this.frameCounter / this.fpsElapsed);
      this.frameCounter = 0;
      this.fpsElapsed = 0;
      const scale = this.adaptiveResolution.currentRatio.toFixed(2);
      setText(this.simulationElement, `${this.currentFps} FPS · ${this.quality.tier.toUpperCase()} ${scale}×`);
    }
  }

  private updateInventoryUi(snapshot: InventorySnapshot): void {
    setText(this.coinBalanceElement, snapshot.coins.toLocaleString());
    setText(this.inventoryCoinsElement, snapshot.coins.toLocaleString());
    for (const resourceId of RESOURCE_IDS) {
      const amount = String(snapshot.resources[resourceId]);
      const summary = this.inventorySummaryElements.get(resourceId);
      const panel = this.inventoryPanelElements.get(resourceId);
      if (summary) setText(summary, amount);
      if (panel) setText(panel, amount);
    }
    this.updateEquipmentUi(snapshot);
    this.refreshGearInventoryUi();
    this.refreshForgeUi();
  }

  private updateInteractionPrompt(): void {
    const prompt = this.resolveInteractionPrompt();
    const targetMeter = this.targetHealthFill.parentElement;
    if (targetMeter) setHidden(targetMeter, !prompt.showHealthMeter);
    setHidden(this.interactionPrompt, !prompt.visible);
    if (prompt.visible) setText(this.interactionPromptText, prompt.text);
    if (prompt.healthWidth !== null) setWidth(this.targetHealthFill, prompt.healthWidth);
  }

  private resolveInteractionPrompt(): InteractionPrompt {
    if (this.inventoryOpen) return promptText(`PACK OPEN · ${panelCloseHint(this.input.activeFamily)}`, '0%');
    if (this.forgeOpen) return promptText('FORGE OPEN · Smelt and craft at the station', '0%');
    if (this.npcPanelOpen) return promptText('CHARACTER · Review the request or service', '0%');
    if (this.questJournalOpen) return promptText('QUEST JOURNAL · Review active objectives', '0%');
    if (this.explorationPanelOpen) return promptText('EXPLORATION LOG · Review discovered interiors and landmarks', '0%');
    if (this.refinerPanelOpen) return promptText('WEAPON REFINEMENT · Upgrade your equipped weapon', '0%');
    if (this.miniGamePanelOpen) return promptText('ACTIVITY OPEN · Complete the challenge or close it', '0%');
    if (this.combatSystem?.isPlayerDefeated()) return HIDDEN_PROMPT;

    if (this.activeDungeonId) {
      if (this.dungeonPointTarget) return promptText(this.dungeonPointInRange ? `${this.label('interact')} — Investigate ${this.dungeonPointTarget.label}` : `Move closer · ${this.dungeonPointTarget.label}`, '0%');
      if (this.dungeonExitTarget) return promptText(this.dungeonExitInRange ? `${this.label('interact')} — Return to the overworld` : 'Move closer · Return arch', '0%');
    }

    if (this.zonePortalTarget) {
      const portal = this.zonePortalTarget;
      const levelUnlocked = this.progression.getLevel() >= portal.requiredLevel;
      const questUnlocked = portal.targetZoneId === 'molten-caves'
        ? this.questSystem.isCompleted('zone1-main-quarry-wakes')
        : portal.targetZoneId === 'crystal-peaks' ? this.questSystem.isCompleted('zone2-main-heart-furnace') : true;
      const text = !levelUnlocked
        ? `SEALED · ${portal.label} · LEVEL ${portal.requiredLevel}`
        : !questUnlocked ? `SEALED · Complete the previous zone's main quest`
        : this.zonePortalInRange
          ? `${this.label('interact')} — Enter ${portal.label}`
          : `Move closer · ${portal.label} gate`;
      return promptText(text, '0%');
    }

    if (this.npcTarget) {
      const step = this.tutorial.getStep();
      const benText = step === 'meet-ben' ? 'Speak with Ben to begin your forge lesson'
        : step === 'return-pickaxe' ? 'Return Ben’s pickaxe to him'
        : step === 'receive-pickaxe' ? 'Speak with Ben to receive your pickaxe back'
        : `Speak with ${this.npcTarget.definition.name}`;
      return promptText(this.npcTargetInRange ? `${this.label('interact')} — ${this.npcTarget.definition.id === 'ben' && !this.tutorial.isComplete() ? benText : `Speak with ${this.npcTarget.definition.name}`}` : `Move closer · ${this.npcTarget.definition.name}`, '0%');
    }
    if (this.isPickaxeInRange()) return promptText(`${this.label('interact')} — Pick up Ben’s lost pickaxe`, '0%');
    if (this.civilianPopulation?.isDogInRange(this.player?.visualRoot.position ?? new THREE.Vector3(), 2.8)) return promptText(`${this.label('interact')} — Pet the dog`, '0%');
    const nearbyCivilian = this.player ? this.civilianPopulation?.getNearestCivilian(this.player.visualRoot.position, 2.8) : null;
    if (nearbyCivilian) return promptText(`${this.label('interact')} — Greet ${nearbyCivilian.definition.name}`, '0%');
    if (this.dungeonEntranceTarget) {
      const name = this.dungeonEntranceTarget.definition.name;
      return promptText(this.dungeonEntranceInRange ? `${this.label('interact')} — Enter ${name}` : `Move closer · ${name}`, '0%');
    }
    if (this.miniGameTarget) {
      const activityName = this.miniGameTarget.definition.label.toLowerCase();
      return promptText(this.miniGameTargetInRange ? `${this.label('interact')} — Start ${activityName}` : `Move closer · ${activityName}`, '0%');
    }

    if (this.questObjectTarget) {
      return promptText(this.questObjectTargetInRange ? `${this.label('interact')} — ${this.questObjectTarget.definition.title}` : `Move closer · ${this.questObjectTarget.definition.title}`, '0%');
    }

    const combatTarget = this.combatSystem?.getTargetState() ?? null;
    if (combatTarget) {
      const text = combatTarget.inRange
        ? `${this.label('interact')} — Attack ${combatTarget.enemy.name}`
        : `Move closer · ${combatTarget.enemy.name}`;
      return {
        visible: true,
        text,
        healthWidth: `${Math.max(0, combatTarget.enemy.getHealthRatio() * 100).toFixed(2)}%`,
        showHealthMeter: true,
      };
    }

    if (this.forgeTargeted) {
      return promptText(this.forgeTargetInRange ? `${this.label('interact')} — Use Quarry Forge` : 'Move closer · Quarry Forge', '0%');
    }

    const targetState = this.miningSystem?.getTargetState() ?? null;
    if (!targetState) return HIDDEN_PROMPT;

    const { node, inRange } = targetState;
    return {
      visible: true,
      text: inRange ? `${this.label('interact')} — Mine ${node.displayName}` : `Move closer · ${node.displayName}`,
      healthWidth: `${Math.max(0, node.getHealthRatio() * 100).toFixed(2)}%`,
      showHealthMeter: true,
    };
  }

  private handleInteractionAction(): void {
    if (this.activeDungeonId) {
      if (this.dungeonPointTarget) { this.claimDungeonPoint(); return; }
      if (this.dungeonExitTarget) { this.exitDungeon(); return; }
      return;
    }
    if (this.zonePortalTarget) {
      this.handleZonePortalAction();
      return;
    }
    if (this.isPickaxeInRange()) { this.handlePickaxeWorldInteraction(); return; }
    if (this.npcTarget) { this.handleNpcInteraction(); return; }
    if (this.player && this.civilianPopulation?.petDog(this.player.visualRoot.position, 2.8)) {
      this.player.playInteractionAnimation();
      this.showToast('The dog wags its tail and happily accepts a pat.');
      this.renderDirty = true;
      return;
    }
    const greeted = this.player ? this.civilianPopulation?.greetNearest(this.player.visualRoot.position, 2.8) : null;
    if (greeted) {
      this.player?.playInteractionAnimation();
      this.showToast(`You greet ${greeted.definition.name}. They respond warmly.`);
      this.renderDirty = true;
      return;
    }
    if (this.dungeonEntranceTarget) {
      if (!this.dungeonEntranceInRange) { this.showToast('Move closer to the interior entrance.'); return; }
      this.enterDungeon(this.dungeonEntranceTarget);
      return;
    }
    if (this.miniGameTarget) { this.handleMiniGameInteraction(); return; }
    if (this.questObjectTarget) { this.handleQuestObjectInteraction(); return; }
    const enemyTarget = this.combatSystem?.getTargetState() ?? null;
    if (enemyTarget) {
      this.handleWeaponAttackAction();
      return;
    }
    if (this.forgeTargeted) {
      if (!this.forgeTargetInRange) {
        this.showToast('Move closer to use the Quarry Forge.');
        return;
      }
      this.setForgeOpen(true);
      return;
    }
    this.handleMiningAction();
  }

  private handleWeaponAttackAction(): void {
    if (!this.player || !this.combatSystem) return;
    const previousLevel = this.progression.snapshot().level;
    const weapon = this.inventory.getEquippedWeapon();
    const gearWeapon = this.gearInventory.getEquippedWeapon();
    if (!weapon && !gearWeapon) {
      this.showToast('Equip a weapon before attacking.');
      return;
    }
    const result = this.combatSystem.tryAttack(this.player.visualRoot.position);
    if (result.kind !== 'no-target') this.player.playAttackAnimation();
    switch (result.kind) {
      case 'no-target':
        return;
      case 'no-weapon':
        this.showToast('Equip a weapon before attacking.');
        return;
      case 'cooldown':
        this.showToast('Your weapon is recovering.');
        return;
      case 'out-of-range':
        this.showToast(`Move closer to strike ${result.enemy.name}.`);
        return;
      case 'hit':
        this.showToast(`${gearWeapon ? GEAR_DEFINITIONS[gearWeapon.gearId].name : weapon?.name ?? 'Weapon'} hit ${result.enemy.name} · ${result.damage} damage · ${result.remainingHealth}/${result.enemy.definition.maximumHealth} health`);
        this.feedback.emit('mine-hit');
        this.audioManager.playHit();
        break;
      case 'defeated': {
        this.questSystem.record({ type: 'defeat', enemyId: result.enemy.definition.id });
        const rewards = result.loot.map((drop) => `+${drop.quantity} ${RESOURCE_DEFINITIONS[drop.resourceId].shortName}`);
        const overflow = result.overflow.length > 0 ? ' · pouch full' : '';
        const currentLevel = this.progression.snapshot().level;
        this.refreshQuestJournal();
        const levelText = result.levelsGained > 0 ? ` · LEVEL ${currentLevel}!` : '';
        const newlyUnlocked = this.zoneProgression.getNewlyUnlocked(previousLevel, currentLevel);
        const unlockText = newlyUnlocked.length > 0
          ? ` · UNLOCKED: ${newlyUnlocked.map((zoneId) => ZONE_DEFINITIONS[zoneId].name).join(', ')}`
          : '';
        this.showToast(`${result.enemy.name} defeated · +${result.xpAwarded} XP · +${result.coinsAwarded} Coins${rewards.length ? ` · ${rewards.join(', ')}` : ''}${overflow}${levelText}${unlockText}`);
        this.feedback.emit('mine-depleted');
        this.audioManager.playDefeat();
        break;
      }
    }
    this.refreshZonePortalAccess();
    this.updateCombatHud();
    this.persist();
  }

  private handleCombatEvents(events: readonly CombatEvent[]): void {
    for (const event of events) {
      if (event.type === 'player-hit') {
        this.damageFlashRemaining = 0.32;
        if (this.screenShakeEnabled) this.shakeRemaining = 0.18;
        this.damageVignetteElement.classList.add('is-hit');
        this.showToast(`${event.enemyName} struck · −${event.damage} vitality`);
        this.feedback.emit('player-hit');
      } else if (event.type === 'player-defeated') {
        this.showToast('Overcome · returning to the quarry checkpoint…');
        this.feedback.emit('player-defeated');
        this.respawnBannerElement.hidden = false;
        if (document.pointerLockElement) document.exitPointerLock();
      } else {
        this.respawnBannerElement.hidden = true;
        const checkpoint = ZONE_DEFINITIONS[this.zoneProgression.getCurrentZoneId()];
        this.player?.respawnAt(checkpoint.spawn);
        this.showToast(`Recovered at ${checkpoint.name}. Your inventory and Coins remain safe.`);
      }
    }
    if (events.length > 0) this.persist();
  }

  private updateCombatHud(): void {
    if (!this.combatSystem) return;
    const vitals = this.combatSystem.getVitals();
    const progression = this.combatSystem.getProgressionSnapshot();
    setText(this.healthTextElement, `${vitals.currentHealth} / ${vitals.maximumHealth}`);
    setWidth(this.healthFillElement, `${((vitals.currentHealth / vitals.maximumHealth) * 100).toFixed(2)}%`);
    setDataAttribute(this.healthFillElement, 'low', String(vitals.currentHealth <= 30));
    setText(this.levelTextElement, String(progression.level));
    setText(this.xpTextElement, `${progression.currentXp} / ${progression.xpToNextLevel} XP`);
    setWidth(this.xpFillElement, `${Math.min(100, (progression.currentXp / progression.xpToNextLevel) * 100).toFixed(2)}%`);
    if (vitals.defeated) {
      setHidden(this.respawnBannerElement, false);
      setText(this.respawnCountdownElement, `${vitals.respawnRemaining.toFixed(1)}s`);
    }
  }

  private updateDamageFlash(deltaSeconds: number): void {
    if (this.damageFlashRemaining <= 0) return;
    this.damageFlashRemaining = Math.max(0, this.damageFlashRemaining - deltaSeconds);
    if (this.damageFlashRemaining === 0) this.damageVignetteElement.classList.remove('is-hit');
  }

  private handleMiningAction(): void {
    const pickaxePower = this.inventory.getEquippedPickaxe()?.miningPower ?? null;
    const result = this.miningSystem?.mineTarget(pickaxePower);
    if (!result) return;

    switch (result.kind) {
      case 'no-target':
        return;
      case 'no-pickaxe':
        this.showToast('Mining is locked until Ben gives you his pickaxe at the end of the tutorial.');
        return;
      case 'out-of-range':
        this.showToast(`Too far away to mine ${result.node.displayName}.`);
        return;
      case 'cooldown':
        this.showToast('Resonance is recharging.');
        return;
      case 'hit':
        this.showToast(`${result.node.displayName} struck · ${result.remainingHealth} durability left`);
        this.feedback.emit('mine-hit');
        return;
      case 'depleted':
        if (result.quantity > 0) {
          this.questSystem.record({ type: 'mine', resourceId: result.node.resourceId, amount: result.quantity });
          this.questSystem.record({ type: 'collect', resourceId: result.node.resourceId, amount: result.quantity });
          this.refreshQuestJournal();
          this.persist();
          const resource = RESOURCE_DEFINITIONS[result.node.resourceId];
          this.showToast(`+${result.quantity} ${resource.name}`);
        } else {
          this.showToast('The resource stack is full.');
        }
        this.feedback.emit(result.quantity > 0 ? 'mine-depleted' : 'impact');
        return;
    }
  }

  private updateForgeTarget(): void {
    this.forgeTargeted = false;
    this.forgeTargetInRange = false;
    if (!this.forgeStation || !this.player) return;
    const hit = this.interactionProbe.firstHit('forge', this.zoneProgression.getCurrentZoneId());
    this.forgeTargeted = !this.zonePortalTarget && hit?.object.userData['forgeStation'] === true;
    if (!this.forgeTargeted) return;
    this.forgeTargetInRange = this.player.visualRoot.position.distanceToSquared(this.forgeStation.position)
      <= 5.2 * 5.2;
  }

  private updateEquipmentUi(snapshot: InventorySnapshot): void {
    const pickaxe = snapshot.equippedPickaxeId
      ? EQUIPMENT_DEFINITIONS[snapshot.equippedPickaxeId]
      : null;
    const weapon = snapshot.equippedWeaponId
      ? EQUIPMENT_DEFINITIONS[snapshot.equippedWeaponId]
      : null;

    this.equippedPickaxeElement.textContent = pickaxe?.name ?? 'None';
    this.equippedWeaponElement.textContent = weapon?.name ?? 'None';
    this.pickaxePowerElement.textContent = pickaxe?.slot === 'pickaxe'
      ? `${pickaxe.miningPower.toFixed(1)}× mining` : 'No pickaxe';
    this.weaponDamageElement.textContent = weapon?.slot === 'weapon'
      ? `${weapon.attackDamage} power · ${weapon.attacksPerSecond.toFixed(2)}/s`
      : 'No weapon';

    const pickaxeName = pickaxe?.name ?? 'None';
    const weaponName = weapon?.name ?? 'None';
    this.inventoryEquippedEquipment.textContent = `Pickaxe: ${pickaxeName} · Weapon: ${weaponName}`;
    this.updateGearEquipmentHud();

    const rows: HTMLElement[] = [];
    for (const equipmentId of snapshot.ownedEquipmentIds) {
      const definition = EQUIPMENT_DEFINITIONS[equipmentId];
      const row = document.createElement('div');
      row.className = 'owned-equipment-row';

      const details = document.createElement('div');
      details.className = 'owned-equipment-copy';
      const name = document.createElement('strong');
      name.textContent = definition.name;
      const stats = document.createElement('span');
      stats.textContent = this.describeEquipment(definition.id);
      details.append(name, stats);

      const action = document.createElement('button');
      action.type = 'button';
      action.className = 'recipe-action compact-action';
      const isEquipped = definition.slot === 'pickaxe'
        ? snapshot.equippedPickaxeId === equipmentId
        : snapshot.equippedWeaponId === equipmentId;
      if (isEquipped) {
        action.textContent = 'Unequip';
        action.dataset['unequipSlot'] = definition.slot;
      } else {
        action.textContent = 'Equip';
        action.dataset['equipEquipment'] = equipmentId;
      }
      row.append(details, action);
      rows.push(row);
    }
    this.inventoryOwnedEquipment.replaceChildren(...rows);
  }

  private refreshForgeUi(): void {
    if (!this.smeltRecipesElement || !this.craftRecipesElement) return;

    const smeltCards: HTMLElement[] = [];
    for (const recipe of SMELTING_RECIPES) {
      const card = document.createElement('article');
      card.className = 'recipe-card';
      const heading = document.createElement('h3');
      heading.textContent = recipe.name;
      const description = document.createElement('p');
      description.className = 'recipe-description';
      description.textContent = recipe.description;
      const cost = document.createElement('p');
      cost.className = 'recipe-cost';
      cost.textContent = `${this.formatCosts(recipe.inputs)}  →  ${this.formatCosts(recipe.outputs)}`;
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'recipe-action';
      button.dataset['smeltRecipe'] = recipe.id;
      const affordable = this.forgeSystem.canSmelt(recipe.id);
      button.disabled = !affordable;
      button.textContent = affordable ? 'Smelt ingot' : 'Need ore';
      card.append(heading, description, cost, button);
      smeltCards.push(card);
    }
    this.smeltRecipesElement.replaceChildren(...smeltCards);

    const craftCards: HTMLElement[] = [];
    for (const recipe of CRAFTING_RECIPES) {
      const definition = EQUIPMENT_DEFINITIONS[recipe.equipmentId];
      const card = document.createElement('article');
      card.className = 'recipe-card';
      const heading = document.createElement('h3');
      heading.textContent = definition.name;
      const description = document.createElement('p');
      description.className = 'recipe-description';
      description.textContent = definition.description;
      const stats = document.createElement('p');
      stats.className = 'recipe-stats';
      stats.textContent = this.describeEquipment(recipe.equipmentId);
      const cost = document.createElement('p');
      cost.className = 'recipe-cost';
      cost.textContent = `Cost: ${this.formatCosts(recipe.costs)}`;
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'recipe-action';

      if (this.inventory.hasEquipment(recipe.equipmentId)) {
        const equippedId = definition.slot === 'pickaxe'
          ? this.inventory.equipmentSnapshot().equippedPickaxeId
          : this.inventory.equipmentSnapshot().equippedWeaponId;
        const isEquipped = equippedId === recipe.equipmentId;
        button.dataset['equipEquipment'] = recipe.equipmentId;
        button.disabled = isEquipped;
        button.textContent = isEquipped ? 'Equipped' : 'Equip';
      } else {
        const craftable = this.forgeSystem.canCraft(recipe.id);
        button.dataset['craftRecipe'] = recipe.id;
        button.disabled = !craftable;
        button.textContent = craftable ? 'Craft equipment' : 'Need materials';
      }
      card.append(heading, description, stats, cost, button);
      craftCards.push(card);
    }
    this.craftRecipesElement.replaceChildren(...craftCards);
    this.refreshGearTradeUi();
  }

  private handleForgePanelClick(event: MouseEvent): void {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const button = target.closest('button');
    if (!(button instanceof HTMLButtonElement) || button.disabled) return;

    const smeltRecipeId = button.dataset['smeltRecipe'];
    if (smeltRecipeId) {
      this.deferInventoryPersist = true;
      const result = this.forgeSystem.smelt(smeltRecipeId);
      this.deferInventoryPersist = false;
      this.forgeFeedbackElement.textContent = result.message;
      if (result.ok) {
        const recipe = SMELTING_RECIPES.find((entry) => entry.id === smeltRecipeId);
        if (recipe) for (const [resourceId, amount] of Object.entries(recipe.outputs)) {
          const id = resourceId as ResourceId;
          this.questSystem.record({ type: 'smelt', resourceId: id, amount: amount ?? 0 });
          this.questSystem.record({ type: 'collect', resourceId: id, amount: amount ?? 0 });
        }
        this.refreshQuestJournal();
        if (this.tutorial.getStep() === 'smelt-ingots' && smeltRecipeId === 'smelt-copper') {
          this.tutorial.markSmelted(); this.renderTutorialPanel(); this.updateTutorialMarkerPosition();
          this.showToast('Smelting lesson complete · Trade your ingots for a gear item.');
        } else this.showToast(result.message);
        this.refreshGearTradeUi(); this.persist();
      }
      return;
    }

    const gearTradeId = button.dataset['gearTrade'];
    if (gearTradeId) {
      const card = button.closest('.gear-trade-card');
      const select = card?.querySelector('select[data-gear-material]') as HTMLSelectElement | null;
      const materialId = select?.value as GearMaterialId | undefined;
      if (!materialId || !GEAR_IDS.includes(gearTradeId as GearId)) { this.showToast('Choose a valid material and gear item.'); return; }
      this.deferInventoryPersist = true;
      const result = this.blacksmithSystem.trade(gearTradeId as GearId, materialId);
      this.deferInventoryPersist = false;
      if (!result.ok) { this.showToast(result.reason); this.refreshGearTradeUi(); return; }
      this.showToast(`Traded ingots for ${GEAR_DEFINITIONS[result.item.gearId].name} (${GEAR_MATERIALS[materialId].label}).`);
      if (this.tutorial.getStep() === 'trade-gear') {
        this.tutorial.markTraded(); this.renderTutorialPanel(); this.updateTutorialMarkerPosition();
        this.showToast('Blacksmithing lesson complete · Visit Selka to refine your gear.');
      }
      this.refreshGearInventoryUi(); this.refreshGearTradeUi(); this.persist();
      return;
    }

    const craftRecipeId = button.dataset['craftRecipe'];
    if (craftRecipeId) {
      this.deferInventoryPersist = true;
      const result = this.forgeSystem.craft(craftRecipeId);
      this.deferInventoryPersist = false;
      this.forgeFeedbackElement.textContent = result.message;
      if (result.ok) {
        this.persist();
        this.showToast(result.message);
      }
      this.refreshForgeUi();
      return;
    }

    const equipmentId = button.dataset['equipEquipment'];
    if (equipmentId) {
      const result = this.forgeSystem.equip(equipmentId as EquipmentId);
      this.forgeFeedbackElement.textContent = result.message;
      if (result.ok) this.showToast(result.message);
    }
  }

  private handleInventoryPanelClick(event: MouseEvent): void {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const button = target.closest('button');
    if (!(button instanceof HTMLButtonElement) || button.disabled) return;

    const gearInstanceId = button.dataset['equipGear'];
    if (gearInstanceId) {
      const result = this.gearInventory.equip(gearInstanceId);
      if (!result.ok || !result.item) { this.showToast(result.ok ? 'Gear could not be equipped.' : result.reason); return; }
      this.syncWeaponVisual(); this.player?.playInteractionAnimation(); this.refreshGearInventoryUi(); this.refreshGearRefinerUi(); this.updateGearEquipmentHud();
      this.showToast(`Equipped ${GEAR_DEFINITIONS[result.item.gearId].name}.`); this.persist(); return;
    }

    const equipmentId = button.dataset['equipEquipment'];
    if (equipmentId) {
      if (EQUIPMENT_DEFINITIONS[equipmentId as EquipmentId]?.slot === 'weapon') this.gearInventory.unequipWeapon();
      const result = this.forgeSystem.equip(equipmentId as EquipmentId);
      this.showToast(result.message);
      this.updateGearEquipmentHud();
      this.syncWeaponVisual();
      this.persist();
      return;
    }

    const slot = button.dataset['unequipSlot'];
    if (slot === 'pickaxe' || slot === 'weapon') {
      const result = this.inventory.unequip(slot as EquipmentSlot);
      this.showToast(result.ok ? `${slot === 'pickaxe' ? 'Pickaxe' : 'Weapon'} unequipped.` : result.reason);
      this.updateGearEquipmentHud(); this.syncWeaponVisual(); this.persist();
    }
  }

  private formatCosts(costs: ResourceCosts): string {
    return Object.entries(costs)
      .filter((entry) => (entry[1] ?? 0) > 0)
      .map(([resourceId, quantity]) => `${quantity} ${RESOURCE_DEFINITIONS[resourceId as ResourceId].shortName}`)
      .join(' + ') || 'No materials';
  }

  private describeEquipment(equipmentId: EquipmentId): string {
    const definition = EQUIPMENT_DEFINITIONS[equipmentId];
    if (definition.slot === 'pickaxe') return `Mining power ${definition.miningPower.toFixed(1)}×`;
    return `${definition.attackDamage} power · ${definition.attacksPerSecond.toFixed(2)} actions/s`;
  }

  private showToast(message: string): void {
    this.toastElement.textContent = message;
    this.toastElement.hidden = false;
    this.toastRemaining = 1.9;
  }

  private updateToast(deltaSeconds: number): void {
    if (this.toastRemaining <= 0) return;
    this.toastRemaining = Math.max(0, this.toastRemaining - deltaSeconds);
    if (this.toastRemaining === 0) this.toastElement.hidden = true;
  }

  private setInventoryOpen(open: boolean): void {
    this.renderDirty = true;
    this.inventoryOpen = open;
    if (open) {
      this.forgeOpen = false;
      this.forgePanel.hidden = true;
      this.miningSystem?.clearTarget();
      this.combatSystem?.clearTarget();
      this.clearZonePortalTarget();
      this.clearMiniGameTarget();
      this.clearDungeonTargets();
      this.forgeTargeted = false;
      this.forgeTargetInRange = false;
    }
    this.inventoryPanel.hidden = !open;
    this.input.setPointerLockEnabled(!this.isAnyOverlayOpen());
    this.input.setMenuOpen(this.isAnyOverlayOpen());
    if (!open && document.activeElement === this.closeInventoryButton) this.closeInventoryButton.blur();
  }

  private setForgeOpen(open: boolean): void {
    this.renderDirty = true;
    this.forgeOpen = open;
    if (open) {
      this.inventoryOpen = false;
      this.inventoryPanel.hidden = true;
      this.miningSystem?.clearTarget();
      this.combatSystem?.clearTarget();
      this.clearZonePortalTarget();
      this.refreshForgeUi();
    } else if (document.activeElement === this.closeForgeButton) {
      this.closeForgeButton.blur();
    }
    this.forgePanel.hidden = !open;
    this.input.setPointerLockEnabled(!this.isAnyOverlayOpen());
    this.input.setMenuOpen(this.isAnyOverlayOpen());
  }

  private persist(): void {
    if (!this.persistenceReady) return;
    const progression = this.progression.snapshot();
    const vitals = this.combatSystem?.getVitals();
    const health = vitals ? (vitals.defeated ? vitals.maximumHealth : vitals.currentHealth) : 100;
    const data = createSaveData({
      playerHealth: health,
      progression,
      inventory: this.inventory.snapshot(),
      currentZoneId: this.zoneProgression.getCurrentZoneId(),
      questState: this.questSystem.snapshot(),
      miniGameState: this.miniGameSystem.snapshot(),
      dungeonState: this.dungeonProgress.snapshot(),
      gearInventory: this.gearInventory.snapshot(),
      gearRefinement: this.gearRefinementSystem.snapshot(),
      tutorialState: this.tutorial.snapshot(),
      minimapState: this.minimap?.getSettings() ?? this.minimapState,
    });
    const result = this.saveSystem.save(data);
    if (result.ok) {
      const time = new Date(data.savedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      this.saveStatusElement.textContent = `SAVED · ${time}`;
      this.saveStatusElement.title = 'Your expedition is stored in this browser.';
      this.saveStatusElement.dataset['state'] = 'saved';
    } else {
      this.saveStatusElement.textContent = 'SAVE UNAVAILABLE';
      this.saveStatusElement.title = result.reason;
      this.saveStatusElement.dataset['state'] = 'warning';
    }
  }

  private resetSave(): void {
    const confirmed = window.confirm('Reset this Forgebound expedition? All locally saved resources, equipment, and progression will be erased.');
    if (!confirmed) return;
    const result = this.saveSystem.clear();
    if (!result.ok) {
      this.showToast(result.reason);
      this.saveStatusElement.textContent = 'RESET FAILED';
      this.saveStatusElement.dataset['state'] = 'warning';
      return;
    }
    window.location.reload();
  }

  private resize(): void {
    const width = Math.max(1, window.innerWidth);
    const height = Math.max(1, window.innerHeight);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.minimap?.resize();
    this.minimap?.update(performance.now(), true);
    this.renderDirty = true;
    this.renderer.setSize(width, height);
  }

  private disposeSceneResources(): void {
    const geometries = new Set<THREE.BufferGeometry>();
    const materials = new Set<THREE.Material>();
    this.scene.traverse((object: THREE.Object3D) => {
      if (!(object instanceof THREE.Mesh)) return;
      geometries.add(object.geometry);
      const objectMaterials = Array.isArray(object.material) ? object.material : [object.material];
      for (const material of objectMaterials) materials.add(material);
    });
    for (const geometry of geometries) geometry.dispose();
    for (const material of materials) material.dispose();
  }

  private getRequiredElement(id: string): HTMLElement {
    const element = document.getElementById(id);
    if (!element) throw new Error(`Required UI element #${id} was not found.`);
    return element;
  }
}
