import type { ResourceId } from '../types/resources';
import type { Inventory, InventoryResult } from './Inventory';

export interface RefinementPlan {
  readonly rank: 1 | 2 | 3;
  readonly name: string;
  readonly costs: Partial<Record<ResourceId, number>>;
  readonly coinCost: number;
  readonly damageBonus: number;
}

export const WEAPON_REFINEMENT_PLANS: readonly RefinementPlan[] = [
  { rank: 1, name: 'Tempered Edge', costs: { 'copper-ingot': 1, 'iron-ingot': 1 }, coinCost: 25, damageBonus: 2 },
  { rank: 2, name: 'Ashbright Edge', costs: { 'gold-ingot': 2, 'iron-ingot': 1 }, coinCost: 50, damageBonus: 4 },
  { rank: 3, name: 'Prismatic Temper', costs: { crystal: 2, 'gold-ingot': 1 }, coinCost: 100, damageBonus: 6 },
];

export type RefinementResult =
  | { readonly ok: true; readonly rank: 1 | 2 | 3; readonly plan: RefinementPlan }
  | { readonly ok: false; readonly reason: string };

export class WeaponRefinementSystem {
  constructor(private readonly inventory: Inventory) {}

  getCurrentRank(): number { return this.inventory.getWeaponRefinementRank(); }
  getNextPlan(): RefinementPlan | null { return WEAPON_REFINEMENT_PLANS[this.getCurrentRank()] ?? null; }

  refine(): RefinementResult {
    const plan = this.getNextPlan();
    if (!plan) return { ok: false, reason: 'Your equipped weapon has reached maximum refinement.' };
    const result: InventoryResult = this.inventory.refineEquippedWeapon(plan.costs, plan.coinCost);
    if (!result.ok) return { ok: false, reason: result.reason };
    return { ok: true, rank: plan.rank, plan };
  }
}
