export const TUTORIAL_STEP_IDS = [
  'movement', 'meet-ben', 'smelt-ingots', 'trade-gear', 'refine-gear', 'use-minimap',
  'find-pickaxe', 'return-pickaxe', 'receive-pickaxe', 'complete',
] as const;
export type TutorialStepId = (typeof TUTORIAL_STEP_IDS)[number];
export type PickaxeCustody = 'at-house' | 'player' | 'ben' | 'gifted';

export interface TutorialSnapshot {
  readonly step: TutorialStepId;
  readonly completed: boolean;
  readonly movementDistanceMetres: number;
  readonly pickaxeInstanceId: 'ben-lost-pickaxe-001';
  readonly pickaxeCustody: PickaxeCustody;
  readonly grantedTutorialSupplies: boolean;
  readonly createdAt: number;
}

export const BEN_PICKAXE_INSTANCE_ID = 'ben-lost-pickaxe-001' as const;

export function createInitialTutorialSnapshot(now = Date.now()): TutorialSnapshot {
  return {
    step: 'movement', completed: false, movementDistanceMetres: 0,
    pickaxeInstanceId: BEN_PICKAXE_INSTANCE_ID, pickaxeCustody: 'at-house',
    grantedTutorialSupplies: false, createdAt: Math.max(0, Math.floor(now)),
  };
}

export function createCompletedLegacyTutorialSnapshot(now = Date.now()): TutorialSnapshot {
  return {
    step: 'complete', completed: true, movementDistanceMetres: 0,
    pickaxeInstanceId: BEN_PICKAXE_INSTANCE_ID, pickaxeCustody: 'gifted',
    grantedTutorialSupplies: true, createdAt: Math.max(0, Math.floor(now)),
  };
}

export function validateTutorialSnapshot(value: unknown): value is TutorialSnapshot {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const state = value as Record<string, unknown>;
  return TUTORIAL_STEP_IDS.includes(state['step'] as TutorialStepId)
    && typeof state['completed'] === 'boolean'
    && typeof state['movementDistanceMetres'] === 'number'
    && Number.isFinite(state['movementDistanceMetres']) && state['movementDistanceMetres'] >= 0 && state['movementDistanceMetres'] <= 100_000
    && state['pickaxeInstanceId'] === BEN_PICKAXE_INSTANCE_ID
    && ['at-house', 'player', 'ben', 'gifted'].includes(String(state['pickaxeCustody']))
    && typeof state['grantedTutorialSupplies'] === 'boolean'
    && Number.isSafeInteger(state['createdAt']) && (state['createdAt'] as number) >= 0
    && (state['completed'] === (state['step'] === 'complete'))
    && (state['step'] === 'return-pickaxe' ? state['pickaxeCustody'] === 'player'
      : state['step'] === 'receive-pickaxe' ? state['pickaxeCustody'] === 'ben'
      : state['step'] === 'complete' ? state['pickaxeCustody'] === 'gifted'
      : state['pickaxeCustody'] === 'at-house')
    && (TUTORIAL_STEP_IDS.indexOf(state['step'] as TutorialStepId) < TUTORIAL_STEP_IDS.indexOf('smelt-ingots')
      || state['grantedTutorialSupplies'] === true);
}

export class TutorialSystem {
  private state: TutorialSnapshot = createInitialTutorialSnapshot();

  snapshot(): TutorialSnapshot { return { ...this.state }; }
  getStep(): TutorialStepId { return this.state.step; }
  isComplete(): boolean { return this.state.completed; }
  getPickaxeCustody(): PickaxeCustody { return this.state.pickaxeCustody; }
  isPickaxeVisibleAtHouse(): boolean { return this.state.pickaxeCustody === 'at-house'; }

  recordMovement(distanceMetres: number): boolean {
    if (this.state.completed || this.state.step !== 'movement' || !Number.isFinite(distanceMetres) || distanceMetres <= 0) return false;
    const travelled = Math.min(100_000, this.state.movementDistanceMetres + distanceMetres);
    this.state = { ...this.state, movementDistanceMetres: travelled, ...(travelled >= 3 ? { step: 'meet-ben' as const } : {}) };
    return true;
  }

  meetBen(): boolean {
    if (this.state.step !== 'meet-ben') return false;
    this.state = { ...this.state, step: 'smelt-ingots' };
    return true;
  }

  markSmelted(): boolean {
    if (this.state.step !== 'smelt-ingots') return false;
    this.state = { ...this.state, step: 'trade-gear' };
    return true;
  }

  markTraded(): boolean {
    if (this.state.step !== 'trade-gear') return false;
    this.state = { ...this.state, step: 'refine-gear' };
    return true;
  }

  markRefined(): boolean {
    if (this.state.step !== 'refine-gear') return false;
    this.state = { ...this.state, step: 'use-minimap' };
    return true;
  }

  markMinimapOpened(): boolean {
    if (this.state.step !== 'use-minimap') return false;
    this.state = { ...this.state, step: 'find-pickaxe' };
    return true;
  }

  grantTutorialSupplies(): boolean {
    if (this.state.grantedTutorialSupplies) return false;
    this.state = { ...this.state, grantedTutorialSupplies: true };
    return true;
  }

  pickUpPickaxe(instanceId: string): boolean {
    if (instanceId !== BEN_PICKAXE_INSTANCE_ID || this.state.step !== 'find-pickaxe' || this.state.pickaxeCustody !== 'at-house') return false;
    this.state = { ...this.state, step: 'return-pickaxe', pickaxeCustody: 'player' };
    return true;
  }

  handPickaxeToBen(instanceId: string): boolean {
    if (instanceId !== BEN_PICKAXE_INSTANCE_ID || this.state.step !== 'return-pickaxe' || this.state.pickaxeCustody !== 'player') return false;
    this.state = { ...this.state, step: 'receive-pickaxe', pickaxeCustody: 'ben' };
    return true;
  }

  receiveGift(instanceId: string): boolean {
    if (instanceId !== BEN_PICKAXE_INSTANCE_ID || this.state.step !== 'receive-pickaxe' || this.state.pickaxeCustody !== 'ben') return false;
    this.state = { ...this.state, step: 'complete', completed: true, pickaxeCustody: 'gifted' };
    return true;
  }

  restore(snapshot: TutorialSnapshot): boolean {
    if (!validateTutorialSnapshot(snapshot)) return false;
    this.state = { ...snapshot };
    return true;
  }
}
