import { DUNGEON_BY_ID, DUNGEON_DEFINITIONS, DUNGEON_ID_SET, DUNGEON_POI_ID_SET, type DungeonId } from '../data/dungeon-data';

export interface DungeonProgressSnapshot {
  readonly discoveredDungeonIds: readonly DungeonId[];
  readonly completedDungeonIds: readonly DungeonId[];
  readonly claimedPointIds: readonly string[];
}

export function createEmptyDungeonSnapshot(): DungeonProgressSnapshot {
  return { discoveredDungeonIds: [], completedDungeonIds: [], claimedPointIds: [] };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export function validateDungeonSnapshot(value: unknown): value is DungeonProgressSnapshot {
  if (!isRecord(value) || Object.keys(value).some((key) => !['discoveredDungeonIds', 'completedDungeonIds', 'claimedPointIds'].includes(key))) return false;
  const discovered = value['discoveredDungeonIds'];
  const completed = value['completedDungeonIds'];
  const claimed = value['claimedPointIds'];
  if (!Array.isArray(discovered) || !Array.isArray(completed) || !Array.isArray(claimed)) return false;
  if (discovered.some((id) => typeof id !== 'string' || !DUNGEON_ID_SET.has(id))
    || completed.some((id) => typeof id !== 'string' || !DUNGEON_ID_SET.has(id))
    || claimed.some((id) => typeof id !== 'string' || !DUNGEON_POI_ID_SET.has(id))) return false;
  if (new Set(discovered).size !== discovered.length || new Set(completed).size !== completed.length || new Set(claimed).size !== claimed.length) return false;
  const discoveredSet = new Set(discovered as string[]);
  const completedSet = new Set(completed as string[]);
  const claimedSet = new Set(claimed as string[]);
  if ((completed as string[]).some((id) => !discoveredSet.has(id))) return false;
  for (const dungeon of DUNGEON_DEFINITIONS) {
    const hasAnyClaim = dungeon.points.some((point) => claimedSet.has(point.id));
    if (hasAnyClaim && !discoveredSet.has(dungeon.id)) return false;
    const allClaimed = dungeon.points.every((point) => claimedSet.has(point.id));
    if (allClaimed !== completedSet.has(dungeon.id)) return false;
  }
  return true;
}

export type DungeonClaimResult =
  | { readonly ok: true; readonly newlyCompleted: boolean }
  | { readonly ok: false; readonly reason: string };

/** Tracks one-time discoveries and POI claims; it never mutates player rewards itself. */
export class DungeonProgressSystem {
  private readonly discovered = new Set<DungeonId>();
  private readonly completed = new Set<DungeonId>();
  private readonly claimedPoints = new Set<string>();

  snapshot(): DungeonProgressSnapshot {
    return {
      discoveredDungeonIds: [...this.discovered],
      completedDungeonIds: [...this.completed],
      claimedPointIds: [...this.claimedPoints],
    };
  }

  restore(snapshot: DungeonProgressSnapshot): boolean {
    if (!validateDungeonSnapshot(snapshot)) return false;
    this.discovered.clear();
    this.completed.clear();
    this.claimedPoints.clear();
    for (const id of snapshot.discoveredDungeonIds) this.discovered.add(id);
    for (const id of snapshot.completedDungeonIds) this.completed.add(id);
    for (const id of snapshot.claimedPointIds) this.claimedPoints.add(id);
    return true;
  }

  discover(dungeonId: string): boolean {
    if (!DUNGEON_ID_SET.has(dungeonId)) return false;
    const id = dungeonId as DungeonId;
    if (this.discovered.has(id)) return false;
    this.discovered.add(id);
    return true;
  }

  isDiscovered(dungeonId: string): boolean { return this.discovered.has(dungeonId as DungeonId); }
  isCompleted(dungeonId: string): boolean { return this.completed.has(dungeonId as DungeonId); }
  isPointClaimed(pointId: string): boolean { return this.claimedPoints.has(pointId); }

  wouldCompleteAfterClaim(dungeonId: string, pointId: string): boolean {
    if (!DUNGEON_ID_SET.has(dungeonId) || !DUNGEON_POI_ID_SET.has(pointId)) return false;
    const dungeon = DUNGEON_BY_ID[dungeonId as DungeonId];
    if (!dungeon.points.some((point) => point.id === pointId) || this.claimedPoints.has(pointId)) return false;
    return dungeon.points.every((point) => point.id === pointId || this.claimedPoints.has(point.id));
  }

  claimPoint(dungeonId: string, pointId: string): DungeonClaimResult {
    if (!DUNGEON_ID_SET.has(dungeonId) || !DUNGEON_POI_ID_SET.has(pointId)) return { ok: false, reason: 'Unknown landmark point.' };
    const typedId = dungeonId as DungeonId;
    const dungeon = DUNGEON_BY_ID[typedId];
    if (!this.discovered.has(typedId)) return { ok: false, reason: 'Discover the landmark before claiming its points.' };
    if (!dungeon.points.some((point) => point.id === pointId)) return { ok: false, reason: 'That point does not belong to this landmark.' };
    if (this.claimedPoints.has(pointId)) return { ok: false, reason: 'This landmark point has already been recorded.' };
    this.claimedPoints.add(pointId);
    const newlyCompleted = dungeon.points.every((point) => this.claimedPoints.has(point.id));
    if (newlyCompleted) this.completed.add(typedId);
    return { ok: true, newlyCompleted };
  }

  getPointCount(dungeonId: string): Readonly<{ claimed: number; total: number }> {
    if (!DUNGEON_ID_SET.has(dungeonId)) return { claimed: 0, total: 0 };
    const dungeon = DUNGEON_BY_ID[dungeonId as DungeonId];
    return { claimed: dungeon.points.filter((point) => this.claimedPoints.has(point.id)).length, total: dungeon.points.length };
  }

  getDiscoveryCount(): number { return this.discovered.size; }
  getCompletedCount(): number { return this.completed.size; }
}
