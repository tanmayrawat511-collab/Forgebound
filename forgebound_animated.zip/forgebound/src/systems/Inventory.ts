import { EQUIPMENT_DEFINITIONS } from '../data/equipment-data';
import { RESOURCE_IDS, type ResourceId } from '../types/resources';
import { EQUIPMENT_IDS, type EquipmentId, type EquipmentSlot, type EquipmentSnapshot, type PickaxeDefinition, type WeaponDefinition } from '../types/equipment';

export type ResourceInventorySnapshot = Readonly<Record<ResourceId, number>>;

export const STARTING_COINS = 100;
export const MAX_COIN_BALANCE = 999_999_999;

export interface InventorySnapshot {
  readonly coins: number;
  readonly resources: ResourceInventorySnapshot;
  readonly ownedEquipmentIds: readonly EquipmentId[];
  readonly equippedPickaxeId: EquipmentId | null;
  readonly equippedWeaponId: EquipmentId | null;
  readonly pickaxeInstanceId: string | null;
  readonly weaponRefinementRank: number;
}

export type InventoryResult =
  | { readonly ok: true }
  | { readonly ok: false; readonly reason: string };

const MAX_RESOURCE_STACK = 9_999;
const RESOURCE_ID_SET: ReadonlySet<string> = new Set(RESOURCE_IDS);
const EQUIPMENT_ID_SET: ReadonlySet<string> = new Set(EQUIPMENT_IDS);

function isPositiveWholeNumber(value: number): boolean {
  return Number.isSafeInteger(value) && value > 0;
}

function isResourceId(value: string): value is ResourceId {
  return RESOURCE_ID_SET.has(value);
}

function isEquipmentId(value: string): value is EquipmentId {
  return EQUIPMENT_ID_SET.has(value);
}

function validateResourceMap(costs: Partial<Record<ResourceId, number>>): string | null {
  for (const [key, quantity] of Object.entries(costs)) {
    if (!isResourceId(key)) return `Unknown resource: ${key}.`;
    if (!Number.isSafeInteger(quantity) || (quantity ?? -1) < 0) {
      return 'Resource quantities must be non-negative whole numbers.';
    }
  }
  return null;
}

export class Inventory {
  private readonly quantities = new Map<ResourceId, number>();
  private coins = STARTING_COINS;
  private readonly ownedEquipment = new Set<EquipmentId>();
  private equippedPickaxeId: EquipmentId | null = null;
  private pickaxeInstanceId: string | null = null;
  private equippedWeaponId: EquipmentId | null = 'starter-sword';
  private weaponRefinementRank = 0;
  private readonly listeners = new Set<(snapshot: InventorySnapshot) => void>();

  constructor(startingCoins = STARTING_COINS) {
    this.coins = Number.isSafeInteger(startingCoins) && startingCoins >= 0 && startingCoins <= MAX_COIN_BALANCE
      ? startingCoins
      : STARTING_COINS;
    for (const resourceId of RESOURCE_IDS) this.quantities.set(resourceId, 0);
    this.ownedEquipment.add('starter-sword');
  }

  count(resourceId: ResourceId): number {
    return this.quantities.get(resourceId) ?? 0;
  }

  getCoins(): number {
    return this.coins;
  }

  addCoins(amount: number): InventoryResult {
    if (!Number.isSafeInteger(amount) || amount <= 0) {
      return { ok: false, reason: 'Coin amounts must be positive whole numbers.' };
    }
    if (this.coins > MAX_COIN_BALANCE - amount) {
      return { ok: false, reason: 'The coin pouch is full.' };
    }
    this.coins += amount;
    this.emit();
    return { ok: true };
  }

  spendCoins(amount: number): InventoryResult {
    if (!Number.isSafeInteger(amount) || amount <= 0) {
      return { ok: false, reason: 'Coin prices must be positive whole numbers.' };
    }
    if (this.coins < amount) return { ok: false, reason: 'You do not have enough Coins.' };
    this.coins -= amount;
    this.emit();
    return { ok: true };
  }

  purchaseEquipment(equipmentId: EquipmentId, price: number): InventoryResult {
    if (!isEquipmentId(equipmentId)) return { ok: false, reason: 'Unknown equipment.' };
    if (this.ownedEquipment.has(equipmentId)) return { ok: false, reason: 'You already own this item.' };
    if (!Number.isSafeInteger(price) || price <= 0) return { ok: false, reason: 'The shop price is invalid.' };
    if (this.coins < price) return { ok: false, reason: 'You do not have enough Coins.' };
    this.coins -= price;
    this.ownedEquipment.add(equipmentId);
    this.emit();
    return { ok: true };
  }

  canAfford(resourceId: ResourceId, quantity: number): boolean {
    return isPositiveWholeNumber(quantity) && this.count(resourceId) >= quantity;
  }

  add(resourceId: ResourceId, quantity: number): InventoryResult {
    if (!isPositiveWholeNumber(quantity)) {
      return { ok: false, reason: 'Quantity must be a positive whole number.' };
    }
    return this.exchange({}, { [resourceId]: quantity });
  }

  remove(resourceId: ResourceId, quantity: number): InventoryResult {
    if (!isPositiveWholeNumber(quantity)) {
      return { ok: false, reason: 'Quantity must be a positive whole number.' };
    }
    return this.consumeAll({ [resourceId]: quantity });
  }

  canAffordAll(costs: Partial<Record<ResourceId, number>>): boolean {
    if (validateResourceMap(costs) !== null) return false;
    return RESOURCE_IDS.every((resourceId) => this.count(resourceId) >= (costs[resourceId] ?? 0));
  }

  /** Consumes all costs or none of them. Zero-cost entries are permitted. */
  consumeAll(costs: Partial<Record<ResourceId, number>>): InventoryResult {
    return this.exchange(costs, {});
  }

  canExchange(
    costs: Partial<Record<ResourceId, number>>,
    outputs: Partial<Record<ResourceId, number>>,
  ): boolean {
    if (validateResourceMap(costs) !== null || validateResourceMap(outputs) !== null) return false;
    if (!this.canAffordAll(costs)) return false;
    return RESOURCE_IDS.every((resourceId) => {
      const nextQuantity = this.count(resourceId)
        - (costs[resourceId] ?? 0)
        + (outputs[resourceId] ?? 0);
      return Number.isSafeInteger(nextQuantity) && nextQuantity >= 0 && nextQuantity <= MAX_RESOURCE_STACK;
    });
  }

  /**
   * Atomic resource exchange used by smelting: validate every input and output stack first,
   * then apply both sides and emit a single inventory update.
   */
  exchange(
    costs: Partial<Record<ResourceId, number>>,
    outputs: Partial<Record<ResourceId, number>>,
  ): InventoryResult {
    const costError = validateResourceMap(costs);
    if (costError) return { ok: false, reason: costError };
    const outputError = validateResourceMap(outputs);
    if (outputError) return { ok: false, reason: outputError };

    if (!this.canAffordAll(costs)) {
      return { ok: false, reason: 'You do not have all required materials.' };
    }

    for (const resourceId of RESOURCE_IDS) {
      const nextQuantity = this.count(resourceId)
        - (costs[resourceId] ?? 0)
        + (outputs[resourceId] ?? 0);
      if (nextQuantity > MAX_RESOURCE_STACK) {
        return { ok: false, reason: `The ${resourceId} stack limit is ${MAX_RESOURCE_STACK}.` };
      }
      if (nextQuantity < 0 || !Number.isSafeInteger(nextQuantity)) {
        return { ok: false, reason: 'The resource transaction is invalid.' };
      }
    }

    for (const resourceId of RESOURCE_IDS) {
      const cost = costs[resourceId] ?? 0;
      const output = outputs[resourceId] ?? 0;
      if (cost !== 0 || output !== 0) {
        this.quantities.set(resourceId, this.count(resourceId) - cost + output);
      }
    }
    this.emit();
    return { ok: true };
  }

  /** Atomically consumes resources and applies a signed Coin delta. */
  transactResourcesAndCoins(
    costs: Partial<Record<ResourceId, number>>,
    outputs: Partial<Record<ResourceId, number>>,
    coinDelta: number,
  ): InventoryResult {
    const costError = validateResourceMap(costs);
    if (costError) return { ok: false, reason: costError };
    const outputError = validateResourceMap(outputs);
    if (outputError) return { ok: false, reason: outputError };
    if (!Number.isSafeInteger(coinDelta)) return { ok: false, reason: 'Coin transaction must use a whole number.' };
    const nextCoins = this.coins + coinDelta;
    if (nextCoins < 0) return { ok: false, reason: 'You do not have enough Coins.' };
    if (nextCoins > MAX_COIN_BALANCE) return { ok: false, reason: 'The coin pouch is full.' };
    for (const resourceId of RESOURCE_IDS) {
      const nextQuantity = this.count(resourceId) - (costs[resourceId] ?? 0) + (outputs[resourceId] ?? 0);
      if (!Number.isSafeInteger(nextQuantity) || nextQuantity < 0 || nextQuantity > MAX_RESOURCE_STACK) {
        return { ok: false, reason: `The ${resourceId} transaction exceeds the available stack.` };
      }
    }
    for (const resourceId of RESOURCE_IDS) {
      const cost = costs[resourceId] ?? 0;
      const output = outputs[resourceId] ?? 0;
      if (cost || output) this.quantities.set(resourceId, this.count(resourceId) - cost + output);
    }
    this.coins = nextCoins;
    this.emit();
    return { ok: true };
  }

  refineEquippedWeapon(costs: Partial<Record<ResourceId, number>>, coinCost: number): InventoryResult {
    if (!this.equippedWeaponId) return { ok: false, reason: 'Equip a weapon before refining it.' };
    if (this.weaponRefinementRank >= 3) return { ok: false, reason: 'This weapon has reached the maximum refinement rank.' };
    if (!Number.isSafeInteger(coinCost) || coinCost < 0) return { ok: false, reason: 'Refinement price is invalid.' };
    const result = this.transactResourcesAndCoins(costs, {}, -coinCost);
    if (!result.ok) return result;
    this.weaponRefinementRank += 1;
    this.emit();
    return { ok: true };
  }

  getWeaponRefinementRank(): number {
    return this.weaponRefinementRank;
  }

  hasEquipment(equipmentId: EquipmentId): boolean {
    return this.ownedEquipment.has(equipmentId);
  }

  /** Grants a unique quest reward without charging materials or Coins. */
  grantEquipment(equipmentId: EquipmentId, equip = false, instanceId: string | null = null): InventoryResult {
    if (!isEquipmentId(equipmentId)) return { ok: false, reason: 'Unknown equipment.' };
    if (this.ownedEquipment.has(equipmentId)) return { ok: false, reason: 'This unique equipment has already been issued.' };
    this.ownedEquipment.add(equipmentId);
    if (EQUIPMENT_DEFINITIONS[equipmentId].slot === 'pickaxe') {
      this.pickaxeInstanceId = instanceId ?? `legacy-${equipmentId}`;
    }
    if (equip) {
      if (EQUIPMENT_DEFINITIONS[equipmentId].slot === 'pickaxe') this.equippedPickaxeId = equipmentId;
      else this.equippedWeaponId = equipmentId;
    }
    this.emit();
    return { ok: true };
  }

  equip(equipmentId: EquipmentId): InventoryResult {
    if (!this.ownedEquipment.has(equipmentId)) {
      return { ok: false, reason: 'You do not own that equipment.' };
    }
    const definition = EQUIPMENT_DEFINITIONS[equipmentId];
    if (definition.slot === 'pickaxe') this.equippedPickaxeId = equipmentId;
    else this.equippedWeaponId = equipmentId;
    this.emit();
    return { ok: true };
  }

  unequip(slot: EquipmentSlot): InventoryResult {
    if (slot === 'pickaxe') {
      if (this.equippedPickaxeId === null) return { ok: false, reason: 'No pickaxe is equipped.' };
      this.equippedPickaxeId = null;
    } else {
      if (this.equippedWeaponId === null) return { ok: false, reason: 'No weapon is equipped.' };
      this.equippedWeaponId = null;
    }
    this.emit();
    return { ok: true };
  }

  /** Validates resource costs and unique ownership before committing a crafted item. */
  craftEquipment(
    costs: Partial<Record<ResourceId, number>>,
    equipmentId: EquipmentId,
  ): InventoryResult {
    if (!isEquipmentId(equipmentId)) return { ok: false, reason: 'Unknown equipment.' };
    if (this.ownedEquipment.has(equipmentId)) {
      return { ok: false, reason: 'You already own this item.' };
    }
    const validationError = validateResourceMap(costs);
    if (validationError) return { ok: false, reason: validationError };
    if (!this.canAffordAll(costs)) {
      return { ok: false, reason: 'You do not have all required materials.' };
    }

    for (const resourceId of RESOURCE_IDS) {
      const quantity = costs[resourceId] ?? 0;
      if (quantity > 0) this.quantities.set(resourceId, this.count(resourceId) - quantity);
    }
    this.ownedEquipment.add(equipmentId);
    this.emit();
    return { ok: true };
  }

  getEquippedPickaxe(): PickaxeDefinition | null {
    if (!this.equippedPickaxeId) return null;
    const definition = EQUIPMENT_DEFINITIONS[this.equippedPickaxeId];
    return definition.slot === 'pickaxe' ? definition : null;
  }

  getEquippedWeapon(): WeaponDefinition | null {
    if (!this.equippedWeaponId) return null;
    const definition = EQUIPMENT_DEFINITIONS[this.equippedWeaponId];
    return definition.slot === 'weapon' ? { ...definition, attackDamage: definition.attackDamage + this.weaponRefinementRank * 2 } : null;
  }

  /** Restores a pre-validated snapshot as one state replacement. */
  restore(snapshot: InventorySnapshot): InventoryResult {
    if (!snapshot || typeof snapshot !== 'object' || !snapshot.resources
      || typeof snapshot.resources !== 'object' || Array.isArray(snapshot.resources)
      || Object.keys(snapshot.resources).some((id) => !RESOURCE_ID_SET.has(id))
      || !Array.isArray(snapshot.ownedEquipmentIds)
      || !('equippedPickaxeId' in snapshot) || !('equippedWeaponId' in snapshot)) {
      return { ok: false, reason: 'Inventory snapshot is malformed.' };
    }
    const restoredCoins = snapshot.coins === undefined ? 0 : snapshot.coins;
    const restoredRefinementRank = snapshot.weaponRefinementRank === undefined ? 0 : snapshot.weaponRefinementRank;
    if (!Number.isSafeInteger(restoredRefinementRank) || restoredRefinementRank < 0 || restoredRefinementRank > 3) {
      return { ok: false, reason: 'Saved weapon refinement rank is invalid.' };
    }
    if (!Number.isSafeInteger(restoredCoins) || restoredCoins < 0 || restoredCoins > MAX_COIN_BALANCE) {
      return { ok: false, reason: 'Saved coin balance is invalid.' };
    }
    const nextQuantities = new Map<ResourceId, number>();
    for (const resourceId of RESOURCE_IDS) {
      const quantity = snapshot.resources[resourceId];
      if (!Number.isSafeInteger(quantity) || quantity < 0 || quantity > MAX_RESOURCE_STACK) {
        return { ok: false, reason: `Saved quantity for ${resourceId} is invalid.` };
      }
      nextQuantities.set(resourceId, quantity);
    }
    const nextOwned = new Set<EquipmentId>();
    for (const equipmentId of snapshot.ownedEquipmentIds) {
      if (!isEquipmentId(equipmentId) || nextOwned.has(equipmentId)) {
        return { ok: false, reason: 'Saved equipment ownership is invalid.' };
      }
      nextOwned.add(equipmentId);
    }
    if (!nextOwned.has('starter-sword')) {
      return { ok: false, reason: 'The starter weapon must remain owned.' };
    }
    const pickaxeId = snapshot.equippedPickaxeId;
    const weaponId = snapshot.equippedWeaponId;
    const pickaxeInstanceId = snapshot.pickaxeInstanceId ?? (nextOwned.has('starter-pickaxe') && pickaxeId ? `legacy-${pickaxeId}` : null);
    if ((nextOwned.has('starter-pickaxe') && (typeof pickaxeInstanceId !== 'string' || !/^[a-z0-9][a-z0-9-]{2,79}$/.test(pickaxeInstanceId)))
      || (!nextOwned.has('starter-pickaxe') && pickaxeInstanceId !== null)) {
      return { ok: false, reason: 'Saved pickaxe instance identity is invalid.' };
    }
    if (pickaxeId !== null
      && (!isEquipmentId(pickaxeId) || !nextOwned.has(pickaxeId) || EQUIPMENT_DEFINITIONS[pickaxeId].slot !== 'pickaxe')) {
      return { ok: false, reason: 'Saved pickaxe slot is invalid.' };
    }
    if (weaponId !== null
      && (!isEquipmentId(weaponId) || !nextOwned.has(weaponId) || EQUIPMENT_DEFINITIONS[weaponId].slot !== 'weapon')) {
      return { ok: false, reason: 'Saved weapon slot is invalid.' };
    }

    this.coins = restoredCoins;
    this.quantities.clear();
    for (const [resourceId, quantity] of nextQuantities) this.quantities.set(resourceId, quantity);
    this.ownedEquipment.clear();
    for (const equipmentId of nextOwned) this.ownedEquipment.add(equipmentId);
    this.equippedPickaxeId = pickaxeId;
    this.pickaxeInstanceId = pickaxeInstanceId;
    this.equippedWeaponId = weaponId;
    this.weaponRefinementRank = restoredRefinementRank;
    this.emit();
    return { ok: true };
  }

  reset(): void {
    this.coins = STARTING_COINS;
    for (const resourceId of RESOURCE_IDS) this.quantities.set(resourceId, 0);
    this.ownedEquipment.clear();
    this.ownedEquipment.add('starter-sword');
    this.equippedPickaxeId = null;
    this.pickaxeInstanceId = null;
    this.equippedWeaponId = 'starter-sword';
    this.weaponRefinementRank = 0;
    this.emit();
  }

  snapshot(): InventorySnapshot {
    return {
      coins: this.coins,
      resources: this.resourceSnapshot(),
      ...this.equipmentSnapshot(),
      pickaxeInstanceId: this.pickaxeInstanceId,
      weaponRefinementRank: this.weaponRefinementRank,
    };
  }

  resourceSnapshot(): ResourceInventorySnapshot {
    const snapshot = {} as Record<ResourceId, number>;
    for (const resourceId of RESOURCE_IDS) snapshot[resourceId] = this.count(resourceId);
    return snapshot;
  }

  equipmentSnapshot(): EquipmentSnapshot {
    return {
      ownedEquipmentIds: [...this.ownedEquipment],
      equippedPickaxeId: this.equippedPickaxeId,
      equippedWeaponId: this.equippedWeaponId,
    };
  }

  subscribe(listener: (snapshot: InventorySnapshot) => void): () => void {
    this.listeners.add(listener);
    listener(this.snapshot());
    return () => this.listeners.delete(listener);
  }

  private emit(): void {
    const state = this.snapshot();
    for (const listener of this.listeners) listener(state);
  }
}
