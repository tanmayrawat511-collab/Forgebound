import { SHOP_STOCK, type ShopStockDefinition } from '../data/shop-data';
import type { EquipmentId } from '../types/equipment';
import type { ZoneId } from '../types/zones';
import { Inventory, type InventoryResult } from './Inventory';

export type ShopPurchaseResult =
  | { readonly ok: true; readonly item: ShopStockDefinition; readonly coinsRemaining: number }
  | { readonly ok: false; readonly reason: string };

/** Zone-aware equipment shop. Quest-gated stock is never exposed before its unlock quest. */
export class ShopSystem {
  constructor(private readonly inventory: Inventory) {}

  getStock(zoneId: ZoneId, playerLevel: number, isQuestCompleted: (questId: string) => boolean = () => false): readonly ShopStockDefinition[] {
    return SHOP_STOCK.filter((item) => item.zoneId === zoneId
      && playerLevel >= item.minimumPlayerLevel
      && (!item.unlockQuestId || isQuestCompleted(item.unlockQuestId)));
  }

  purchase(
    equipmentId: EquipmentId,
    zoneId: ZoneId,
    playerLevel: number,
    isQuestCompleted: (questId: string) => boolean = () => false,
  ): ShopPurchaseResult {
    const item = SHOP_STOCK.find((candidate) => candidate.equipmentId === equipmentId);
    if (!item) return { ok: false, reason: 'That item is not sold by any registered shop.' };
    if (item.zoneId !== zoneId) return { ok: false, reason: 'This item is not stocked in the current zone.' };
    if (playerLevel < item.minimumPlayerLevel) return { ok: false, reason: `Reach level ${item.minimumPlayerLevel} to purchase this item.` };
    if (item.unlockQuestId && !isQuestCompleted(item.unlockQuestId)) return { ok: false, reason: 'Complete the shopkeeper’s supply quest to unlock this stock.' };
    const result: InventoryResult = this.inventory.purchaseEquipment(item.equipmentId, item.priceCoins);
    if (!result.ok) return result;
    return { ok: true, item, coinsRemaining: this.inventory.getCoins() };
  }
}
