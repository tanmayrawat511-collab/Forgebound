import { QUEST_BY_ID, QUEST_DEFINITIONS, type QuestDefinition, type QuestObjective } from '../data/quest-data';
import type { ResourceId } from '../types/resources';
import { QUEST_WORLD_OBJECTS } from '../data/quest-world-data';
import type { ZoneId } from '../types/zones';

export type QuestStatus = 'locked' | 'available' | 'active' | 'ready-to-turn-in' | 'completed';

export interface QuestProgressSnapshot {
  readonly acceptedQuestIds: readonly string[];
  readonly completedQuestIds: readonly string[];
  readonly progress: Readonly<Record<string, Readonly<Record<string, number>>>>;
  readonly usedWorldObjectIds: readonly string[];
}

export type QuestEvent =
  | { readonly type: 'mine' | 'collect' | 'smelt' | 'craft'; readonly resourceId: ResourceId; readonly amount: number }
  | { readonly type: 'defeat'; readonly enemyId: string; readonly amount?: number }
  | { readonly type: 'interact'; readonly objectId: string; readonly amount?: number }
  | { readonly type: 'talk'; readonly npcId: string; readonly amount?: number }
  | { readonly type: 'refine'; readonly rank: number; readonly amount?: number }
  | { readonly type: 'minigame'; readonly gameId: string; readonly amount?: number };

export interface QuestObjectiveView {
  readonly id: string;
  readonly text: string;
  readonly progress: number;
  readonly target: number;
  readonly complete: boolean;
}

const QUEST_ID_SET = new Set(QUEST_DEFINITIONS.map((quest) => quest.id));
const STATUS_KEYS = new Set(['acceptedQuestIds', 'completedQuestIds', 'progress', 'usedWorldObjectIds']);
const WORLD_OBJECT_ID_SET = new Set(QUEST_WORLD_OBJECTS.map((object) => object.id));

export function createEmptyQuestSnapshot(): QuestProgressSnapshot {
  return { acceptedQuestIds: [], completedQuestIds: [], progress: {}, usedWorldObjectIds: [] };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export function validateQuestSnapshot(value: unknown): value is QuestProgressSnapshot {
  if (!isRecord(value) || Object.keys(value).some((key) => !STATUS_KEYS.has(key))) return false;
  const accepted = value['acceptedQuestIds'];
  const completed = value['completedQuestIds'];
  const progress = value['progress'];
  const usedWorldObjectIds = value['usedWorldObjectIds'];
  if (!Array.isArray(accepted) || !Array.isArray(completed) || !isRecord(progress) || !Array.isArray(usedWorldObjectIds)) return false;
  if (accepted.some((id) => typeof id !== 'string' || !QUEST_ID_SET.has(id))
    || completed.some((id) => typeof id !== 'string' || !QUEST_ID_SET.has(id))) return false;
  if (new Set(accepted).size !== accepted.length || new Set(completed).size !== completed.length) return false;
  if (usedWorldObjectIds.some((id) => typeof id !== 'string' || !WORLD_OBJECT_ID_SET.has(id))
    || new Set(usedWorldObjectIds).size !== usedWorldObjectIds.length) return false;
  const completedSet = new Set(completed as string[]);
  if ((accepted as string[]).some((id) => completedSet.has(id))) return false;
  for (const [questId, questProgress] of Object.entries(progress)) {
    if (!QUEST_ID_SET.has(questId) || !accepted.includes(questId) || !isRecord(questProgress)) return false;
    const quest = QUEST_BY_ID[questId];
    if (!quest) return false;
    if (quest.prerequisites.some((prerequisite) => !completedSet.has(prerequisite))) return false;
    const objectiveIds = new Set(quest.objectives.map((objective) => objective.id));
    const progressIds = Object.keys(questProgress);
    if (progressIds.length !== objectiveIds.size || progressIds.some((id) => !objectiveIds.has(id))) return false;
    for (const objective of quest.objectives) {
      const amount = questProgress[objective.id];
      if (!Number.isSafeInteger(amount) || (amount as number) < 0 || (amount as number) > objective.amount) return false;
    }
  }
  for (const questId of completed as string[]) {
    const quest = QUEST_BY_ID[questId];
    if (!quest || quest.prerequisites.some((prerequisite) => !completedSet.has(prerequisite))) return false;
  }
  return (accepted as string[]).every((id) => Object.hasOwn(progress, id));
}

export class QuestSystem {
  private readonly accepted = new Set<string>();
  private readonly completed = new Set<string>();
  private readonly progress = new Map<string, Map<string, number>>();
  private readonly usedWorldObjects = new Set<string>();

  getDefinitions(): readonly QuestDefinition[] { return QUEST_DEFINITIONS; }
  getDefinition(questId: string): QuestDefinition | null { return QUEST_BY_ID[questId] ?? null; }
  isCompleted(questId: string): boolean { return this.completed.has(questId); }
  canProgress(event: QuestEvent): boolean {
    for (const questId of this.accepted) {
      const quest = QUEST_BY_ID[questId];
      const progress = this.progress.get(questId);
      if (!quest || !progress) continue;
      if (quest.objectives.some((objective) => (progress.get(objective.id) ?? 0) < objective.amount && matches(objective, event))) return true;
    }
    return false;
  }

  getStatus(questId: string, activeZoneId: ZoneId, playerLevel: number): QuestStatus {
    const quest = QUEST_BY_ID[questId];
    if (!quest) return 'locked';
    if (this.completed.has(questId)) return 'completed';
    if (this.accepted.has(questId)) return this.isObjectiveSetComplete(quest) ? 'ready-to-turn-in' : 'active';
    const prerequisitesMet = quest.prerequisites.every((id) => this.completed.has(id));
    if (!prerequisitesMet || playerLevel < quest.minimumLevel || activeZoneId !== quest.zoneId) return 'locked';
    return 'available';
  }

  getNpcQuestStatus(npcId: string, activeZoneId: ZoneId, playerLevel: number): QuestStatus | null {
    const quest = QUEST_DEFINITIONS.find((candidate) => candidate.npcId === npcId);
    return quest ? this.getStatus(quest.id, activeZoneId, playerLevel) : null;
  }

  accept(questId: string, activeZoneId: ZoneId, playerLevel: number): { readonly ok: boolean; readonly reason: string } {
    const quest = QUEST_BY_ID[questId];
    if (!quest) return { ok: false, reason: 'Unknown quest.' };
    const status = this.getStatus(questId, activeZoneId, playerLevel);
    if (status === 'completed') return { ok: false, reason: 'This quest has already been completed.' };
    if (status !== 'available') {
      if (playerLevel < quest.minimumLevel) return { ok: false, reason: `Reach level ${quest.minimumLevel} to accept this quest.` };
      const unmet = quest.prerequisites.find((id) => !this.completed.has(id));
      if (unmet) return { ok: false, reason: `Complete "${QUEST_BY_ID[unmet]?.name ?? unmet}" first.` };
      return { ok: false, reason: 'This quest is not available in the current zone.' };
    }
    this.accepted.add(questId);
    this.progress.set(questId, new Map(quest.objectives.map((objective) => [objective.id, 0])));
    return { ok: true, reason: `Quest accepted: ${quest.name}.` };
  }

  record(event: QuestEvent): readonly string[] {
    const newlyReady: string[] = [];
    for (const questId of this.accepted) {
      const quest = QUEST_BY_ID[questId];
      const questProgress = this.progress.get(questId);
      if (!quest || !questProgress) continue;
      for (let index = 0; index < quest.objectives.length; index += 1) {
        const objective = quest.objectives[index];
        if (!objective) continue;
        const current = questProgress.get(objective.id) ?? 0;
        if (current >= objective.amount || !matches(objective, event)) continue;
        // Multi-step dialogue chains stay ordered (Michael -> Jason -> Michael).
        if (objective.kind === 'talk' && quest.objectives.slice(0, index).some((previous) =>
          previous.kind === 'talk' && (questProgress.get(previous.id) ?? 0) < previous.amount)) continue;
        const increment = 'amount' in event && event.amount !== undefined ? event.amount : 1;
        if (!Number.isSafeInteger(increment) || increment <= 0) continue;
        questProgress.set(objective.id, Math.min(objective.amount, current + increment));
      }
      if (this.isObjectiveSetComplete(quest)) newlyReady.push(questId);
    }
    return newlyReady;
  }

  complete(questId: string, commitRewards: () => boolean): { readonly ok: boolean; readonly reason: string } {
    const quest = QUEST_BY_ID[questId];
    if (!quest) return { ok: false, reason: 'Unknown quest.' };
    if (this.completed.has(questId)) return { ok: false, reason: 'Quest rewards have already been claimed.' };
    if (!this.accepted.has(questId) || !this.isObjectiveSetComplete(quest)) {
      return { ok: false, reason: 'Complete every objective before turning in this quest.' };
    }
    if (!commitRewards()) return { ok: false, reason: 'The reward transaction could not be completed. Check your materials and pouch capacity.' };
    this.accepted.delete(questId);
    this.progress.delete(questId);
    this.completed.add(questId);
    return { ok: true, reason: `Quest completed: ${quest.name}.` };
  }

  getObjectiveViews(questId: string): readonly QuestObjectiveView[] {
    const quest = QUEST_BY_ID[questId];
    if (!quest) return [];
    const progress = this.progress.get(questId);
    return quest.objectives.map((objective) => {
      const amount = this.completed.has(questId) ? objective.amount : progress?.get(objective.id) ?? 0;
      return { id: objective.id, text: objective.text, progress: amount, target: objective.amount, complete: amount >= objective.amount };
    });
  }

  getQuestsForNpc(npcId: string): readonly QuestDefinition[] {
    return QUEST_DEFINITIONS.filter((quest) => quest.npcId === npcId);
  }

  markWorldObjectUsed(instanceId: string): void { if (WORLD_OBJECT_ID_SET.has(instanceId)) this.usedWorldObjects.add(instanceId); }
  isWorldObjectUsed(instanceId: string): boolean { return this.usedWorldObjects.has(instanceId); }

  getCompletedQuestIds(): readonly string[] { return [...this.completed]; }
  getAcceptedQuestIds(): readonly string[] { return [...this.accepted]; }

  snapshot(): QuestProgressSnapshot {
    const progress: Record<string, Record<string, number>> = {};
    for (const [questId, objectives] of this.progress) progress[questId] = Object.fromEntries(objectives);
    return { acceptedQuestIds: [...this.accepted], completedQuestIds: [...this.completed], progress, usedWorldObjectIds: [...this.usedWorldObjects] };
  }

  restore(snapshot: QuestProgressSnapshot): boolean {
    if (!validateQuestSnapshot(snapshot)) return false;
    this.accepted.clear();
    this.completed.clear();
    this.progress.clear();
    this.usedWorldObjects.clear();
    for (const id of snapshot.usedWorldObjectIds) this.usedWorldObjects.add(id);
    for (const id of snapshot.acceptedQuestIds) this.accepted.add(id);
    for (const id of snapshot.completedQuestIds) this.completed.add(id);
    for (const [questId, objectives] of Object.entries(snapshot.progress)) {
      this.progress.set(questId, new Map(Object.entries(objectives)));
    }
    return true;
  }

  reset(): void {
    this.accepted.clear();
    this.completed.clear();
    this.progress.clear();
    this.usedWorldObjects.clear();
  }

  private isObjectiveSetComplete(quest: QuestDefinition): boolean {
    const progress = this.progress.get(quest.id);
    return Boolean(progress) && quest.objectives.every((objective) => (progress?.get(objective.id) ?? 0) >= objective.amount);
  }
}

function matches(objective: QuestObjective, event: QuestEvent): boolean {
  switch (objective.kind) {
    case 'mine': return event.type === 'mine' && event.resourceId === objective.resourceId;
    case 'collect': return event.type === 'collect' && event.resourceId === objective.resourceId;
    case 'smelt': return event.type === 'smelt' && event.resourceId === objective.resourceId;
    case 'craft': return event.type === 'craft' && event.resourceId === objective.resourceId;
    case 'defeat': return event.type === 'defeat' && event.enemyId === objective.enemyId;
    case 'interact': return event.type === 'interact' && event.objectId === objective.objectId;
    case 'talk': return event.type === 'talk' && event.npcId === objective.npcId;
    case 'refine': return event.type === 'refine' && event.rank >= objective.rank;
    case 'minigame': return event.type === 'minigame' && event.gameId === objective.gameId;
  }
}
