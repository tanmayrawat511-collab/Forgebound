/** Small procedural audio layer: settings always affect real WebAudio nodes, without external assets. */
export class AudioManager {
  private context: AudioContext | null = null;
  private musicGain: GainNode | null = null;
  private effectsGain: GainNode | null = null;
  private musicOscillators: OscillatorNode[] = [];
  private musicEnabled = true;
  private musicVolume = 0.7;
  private effectsEnabled = true;
  private effectsVolume = 0.8;

  configure(options: { musicEnabled: boolean; musicVolume: number; effectsEnabled: boolean; effectsVolume: number }): void {
    this.musicEnabled = options.musicEnabled;
    this.musicVolume = Math.min(1, Math.max(0, options.musicVolume / 100));
    this.effectsEnabled = options.effectsEnabled;
    this.effectsVolume = Math.min(1, Math.max(0, options.effectsVolume / 100));
    this.applyGains();
  }

  /** Must be called from a user gesture (Start / Continue) to satisfy browser autoplay policy. */
  async start(): Promise<void> {
    if (typeof window === 'undefined' || !('AudioContext' in window)) return;
    this.context ??= new AudioContext();
    await this.context.resume();
    if (!this.musicGain) {
      this.musicGain = this.context.createGain();
      this.musicGain.connect(this.context.destination);
      this.effectsGain = this.context.createGain();
      this.effectsGain.connect(this.context.destination);
      // A quiet, original two-note ambient bed. It is generated locally and is not a recording.
      for (const [frequency, gain] of [[110, 0.045], [164.81, 0.018]] as const) {
        const oscillator = this.context.createOscillator();
        const toneGain = this.context.createGain();
        oscillator.type = 'sine';
        oscillator.frequency.value = frequency;
        toneGain.gain.value = gain;
        oscillator.connect(toneGain).connect(this.musicGain);
        oscillator.start();
        this.musicOscillators.push(oscillator);
      }
    }
    this.applyGains();
  }

  playHit(): void { this.playTone(170, 95, 0.12, 'triangle'); }
  playDefeat(): void { this.playTone(260, 120, 0.16, 'sawtooth'); }
  playUi(): void { this.playTone(520, 55, 0.04, 'sine'); }

  dispose(): void {
    for (const oscillator of this.musicOscillators) oscillator.stop();
    this.musicOscillators = [];
    void this.context?.close();
    this.context = null;
    this.musicGain = null;
    this.effectsGain = null;
  }

  private applyGains(): void {
    if (this.musicGain) this.musicGain.gain.value = this.musicEnabled ? this.musicVolume : 0;
    if (this.effectsGain) this.effectsGain.gain.value = this.effectsEnabled ? this.effectsVolume : 0;
  }

  private playTone(frequency: number, durationMs: number, level: number, type: OscillatorType): void {
    if (!this.effectsEnabled || !this.context || !this.effectsGain) return;
    const oscillator = this.context.createOscillator();
    const envelope = this.context.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, this.context.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(40, frequency * 0.55), this.context.currentTime + durationMs / 1000);
    envelope.gain.setValueAtTime(Math.max(0.0001, level), this.context.currentTime);
    envelope.gain.exponentialRampToValueAtTime(0.0001, this.context.currentTime + durationMs / 1000);
    oscillator.connect(envelope).connect(this.effectsGain);
    oscillator.start();
    oscillator.stop(this.context.currentTime + durationMs / 1000 + 0.01);
  }
}
