import { EQUIPMENT_DEFINITIONS } from '../data/equipment-data';
import { ZONE_DEFINITIONS, ZONE_ORDER } from '../data/zone-data';
import { EQUIPMENT_IDS, type EquipmentId } from '../types/equipment';
import { RESOURCE_IDS } from '../types/resources';
import { ZONE_IDS, type ZoneId } from '../types/zones';
import type { InventorySnapshot } from './Inventory';
import { createEmptyGearInventorySnapshot, validateGearInventorySnapshot } from './GearInventorySystem';
import type { GearInventorySnapshot } from '../types/gear';
import { createEmptyGearRefinementSnapshot, validateGearRefinementSnapshot } from './GearRefinementSystem';
import type { GearRefinementSnapshot } from '../types/gear';
import { createCompletedLegacyTutorialSnapshot, validateTutorialSnapshot, type TutorialSnapshot } from './TutorialSystem';
import type { ProgressionSnapshot } from '../types/combat';
import { createEmptyQuestSnapshot, validateQuestSnapshot, type QuestProgressSnapshot } from './QuestSystem';
import { createEmptyMiniGameSnapshot, validateMiniGameSnapshot, type MiniGameSnapshot } from './MiniGameSystem';
import { createEmptyDungeonSnapshot, validateDungeonSnapshot, type DungeonProgressSnapshot } from './DungeonProgressSystem';

export const SAVE_SCHEMA_VERSION = 6;
export const SAVE_STORAGE_KEY = 'forgebound.save.v6';
export const PREVIOUS_SAVE_STORAGE_KEY = 'forgebound.save.v5';
export const OLDER_SAVE_STORAGE_KEY = 'forgebound.save.v4';
export const LEGACY_SAVE_STORAGE_KEY = 'forgebound.save.v3';
export const OLDEST_SAVE_STORAGE_KEY = 'forgebound.save.v2';
export const OLDEST_LEGACY_SAVE_STORAGE_KEY = 'forgebound.save.v1';

export interface MinimapSnapshot { readonly northLocked: boolean; readonly zoom: number; }
export const DEFAULT_MINIMAP_SNAPSHOT: MinimapSnapshot = { northLocked: true, zoom: 1 };
export const MAX_RESOURCE_STACK = 9_999;
export const MAX_PLAYER_HEALTH = 100;

export interface SaveGameData {
  readonly schemaVersion: typeof SAVE_SCHEMA_VERSION;
  readonly savedAt: number;
  readonly playerHealth: number;
  readonly progression: Pick<ProgressionSnapshot, 'level' | 'currentXp' | 'totalXp'>;
  readonly inventory: InventorySnapshot;
  readonly unlockedZoneIds: readonly ZoneId[];
  readonly currentZoneId: ZoneId;
  readonly checkpointId: ZoneId;
  readonly questState: QuestProgressSnapshot;
  readonly miniGameState: MiniGameSnapshot;
  readonly dungeonState: DungeonProgressSnapshot;
  readonly gearInventory: GearInventorySnapshot;
  readonly gearRefinement: GearRefinementSnapshot;
  readonly tutorialState: TutorialSnapshot;
  readonly minimapState: MinimapSnapshot;
}

export interface SaveCapture {
  readonly playerHealth: number;
  readonly progression: ProgressionSnapshot;
  readonly inventory: InventorySnapshot;
  readonly currentZoneId: ZoneId;
  readonly questState: QuestProgressSnapshot;
  readonly miniGameState: MiniGameSnapshot;
  readonly dungeonState: DungeonProgressSnapshot;
  readonly gearInventory: GearInventorySnapshot;
  readonly gearRefinement: GearRefinementSnapshot;
  readonly tutorialState: TutorialSnapshot;
  readonly minimapState: MinimapSnapshot;
}

export interface StorageLike {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

export type SaveValidationResult =
  | { readonly ok: true; readonly data: SaveGameData; readonly migrated: boolean }
  | { readonly ok: false; readonly reason: string };

export type SaveLoadResult =
  | { readonly status: 'new' }
  | { readonly status: 'loaded'; readonly data: SaveGameData }
  | { readonly status: 'migrated'; readonly data: SaveGameData }
  | { readonly status: 'invalid'; readonly reason: string }
  | { readonly status: 'unavailable'; readonly reason: string };

export type SaveWriteResult =
  | { readonly ok: true }
  | { readonly ok: false; readonly reason: string };

const RESOURCE_ID_SET: ReadonlySet<string> = new Set(RESOURCE_IDS);
const EQUIPMENT_ID_SET: ReadonlySet<string> = new Set(EQUIPMENT_IDS);
const ZONE_ID_SET: ReadonlySet<string> = new Set(ZONE_IDS);

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isSafeIntegerBetween(value: unknown, minimum: number, maximum: number): value is number {
  return typeof value === 'number'
    && Number.isSafeInteger(value)
    && value >= minimum
    && value <= maximum;
}

function isZoneId(value: unknown): value is ZoneId {
  return typeof value === 'string' && ZONE_ID_SET.has(value);
}

function totalXpRequiredBeforeLevel(level: number): number {
  let total = 0;
  for (let currentLevel = 1; currentLevel < level; currentLevel += 1) {
    total += 50 + (currentLevel - 1) * 35;
  }
  return total;
}

function validateProgression(value: unknown): SaveValidationResult | null {
  if (!isRecord(value)) return { ok: false, reason: 'Progression data is missing.' };
  const level = value['level'];
  const currentXp = value['currentXp'];
  const totalXp = value['totalXp'];
  if (!isSafeIntegerBetween(level, 1, 99)
    || !isSafeIntegerBetween(currentXp, 0, Number.MAX_SAFE_INTEGER)
    || !isSafeIntegerBetween(totalXp, 0, Number.MAX_SAFE_INTEGER)) {
    return { ok: false, reason: 'Progression values are outside their valid ranges.' };
  }
  const expectedTotal = totalXpRequiredBeforeLevel(level) + currentXp;
  if (!Number.isSafeInteger(expectedTotal) || expectedTotal !== totalXp) {
    return { ok: false, reason: 'Progression XP totals do not match the saved level.' };
  }
  if (level < 99 && currentXp >= 50 + (level - 1) * 35) {
    return { ok: false, reason: 'Current XP exceeds the threshold for the saved level.' };
  }
  return null;
}

function validateInventory(value: unknown): SaveValidationResult | null {
  if (!isRecord(value)) return { ok: false, reason: 'Inventory data is missing.' };
  const resourcesValue = value['resources'];
  if (!isRecord(resourcesValue)) return { ok: false, reason: 'Resource inventory is malformed.' };
  const coins = value['coins'];
  if (!isSafeIntegerBetween(coins, 0, 999_999_999)) {
    return { ok: false, reason: 'Saved coin balance is invalid.' };
  }
  if (!isSafeIntegerBetween(value['weaponRefinementRank'], 0, 3)) {
    return { ok: false, reason: 'Saved weapon refinement rank is invalid.' };
  }
  for (const resourceId of RESOURCE_IDS) {
    if (!isSafeIntegerBetween(resourcesValue[resourceId], 0, MAX_RESOURCE_STACK)) {
      return { ok: false, reason: `Saved quantity for ${resourceId} is invalid.` };
    }
  }
  if (Object.keys(resourcesValue).some((key) => !RESOURCE_ID_SET.has(key))) {
    return { ok: false, reason: 'Inventory contains an unknown resource.' };
  }

  const ownedValue = value['ownedEquipmentIds'];
  if (!Array.isArray(ownedValue) || ownedValue.some((id) => typeof id !== 'string' || !EQUIPMENT_ID_SET.has(id))) {
    return { ok: false, reason: 'Owned equipment list is invalid.' };
  }
  const owned = ownedValue as string[];
  if (new Set(owned).size !== owned.length) return { ok: false, reason: 'Owned equipment contains duplicates.' };
  if (!owned.includes('starter-sword')) {
    return { ok: false, reason: 'The starter weapon must remain owned.' };
  }

  const pickaxeInstanceId = value['pickaxeInstanceId'];
  if (owned.includes('starter-pickaxe') && (typeof pickaxeInstanceId !== 'string' || !/^[a-z0-9][a-z0-9-]{2,79}$/.test(pickaxeInstanceId))) {
    return { ok: false, reason: 'Pickaxe instance identity is invalid.' };
  }
  if (!owned.includes('starter-pickaxe') && pickaxeInstanceId !== null) {
    return { ok: false, reason: 'An unowned pickaxe cannot have an instance identity.' };
  }
  const equippedPickaxe = value['equippedPickaxeId'];
  const equippedWeapon = value['equippedWeaponId'];
  if (equippedPickaxe !== null && (typeof equippedPickaxe !== 'string' || !EQUIPMENT_ID_SET.has(equippedPickaxe))) {
    return { ok: false, reason: 'Equipped pickaxe ID is invalid.' };
  }
  if (equippedWeapon !== null && (typeof equippedWeapon !== 'string' || !EQUIPMENT_ID_SET.has(equippedWeapon))) {
    return { ok: false, reason: 'Equipped weapon ID is invalid.' };
  }
  if (equippedPickaxe !== null) {
    if (!owned.includes(equippedPickaxe) || EQUIPMENT_DEFINITIONS[equippedPickaxe as EquipmentId].slot !== 'pickaxe') {
      return { ok: false, reason: 'Equipped pickaxe is not owned or has the wrong slot.' };
    }
  }
  if (equippedWeapon !== null) {
    if (!owned.includes(equippedWeapon) || EQUIPMENT_DEFINITIONS[equippedWeapon as EquipmentId].slot !== 'weapon') {
      return { ok: false, reason: 'Equipped weapon is not owned or has the wrong slot.' };
    }
  }
  return null;
}

function makeValidatedData(value: Record<string, unknown>, migrated: boolean): SaveValidationResult {
  const savedAt = value['savedAt'];
  const playerHealth = value['playerHealth'];
  const progression = value['progression'];
  const inventory = value['inventory'];
  const currentZoneId = value['currentZoneId'];
  const checkpointId = value['checkpointId'];
  const unlockedZoneIds = value['unlockedZoneIds'];

  if (!isSafeIntegerBetween(savedAt, 1, Number.MAX_SAFE_INTEGER)) {
    return { ok: false, reason: 'Save timestamp is invalid.' };
  }
  if (!isSafeIntegerBetween(playerHealth, 1, MAX_PLAYER_HEALTH)) {
    return { ok: false, reason: 'Saved vitality is invalid.' };
  }
  const progressionError = validateProgression(progression);
  if (progressionError) return progressionError;
  const inventoryError = validateInventory(inventory);
  if (inventoryError) return inventoryError;
  if (!validateQuestSnapshot(value['questState'])) return { ok: false, reason: 'Saved quest progress is invalid.' };
  if (!validateMiniGameSnapshot(value['miniGameState'])) return { ok: false, reason: 'Saved mini-game progress is invalid.' };
  if (!validateDungeonSnapshot(value['dungeonState'])) return { ok: false, reason: 'Saved exploration progress is invalid.' };
  if (!validateGearInventorySnapshot(value['gearInventory'])) return { ok: false, reason: 'Saved gear inventory is invalid.' };
  if (!validateGearRefinementSnapshot(value['gearRefinement'])) return { ok: false, reason: 'Saved gear refinement pity data is invalid.' };
  if (!validateTutorialSnapshot(value['tutorialState'])) return { ok: false, reason: 'Saved tutorial progress is invalid.' };
  const minimapValue = value['minimapState'];
  if (!isRecord(minimapValue) || typeof minimapValue['northLocked'] !== 'boolean'
    || typeof minimapValue['zoom'] !== 'number' || !Number.isFinite(minimapValue['zoom'])
    || minimapValue['zoom'] < 0.6 || minimapValue['zoom'] > 2.5) {
    return { ok: false, reason: 'Saved minimap settings are invalid.' };
  }
  if (!isZoneId(currentZoneId) || !isZoneId(checkpointId)) {
    return { ok: false, reason: 'Saved zone or checkpoint is unknown.' };
  }
  if (currentZoneId !== checkpointId) {
    return { ok: false, reason: 'The saved checkpoint must match the current safe zone.' };
  }

  const levelValue = isRecord(progression) ? progression['level'] : undefined;
  if (!isSafeIntegerBetween(levelValue, 1, 99)) {
    return { ok: false, reason: 'Progression level is invalid.' };
  }
  const level = levelValue;
  const expectedUnlocked = ZONE_ORDER.filter((zoneId) => ZONE_DEFINITIONS[zoneId].requiredLevel <= level);
  if (!Array.isArray(unlockedZoneIds)
    || unlockedZoneIds.length !== expectedUnlocked.length
    || new Set(unlockedZoneIds).size !== expectedUnlocked.length
    || unlockedZoneIds.some((id) => !isZoneId(id) || !expectedUnlocked.includes(id))) {
    return { ok: false, reason: 'Unlocked zone data does not match the saved level.' };
  }
  if (!expectedUnlocked.includes(currentZoneId)) {
    return { ok: false, reason: 'The current zone is locked at the saved level.' };
  }

  const snapshot = progression as { level: number; currentXp: number; totalXp: number };
  const inventorySnapshot = inventory as InventorySnapshot;
  const data: SaveGameData = {
    schemaVersion: SAVE_SCHEMA_VERSION,
    savedAt,
    playerHealth,
    progression: {
      level: snapshot.level,
      currentXp: snapshot.currentXp,
      totalXp: snapshot.totalXp,
    },
    inventory: {
      coins: inventorySnapshot.coins,
      weaponRefinementRank: inventorySnapshot.weaponRefinementRank,
      resources: { ...inventorySnapshot.resources },
      ownedEquipmentIds: [...inventorySnapshot.ownedEquipmentIds],
      equippedPickaxeId: inventorySnapshot.equippedPickaxeId,
      equippedWeaponId: inventorySnapshot.equippedWeaponId,
      pickaxeInstanceId: inventorySnapshot.pickaxeInstanceId,
    },
    unlockedZoneIds: [...expectedUnlocked],
    currentZoneId,
    checkpointId,
    questState: value['questState'] as QuestProgressSnapshot,
    miniGameState: value['miniGameState'] as MiniGameSnapshot,
    dungeonState: value['dungeonState'] as DungeonProgressSnapshot,
    gearInventory: value['gearInventory'] as GearInventorySnapshot,
    gearRefinement: value['gearRefinement'] as GearRefinementSnapshot,
    tutorialState: value['tutorialState'] as TutorialSnapshot,
    minimapState: { northLocked: minimapValue['northLocked'], zoom: minimapValue['zoom'] },
  };
  return { ok: true, data, migrated };
}

/** Validates current schema saves. It never trusts values read from localStorage. */
export function validateSaveData(value: unknown): SaveValidationResult {
  if (!isRecord(value)) return { ok: false, reason: 'Save data is not an object.' };
  if (value['schemaVersion'] !== SAVE_SCHEMA_VERSION) {
    return { ok: false, reason: `Unsupported save schema version: ${String(value['schemaVersion'])}.` };
  }
  return makeValidatedData(value, false);
}

/** Version 0 did not persist a separate checkpoint or explicit derived unlock list. */
export function migrateSaveData(value: unknown): SaveValidationResult {
  if (!isRecord(value) || value['schemaVersion'] !== 0) {
    return { ok: false, reason: 'This is not a supported legacy save.' };
  }
  const progression = value['progression'];
  if (!isRecord(progression) || !isSafeIntegerBetween(progression['level'], 1, 99)) {
    return { ok: false, reason: 'Legacy progression data is invalid.' };
  }
  const currentZoneId = isZoneId(value['currentZoneId']) ? value['currentZoneId'] : 'starter-quarry';
  const level = progression['level'];
  const unlockedZoneIds = ZONE_ORDER.filter((zoneId) => ZONE_DEFINITIONS[zoneId].requiredLevel <= level);
  const oldInventory = isRecord(value['inventory']) ? value['inventory'] : {};
  const migrated: Record<string, unknown> = {
    ...value,
    schemaVersion: SAVE_SCHEMA_VERSION,
    gearInventory: createEmptyGearInventorySnapshot(),
    gearRefinement: createEmptyGearRefinementSnapshot(),
    tutorialState: createCompletedLegacyTutorialSnapshot(),
    minimapState: DEFAULT_MINIMAP_SNAPSHOT,
    inventory: migrateInventory(oldInventory, 0),
    questState: createEmptyQuestSnapshot(),
    miniGameState: createEmptyMiniGameSnapshot(),
    dungeonState: createEmptyDungeonSnapshot(),
    savedAt: isSafeIntegerBetween(value['savedAt'], 1, Number.MAX_SAFE_INTEGER) ? value['savedAt'] : Date.now(),
    playerHealth: isSafeIntegerBetween(value['playerHealth'], 1, MAX_PLAYER_HEALTH) ? value['playerHealth'] : MAX_PLAYER_HEALTH,
    currentZoneId: unlockedZoneIds.includes(currentZoneId) ? currentZoneId : 'starter-quarry',
    checkpointId: unlockedZoneIds.includes(currentZoneId) ? currentZoneId : 'starter-quarry',
    unlockedZoneIds,
  };
  return makeValidatedData(migrated, true);
}

/** Version 1 saves had no wallet; preserve progress and initialize the new wallet at zero. */
export function migrateVersionOneSaveData(value: unknown): SaveValidationResult {
  if (!isRecord(value) || value['schemaVersion'] !== 1 || !isRecord(value['inventory'])) {
    return { ok: false, reason: 'This is not a supported version 1 save.' };
  }
  const migrated: Record<string, unknown> = {
    ...value,
    schemaVersion: SAVE_SCHEMA_VERSION,
    gearInventory: createEmptyGearInventorySnapshot(),
    gearRefinement: createEmptyGearRefinementSnapshot(),
    tutorialState: createCompletedLegacyTutorialSnapshot(),
    minimapState: DEFAULT_MINIMAP_SNAPSHOT,
    inventory: migrateInventory(value['inventory'], 0),
    questState: createEmptyQuestSnapshot(),
    miniGameState: createEmptyMiniGameSnapshot(),
    dungeonState: createEmptyDungeonSnapshot(),
  };
  return makeValidatedData(migrated, true);
}

/** Version 2 saves already had Coins but predate the expanded Phase J2 resources and quest journal. */
export function migrateVersionTwoSaveData(value: unknown): SaveValidationResult {
  if (!isRecord(value) || value['schemaVersion'] !== 2 || !isRecord(value['inventory'])) {
    return { ok: false, reason: 'This is not a supported version 2 save.' };
  }
  const migrated: Record<string, unknown> = {
    ...value,
    schemaVersion: SAVE_SCHEMA_VERSION,
    gearInventory: createEmptyGearInventorySnapshot(),
    gearRefinement: createEmptyGearRefinementSnapshot(),
    tutorialState: createCompletedLegacyTutorialSnapshot(),
    minimapState: DEFAULT_MINIMAP_SNAPSHOT,
    inventory: migrateInventory(value['inventory'], 0),
    questState: createEmptyQuestSnapshot(),
    miniGameState: createEmptyMiniGameSnapshot(),
    dungeonState: createEmptyDungeonSnapshot(),
  };
  return makeValidatedData(migrated, true);
}

/** Version 3 saves contain the complete J2 quest state; preserve it while adding J3 medals. */
export function migrateVersionThreeSaveData(value: unknown): SaveValidationResult {
  if (!isRecord(value) || value['schemaVersion'] !== 3 || !isRecord(value['inventory'])) {
    return { ok: false, reason: 'This is not a supported version 3 save.' };
  }
  const migrated: Record<string, unknown> = {
    ...value,
    schemaVersion: SAVE_SCHEMA_VERSION,
    gearInventory: createEmptyGearInventorySnapshot(),
    gearRefinement: createEmptyGearRefinementSnapshot(),
    tutorialState: createCompletedLegacyTutorialSnapshot(),
    minimapState: DEFAULT_MINIMAP_SNAPSHOT,
    inventory: { ...migrateInventory(value['inventory'], 0), weaponRefinementRank: isSafeIntegerBetween(value['inventory']['weaponRefinementRank'], 0, 3) ? value['inventory']['weaponRefinementRank'] : 0 },
    questState: value['questState'] ?? createEmptyQuestSnapshot(),
    miniGameState: createEmptyMiniGameSnapshot(),
    dungeonState: createEmptyDungeonSnapshot(),
  };
  return makeValidatedData(migrated, true);
}

/** Version 4 saves include J3 mini-game medals; preserve them and initialize J4 exploration progress. */
export function migrateVersionFourSaveData(value: unknown): SaveValidationResult {
  if (!isRecord(value) || value['schemaVersion'] !== 4 || !isRecord(value['inventory'])) {
    return { ok: false, reason: 'This is not a supported version 4 save.' };
  }
  const migrated: Record<string, unknown> = {
    ...value,
    schemaVersion: SAVE_SCHEMA_VERSION,
    gearInventory: createEmptyGearInventorySnapshot(),
    gearRefinement: createEmptyGearRefinementSnapshot(),
    tutorialState: createCompletedLegacyTutorialSnapshot(),
    minimapState: DEFAULT_MINIMAP_SNAPSHOT,
    inventory: { ...migrateInventory(value['inventory'], 0), weaponRefinementRank: isSafeIntegerBetween(value['inventory']['weaponRefinementRank'], 0, 3) ? value['inventory']['weaponRefinementRank'] : 0 },
    questState: value['questState'] ?? createEmptyQuestSnapshot(),
    miniGameState: value['miniGameState'] ?? createEmptyMiniGameSnapshot(),
    dungeonState: createEmptyDungeonSnapshot(),
  };
  return makeValidatedData(migrated, true);
}


/** Version 5 is the shipped J6 save. Preserve its inventory and quest progress,
 * and initialise the J7-only state without forcing existing players through the tutorial. */
export function migrateVersionFiveSaveData(value: unknown): SaveValidationResult {
  if (!isRecord(value) || value['schemaVersion'] !== 5 || !isRecord(value['inventory'])) {
    return { ok: false, reason: 'This is not a supported version 5 save.' };
  }
  const oldInventory = value['inventory'];
  const migrated: Record<string, unknown> = {
    ...value,
    schemaVersion: SAVE_SCHEMA_VERSION,
    inventory: {
      ...migrateInventory(oldInventory, 0),
      weaponRefinementRank: isSafeIntegerBetween(oldInventory['weaponRefinementRank'], 0, 3) ? oldInventory['weaponRefinementRank'] : 0,
    },
    gearInventory: createEmptyGearInventorySnapshot(),
    gearRefinement: createEmptyGearRefinementSnapshot(),
    tutorialState: createCompletedLegacyTutorialSnapshot(),
    minimapState: DEFAULT_MINIMAP_SNAPSHOT,
  };
  return makeValidatedData(migrated, true);
}

function migrateInventory(oldInventory: Record<string, unknown>, defaultCoins: number): Record<string, unknown> {
  const oldResources = isRecord(oldInventory['resources']) ? oldInventory['resources'] : {};
  const resources: Record<string, number> = {};
  for (const resourceId of RESOURCE_IDS) {
    const oldAmount = oldResources[resourceId];
    resources[resourceId] = isSafeIntegerBetween(oldAmount, 0, MAX_RESOURCE_STACK) ? oldAmount : 0;
  }
  return {
    ...oldInventory,
    coins: isSafeIntegerBetween(oldInventory['coins'], 0, 999_999_999) ? oldInventory['coins'] : defaultCoins,
    weaponRefinementRank: 0,
    resources,
    pickaxeInstanceId: Array.isArray(oldInventory['ownedEquipmentIds']) && oldInventory['ownedEquipmentIds'].includes('starter-pickaxe')
      ? (typeof oldInventory['pickaxeInstanceId'] === 'string' ? oldInventory['pickaxeInstanceId'] : `legacy-${typeof oldInventory['equippedPickaxeId'] === 'string' ? oldInventory['equippedPickaxeId'] : 'starter-pickaxe'}`)
      : null,
  };
}

export function createSaveData(capture: SaveCapture, savedAt = Date.now()): SaveGameData {
  const level = capture.progression.level;
  return {
    schemaVersion: SAVE_SCHEMA_VERSION,
    savedAt,
    playerHealth: Math.max(1, Math.min(MAX_PLAYER_HEALTH, Math.floor(capture.playerHealth))),
    progression: {
      level,
      currentXp: capture.progression.currentXp,
      totalXp: capture.progression.totalXp,
    },
    inventory: {
      coins: capture.inventory.coins,
      weaponRefinementRank: capture.inventory.weaponRefinementRank,
      resources: { ...capture.inventory.resources },
      ownedEquipmentIds: [...capture.inventory.ownedEquipmentIds],
      equippedPickaxeId: capture.inventory.equippedPickaxeId,
      equippedWeaponId: capture.inventory.equippedWeaponId,
      pickaxeInstanceId: capture.inventory.pickaxeInstanceId,
    },
    unlockedZoneIds: ZONE_ORDER.filter((zoneId) => ZONE_DEFINITIONS[zoneId].requiredLevel <= level),
    currentZoneId: capture.currentZoneId,
    checkpointId: capture.currentZoneId,
    questState: capture.questState,
    miniGameState: capture.miniGameState,
    dungeonState: capture.dungeonState,
    gearInventory: capture.gearInventory ?? createEmptyGearInventorySnapshot(),
    gearRefinement: capture.gearRefinement ?? createEmptyGearRefinementSnapshot(),
    tutorialState: capture.tutorialState ?? createCompletedLegacyTutorialSnapshot(),
    minimapState: capture.minimapState ?? DEFAULT_MINIMAP_SNAPSHOT,
  };
}

export class SaveSystem {
  constructor(private readonly storage: StorageLike | null) {}

  load(): SaveLoadResult {
    if (!this.storage) return { status: 'unavailable', reason: 'Browser storage is unavailable.' };
    let serialized: string | null;
    let sourceKey = SAVE_STORAGE_KEY;
    try {
      serialized = this.storage.getItem(SAVE_STORAGE_KEY);
      if (serialized === null) {
        sourceKey = PREVIOUS_SAVE_STORAGE_KEY;
        serialized = this.storage.getItem(PREVIOUS_SAVE_STORAGE_KEY);
      }
      if (serialized === null) {
        sourceKey = OLDER_SAVE_STORAGE_KEY;
        serialized = this.storage.getItem(OLDER_SAVE_STORAGE_KEY);
      }
      if (serialized === null) {
        sourceKey = LEGACY_SAVE_STORAGE_KEY;
        serialized = this.storage.getItem(LEGACY_SAVE_STORAGE_KEY);
      }
      if (serialized === null) {
        sourceKey = OLDEST_SAVE_STORAGE_KEY;
        serialized = this.storage.getItem(OLDEST_SAVE_STORAGE_KEY);
      }
      if (serialized === null) {
        sourceKey = OLDEST_LEGACY_SAVE_STORAGE_KEY;
        serialized = this.storage.getItem(OLDEST_LEGACY_SAVE_STORAGE_KEY);
      }
    } catch {
      return { status: 'unavailable', reason: 'Browser storage could not be read.' };
    }
    if (serialized === null) return { status: 'new' };

    let parsed: unknown;
    try {
      parsed = JSON.parse(serialized) as unknown;
    } catch {
      return { status: 'invalid', reason: 'Saved data is not valid JSON.' };
    }

    let result: SaveValidationResult;
    if (isRecord(parsed) && parsed['schemaVersion'] === 0) {
      result = migrateSaveData(parsed);
    } else if (isRecord(parsed) && parsed['schemaVersion'] === 1) {
      result = migrateVersionOneSaveData(parsed);
    } else if (isRecord(parsed) && parsed['schemaVersion'] === 2) {
      result = migrateVersionTwoSaveData(parsed);
    } else if (isRecord(parsed) && parsed['schemaVersion'] === 3) {
      result = migrateVersionThreeSaveData(parsed);
    } else if (isRecord(parsed) && parsed['schemaVersion'] === 4) {
      result = migrateVersionFourSaveData(parsed);
    } else if (isRecord(parsed) && parsed['schemaVersion'] === 5) {
      result = migrateVersionFiveSaveData(parsed);
    } else {
      result = validateSaveData(parsed);
    }
    if (!result.ok) return { status: 'invalid', reason: result.reason };
    // A migrated legacy-key save is rewritten to the current key on the next normal save.
    return result.migrated || sourceKey !== SAVE_STORAGE_KEY
      ? { status: 'migrated', data: result.data }
      : { status: 'loaded', data: result.data };
  }

  save(data: SaveGameData): SaveWriteResult {
    if (!this.storage) return { ok: false, reason: 'Browser storage is unavailable.' };
    const validated = validateSaveData(data);
    if (!validated.ok) return { ok: false, reason: validated.reason };
    try {
      this.storage.setItem(SAVE_STORAGE_KEY, JSON.stringify(validated.data));
      return { ok: true };
    } catch {
      return { ok: false, reason: 'Save could not be written. Browser storage may be full or blocked.' };
    }
  }

  clear(): SaveWriteResult {
    if (!this.storage) return { ok: false, reason: 'Browser storage is unavailable.' };
    try {
      this.storage.removeItem(SAVE_STORAGE_KEY);
      this.storage.removeItem(LEGACY_SAVE_STORAGE_KEY);
      this.storage.removeItem(PREVIOUS_SAVE_STORAGE_KEY);
      this.storage.removeItem(OLDER_SAVE_STORAGE_KEY);
      this.storage.removeItem(OLDEST_SAVE_STORAGE_KEY);
      this.storage.removeItem(OLDEST_LEGACY_SAVE_STORAGE_KEY);
      return { ok: true };
    } catch {
      return { ok: false, reason: 'The saved expedition could not be cleared.' };
    }
  }
}
