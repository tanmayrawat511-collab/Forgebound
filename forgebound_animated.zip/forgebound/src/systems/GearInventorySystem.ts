import { GEAR_DEFINITIONS } from '../data/gear-data';
import type { GearId, GearInstanceSnapshot, GearInventorySnapshot, GearMaterialId, GearSlot } from '../types/gear';

export type GearInventoryResult = { readonly ok: true; readonly item?: GearInstanceSnapshot } | { readonly ok: false; readonly reason: string };

const VALID_TIERS = new Set([0, 1, 2, 3, 4, 5]);
const VALID_GEAR = new Set(Object.keys(GEAR_DEFINITIONS));
const VALID_MATERIALS = new Set(['copper', 'iron', 'gold', 'crystal']);
const ID_PATTERN = /^[a-z0-9][a-z0-9-]{2,79}$/;

export function createEmptyGearInventorySnapshot(): GearInventorySnapshot {
  return { items: [], equippedWeaponInstanceId: null, equippedArmorInstanceIds: [], nextInstanceSequence: 1 };
}

export function validateGearInventorySnapshot(value: unknown): value is GearInventorySnapshot {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const snapshot = value as Record<string, unknown>;
  if (!Array.isArray(snapshot['items']) || !Array.isArray(snapshot['equippedArmorInstanceIds'])
    || !Number.isSafeInteger(snapshot['nextInstanceSequence']) || (snapshot['nextInstanceSequence'] as number) < 1) return false;
  const ids = new Set<string>();
  for (const raw of snapshot['items']) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return false;
    const item = raw as Record<string, unknown>;
    if (typeof item['instanceId'] !== 'string' || !ID_PATTERN.test(item['instanceId']) || ids.has(item['instanceId'])) return false;
    if (typeof item['gearId'] !== 'string' || !VALID_GEAR.has(item['gearId'])) return false;
    if (typeof item['materialId'] !== 'string' || !VALID_MATERIALS.has(item['materialId'])) return false;
    if (typeof item['refinementTier'] !== 'number' || !VALID_TIERS.has(item['refinementTier'])) return false;
    if (!Number.isSafeInteger(item['obtainedAt']) || (item['obtainedAt'] as number) < 0) return false;
    ids.add(item['instanceId']);
  }
  const weaponId = snapshot['equippedWeaponInstanceId'];
  if (weaponId !== null) {
    const item = (snapshot['items'] as GearInstanceSnapshot[]).find((entry) => entry.instanceId === weaponId);
    if (!item || GEAR_DEFINITIONS[item.gearId].slot !== 'weapon') return false;
  }
  const armorIds = snapshot['equippedArmorInstanceIds'] as unknown[];
  if (armorIds.some((id) => typeof id !== 'string' || !ids.has(id)) || new Set(armorIds).size !== armorIds.length) return false;
  const armorSlots = new Set<GearSlot>();
  for (const id of armorIds as string[]) {
    const item = (snapshot['items'] as GearInstanceSnapshot[]).find((entry) => entry.instanceId === id);
    if (!item) return false;
    const slot = GEAR_DEFINITIONS[item.gearId].slot;
    if (slot === 'weapon' || armorSlots.has(slot)) return false;
    armorSlots.add(slot);
  }
  return true;
}

export class GearInventorySystem {
  private items: GearInstanceSnapshot[] = [];
  private equippedWeaponInstanceId: string | null = null;
  private readonly equippedArmorInstanceIds = new Set<string>();
  private nextInstanceSequence = 1;

  grant(gearId: GearId, materialId: GearMaterialId, now = Date.now()): GearInventoryResult {
    if (!VALID_GEAR.has(gearId) || !VALID_MATERIALS.has(materialId)) return { ok: false, reason: 'Unknown gear or material.' };
    const sequence = this.nextInstanceSequence++;
    const item: GearInstanceSnapshot = {
      instanceId: `gear-${sequence.toString().padStart(6, '0')}-${gearId}`,
      gearId,
      materialId,
      refinementTier: 0,
      obtainedAt: Math.max(0, Math.floor(now)),
    };
    this.items.push(item);
    return { ok: true, item };
  }

  getItems(): readonly GearInstanceSnapshot[] { return this.items.map((item) => ({ ...item })); }
  getItem(instanceId: string): GearInstanceSnapshot | null { return this.items.find((item) => item.instanceId === instanceId) ?? null; }
  getEquippedWeapon(): GearInstanceSnapshot | null { return this.equippedWeaponInstanceId ? this.getItem(this.equippedWeaponInstanceId) : null; }
  getEquippedArmor(): readonly GearInstanceSnapshot[] { return [...this.equippedArmorInstanceIds].map((id) => this.getItem(id)).filter((item): item is GearInstanceSnapshot => item !== null); }

  unequipWeapon(): void { this.equippedWeaponInstanceId = null; }

  equip(instanceId: string): GearInventoryResult {
    const item = this.getItem(instanceId);
    if (!item) return { ok: false, reason: 'You do not own that gear instance.' };
    const slot = GEAR_DEFINITIONS[item.gearId].slot;
    if (slot === 'weapon') this.equippedWeaponInstanceId = instanceId;
    else {
      for (const oldId of [...this.equippedArmorInstanceIds]) {
        const old = this.getItem(oldId);
        if (old && GEAR_DEFINITIONS[old.gearId].slot === slot) this.equippedArmorInstanceIds.delete(oldId);
      }
      this.equippedArmorInstanceIds.add(instanceId);
    }
    return { ok: true, item };
  }

  applyRefinement(instanceId: string, targetTier: number): GearInventoryResult {
    const index = this.items.findIndex((item) => item.instanceId === instanceId);
    if (index < 0) return { ok: false, reason: 'That gear instance is no longer in your inventory.' };
    if (!Number.isInteger(targetTier) || targetTier !== this.items[index]!.refinementTier + 1 || targetTier > 5) {
      return { ok: false, reason: 'Refinement must advance the selected item by exactly one tier.' };
    }
    const previous = this.items[index]!;
    const updated = { ...previous, refinementTier: targetTier as GearInstanceSnapshot['refinementTier'] };
    this.items[index] = updated;
    return { ok: true, item: updated };
  }

  restore(snapshot: GearInventorySnapshot): GearInventoryResult {
    if (!validateGearInventorySnapshot(snapshot)) return { ok: false, reason: 'Saved gear inventory is invalid.' };
    this.items = snapshot.items.map((item) => ({ ...item }));
    this.equippedWeaponInstanceId = snapshot.equippedWeaponInstanceId;
    this.equippedArmorInstanceIds.clear();
    for (const id of snapshot.equippedArmorInstanceIds) this.equippedArmorInstanceIds.add(id);
    this.nextInstanceSequence = snapshot.nextInstanceSequence;
    return { ok: true };
  }

  snapshot(): GearInventorySnapshot {
    return {
      items: this.getItems(),
      equippedWeaponInstanceId: this.equippedWeaponInstanceId,
      equippedArmorInstanceIds: [...this.equippedArmorInstanceIds],
      nextInstanceSequence: this.nextInstanceSequence,
    };
  }
}
