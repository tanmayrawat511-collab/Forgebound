import type { ProgressionSnapshot, XpAwardResult } from '../types/combat';

const MAX_LEVEL = 99;
const MAX_TOTAL_XP = Number.MAX_SAFE_INTEGER;

/** Deterministic level curve: level 1 needs 50 XP, then each level adds 35 XP. */
export function xpRequiredForLevel(level: number): number {
  if (!Number.isSafeInteger(level) || level < 1 || level > MAX_LEVEL) return 0;
  return 50 + (level - 1) * 35;
}

export class ProgressionSystem {
  private level = 1;
  private currentXp = 0;
  private totalXp = 0;

  snapshot(): ProgressionSnapshot {
    return {
      level: this.level,
      currentXp: this.currentXp,
      xpToNextLevel: xpRequiredForLevel(this.level),
      totalXp: this.totalXp,
    };
  }

  /** Cheap per-frame read; snapshot() allocates an object on every call. */
  getLevel(): number {
    return this.level;
  }

  restore(snapshot: Pick<ProgressionSnapshot, 'level' | 'currentXp' | 'totalXp'>): boolean {
    if (!snapshot
      || !Number.isSafeInteger(snapshot.level)
      || snapshot.level < 1
      || snapshot.level > MAX_LEVEL
      || !Number.isSafeInteger(snapshot.currentXp)
      || snapshot.currentXp < 0
      || !Number.isSafeInteger(snapshot.totalXp)
      || snapshot.totalXp < 0) return false;
    let requiredBeforeLevel = 0;
    for (let level = 1; level < snapshot.level; level += 1) {
      requiredBeforeLevel += xpRequiredForLevel(level);
    }
    if (requiredBeforeLevel + snapshot.currentXp !== snapshot.totalXp) return false;
    if (snapshot.level < MAX_LEVEL && snapshot.currentXp >= xpRequiredForLevel(snapshot.level)) return false;
    this.level = snapshot.level;
    this.currentXp = snapshot.currentXp;
    this.totalXp = snapshot.totalXp;
    return true;
  }

  reset(): void {
    this.level = 1;
    this.currentXp = 0;
    this.totalXp = 0;
  }

  awardXp(amount: number): XpAwardResult {
    if (!Number.isSafeInteger(amount) || amount <= 0) {
      return { ok: false, awarded: 0, levelsGained: 0, snapshot: this.snapshot() };
    }
    if (this.totalXp > MAX_TOTAL_XP - amount || this.level >= MAX_LEVEL) {
      return { ok: false, awarded: 0, levelsGained: 0, snapshot: this.snapshot() };
    }

    this.totalXp += amount;
    this.currentXp += amount;
    let levelsGained = 0;

    while (this.level < MAX_LEVEL && this.currentXp >= xpRequiredForLevel(this.level)) {
      this.currentXp -= xpRequiredForLevel(this.level);
      this.level += 1;
      levelsGained += 1;
    }

    return {
      ok: true,
      awarded: amount,
      levelsGained,
      snapshot: this.snapshot(),
    };
  }
}
