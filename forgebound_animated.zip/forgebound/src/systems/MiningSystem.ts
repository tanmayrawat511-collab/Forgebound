import * as THREE from 'three';
import { MINING_CONFIG } from '../data/mining-data';
import { OreNode } from '../entities/OreNode';
import { Inventory } from './Inventory';
import type { ZoneId } from '../types/zones';

export type MiningActionResult =
  | { readonly kind: 'no-target' }
  | { readonly kind: 'no-pickaxe' }
  | { readonly kind: 'out-of-range'; readonly node: OreNode }
  | { readonly kind: 'cooldown' }
  | { readonly kind: 'hit'; readonly node: OreNode; readonly remainingHealth: number }
  | { readonly kind: 'depleted'; readonly node: OreNode; readonly quantity: number };

export interface MiningTargetState {
  readonly node: OreNode;
  readonly inRange: boolean;
}

export class MiningSystem {
  private readonly playerPosition = new THREE.Vector3();
  private readonly nodesById = new Map<string, OreNode>();
  private currentTarget: OreNode | null = null;
  private targetInRange = false;
  private cooldownRemaining = 0;
  private activeZoneId: ZoneId = 'starter-quarry';

  constructor(
    private readonly nodes: readonly OreNode[],
    private readonly inventory: Inventory,
  ) {
    for (const node of nodes) this.nodesById.set(node.id, node);
  }

  update(deltaSeconds: number): void {
    this.cooldownRemaining = Math.max(0, this.cooldownRemaining - deltaSeconds);
    for (const node of this.nodes) {
      if (node.zoneId === this.activeZoneId) node.update(deltaSeconds);
    }
  }

  /**
   * `firstHit` is the nearest hit mining may act on, supplied by InteractionProbe.
   * Candidate filtering (active zone, live nodes, occluders) happens there.
   */
  updateTarget(firstHit: THREE.Intersection | null, playerWorldPosition: THREE.Vector3): void {
    const nodeId = firstHit?.object.userData['oreNodeId'];
    const nextTarget = typeof nodeId === 'string'
      ? this.nodesById.get(nodeId) ?? null
      : null;

    if (nextTarget !== this.currentTarget) {
      this.currentTarget?.setTargeted(false);
      this.currentTarget = nextTarget?.isAvailable() ? nextTarget : null;
      this.currentTarget?.setTargeted(true);
    }

    if (!this.currentTarget) {
      this.targetInRange = false;
      return;
    }

    this.playerPosition.copy(playerWorldPosition);
    this.targetInRange = this.playerPosition.distanceToSquared(this.currentTarget.position)
      <= MINING_CONFIG.interactionRange ** 2;
  }

  setActiveZone(zoneId: ZoneId): void {
    this.clearTarget();
    this.activeZoneId = zoneId;
  }

  clearTarget(): void {
    this.currentTarget?.setTargeted(false);
    this.currentTarget = null;
    this.targetInRange = false;
  }

  /** True while the pickaxe hit cooldown is running. Read-only; drives trigger feedback. */
  isCoolingDown(): boolean {
    return this.cooldownRemaining > 0;
  }

  getTargetState(): MiningTargetState | null {
    if (!this.currentTarget || !this.currentTarget.isAvailable()) return null;
    return { node: this.currentTarget, inRange: this.targetInRange };
  }

  mineTarget(pickaxePower: number | null = MINING_CONFIG.starterPickaxePower): MiningActionResult {
    const node = this.currentTarget;
    if (pickaxePower === null || !Number.isFinite(pickaxePower) || pickaxePower <= 0) return { kind: 'no-pickaxe' };
    if (!node || !node.isAvailable()) return { kind: 'no-target' };
    if (!this.targetInRange) return { kind: 'out-of-range', node };
    if (this.cooldownRemaining > 0) return { kind: 'cooldown' };

    const result = node.mine(pickaxePower);
    if (!result) return { kind: 'no-target' };
    this.cooldownRemaining = MINING_CONFIG.hitCooldownSeconds;

    if (!result.depleted) {
      return {
        kind: 'hit',
        node,
        remainingHealth: result.remainingHealth,
      };
    }

    const reward = this.inventory.add(node.resourceId, result.dropQuantity);
    if (!reward.ok) {
      // A stack-cap failure is exceptionally unlikely, but the node is still depleted only once.
      return { kind: 'depleted', node, quantity: 0 };
    }

    this.clearTarget();
    return {
      kind: 'depleted',
      node,
      quantity: result.dropQuantity,
    };
  }
}
