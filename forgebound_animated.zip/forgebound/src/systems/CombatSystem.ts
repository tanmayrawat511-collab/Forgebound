import * as THREE from 'three';
import { Enemy } from '../entities/Enemy';
import { Inventory } from './Inventory';
import { ProgressionSystem } from './ProgressionSystem';
import { canPacifyTarget, rollLootTable } from './CombatRules';
import { hasVisibleHit } from '../render/intersectVisible';
import type { LootDrop, ProgressionSnapshot } from '../types/combat';
import type { ResourceId } from '../types/resources';
import type { ZoneId } from '../types/zones';

export type PacificationResult =
  | { readonly kind: 'no-target' | 'cooldown' }
  | { readonly kind: 'already-pacified'; readonly enemy: Enemy }
  | { readonly kind: 'out-of-range'; readonly enemy: Enemy }
  | {
      readonly kind: 'pacified';
      readonly enemy: Enemy;
      readonly xpAwarded: number;
      readonly loot: readonly LootDrop[];
      readonly overflow: readonly ResourceId[];
      readonly levelsGained: number;
    };


export type WeaponAttackResult =
  | { readonly kind: 'no-target' | 'cooldown' | 'no-weapon' }
  | { readonly kind: 'out-of-range'; readonly enemy: Enemy }
  | { readonly kind: 'hit'; readonly enemy: Enemy; readonly damage: number; readonly remainingHealth: number }
  | {
      readonly kind: 'defeated';
      readonly enemy: Enemy;
      readonly damage: number;
      readonly xpAwarded: number;
      readonly coinsAwarded: number;
      readonly loot: readonly LootDrop[];
      readonly overflow: readonly ResourceId[];
      readonly levelsGained: number;
    };

export type CombatEvent =
  | { readonly type: 'player-hit'; readonly enemyName: string; readonly damage: number; readonly remainingHealth: number }
  | { readonly type: 'player-defeated' }
  | { readonly type: 'player-respawned' };

export interface CombatTargetState {
  readonly enemy: Enemy;
  readonly inRange: boolean;
}

export interface PlayerVitalsSnapshot {
  readonly currentHealth: number;
  readonly maximumHealth: number;
  readonly defeated: boolean;
  readonly respawnRemaining: number;
}

const MAXIMUM_PLAYER_HEALTH = 100;
const PLAYER_RESPAWN_SECONDS = 2.6;
const PACIFICATION_RANGE = 5.1;
const PACIFICATION_COOLDOWN_SECONDS = 2.2;
const WEAPON_ATTACK_RANGE = 5.1;
/**
 * Line of sight is recomputed every N fixed steps (100 ms at 60 Hz) instead of every step.
 * A creature's decision to attack can therefore lag a sightline change by up to 100 ms.
 */
const LINE_OF_SIGHT_REFRESH_STEPS = 6;

export class CombatSystem {
  private readonly enemiesById = new Map<string, Enemy>();
  private readonly obstructionRaycaster = new THREE.Raycaster();
  private readonly lineOfSightCache: boolean[];
  private readonly lineOfSightAge: number[];
  private readonly rayOrigin = new THREE.Vector3();
  private readonly rayDirection = new THREE.Vector3();
  private readonly enemyPosition = new THREE.Vector3();
  private readonly targetPosition = new THREE.Vector3();
  private currentTarget: Enemy | null = null;
  private targetInRange = false;
  private currentHealth = MAXIMUM_PLAYER_HEALTH;
  private playerDefeated = false;
  private respawnRemaining = 0;
  private pacificationCooldownRemaining = 0;
  private weaponCooldownRemaining = 0;
  private activeZoneId: ZoneId = 'starter-quarry';
  private playerDamageMultiplier = 1;
  private gearStatsResolver: (() => { readonly damage: number; readonly attackSpeed: number } | null) | null = null;
  private gearDefenseResolver: (() => number) | null = null;

  constructor(
    readonly enemies: readonly Enemy[],
    private readonly inventory: Inventory,
    private readonly progression: ProgressionSystem,
    private readonly random: () => number = Math.random,
  ) {
    for (const enemy of enemies) this.enemiesById.set(enemy.id, enemy);
    this.lineOfSightCache = enemies.map(() => true);
    this.lineOfSightAge = enemies.map(() => LINE_OF_SIGHT_REFRESH_STEPS);
    this.obstructionRaycaster.near = 0.2;
  }

  /**
   * `firstHit` is the nearest hit this system may act on, supplied by InteractionProbe.
   * The probe casts the centre ray once per frame for all targeting systems.
   */
  updateTarget(firstHit: THREE.Intersection | null, playerPosition: THREE.Vector3): void {
    const enemyId = firstHit?.object.userData['enemyId'];
    const nextTarget = typeof enemyId === 'string'
      ? this.enemiesById.get(enemyId) ?? null
      : null;

    if (nextTarget !== this.currentTarget) {
      this.currentTarget?.setTargeted(false);
      this.currentTarget = nextTarget?.isAlive() ? nextTarget : null;
      this.currentTarget?.setTargeted(true);
    }

    if (!this.currentTarget || !this.currentTarget.isAlive()) {
      this.targetInRange = false;
      return;
    }

    this.currentTarget.getWorldPosition(this.enemyPosition);
    this.targetPosition.copy(playerPosition);
    this.targetInRange = this.enemyPosition.distanceTo(this.targetPosition) <= PACIFICATION_RANGE;
  }

  setGearStatsResolver(resolver: () => { readonly damage: number; readonly attackSpeed: number } | null): void {
    this.gearStatsResolver = resolver;
  }

  setGearDefenseResolver(resolver: () => number): void { this.gearDefenseResolver = resolver; }

  setPlayerDamageMultiplier(multiplier: number): void {
    this.playerDamageMultiplier = Number.isFinite(multiplier) ? Math.max(0.5, Math.min(2, multiplier)) : 1;
  }

  getTargetState(): CombatTargetState | null {
    if (!this.currentTarget || !this.currentTarget.isAlive()) return null;
    return { enemy: this.currentTarget, inRange: this.targetInRange };
  }

  /** Performs a real melee strike using the equipped weapon's damage and attack cadence. */
  tryAttack(playerPosition: THREE.Vector3): WeaponAttackResult {
    const enemy = this.currentTarget;
    if (!enemy || !enemy.isAlive()) return { kind: 'no-target' };
    const weapon = this.inventory.getEquippedWeapon();
    const gearStats = this.gearStatsResolver?.() ?? null;
    if (!weapon && !gearStats) return { kind: 'no-weapon' };
    if (this.weaponCooldownRemaining > 0) return { kind: 'cooldown' };

    enemy.getWorldPosition(this.enemyPosition);
    if (this.enemyPosition.distanceTo(playerPosition) > WEAPON_ATTACK_RANGE || !this.targetInRange) {
      this.targetInRange = false;
      return { kind: 'out-of-range', enemy };
    }

    const attackSpeed = gearStats?.attackSpeed ?? weapon!.attacksPerSecond;
    const attackDamage = gearStats?.damage ?? weapon!.attackDamage;
    this.weaponCooldownRemaining = 1 / Math.max(0.1, attackSpeed);
    const resolvedDamage = Math.max(1, Math.round(attackDamage * this.playerDamageMultiplier));
    const damageResult = enemy.takeDamage(resolvedDamage);
    if (damageResult.applied <= 0) return { kind: 'no-target' };

    if (!damageResult.defeated) {
      return {
        kind: 'hit',
        enemy,
        damage: damageResult.applied,
        remainingHealth: damageResult.remainingHealth,
      };
    }

    enemy.setTargeted(false);
    if (this.currentTarget === enemy) this.currentTarget = null;
    this.targetInRange = false;

    const xpResult = this.progression.awardXp(enemy.definition.xpReward);
    const coinResult = this.inventory.addCoins(enemy.definition.coinReward);
    const rolledLoot = rollLootTable(enemy.definition.loot, this.random);
    const grantedLoot: LootDrop[] = [];
    const overflow: ResourceId[] = [];
    for (const drop of rolledLoot) {
      const result = this.inventory.add(drop.resourceId, drop.quantity);
      if (result.ok) grantedLoot.push(drop);
      else overflow.push(drop.resourceId);
    }

    return {
      kind: 'defeated',
      enemy,
      damage: damageResult.applied,
      xpAwarded: xpResult.awarded,
      coinsAwarded: coinResult.ok ? enemy.definition.coinReward : 0,
      loot: grantedLoot,
      overflow,
      levelsGained: xpResult.levelsGained,
    };
  }

  /** The player uses a resonance pulse to calm a creature; no weapon action is used. */
  tryPacify(playerPosition: THREE.Vector3): PacificationResult {
    const enemy = this.currentTarget;
    if (!enemy || !enemy.isAlive()) return { kind: 'no-target' };
    if (enemy.isPacified()) return { kind: 'already-pacified', enemy };
    enemy.getWorldPosition(this.enemyPosition);
    if (this.enemyPosition.distanceTo(playerPosition) > PACIFICATION_RANGE || !this.targetInRange) {
      this.targetInRange = false;
      return { kind: 'out-of-range', enemy };
    }
    if (!canPacifyTarget({
      cooldownSeconds: this.pacificationCooldownRemaining,
      inRange: true,
      targetCanBePacified: enemy.canBePacified(),
    })) return { kind: 'cooldown' };
    if (!enemy.pacify()) return { kind: 'already-pacified', enemy };

    this.pacificationCooldownRemaining = PACIFICATION_COOLDOWN_SECONDS;
    enemy.setTargeted(false);
    if (this.currentTarget === enemy) this.currentTarget = null;
    this.targetInRange = false;

    const xpResult = this.progression.awardXp(enemy.definition.xpReward);
    const rolledLoot = rollLootTable(enemy.definition.loot, this.random);
    const grantedLoot: LootDrop[] = [];
    const overflow: ResourceId[] = [];
    for (const drop of rolledLoot) {
      const result = this.inventory.add(drop.resourceId, drop.quantity);
      if (result.ok) grantedLoot.push(drop);
      else overflow.push(drop.resourceId);
    }

    return {
      kind: 'pacified',
      enemy,
      xpAwarded: xpResult.awarded,
      loot: grantedLoot,
      overflow,
      levelsGained: xpResult.levelsGained,
    };
  }

  /** Runs enemy decisions on the same fixed step as player physics. */
  fixedUpdate(
    playerPosition: THREE.Vector3,
    deltaSeconds: number,
    environmentOccluders: readonly THREE.Object3D[],
  ): readonly CombatEvent[] {
    this.pacificationCooldownRemaining = Math.max(0, this.pacificationCooldownRemaining - deltaSeconds);
    this.weaponCooldownRemaining = Math.max(0, this.weaponCooldownRemaining - deltaSeconds);

    if (this.playerDefeated) {
      this.respawnRemaining = Math.max(0, this.respawnRemaining - deltaSeconds);
      if (this.respawnRemaining === 0) {
        this.playerDefeated = false;
        this.currentHealth = MAXIMUM_PLAYER_HEALTH;
        for (const enemy of this.enemies) enemy.disengage();
        return [{ type: 'player-respawned' }];
      }
      return [];
    }

    const events: CombatEvent[] = [];
    for (let index = 0; index < this.enemies.length; index += 1) {
      const enemy = this.enemies[index];
      if (!enemy || enemy.definition.zoneId !== this.activeZoneId) continue;
      const lineOfSight = this.resolveLineOfSight(index, enemy, playerPosition, environmentOccluders);
      const incomingDamage = enemy.fixedUpdate(playerPosition, deltaSeconds, lineOfSight);
      if (incomingDamage === null || incomingDamage <= 0) continue;

      const defense = Math.max(0, this.gearDefenseResolver?.() ?? 0);
      const mitigatedDamage = Math.max(1, Math.round(incomingDamage * (100 / (100 + defense))));
      this.currentHealth = Math.max(0, this.currentHealth - mitigatedDamage);
      events.push({
        type: 'player-hit',
        enemyName: enemy.name,
        damage: mitigatedDamage,
        remainingHealth: this.currentHealth,
      });
      if (this.currentHealth === 0) {
        this.playerDefeated = true;
        this.respawnRemaining = PLAYER_RESPAWN_SECONDS;
        events.push({ type: 'player-defeated' });
        break;
      }
    }
    return events;
  }

  setActiveZone(zoneId: ZoneId): void {
    this.clearTarget();
    for (const enemy of this.enemies) enemy.disengage();
    this.activeZoneId = zoneId;
    // Force a fresh sightline check for every creature in the new zone.
    this.lineOfSightAge.fill(LINE_OF_SIGHT_REFRESH_STEPS);
  }

  getActiveZoneId(): ZoneId {
    return this.activeZoneId;
  }

  syncFromPhysics(): void {
    for (const enemy of this.enemies) enemy.syncFromPhysics();
  }

  /** Restores saved vitality while guaranteeing the player is not left defeated. */
  restoreHealth(health: number): boolean {
    if (!Number.isSafeInteger(health) || health < 1 || health > MAXIMUM_PLAYER_HEALTH) return false;
    this.currentHealth = health;
    this.playerDefeated = false;
    this.respawnRemaining = 0;
    this.pacificationCooldownRemaining = 0;
    this.weaponCooldownRemaining = 0;
    return true;
  }

  reset(): void {
    this.currentHealth = MAXIMUM_PLAYER_HEALTH;
    this.playerDefeated = false;
    this.respawnRemaining = 0;
    this.pacificationCooldownRemaining = 0;
    this.weaponCooldownRemaining = 0;
    this.clearTarget();
    for (const enemy of this.enemies) enemy.disengage();
  }

  getVitals(): PlayerVitalsSnapshot {
    return {
      currentHealth: this.currentHealth,
      maximumHealth: MAXIMUM_PLAYER_HEALTH,
      defeated: this.playerDefeated,
      respawnRemaining: this.respawnRemaining,
    };
  }

  getProgressionSnapshot(): ProgressionSnapshot {
    return this.progression.snapshot();
  }

  isPlayerDefeated(): boolean {
    return this.playerDefeated;
  }

  clearTarget(): void {
    this.currentTarget?.setTargeted(false);
    this.currentTarget = null;
    this.targetInRange = false;
  }

  dispose(): void {
    this.clearTarget();
    for (const enemy of this.enemies) enemy.dispose();
  }

  private resolveLineOfSight(
    index: number,
    enemy: Enemy,
    playerPosition: THREE.Vector3,
    environmentOccluders: readonly THREE.Object3D[],
  ): boolean {
    const age = this.lineOfSightAge[index] ?? LINE_OF_SIGHT_REFRESH_STEPS;
    if (age >= LINE_OF_SIGHT_REFRESH_STEPS) {
      this.lineOfSightCache[index] = this.computeLineOfSight(enemy, playerPosition, environmentOccluders);
      this.lineOfSightAge[index] = 1;
    } else {
      this.lineOfSightAge[index] = age + 1;
    }
    return this.lineOfSightCache[index] ?? true;
  }

  private computeLineOfSight(
    enemy: Enemy,
    playerPosition: THREE.Vector3,
    environmentOccluders: readonly THREE.Object3D[],
  ): boolean {
    enemy.getWorldPosition(this.rayOrigin);
    this.targetPosition.copy(playerPosition);
    this.rayDirection.subVectors(this.targetPosition, this.rayOrigin);
    const distance = this.rayDirection.length();
    if (distance <= 0.01) return true;
    this.rayDirection.multiplyScalar(1 / distance);
    this.obstructionRaycaster.set(this.rayOrigin, this.rayDirection);
    this.obstructionRaycaster.far = Math.max(0, distance - 0.48);
    return !hasVisibleHit(this.obstructionRaycaster, environmentOccluders);
  }
}
