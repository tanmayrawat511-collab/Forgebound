import { GEAR_DEFINITIONS, GEAR_MATERIALS } from '../data/gear-data';
import type { GearId, GearMaterialId } from '../types/gear';
import type { ResourceId } from '../types/resources';
import { Inventory } from './Inventory';
import { GearInventorySystem } from './GearInventorySystem';

export class BlacksmithSystem {
  constructor(private readonly inventory: Inventory, private readonly gear: GearInventorySystem) {}

  getCatalog(): readonly GearId[] { return Object.keys(GEAR_DEFINITIONS) as GearId[]; }

  trade(gearId: GearId, materialId: GearMaterialId): { readonly ok: true; readonly item: NonNullable<ReturnType<GearInventorySystem['getItem']>> } | { readonly ok: false; readonly reason: string } {
    const definition = GEAR_DEFINITIONS[gearId];
    const material = GEAR_MATERIALS[materialId];
    if (!definition || !material) return { ok: false, reason: 'Unknown blacksmith selection.' };
    const quantity = definition.slot === 'weapon' ? (gearId === 'daggers' || gearId === 'gauntlet' ? 2 : 3) : 4;
    const costs: Partial<Record<ResourceId, number>> = { [material.ingotId]: quantity };
    if (!this.inventory.canAffordAll(costs)) return { ok: false, reason: `Bring ${quantity} ${material.label} ingots. The blacksmith accepts ingots only.` };
    // Trade the ingots first, then grant the instance. The grant is deterministic and cannot fail
    // after the catalog and material validation above.
    const payment = this.inventory.exchange(costs, {});
    if (!payment.ok) return { ok: false, reason: payment.reason };
    const granted = this.gear.grant(gearId, materialId);
    if (!granted.ok || !granted.item) {
      // This branch is defensive; current grant validation makes it unreachable.
      this.inventory.add(material.ingotId, quantity);
      return { ok: false, reason: granted.ok ? 'The gear could not be issued.' : granted.reason };
    }
    return { ok: true, item: granted.item };
  }
}
