import { ZONE_DEFINITIONS, ZONE_ORDER } from '../data/zone-data';
import type { ZoneId } from '../types/zones';

export type ZoneTravelResult =
  | { readonly ok: true; readonly from: ZoneId; readonly to: ZoneId }
  | { readonly ok: false; readonly reason: 'unknown-zone' | 'locked' | 'already-here'; readonly requiredLevel?: number };

/** Zone access is derived from level, so an old/stale unlock flag cannot bypass progression. */
export class ZoneProgressionSystem {
  private currentZoneId: ZoneId = 'starter-quarry';

  reset(): void {
    this.currentZoneId = 'starter-quarry';
  }

  getCurrentZoneId(): ZoneId {
    return this.currentZoneId;
  }

  getUnlockedZoneIds(level: number): readonly ZoneId[] {
    const safeLevel = Number.isFinite(level) ? Math.max(1, Math.floor(level)) : 1;
    return ZONE_ORDER.filter((zoneId) => ZONE_DEFINITIONS[zoneId].requiredLevel <= safeLevel);
  }

  isUnlocked(zoneId: ZoneId, level: number): boolean {
    return this.getUnlockedZoneIds(level).includes(zoneId);
  }

  getNewlyUnlocked(previousLevel: number, currentLevel: number): readonly ZoneId[] {
    if (!Number.isFinite(previousLevel) || !Number.isFinite(currentLevel) || currentLevel <= previousLevel) return [];
    const before = new Set(this.getUnlockedZoneIds(previousLevel));
    return this.getUnlockedZoneIds(currentLevel).filter((zoneId) => !before.has(zoneId));
  }

  travelTo(targetZoneId: string, level: number): ZoneTravelResult {
    if (!ZONE_ORDER.includes(targetZoneId as ZoneId)) return { ok: false, reason: 'unknown-zone' };
    const target = targetZoneId as ZoneId;
    if (target === this.currentZoneId) return { ok: false, reason: 'already-here' };
    const requirement = ZONE_DEFINITIONS[target].requiredLevel;
    if (!this.isUnlocked(target, level)) return { ok: false, reason: 'locked', requiredLevel: requirement };

    const from = this.currentZoneId;
    this.currentZoneId = target;
    return { ok: true, from, to: target };
  }

  /** Used by checkpoint recovery and tests; it still enforces the level requirement. */
  setCurrentZone(targetZoneId: ZoneId, level: number): boolean {
    if (!this.isUnlocked(targetZoneId, level)) return false;
    this.currentZoneId = targetZoneId;
    return true;
  }
}
