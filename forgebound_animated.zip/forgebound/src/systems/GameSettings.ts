import type { StorageLike } from './SaveSystem';

export type Difficulty = "Piece o' Cake" | 'Easy' | 'Normal' | 'Hard';
export type GraphicsPreset = 'low' | 'high';
export type DrawDistance = 'far' | 'normal' | 'short' | 'tiny';
export type PerformancePreset = 'fps' | 'balance' | 'power-saver';
export type GuiScale = 'massive' | 'large' | 'normal' | 'small';

export interface KeyboardBindings {
  readonly moveForward: string;
  readonly moveBackward: string;
  readonly moveLeft: string;
  readonly moveRight: string;
  readonly jump: string;
  readonly interact: string;
  readonly inventory: string;
}

export type GamepadButton = 'cross' | 'circle' | 'square' | 'triangle' | 'l1' | 'r1' | 'l2' | 'r2' | 'create' | 'options' | 'l3' | 'r3' | 'touchpad';

export interface GamepadBindings {
  readonly jump: GamepadButton;
  readonly interact: GamepadButton;
  readonly inventory: GamepadButton;
  readonly pause: GamepadButton;
}

export interface GameSettings {
  readonly audio: {
    readonly musicEnabled: boolean;
    readonly musicVolume: number;
    readonly effectsEnabled: boolean;
    readonly effectsVolume: number;
  };
  readonly camera: {
    readonly inverted: boolean;
    readonly sensitivity: number;
    readonly fov: number;
  };
  readonly difficulty: Difficulty;
  readonly video: {
    readonly graphics: GraphicsPreset;
    readonly drawDistance: DrawDistance;
    readonly smoothLighting: boolean;
    readonly performance: PerformancePreset;
    readonly invertedColors: boolean;
    readonly screenShake: boolean;
    readonly guiScale: GuiScale;
    readonly animations: boolean;
    readonly brightness: number;
  };
  readonly controls: {
    readonly keyboard: KeyboardBindings;
    readonly gamepad: GamepadBindings;
    readonly touchScale: number;
  };
}

export const GAME_SETTINGS_KEY = 'forgebound.settings.v1';
export const DEFAULT_GAMEPAD_BINDINGS: GamepadBindings = { jump: 'circle', interact: 'cross', inventory: 'triangle', pause: 'options' };
const GAMEPAD_BUTTONS: readonly GamepadButton[] = ['cross','circle','square','triangle','l1','r1','l2','r2','create','options','l3','r3','touchpad'];

export const DEFAULT_KEYBOARD_BINDINGS: KeyboardBindings = {
  moveForward: 'KeyW', moveBackward: 'KeyS', moveLeft: 'KeyA', moveRight: 'KeyD',
  jump: 'Space', interact: 'KeyE', inventory: 'KeyI',
};

export const DEFAULT_GAME_SETTINGS: GameSettings = {
  audio: { musicEnabled: true, musicVolume: 70, effectsEnabled: true, effectsVolume: 80 },
  camera: { inverted: false, sensitivity: 100, fov: 90 },
  difficulty: 'Normal',
  video: {
    graphics: 'high', drawDistance: 'normal', smoothLighting: true,
    performance: 'balance', invertedColors: false, screenShake: true,
    guiScale: 'normal', animations: true, brightness: 100,
  },
  controls: { keyboard: DEFAULT_KEYBOARD_BINDINGS, gamepad: DEFAULT_GAMEPAD_BINDINGS, touchScale: 1 },
};

const DIFFICULTIES: readonly Difficulty[] = ["Piece o' Cake", 'Easy', 'Normal', 'Hard'];
const GRAPHICS: readonly GraphicsPreset[] = ['low', 'high'];
const DISTANCES: readonly DrawDistance[] = ['far', 'normal', 'short', 'tiny'];
const PERFORMANCE: readonly PerformancePreset[] = ['fps', 'balance', 'power-saver'];
const GUI_SCALES: readonly GuiScale[] = ['massive', 'large', 'normal', 'small'];
const KEY_ACTIONS = Object.keys(DEFAULT_KEYBOARD_BINDINGS) as (keyof KeyboardBindings)[];

function record(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function bool(value: unknown, fallback: boolean): boolean { return typeof value === 'boolean' ? value : fallback; }
function numberIn(value: unknown, min: number, max: number, fallback: number): number {
  return typeof value === 'number' && Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : fallback;
}
function choice<T extends string>(value: unknown, choices: readonly T[], fallback: T): T {
  return typeof value === 'string' && choices.includes(value as T) ? value as T : fallback;
}
function parseBindings(value: unknown): KeyboardBindings {
  const source = record(value) ? value : {};
  const result = { ...DEFAULT_KEYBOARD_BINDINGS } as Record<keyof KeyboardBindings, string>;
  for (const key of KEY_ACTIONS) {
    const candidate = source[key];
    if (typeof candidate === 'string' && /^[A-Za-z0-9]+$/.test(candidate) && candidate.length <= 24) result[key] = candidate;
  }
  // Duplicate bindings are not accepted; retain the default binding for later conflicting actions.
  const used = new Set<string>();
  for (const key of KEY_ACTIONS) {
    if (used.has(result[key])) result[key] = DEFAULT_KEYBOARD_BINDINGS[key];
    used.add(result[key]);
  }
  return result;
}

function parseGamepadBindings(value: unknown): GamepadBindings {
  const source = record(value) ? value : {};
  const result = { ...DEFAULT_GAMEPAD_BINDINGS } as Record<keyof GamepadBindings, GamepadButton>;
  for (const key of ['jump', 'interact', 'inventory', 'pause'] as const) {
    const candidate = source[key];
    if (typeof candidate === 'string' && GAMEPAD_BUTTONS.includes(candidate as GamepadButton)) result[key] = candidate as GamepadButton;
  }
  const used = new Set<GamepadButton>();
  for (const key of ['jump', 'interact', 'inventory', 'pause'] as const) {
    if (used.has(result[key])) result[key] = DEFAULT_GAMEPAD_BINDINGS[key];
    used.add(result[key]);
  }
  return result;
}

export function parseGameSettings(value: unknown): GameSettings {
  if (!record(value)) return DEFAULT_GAME_SETTINGS;
  const audio = record(value['audio']) ? value['audio'] : {};
  const camera = record(value['camera']) ? value['camera'] : {};
  const video = record(value['video']) ? value['video'] : {};
  const controls = record(value['controls']) ? value['controls'] : {};
  return {
    audio: {
      musicEnabled: bool(audio['musicEnabled'], DEFAULT_GAME_SETTINGS.audio.musicEnabled),
      musicVolume: numberIn(audio['musicVolume'], 0, 100, DEFAULT_GAME_SETTINGS.audio.musicVolume),
      effectsEnabled: bool(audio['effectsEnabled'], DEFAULT_GAME_SETTINGS.audio.effectsEnabled),
      effectsVolume: numberIn(audio['effectsVolume'], 0, 100, DEFAULT_GAME_SETTINGS.audio.effectsVolume),
    },
    camera: {
      inverted: bool(camera['inverted'], DEFAULT_GAME_SETTINGS.camera.inverted),
      sensitivity: numberIn(camera['sensitivity'], 0, 200, DEFAULT_GAME_SETTINGS.camera.sensitivity),
      fov: numberIn(camera['fov'], 70, 110, DEFAULT_GAME_SETTINGS.camera.fov),
    },
    difficulty: choice(value['difficulty'], DIFFICULTIES, DEFAULT_GAME_SETTINGS.difficulty),
    video: {
      graphics: choice(video['graphics'], GRAPHICS, DEFAULT_GAME_SETTINGS.video.graphics),
      drawDistance: choice(video['drawDistance'], DISTANCES, DEFAULT_GAME_SETTINGS.video.drawDistance),
      smoothLighting: bool(video['smoothLighting'], DEFAULT_GAME_SETTINGS.video.smoothLighting),
      performance: choice(video['performance'], PERFORMANCE, DEFAULT_GAME_SETTINGS.video.performance),
      invertedColors: bool(video['invertedColors'], DEFAULT_GAME_SETTINGS.video.invertedColors),
      screenShake: bool(video['screenShake'], DEFAULT_GAME_SETTINGS.video.screenShake),
      guiScale: choice(video['guiScale'], GUI_SCALES, DEFAULT_GAME_SETTINGS.video.guiScale),
      animations: bool(video['animations'], DEFAULT_GAME_SETTINGS.video.animations),
      brightness: numberIn(video['brightness'], 50, 150, DEFAULT_GAME_SETTINGS.video.brightness),
    },
    controls: {
      keyboard: parseBindings(controls['keyboard']),
      gamepad: parseGamepadBindings(controls['gamepad']),
      touchScale: numberIn(controls['touchScale'], 0.75, 1.5, DEFAULT_GAME_SETTINGS.controls.touchScale),
    },
  };
}

export function loadGameSettings(storage: StorageLike | null): GameSettings {
  if (!storage) return DEFAULT_GAME_SETTINGS;
  try {
    const raw = storage.getItem(GAME_SETTINGS_KEY);
    return raw ? parseGameSettings(JSON.parse(raw) as unknown) : DEFAULT_GAME_SETTINGS;
  } catch { return DEFAULT_GAME_SETTINGS; }
}

export function saveGameSettings(storage: StorageLike | null, settings: GameSettings): boolean {
  if (!storage) return false;
  try {
    storage.setItem(GAME_SETTINGS_KEY, JSON.stringify(parseGameSettings(settings)));
    return true;
  } catch { return false; }
}

export function difficultyDamageMultiplier(difficulty: Difficulty): number {
  switch (difficulty) {
    case "Piece o' Cake": return 0.45;
    case 'Easy': return 0.7;
    case 'Normal': return 1;
    case 'Hard': return 1.4;
  }
}


/** Difficulty tuning for both sides of combat; rewards intentionally remain unchanged. */
export interface DifficultyCombatProfile {
  readonly playerDamageMultiplier: number;
  readonly enemyDamageMultiplier: number;
  readonly enemyHealthMultiplier: number;
}

export function difficultyCombatProfile(difficulty: Difficulty): DifficultyCombatProfile {
  switch (difficulty) {
    case "Piece o' Cake": return { playerDamageMultiplier: 1.2, enemyDamageMultiplier: 0.45, enemyHealthMultiplier: 0.85 };
    case 'Easy': return { playerDamageMultiplier: 1.1, enemyDamageMultiplier: 0.7, enemyHealthMultiplier: 0.95 };
    case 'Normal': return { playerDamageMultiplier: 1, enemyDamageMultiplier: 1, enemyHealthMultiplier: 1 };
    case 'Hard': return { playerDamageMultiplier: 0.9, enemyDamageMultiplier: 1.4, enemyHealthMultiplier: 1.15 };
  }
}
