import { GEAR_MATERIALS, REFINEMENT_SUCCESS_CHANCES } from '../data/gear-data';
import type { GearInstanceSnapshot, GearMaterialId, GearRefinementSnapshot } from '../types/gear';
import { GearInventorySystem } from './GearInventorySystem';
import { Inventory } from './Inventory';

const MAX_CONSECUTIVE_FAILURES = 3;

export interface GearRefinementPlan {
  readonly targetTier: 1 | 2 | 3 | 4 | 5;
  readonly chance: number;
  readonly ingotId: 'copper-ingot' | 'iron-ingot' | 'gold-ingot' | 'crystal-ingot';
  readonly ingotCost: number;
  readonly coinCost: number;
}

export type GearRefinementResult =
  | { readonly ok: true; readonly item: GearInstanceSnapshot; readonly chance: number; readonly pityGuaranteed: boolean }
  | { readonly ok: false; readonly reason: string; readonly failed: boolean; readonly targetTier?: number; readonly consecutiveFailures?: number; readonly pityRemaining?: number };

export function createEmptyGearRefinementSnapshot(): GearRefinementSnapshot { return { failureStreaks: {} }; }

export function validateGearRefinementSnapshot(value: unknown): value is GearRefinementSnapshot {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const streaks = (value as Record<string, unknown>)['failureStreaks'];
  if (!streaks || typeof streaks !== 'object' || Array.isArray(streaks)) return false;
  for (const [key, count] of Object.entries(streaks)) {
    if (!/^[a-z0-9][a-z0-9-]{2,79}:[1-5]$/.test(key) || !Number.isSafeInteger(count) || (count as number) < 0 || (count as number) > MAX_CONSECUTIVE_FAILURES) return false;
  }
  return true;
}

export class GearRefinementSystem {
  private readonly failureStreaks = new Map<string, number>();

  constructor(
    private readonly inventory: Inventory,
    private readonly gear: GearInventorySystem,
    private readonly random: () => number = Math.random,
  ) {}

  getPlan(item: GearInstanceSnapshot): GearRefinementPlan | null {
    const targetTier = item.refinementTier + 1;
    if (targetTier < 1 || targetTier > 5) return null;
    const material = GEAR_MATERIALS[item.materialId as GearMaterialId];
    return {
      targetTier: targetTier as GearRefinementPlan['targetTier'],
      chance: REFINEMENT_SUCCESS_CHANCES[targetTier as 1 | 2 | 3 | 4 | 5],
      ingotId: material.ingotId,
      ingotCost: targetTier,
      coinCost: 25 * targetTier,
    };
  }

  getFailureStreak(instanceId: string, targetTier: number): number {
    return this.failureStreaks.get(`${instanceId}:${targetTier}`) ?? 0;
  }

  getPityAttemptsRemaining(instanceId: string, targetTier: number): number {
    return Math.max(0, MAX_CONSECUTIVE_FAILURES - this.getFailureStreak(instanceId, targetTier));
  }

  refine(instanceId: string): GearRefinementResult {
    const item = this.gear.getItem(instanceId);
    if (!item) return { ok: false, failed: false, reason: 'Select a gear item that you own.' };
    const plan = this.getPlan(item);
    if (!plan) return { ok: false, failed: false, reason: 'This item has reached refinement tier V.' };
    const key = `${instanceId}:${plan.targetTier}`;
    const failures = this.getFailureStreak(instanceId, plan.targetTier);
    const pityGuaranteed = failures >= MAX_CONSECUTIVE_FAILURES;

    // A failed roll still consumes the full materials-and-Coins cost, as specified for J7.
    const payment = this.inventory.transactResourcesAndCoins({ [plan.ingotId]: plan.ingotCost }, {}, -plan.coinCost);
    if (!payment.ok) return { ok: false, failed: false, reason: payment.reason, targetTier: plan.targetTier };

    const succeeds = pityGuaranteed || this.random() < plan.chance;
    if (!succeeds) {
      const streak = Math.min(MAX_CONSECUTIVE_FAILURES, failures + 1);
      this.failureStreaks.set(key, streak);
      return {
        ok: false,
        failed: true,
        reason: `Refinement failed. The item remains at tier ${item.refinementTier}; ${this.getPityAttemptsRemaining(instanceId, plan.targetTier)} more failed attempt(s) before guaranteed success.`,
        targetTier: plan.targetTier,
        consecutiveFailures: streak,
        pityRemaining: this.getPityAttemptsRemaining(instanceId, plan.targetTier),
      };
    }

    const upgraded = this.gear.applyRefinement(instanceId, plan.targetTier);
    if (!upgraded.ok || !upgraded.item) return { ok: false, failed: false, reason: upgraded.ok ? 'Refinement could not be applied.' : upgraded.reason };
    this.failureStreaks.delete(key);
    return { ok: true, item: upgraded.item, chance: plan.chance, pityGuaranteed };
  }

  restore(snapshot: GearRefinementSnapshot): boolean {
    if (!validateGearRefinementSnapshot(snapshot)) return false;
    this.failureStreaks.clear();
    for (const [key, count] of Object.entries(snapshot.failureStreaks)) this.failureStreaks.set(key, count);
    return true;
  }

  snapshot(): GearRefinementSnapshot { return { failureStreaks: Object.fromEntries(this.failureStreaks) }; }
}
