import type { LootDrop, LootDropDefinition } from '../types/combat';

export interface PacificationWindow {
  readonly cooldownSeconds: number;
  readonly inRange: boolean;
  readonly targetCanBePacified: boolean;
}

export function canPacifyTarget(window: PacificationWindow): boolean {
  return Number.isFinite(window.cooldownSeconds)
    && window.cooldownSeconds <= 0
    && window.inRange
    && window.targetCanBePacified;
}

/** Each loot entry gets one independent probability roll on a successful pacification. */
export function rollLootTable(
  table: readonly LootDropDefinition[],
  random: () => number = Math.random,
): LootDrop[] {
  const drops: LootDrop[] = [];
  for (const entry of table) {
    if (!Number.isFinite(entry.chance) || entry.chance < 0 || entry.chance > 1) continue;
    if (!Number.isSafeInteger(entry.minimumQuantity) || !Number.isSafeInteger(entry.maximumQuantity)) continue;
    if (entry.minimumQuantity <= 0 || entry.maximumQuantity < entry.minimumQuantity) continue;
    const chanceRoll = random();
    if (!Number.isFinite(chanceRoll) || chanceRoll < 0 || chanceRoll >= entry.chance) continue;
    const quantityRange = entry.maximumQuantity - entry.minimumQuantity + 1;
    const quantityRoll = random();
    if (!Number.isFinite(quantityRoll) || quantityRoll < 0 || quantityRoll >= 1) continue;
    const quantity = entry.minimumQuantity + Math.floor(quantityRoll * quantityRange);
    drops.push({ resourceId: entry.resourceId, quantity });
  }
  return drops;
}
