import { CRAFTING_RECIPES, SMELTING_RECIPES } from '../data/forge-data';
import { EQUIPMENT_DEFINITIONS } from '../data/equipment-data';
import type { EquipmentId } from '../types/equipment';
import { RESOURCE_DEFINITIONS } from '../types/resources';
import type { Inventory, InventoryResult } from './Inventory';

export interface ForgeActionResult {
  readonly ok: boolean;
  readonly message: string;
}

function failure(result: InventoryResult): ForgeActionResult {
  return { ok: false, message: result.ok ? 'The forge action could not be completed.' : result.reason };
}

export class ForgeSystem {
  constructor(private readonly inventory: Inventory) {}

  canSmelt(recipeId: string): boolean {
    const recipe = SMELTING_RECIPES.find((entry) => entry.id === recipeId);
    return recipe !== undefined && this.inventory.canExchange(recipe.inputs, recipe.outputs);
  }

  smelt(recipeId: string): ForgeActionResult {
    const recipe = SMELTING_RECIPES.find((entry) => entry.id === recipeId);
    if (!recipe) return { ok: false, message: 'Unknown smelting recipe.' };

    const result = this.inventory.exchange(recipe.inputs, recipe.outputs);
    if (!result.ok) return failure(result);
    const output = Object.entries(recipe.outputs)
      .map(([resourceId, quantity]) => `${quantity ?? 0} ${RESOURCE_DEFINITIONS[resourceId as keyof typeof RESOURCE_DEFINITIONS].name}`)
      .join(', ');
    return { ok: true, message: `Smelted ${output}.` };
  }

  canCraft(recipeId: string): boolean {
    const recipe = CRAFTING_RECIPES.find((entry) => entry.id === recipeId);
    return recipe !== undefined
      && !this.inventory.hasEquipment(recipe.equipmentId)
      && this.inventory.canAffordAll(recipe.costs);
  }

  craft(recipeId: string): ForgeActionResult {
    const recipe = CRAFTING_RECIPES.find((entry) => entry.id === recipeId);
    if (!recipe) return { ok: false, message: 'Unknown crafting recipe.' };

    const result = this.inventory.craftEquipment(recipe.costs, recipe.equipmentId);
    if (!result.ok) return failure(result);
    return {
      ok: true,
      message: `Crafted ${EQUIPMENT_DEFINITIONS[recipe.equipmentId].name}. Equip it from the forge.`
    };
  }

  equip(equipmentId: EquipmentId): ForgeActionResult {
    const result = this.inventory.equip(equipmentId);
    if (!result.ok) return failure(result);
    return { ok: true, message: `Equipped ${EQUIPMENT_DEFINITIONS[equipmentId].name}.` };
  }
}
