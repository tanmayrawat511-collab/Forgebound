export type ChessColor = 'w' | 'b';
export type ChessPiece = 'K' | 'Q' | 'R' | 'B' | 'N' | 'P' | 'k' | 'q' | 'r' | 'b' | 'n' | 'p';
export type ChessOutcome = 'playing' | 'white-won' | 'black-won' | 'draw';
export interface ChessMove { readonly from: number; readonly to: number; readonly promotion?: 'q' | 'r' | 'b' | 'n'; }

const INITIAL_BOARD: (ChessPiece | null)[] = [
  'r','n','b','q','k','b','n','r',
  'p','p','p','p','p','p','p','p',
  null,null,null,null,null,null,null,null,
  null,null,null,null,null,null,null,null,
  null,null,null,null,null,null,null,null,
  null,null,null,null,null,null,null,null,
  'P','P','P','P','P','P','P','P',
  'R','N','B','Q','K','B','N','R',
];
const MATERIAL: Readonly<Record<string, number>> = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 20_000 };
const KNIGHT_STEPS: readonly (readonly [number, number])[] = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
const RAY_DIRECTIONS: readonly (readonly [number, number])[] = [[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[-1,1],[1,-1],[1,1]];
const FILES = 'abcdefgh';
const glyph: Readonly<Record<ChessPiece, string>> = {
  K: '♔', Q: '♕', R: '♖', B: '♗', N: '♘', P: '♙',
  k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟',
};

function colorOf(piece: ChessPiece): ChessColor { return piece === piece.toUpperCase() ? 'w' : 'b'; }
function rowOf(square: number): number { return Math.floor(square / 8); }
function colOf(square: number): number { return square % 8; }
function at(row: number, col: number): number { return row * 8 + col; }
function inside(row: number, col: number): boolean { return row >= 0 && row < 8 && col >= 0 && col < 8; }
function fileRank(square: number): string { return `${FILES[colOf(square)]}${8 - rowOf(square)}`; }

export class ChessGame {
  private board: (ChessPiece | null)[] = [...INITIAL_BOARD];
  private side: ChessColor = 'w';
  private castling = 'KQkq';
  private enPassant: number | null = null;
  private halfmove = 0;
  private outcome: ChessOutcome = 'playing';
  private history: string[] = [];
  private readonly moves: string[] = [];

  constructor() {
    this.history.push(this.positionKey());
  }

  get currentTurn(): ChessColor { return this.side; }
  get result(): ChessOutcome { return this.outcome; }
  get moveHistory(): readonly string[] { return this.moves; }
  getGlyph(piece: ChessPiece): string { return glyph[piece]; }
  getPiece(square: number): ChessPiece | null { return this.board[square] ?? null; }
  getLegalMoves(from?: number): readonly ChessMove[] { return this.legalMoves(this.side).filter((move) => from === undefined || move.from === from); }
  isCheck(): boolean { return this.isInCheck(this.side); }

  playHumanMove(from: number, to: number): boolean {
    if (this.outcome !== 'playing' || this.side !== 'w') return false;
    const move = this.legalMoves('w').find((candidate) => candidate.from === from && candidate.to === to);
    if (!move) return false;
    this.applyMove(move);
    this.moves.push(`${fileRank(from)}${fileRank(to)}${move.promotion ?? ''}`);
    this.updateOutcome();
    return true;
  }

  playComputerMove(): ChessMove | null {
    if (this.outcome !== 'playing' || this.side !== 'b') return null;
    const legal = this.legalMoves('b');
    if (legal.length === 0) { this.updateOutcome(); return null; }
    const ranked = legal.map((move) => ({ move, score: this.scoreComputerMove(move) }));
    ranked.sort((a, b) => b.score - a.score || a.move.from - b.move.from || a.move.to - b.move.to);
    const chosen = ranked[0]?.move ?? null;
    if (!chosen) return null;
    this.applyMove(chosen);
    this.moves.push(`${fileRank(chosen.from)}${fileRank(chosen.to)}${chosen.promotion ?? ''}`);
    this.updateOutcome();
    return chosen;
  }

  reset(): void {
    this.board = [...INITIAL_BOARD]; this.side = 'w'; this.castling = 'KQkq'; this.enPassant = null;
    this.halfmove = 0; this.outcome = 'playing'; this.history = [this.positionKey()]; this.moves.length = 0;
  }

  private legalMoves(color: ChessColor): ChessMove[] {
    const result: ChessMove[] = [];
    for (let from = 0; from < 64; from += 1) {
      const piece = this.board[from];
      if (!piece || colorOf(piece) !== color) continue;
      for (const move of this.pseudoMoves(from, piece)) {
        const copy = this.copy();
        copy.applyMove(move);
        if (!copy.isInCheck(color)) result.push(move);
      }
    }
    return result;
  }

  private pseudoMoves(from: number, piece: ChessPiece): ChessMove[] {
    const row = rowOf(from), col = colOf(from), color = colorOf(piece), lower = piece.toLowerCase();
    const result: ChessMove[] = [];
    const push = (r: number, c: number): void => {
      if (!inside(r, c)) return;
      const to = at(r, c), target = this.board[to];
      if (!target || colorOf(target) !== color) result.push({ from, to });
    };
    if (lower === 'p') {
      const direction = color === 'w' ? -1 : 1;
      const startRow = color === 'w' ? 6 : 1;
      const one = row + direction;
      if (inside(one, col) && !this.board[at(one, col)]) {
        result.push(this.promotionMove(from, at(one, col), color));
        const two = row + direction * 2;
        if (row === startRow && !this.board[at(two, col)]) result.push({ from, to: at(two, col) });
      }
      for (const dc of [-1, 1]) {
        const r = row + direction, c = col + dc;
        if (!inside(r, c)) continue;
        const to = at(r, c), target = this.board[to];
        if ((target && colorOf(target) !== color) || to === this.enPassant) result.push(this.promotionMove(from, to, color));
      }
      return result;
    }
    if (lower === 'n') {
      for (const [dr, dc] of KNIGHT_STEPS) push(row + dr, col + dc);
      return result;
    }
    if (lower === 'k') {
      for (let dr = -1; dr <= 1; dr += 1) for (let dc = -1; dc <= 1; dc += 1) if (dr || dc) push(row + dr, col + dc);
      const homeRow = color === 'w' ? 7 : 0;
      const kingSide = color === 'w' ? 'K' : 'k';
      const queenSide = color === 'w' ? 'Q' : 'q';
      const enemy: ChessColor = color === 'w' ? 'b' : 'w';
      if (row === homeRow && col === 4 && !this.isInCheck(color)) {
        if (this.castling.includes(kingSide) && !this.board[at(homeRow,5)] && !this.board[at(homeRow,6)]
          && this.board[at(homeRow,7)]?.toLowerCase() === 'r'
          && !this.isSquareAttacked(at(homeRow,5), enemy) && !this.isSquareAttacked(at(homeRow,6), enemy)) result.push({ from, to: at(homeRow,6) });
        if (this.castling.includes(queenSide) && !this.board[at(homeRow,1)] && !this.board[at(homeRow,2)] && !this.board[at(homeRow,3)]
          && this.board[at(homeRow,0)]?.toLowerCase() === 'r'
          && !this.isSquareAttacked(at(homeRow,3), enemy) && !this.isSquareAttacked(at(homeRow,2), enemy)) result.push({ from, to: at(homeRow,2) });
      }
      return result;
    }
    const directions: readonly (readonly [number, number])[] = lower === 'r' ? RAY_DIRECTIONS.slice(0, 4)
      : lower === 'b' ? RAY_DIRECTIONS.slice(4) : RAY_DIRECTIONS;
    for (const [dr, dc] of directions) {
      let r = row + dr, c = col + dc;
      while (inside(r, c)) {
        const to = at(r, c), target = this.board[to];
        if (!target) result.push({ from, to });
        else { if (colorOf(target) !== color) result.push({ from, to }); break; }
        r += dr; c += dc;
      }
    }
    return result;
  }

  private promotionMove(from: number, to: number, color: ChessColor): ChessMove {
    const promotionRow = color === 'w' ? 0 : 7;
    return rowOf(to) === promotionRow ? { from, to, promotion: 'q' } : { from, to };
  }

  private applyMove(move: ChessMove): void {
    const piece = this.board[move.from];
    if (!piece) return;
    const color = colorOf(piece), target = this.board[move.to];
    if (piece.toLowerCase() === 'p' || target) this.halfmove = 0; else this.halfmove += 1;
    if (piece === 'K') this.castling = this.castling.replace(/[KQ]/g, '');
    if (piece === 'k') this.castling = this.castling.replace(/[kq]/g, '');
    if (move.from === 63 || move.to === 63) this.castling = this.castling.replace('K', '');
    if (move.from === 56 || move.to === 56) this.castling = this.castling.replace('Q', '');
    if (move.from === 7 || move.to === 7) this.castling = this.castling.replace('k', '');
    if (move.from === 0 || move.to === 0) this.castling = this.castling.replace('q', '');
    if (piece.toLowerCase() === 'p' && move.to === this.enPassant && !target) {
      const captured = move.to + (color === 'w' ? 8 : -8);
      this.board[captured] = null;
    }
    this.board[move.from] = null;
    this.board[move.to] = move.promotion ? (color === 'w' ? move.promotion.toUpperCase() : move.promotion) as ChessPiece : piece;
    if (piece.toLowerCase() === 'k' && Math.abs(colOf(move.to) - colOf(move.from)) === 2) {
      const row = rowOf(move.from);
      if (colOf(move.to) === 6) { this.board[at(row,5)] = this.board[at(row,7)] ?? null; this.board[at(row,7)] = null; }
      else { this.board[at(row,3)] = this.board[at(row,0)] ?? null; this.board[at(row,0)] = null; }
    }
    this.enPassant = null;
    if (piece.toLowerCase() === 'p' && Math.abs(rowOf(move.to) - rowOf(move.from)) === 2) this.enPassant = (move.to + move.from) / 2;
    this.side = color === 'w' ? 'b' : 'w';
  }

  private isInCheck(color: ChessColor): boolean {
    const king = color === 'w' ? 'K' : 'k';
    const square = this.board.indexOf(king as ChessPiece);
    if (square < 0) return true;
    return this.isSquareAttacked(square, color === 'w' ? 'b' : 'w');
  }

  private isSquareAttacked(square: number, by: ChessColor): boolean {
    const row = rowOf(square), col = colOf(square);
    const pawnRow = row + (by === 'w' ? 1 : -1);
    for (const dc of [-1, 1]) {
      const c = col + dc;
      if (inside(pawnRow, c)) {
        const piece = this.board[at(pawnRow, c)];
        if (piece && colorOf(piece) === by && piece.toLowerCase() === 'p') return true;
      }
    }
    for (const [dr, dc] of KNIGHT_STEPS) {
      const r = row + dr, c = col + dc;
      if (inside(r, c)) { const p = this.board[at(r,c)]; if (p && colorOf(p) === by && p.toLowerCase() === 'n') return true; }
    }
    for (const [dr, dc] of RAY_DIRECTIONS) {
      let r = row + dr, c = col + dc, distance = 1;
      while (inside(r,c)) {
        const p = this.board[at(r,c)];
        if (p) {
          if (colorOf(p) === by) {
            const kind = p.toLowerCase();
            if (kind === 'q' || (distance === 1 && kind === 'k')
              || (distance === 1 && ((dr === 0 || dc === 0) ? kind === 'r' : kind === 'b'))) return true;
          }
          break;
        }
        r += dr; c += dc; distance += 1;
      }
    }
    return false;
  }

  private updateOutcome(): void {
    const legal = this.legalMoves(this.side);
    if (legal.length === 0) this.outcome = this.isInCheck(this.side) ? (this.side === 'w' ? 'black-won' : 'white-won') : 'draw';
    else if (this.halfmove >= 100) this.outcome = 'draw';
    const key = this.positionKey();
    this.history.push(key);
    if (this.history.filter((entry) => entry === key).length >= 3) this.outcome = 'draw';
  }

  private copy(): ChessGame {
    const copy = new ChessGame();
    copy.board = [...this.board]; copy.side = this.side; copy.castling = this.castling; copy.enPassant = this.enPassant;
    copy.halfmove = this.halfmove; copy.outcome = this.outcome; copy.history = [...this.history];
    copy.moves.push(...this.moves);
    return copy;
  }


  private positionKey(): string {
    return `${this.board.map((piece) => piece ?? '-').join('')}:${this.side}:${this.castling}:${this.enPassant ?? '-'}`;
  }

  private scoreComputerMove(move: ChessMove): number {
    const copy = this.copy();
    const captured = this.board[move.to];
    copy.applyMove(move);
    const material = this.evaluateMaterial(copy);
    const capture = captured ? (MATERIAL[captured.toLowerCase()] ?? 0) : 0;
    const givesCheck = copy.isInCheck('w') ? 35 : 0;
    const centre = 7 - Math.abs(3.5 - colOf(move.to)) - Math.abs(3.5 - rowOf(move.to));
    const selfCheckSafety = copy.isInCheck('b') ? -1000 : 0;
    return -material + capture * 0.12 + givesCheck + centre * 2 + selfCheckSafety;
  }

  private evaluateMaterial(position: ChessGame): number {
    let score = 0;
    for (const piece of position.board) {
      if (!piece) continue;
      const value = MATERIAL[piece.toLowerCase()] ?? 0;
      score += colorOf(piece) === 'w' ? value : -value;
    }
    return score;
  }
}

export function chessPieceGlyph(piece: ChessPiece): string { return glyph[piece]; }
export function chessSquareLabel(square: number): string { return fileRank(square); }
