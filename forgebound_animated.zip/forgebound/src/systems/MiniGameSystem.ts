import type { ResourceId } from '../types/resources';
import type { ZoneId } from '../types/zones';

export const MINI_GAME_IDS = [
  'quarry-cart-rally',
  'timberline-relay',
  'veinfinder-challenge',
  'magma-corn-harvest',
  'vent-tuning',
  'basalt-sprint',
  'summit-chess',
  'crystal-fishing',
  'glacier-echo',
] as const;
export type MiniGameId = (typeof MINI_GAME_IDS)[number];
export type RewardTier = 'bronze' | 'silver' | 'gold';
export type MiniGameOutcome = 'completed' | 'draw' | 'won' | 'lost';

export interface MiniGameReward {
  readonly xp: number;
  readonly coins: number;
  readonly resources: Partial<Record<ResourceId, number>>;
  readonly unlocks?: readonly string[];
}

export interface MiniGameDefinition {
  readonly id: MiniGameId;
  readonly zoneId: ZoneId;
  readonly name: string;
  readonly shortName: string;
  readonly description: string;
  readonly instructions: string;
  readonly rewards: Readonly<Record<RewardTier, MiniGameReward>>;
}

const reward = (xp: number, coins: number, resourceId?: ResourceId, quantity = 0, unlocks?: readonly string[]): MiniGameReward => ({
  xp, coins,
  resources: resourceId && quantity > 0 ? { [resourceId]: quantity } : {},
  ...(unlocks ? { unlocks } : {}),
});

export const MINI_GAME_DEFINITIONS: readonly MiniGameDefinition[] = [
  {
    id: 'quarry-cart-rally', zoneId: 'starter-quarry', name: 'Quarry Cart Rally', shortName: 'Cart Rally',
    description: 'Race the old ore cart through six quarry checkpoints.',
    instructions: 'Hit each checkpoint as quickly as you can. Finish all six before the 30-second limit.',
    rewards: { bronze: reward(25, 10, 'copper-ore', 1), silver: reward(45, 20, 'copper-ore', 2), gold: reward(70, 35, 'copper-ore', 3) },
  },
  {
    id: 'timberline-relay', zoneId: 'starter-quarry', name: 'Timberline Relay', shortName: 'Timber Relay',
    description: 'Gather and deliver timber bundles to the forest depot.',
    instructions: 'Collect eight marked bundles. Each tap secures one bundle; complete the relay before time runs out.',
    rewards: { bronze: reward(20, 10, 'timber', 1), silver: reward(35, 20, 'timber', 2), gold: reward(50, 30, 'timber', 3) },
  },
  {
    id: 'veinfinder-challenge', zoneId: 'starter-quarry', name: 'Veinfinder Challenge', shortName: 'Veinfinder',
    description: 'Read the quarry clues and locate three hidden ore seams.',
    instructions: 'Choose a survey tile for each clue. You have two attempts per seam; closer clues identify the correct row or column.',
    rewards: { bronze: reward(15, 8, 'copper-ore', 1), silver: reward(30, 15, 'copper-ore', 2), gold: reward(50, 25, 'copper-ore', 3) },
  },
  {
    id: 'magma-corn-harvest', zoneId: 'molten-caves', name: 'Magma Corn Harvest', shortName: 'Magma Harvest',
    description: 'Harvest ripe magma corn before the garden cools.',
    instructions: 'Pick six ripe plants from the garden grid. Avoid the unripe plants and finish within 25 seconds.',
    rewards: { bronze: reward(20, 12, 'magma-corn', 2), silver: reward(40, 24, 'magma-corn', 4), gold: reward(60, 36, 'magma-corn', 6) },
  },
  {
    id: 'vent-tuning', zoneId: 'molten-caves', name: 'Vent Tuning', shortName: 'Vent Tuning',
    description: 'Stabilize geothermal vents by reproducing their pressure sequence.',
    instructions: 'Watch the glowing vent sequence, then repeat it in order. Each round adds another signal.',
    rewards: { bronze: reward(25, 15, 'gold-ore', 1), silver: reward(45, 30, 'gold-ore', 2), gold: reward(70, 45, 'gold-ore', 3) },
  },
  {
    id: 'basalt-sprint', zoneId: 'molten-caves', name: 'Basalt Sprint', shortName: 'Basalt Sprint',
    description: 'Sprint a marked basalt trail and react to six route hazards.',
    instructions: 'Press DODGE when a falling rock warning appears. Clear all six hazards without timing out.',
    rewards: { bronze: reward(20, 10, 'iron-ore', 1), silver: reward(40, 20, 'iron-ore', 2), gold: reward(65, 35, 'iron-ore', 3) },
  },
  {
    id: 'summit-chess', zoneId: 'crystal-peaks', name: 'Summit Chess', shortName: 'Summit Chess',
    description: 'Play a complete chess match against Frank at the summit lookout.',
    instructions: 'You play White. Select one of your pieces, then a highlighted legal destination. Frank replies after every valid move.',
    rewards: { bronze: reward(30, 15), silver: reward(55, 25), gold: reward(85, 40, undefined, 0, ['chessmaster-crest']) },
  },
  {
    id: 'crystal-fishing', zoneId: 'crystal-peaks', name: 'Crystal Fishing', shortName: 'Crystal Fishing',
    description: 'Cast into Crystal Lake and reel in up to three Crystal Cod.',
    instructions: 'Cast your line, watch for the bite, then hook it before the fish escapes. Three casts determine your reward tier.',
    rewards: { bronze: reward(20, 12, 'crystal-cod', 1), silver: reward(40, 25, 'crystal-cod', 2), gold: reward(60, 40, 'crystal-cod', 3) },
  },
  {
    id: 'glacier-echo', zoneId: 'crystal-peaks', name: 'Glacier Echo', shortName: 'Glacier Echo',
    description: 'Reproduce the sequence of glowing crystal notes.',
    instructions: 'Watch the crystals light up, then repeat their order. Each round lengthens the echo.',
    rewards: { bronze: reward(25, 15, 'crystal', 1), silver: reward(50, 30, 'crystal', 2), gold: reward(75, 45, 'crystal', 3) },
  },
];

export const MINI_GAME_BY_ID: Readonly<Record<MiniGameId, MiniGameDefinition>> = Object.fromEntries(
  MINI_GAME_DEFINITIONS.map((definition) => [definition.id, definition]),
) as Record<MiniGameId, MiniGameDefinition>;

export interface MiniGameSnapshot {
  readonly bestTierByGame: Readonly<Partial<Record<MiniGameId, RewardTier>>>;
  readonly completionCounts: Readonly<Partial<Record<MiniGameId, number>>>;
  readonly unlockedRewards: readonly string[];
}

export interface MiniGamePayout {
  readonly xp: number;
  readonly coins: number;
  readonly resources: Partial<Record<ResourceId, number>>;
  readonly newUnlocks: readonly string[];
  readonly improvedTier: boolean;
}

const TIER_ORDER: readonly RewardTier[] = ['bronze', 'silver', 'gold'];
const UNLOCK_SET = new Set(['chessmaster-crest']);
const GAME_SET = new Set<string>(MINI_GAME_IDS);
const ZERO_PAYOUT: MiniGamePayout = { xp: 0, coins: 0, resources: {}, newUnlocks: [], improvedTier: false };

export function createEmptyMiniGameSnapshot(): MiniGameSnapshot {
  return { bestTierByGame: {}, completionCounts: {}, unlockedRewards: [] };
}

export function validateMiniGameSnapshot(value: unknown): value is MiniGameSnapshot {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const record = value as Record<string, unknown>;
  const best = record['bestTierByGame'];
  const counts = record['completionCounts'];
  const unlocks = record['unlockedRewards'];
  if (!best || typeof best !== 'object' || Array.isArray(best) || !counts || typeof counts !== 'object' || Array.isArray(counts) || !Array.isArray(unlocks)) return false;
  const bestRecord = best as Record<string, unknown>;
  const countRecord = counts as Record<string, unknown>;
  if (Object.keys(bestRecord).some((id) => !GAME_SET.has(id) || !TIER_ORDER.includes(bestRecord[id] as RewardTier))) return false;
  if (Object.keys(countRecord).some((id) => !GAME_SET.has(id) || !Number.isSafeInteger(countRecord[id]) || (countRecord[id] as number) < 0 || (countRecord[id] as number) > 1_000_000)) return false;
  if (Object.entries(countRecord).some(([id, count]) => (count as number) > 0 && !(id in bestRecord))) return false;
  if (Object.keys(bestRecord).some((id) => !Number.isSafeInteger(countRecord[id]) || (countRecord[id] as number) < 1)) return false;
  if (!unlocks.every((id) => typeof id === 'string' && UNLOCK_SET.has(id)) || new Set(unlocks).size !== unlocks.length) return false;
  const crestEarned = bestRecord['summit-chess'] === 'gold';
  return crestEarned === unlocks.includes('chessmaster-crest');
}

/** Persistent activity medals. Replays count, but only a new personal-best tier pays the tier difference. */
export class MiniGameSystem {
  private bestTier: Partial<Record<MiniGameId, RewardTier>> = {};
  private completionCounts: Partial<Record<MiniGameId, number>> = {};
  private readonly unlockedRewards = new Set<string>();

  getDefinition(gameId: MiniGameId): MiniGameDefinition { return MINI_GAME_BY_ID[gameId]; }
  getForZone(zoneId: ZoneId): readonly MiniGameDefinition[] { return MINI_GAME_DEFINITIONS.filter((game) => game.zoneId === zoneId); }
  getBestTier(gameId: MiniGameId): RewardTier | null { return this.bestTier[gameId] ?? null; }
  getCompletionCount(gameId: MiniGameId): number { return this.completionCounts[gameId] ?? 0; }
  hasUnlock(id: string): boolean { return this.unlockedRewards.has(id); }

  previewPayout(gameId: MiniGameId, tier: RewardTier): MiniGamePayout {
    const definition = MINI_GAME_BY_ID[gameId];
    const previousTier = this.bestTier[gameId];
    const previousIndex = previousTier ? TIER_ORDER.indexOf(previousTier) : -1;
    const nextIndex = TIER_ORDER.indexOf(tier);
    if (nextIndex <= previousIndex) return ZERO_PAYOUT;
    const current = definition.rewards[tier];
    const previous = previousTier ? definition.rewards[previousTier] : { xp: 0, coins: 0, resources: {} };
    const resources: Partial<Record<ResourceId, number>> = {};
    for (const resourceId of Object.keys(current.resources) as ResourceId[]) {
      const delta = (current.resources[resourceId] ?? 0) - (previous.resources[resourceId] ?? 0);
      if (delta > 0) resources[resourceId] = delta;
    }
    const newUnlocks = (current.unlocks ?? []).filter((id) => !this.unlockedRewards.has(id));
    return {
      xp: Math.max(0, current.xp - previous.xp),
      coins: Math.max(0, current.coins - previous.coins),
      resources,
      newUnlocks,
      improvedTier: true,
    };
  }

  recordCompletion(gameId: MiniGameId, tier: RewardTier): void {
    const previousTier = this.bestTier[gameId];
    if (!previousTier || TIER_ORDER.indexOf(tier) > TIER_ORDER.indexOf(previousTier)) {
      this.bestTier[gameId] = tier;
      const unlocks = MINI_GAME_BY_ID[gameId].rewards[tier].unlocks ?? [];
      for (const id of unlocks) this.unlockedRewards.add(id);
    }
    this.completionCounts[gameId] = Math.min(1_000_000, (this.completionCounts[gameId] ?? 0) + 1);
  }

  snapshot(): MiniGameSnapshot {
    return {
      bestTierByGame: { ...this.bestTier },
      completionCounts: { ...this.completionCounts },
      unlockedRewards: [...this.unlockedRewards].sort(),
    };
  }

  restore(snapshot: MiniGameSnapshot): boolean {
    if (!validateMiniGameSnapshot(snapshot)) return false;
    this.bestTier = { ...snapshot.bestTierByGame };
    this.completionCounts = { ...snapshot.completionCounts };
    this.unlockedRewards.clear();
    for (const id of snapshot.unlockedRewards) this.unlockedRewards.add(id);
    return true;
  }

  reset(): void {
    this.bestTier = {};
    this.completionCounts = {};
    this.unlockedRewards.clear();
  }
}

export function tierFromProgress(progress: number): RewardTier {
  if (progress >= 0.85) return 'gold';
  if (progress >= 0.55) return 'silver';
  return 'bronze';
}
