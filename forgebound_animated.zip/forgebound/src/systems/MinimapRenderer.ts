import * as THREE from 'three';
import type { ZoneId } from '../types/zones';

export type MinimapMarkerKind = 'player' | 'civilian' | 'dog' | 'ben' | 'blacksmith' | 'refiner' | 'quest';
export interface MinimapMarker { readonly id: string; readonly kind: MinimapMarkerKind; readonly x: number; readonly z: number; }

const MARKER_STYLE: Readonly<Record<MinimapMarkerKind, { color: string; radius: number; label: string }>> = {
  player: { color: '#f4ead0', radius: 5, label: 'P' },
  civilian: { color: '#8fb6a1', radius: 3, label: '' },
  dog: { color: '#d4a16e', radius: 4, label: 'D' },
  ben: { color: '#e1be69', radius: 4, label: 'B' },
  blacksmith: { color: '#d88958', radius: 4, label: 'F' },
  refiner: { color: '#b2a0d8', radius: 4, label: 'R' },
  quest: { color: '#ffe45c', radius: 6, label: '✚' },
};

/** Canvas minimap. World north is -Z; north-lock is enabled by default. */
export class MinimapRenderer {
  private readonly context: CanvasRenderingContext2D;
  private markers: readonly MinimapMarker[] = [];
  private player = new THREE.Vector3();
  private heading = 0;
  private zone: ZoneId = 'starter-quarry';
  private northLocked = true;
  private zoom = 1;
  private lastPaint = 0;

  constructor(private readonly canvas: HTMLCanvasElement) {
    const context = canvas.getContext('2d');
    if (!context) throw new Error('The minimap canvas is unavailable.');
    this.context = context;
    this.resize();
  }

  setSettings(northLocked: boolean, zoom: number): void {
    this.northLocked = northLocked;
    this.zoom = THREE.MathUtils.clamp(zoom, 0.6, 2.5);
  }

  getSettings(): { northLocked: boolean; zoom: number } { return { northLocked: this.northLocked, zoom: this.zoom }; }

  setWorld(zone: ZoneId, player: THREE.Vector3, heading: number, markers: readonly MinimapMarker[]): void {
    this.zone = zone;
    this.player.copy(player);
    this.heading = heading;
    this.markers = markers;
  }

  update(now = performance.now(), force = false): void {
    if (!force && now - this.lastPaint < 160) return;
    this.lastPaint = now;
    const { context: ctx, canvas } = this;
    const width = canvas.width;
    const height = canvas.height;
    const cx = width / 2;
    const cy = height / 2;
    const radius = Math.min(width, height) * 0.44;
    ctx.clearRect(0, 0, width, height);
    ctx.save();
    ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI * 2); ctx.clip();
    ctx.fillStyle = 'rgba(13, 23, 24, .94)'; ctx.fillRect(0, 0, width, height);
    ctx.strokeStyle = 'rgba(213, 198, 161, .15)'; ctx.lineWidth = 1;
    for (let ring = 1; ring <= 3; ring += 1) {
      ctx.beginPath(); ctx.arc(cx, cy, radius * ring / 3, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.beginPath(); ctx.moveTo(cx - radius, cy); ctx.lineTo(cx + radius, cy); ctx.moveTo(cx, cy - radius); ctx.lineTo(cx, cy + radius); ctx.stroke();
    const rotation = this.northLocked ? 0 : -this.heading;
    const scale = radius / 35 * this.zoom;
    const cos = Math.cos(rotation);
    const sin = Math.sin(rotation);
    for (const marker of this.markers) {
      const dx = marker.x - this.player.x;
      const dz = marker.z - this.player.z;
      const px = cx + (dx * cos - dz * sin) * scale;
      const py = cy + (dx * sin + dz * cos) * scale;
      if (Math.hypot(px - cx, py - cy) > radius - 5) continue;
      const style = MARKER_STYLE[marker.kind];
      ctx.fillStyle = style.color;
      ctx.beginPath(); ctx.arc(px, py, style.radius, 0, Math.PI * 2); ctx.fill();
      if (style.label) {
        ctx.fillStyle = '#182020'; ctx.font = '700 8px system-ui'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(style.label, px, py + 0.5);
      }
    }
    // Player arrow is always drawn above the marker layer.
    ctx.save(); ctx.translate(cx, cy); if (this.northLocked) ctx.rotate(this.heading);
    ctx.fillStyle = '#fff4d4'; ctx.strokeStyle = '#27312c'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, -9); ctx.lineTo(6, 7); ctx.lineTo(0, 4); ctx.lineTo(-6, 7); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
    ctx.restore();
    ctx.strokeStyle = 'rgba(220, 188, 126, .75)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = '#e5d1a7'; ctx.font = '700 9px ui-monospace, monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('N', cx, 6);
    ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(218, 218, 197, .65)'; ctx.font = '8px ui-monospace, monospace';
    ctx.fillText(this.zone.replace('-', ' ').toUpperCase(), 9, height - 14);
  }

  resize(): void {
    const scale = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
    const size = 180;
    this.canvas.width = Math.round(size * scale);
    this.canvas.height = Math.round(size * scale);
    this.canvas.style.width = `${size}px`;
    this.canvas.style.height = `${size}px`;
    this.context.setTransform(scale, 0, 0, scale, 0, 0);
  }
}
