export const RESOURCE_IDS = [
  'copper-ore',
  'iron-ore',
  'gold-ore',
  'crystal',
  'copper-ingot',
  'iron-ingot',
  'gold-ingot',
  'crystal-ingot',
  'timber',
  'magma-corn',
  'crystal-cod',
  'frostglass-alloy',
] as const;

export type ResourceId = (typeof RESOURCE_IDS)[number];

export interface ResourceDefinition {
  readonly id: ResourceId;
  readonly name: string;
  readonly shortName: string;
  readonly color: number;
  readonly category: 'ore' | 'ingot' | 'gem' | 'special';
}

export const RESOURCE_DEFINITIONS: Readonly<Record<ResourceId, ResourceDefinition>> = {
  'copper-ore': { id: 'copper-ore', name: 'Copper Ore', shortName: 'Copper Ore', color: 0xc87942, category: 'ore' },
  'iron-ore': { id: 'iron-ore', name: 'Iron Ore', shortName: 'Iron Ore', color: 0x8b9b9c, category: 'ore' },
  'gold-ore': { id: 'gold-ore', name: 'Gold Ore', shortName: 'Gold Ore', color: 0xe2b653, category: 'ore' },
  crystal: { id: 'crystal', name: 'Crystal', shortName: 'Crystal', color: 0x83a9ec, category: 'gem' },
  'copper-ingot': { id: 'copper-ingot', name: 'Copper Ingot', shortName: 'Copper Bar', color: 0xd58b58, category: 'ingot' },
  'iron-ingot': { id: 'iron-ingot', name: 'Iron Ingot', shortName: 'Iron Bar', color: 0xb7c4c3, category: 'ingot' },
  'gold-ingot': { id: 'gold-ingot', name: 'Gold Ingot', shortName: 'Gold Bar', color: 0xf0ca69, category: 'ingot' },
  'crystal-ingot': { id: 'crystal-ingot', name: 'Crystal Ingot', shortName: 'Crystal Bar', color: 0x9bbaf5, category: 'ingot' },
  timber: { id: 'timber', name: 'Timber', shortName: 'Timber', color: 0x9a6943, category: 'special' },
  'magma-corn': { id: 'magma-corn', name: 'Magma Corn', shortName: 'Magma Corn', color: 0xf18a3b, category: 'special' },
  'crystal-cod': { id: 'crystal-cod', name: 'Crystal Cod', shortName: 'Crystal Cod', color: 0x8ac9e8, category: 'special' },
  'frostglass-alloy': { id: 'frostglass-alloy', name: 'Frostglass Alloy', shortName: 'Frostglass Alloy', color: 0xa8c8ef, category: 'special' },
};
