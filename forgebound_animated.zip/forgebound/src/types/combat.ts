import type { ResourceId } from './resources';
import type { ZoneId } from './zones';

export const ENEMY_IDS = ['quarry-crawler', 'ember-stalker', 'crystal-sentinel'] as const;
export type EnemyId = (typeof ENEMY_IDS)[number];

export type EnemyState = 'idle' | 'detect' | 'chase' | 'attack' | 'return' | 'pacified' | 'defeated';

export interface LootDropDefinition {
  readonly resourceId: ResourceId;
  readonly chance: number;
  readonly minimumQuantity: number;
  readonly maximumQuantity: number;
}

export interface EnemyDefinition {
  readonly id: EnemyId;
  readonly zoneId: ZoneId;
  readonly name: string;
  readonly title: string;
  readonly moveSpeed: number;
  readonly maximumHealth: number;
  readonly coinReward: number;
  readonly respawnSeconds: number;
  readonly attackDamage: number;
  readonly attackRange: number;
  readonly attackCooldownSeconds: number;
  readonly detectionRange: number;
  readonly leashRange: number;
  readonly xpReward: number;
  readonly pacifiedSeconds: number;
  readonly bodyColor: number;
  readonly accentColor: number;
  readonly emissiveColor: number;
  readonly bodyScale: number;
  readonly loot: readonly LootDropDefinition[];
  readonly spawn: Readonly<{ x: number; z: number }>;
}

export interface LootDrop {
  readonly resourceId: ResourceId;
  readonly quantity: number;
}

export interface ProgressionSnapshot {
  readonly level: number;
  readonly currentXp: number;
  readonly xpToNextLevel: number;
  readonly totalXp: number;
}

export interface XpAwardResult {
  readonly ok: boolean;
  readonly awarded: number;
  readonly levelsGained: number;
  readonly snapshot: ProgressionSnapshot;
}
