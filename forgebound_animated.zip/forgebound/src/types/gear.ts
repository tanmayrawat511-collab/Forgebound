export const GEAR_IDS = [
  'daggers', 'straight-sword', 'mace', 'gauntlet', 'axe', 'katana', 'great-sword',
  'spear', 'great-axe', 'colossal-sword', 'helmet', 'chestplate', 'leggings',
] as const;
export type GearId = (typeof GEAR_IDS)[number];
export type GearMaterialId = 'copper' | 'iron' | 'gold' | 'crystal';
export type GearSlot = 'weapon' | 'helmet' | 'chestplate' | 'leggings';

export interface GearStats {
  readonly damage: number;
  readonly attackSpeed: number;
  readonly defense: number;
}

export interface GearInstanceSnapshot {
  readonly instanceId: string;
  readonly gearId: GearId;
  readonly materialId: GearMaterialId;
  readonly refinementTier: 0 | 1 | 2 | 3 | 4 | 5;
  readonly obtainedAt: number;
}

export interface GearInventorySnapshot {
  readonly items: readonly GearInstanceSnapshot[];
  readonly equippedWeaponInstanceId: string | null;
  readonly equippedArmorInstanceIds: readonly string[];
  readonly nextInstanceSequence: number;
}

export interface GearRefinementSnapshot {
  /** Consecutive failed attempts, keyed by `${instanceId}:${targetTier}`. */
  readonly failureStreaks: Readonly<Record<string, number>>;
}

