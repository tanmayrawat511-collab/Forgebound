export const ZONE_IDS = ['starter-quarry', 'molten-caves', 'crystal-peaks'] as const;
export type ZoneId = (typeof ZONE_IDS)[number];

export interface WorldPosition {
  readonly x: number;
  readonly y: number;
  readonly z: number;
}

export interface ZoneDefinition {
  readonly id: ZoneId;
  readonly name: string;
  readonly subtitle: string;
  readonly description: string;
  readonly requiredLevel: number;
  readonly center: Readonly<{ x: number; z: number }>;
  readonly spawn: WorldPosition;
  readonly palette: Readonly<{
    background: number;
    fog: number;
    floor: number;
    wall: number;
    obstacle: number;
    skyLight: number;
    groundLight: number;
    keyLight: number;
    fillLight: number;
    accent: number;
  }>;
}


export interface ZoneGateDefinition {
  readonly id: string;
  readonly sourceZoneId: ZoneId;
  readonly targetZoneId: ZoneId;
  readonly position: Readonly<{ x: number; z: number }>;
  readonly label: string;
  readonly color: number;
  readonly requiredLevel: number;
}
