export const EQUIPMENT_IDS = [
  'starter-pickaxe',
  'starter-sword',
  'copper-pickaxe',
  'copper-sword',
  'iron-maul',
  'basalt-pickaxe',
  'crystal-pickaxe',
] as const;

export type EquipmentId = (typeof EQUIPMENT_IDS)[number];
export type EquipmentSlot = 'pickaxe' | 'weapon';

interface EquipmentBase {
  readonly id: EquipmentId;
  readonly name: string;
  readonly description: string;
  readonly slot: EquipmentSlot;
  readonly tier: number;
}

export interface PickaxeDefinition extends EquipmentBase {
  readonly slot: 'pickaxe';
  readonly miningPower: number;
}

export interface WeaponDefinition extends EquipmentBase {
  readonly slot: 'weapon';
  readonly attackDamage: number;
  readonly attacksPerSecond: number;
}

export type EquipmentDefinition = PickaxeDefinition | WeaponDefinition;

export interface EquipmentSnapshot {
  readonly ownedEquipmentIds: readonly EquipmentId[];
  readonly equippedPickaxeId: EquipmentId | null;
  readonly equippedWeaponId: EquipmentId | null;
}
