import type { AssetId } from '../assets/asset-manifest';
import type { MiniGameId } from '../systems/MiniGameSystem';
import type { ZoneId } from '../types/zones';

export interface MiniGameStationDefinition {
  readonly id: string;
  readonly gameId: MiniGameId;
  readonly zoneId: ZoneId;
  readonly assetId: AssetId;
  readonly offset: Readonly<{ x: number; z: number }>;
  readonly label: string;
}

/** One physical activity station for every mini-game; all referenced meshes are Python GLBs. */
export const MINI_GAME_STATIONS: readonly MiniGameStationDefinition[] = [
  { id: 'station-cart-rally', gameId: 'quarry-cart-rally', zoneId: 'starter-quarry', assetId: 'ore-cart', offset: { x: -70, z: -48 }, label: 'CART RALLY' },
  { id: 'station-timber-relay', gameId: 'timberline-relay', zoneId: 'starter-quarry', assetId: 'timber-stack', offset: { x: -86, z: 40 }, label: 'TIMBER RELAY' },
  { id: 'station-veinfinder', gameId: 'veinfinder-challenge', zoneId: 'starter-quarry', assetId: 'ore-copper', offset: { x: 82, z: 42 }, label: 'VEINFINDER' },
  { id: 'station-magma-harvest', gameId: 'magma-corn-harvest', zoneId: 'molten-caves', assetId: 'magma-corn', offset: { x: -80, z: -52 }, label: 'MAGMA HARVEST' },
  { id: 'station-vent-tuning', gameId: 'vent-tuning', zoneId: 'molten-caves', assetId: 'volcanic-vent', offset: { x: 82, z: -45 }, label: 'VENT TUNING' },
  { id: 'station-basalt-sprint', gameId: 'basalt-sprint', zoneId: 'molten-caves', assetId: 'cave-arch', offset: { x: 0, z: 105 }, label: 'BASALT SPRINT' },
  { id: 'station-summit-chess', gameId: 'summit-chess', zoneId: 'crystal-peaks', assetId: 'chessboard', offset: { x: -82, z: -48 }, label: 'SUMMIT CHESS' },
  { id: 'station-crystal-fishing', gameId: 'crystal-fishing', zoneId: 'crystal-peaks', assetId: 'water-plane', offset: { x: 90, z: 42 }, label: 'CRYSTAL FISHING' },
  { id: 'station-glacier-echo', gameId: 'glacier-echo', zoneId: 'crystal-peaks', assetId: 'crystal-spire', offset: { x: 0, z: 110 }, label: 'GLACIER ECHO' },
];
