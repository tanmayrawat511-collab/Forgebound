import type { EquipmentId } from '../types/equipment';
import type { ZoneId } from '../types/zones';

export interface ShopStockDefinition {
  readonly id: string;
  readonly zoneId: ZoneId;
  readonly equipmentId: EquipmentId;
  readonly priceCoins: number;
  readonly minimumPlayerLevel: number;
  readonly stockLabel: string;
  readonly unlockQuestId?: string;
}

/** First-pass Coin prices; these are balance inputs and should be tuned after playtesting. */
export const SHOP_STOCK: readonly ShopStockDefinition[] = [
  { id: 'starter-copper-pickaxe', zoneId: 'starter-quarry', equipmentId: 'copper-pickaxe', priceCoins: 180, minimumPlayerLevel: 1, stockLabel: 'Copperhead Pickaxe', unlockQuestId: 'zone1-pickaxe-better-bite' },
  { id: 'starter-copper-sword', zoneId: 'starter-quarry', equipmentId: 'copper-sword', priceCoins: 240, minimumPlayerLevel: 2, stockLabel: 'Emberline Sword' },
  { id: 'molten-iron-maul', zoneId: 'molten-caves', equipmentId: 'iron-maul', priceCoins: 450, minimumPlayerLevel: 3, stockLabel: 'Deepdelver Maul' },
  { id: 'molten-basalt-pickaxe', zoneId: 'molten-caves', equipmentId: 'basalt-pickaxe', priceCoins: 650, minimumPlayerLevel: 3, stockLabel: 'Basalt Breaker', unlockQuestId: 'zone2-pickaxe-basalt-breaker' },
  { id: 'crystal-summit-pickaxe', zoneId: 'crystal-peaks', equipmentId: 'crystal-pickaxe', priceCoins: 1_050, minimumPlayerLevel: 5, stockLabel: 'Summit Tooth', unlockQuestId: 'zone3-pickaxe-summit-tooth' },
];
