import { ZONE_DEFINITIONS } from './zone-data';
import type { ZoneGateDefinition } from '../types/zones';

/** Directed gates form a compact progression route: Quarry ↔ Molten ↔ Peaks. */
export const ZONE_GATES: readonly ZoneGateDefinition[] = [
  {
    id: 'quarry-to-molten',
    sourceZoneId: 'starter-quarry',
    targetZoneId: 'molten-caves',
    position: { x: 0, z: -10.5 },
    label: 'Molten Caves',
    color: 0xff7a39,
    requiredLevel: ZONE_DEFINITIONS['molten-caves'].requiredLevel,
  },
  {
    id: 'molten-to-quarry',
    sourceZoneId: 'molten-caves',
    targetZoneId: 'starter-quarry',
    position: { x: 3000, z: 10.5 },
    label: 'Starter Quarry',
    color: 0xd7ad74,
    requiredLevel: ZONE_DEFINITIONS['starter-quarry'].requiredLevel,
  },
  {
    id: 'molten-to-peaks',
    sourceZoneId: 'molten-caves',
    targetZoneId: 'crystal-peaks',
    position: { x: 3000, z: -10.5 },
    label: 'Crystal Peaks',
    color: 0x8e9cff,
    requiredLevel: ZONE_DEFINITIONS['crystal-peaks'].requiredLevel,
  },
  {
    id: 'peaks-to-molten',
    sourceZoneId: 'crystal-peaks',
    targetZoneId: 'molten-caves',
    position: { x: 6000, z: 10.5 },
    label: 'Molten Caves',
    color: 0xff8b4e,
    requiredLevel: ZONE_DEFINITIONS['molten-caves'].requiredLevel,
  },
];
