import type { ResourceId } from '../types/resources';
import type { ZoneId } from '../types/zones';

export type QuestObjective =
  | { readonly id: string; readonly text: string; readonly kind: 'mine' | 'collect' | 'smelt' | 'craft'; readonly resourceId: ResourceId; readonly amount: number }
  | { readonly id: string; readonly text: string; readonly kind: 'defeat'; readonly enemyId: string; readonly amount: number }
  | { readonly id: string; readonly text: string; readonly kind: 'interact'; readonly objectId: string; readonly amount: number }
  | { readonly id: string; readonly text: string; readonly kind: 'talk'; readonly npcId: string; readonly amount: number }
  | { readonly id: string; readonly text: string; readonly kind: 'refine'; readonly rank: number; readonly amount: number }
  | { readonly id: string; readonly text: string; readonly kind: 'minigame'; readonly gameId: string; readonly amount: number };

export interface QuestReward {
  readonly xp: number;
  readonly coins: number;
  readonly resources?: Partial<Record<ResourceId, number>>;
  readonly unlocks?: readonly string[];
}

export interface QuestDefinition {
  readonly id: string;
  readonly npcId: string;
  readonly zoneId: ZoneId;
  readonly name: string;
  readonly category: 'main' | 'side';
  readonly description: string;
  readonly prerequisites: readonly string[];
  readonly minimumLevel: number;
  readonly objectives: readonly QuestObjective[];
  readonly turnInCosts?: Partial<Record<ResourceId, number>>;
  readonly rewards: QuestReward;
}

const mine = (id: string, text: string, resourceId: ResourceId, amount: number): QuestObjective => ({ id, text, kind: 'mine', resourceId, amount });
const collect = (id: string, text: string, resourceId: ResourceId, amount: number): QuestObjective => ({ id, text, kind: 'collect', resourceId, amount });
const interact = (id: string, text: string, objectId: string, amount = 1): QuestObjective => ({ id, text, kind: 'interact', objectId, amount });
const defeat = (id: string, text: string, enemyId: string): QuestObjective => ({ id, text, kind: 'defeat', enemyId, amount: 1 });
const smelt = (id: string, text: string, resourceId: ResourceId, amount: number): QuestObjective => ({ id, text, kind: 'smelt', resourceId, amount });
const craft = (id: string, text: string, resourceId: ResourceId, amount: number): QuestObjective => ({ id, text, kind: 'craft', resourceId, amount });
const talk = (id: string, text: string, npcId: string): QuestObjective => ({ id, text, kind: 'talk', npcId, amount: 1 });
const refine = (id: string, text: string, rank: number): QuestObjective => ({ id, text, kind: 'refine', rank, amount: 1 });
const mini = (id: string, text: string, gameId: string): QuestObjective => ({ id, text, kind: 'minigame', gameId, amount: 1 });

/** Phase J2's authored quest register. Mini-game event hooks are ready for Phase J3. */
export const QUEST_DEFINITIONS: readonly QuestDefinition[] = [
  // Zone 1 — Starter Quarry
  { id: 'zone1-main-quarry-wakes', npcId: 'mara-flint', zoneId: 'starter-quarry', name: 'The Quarry Wakes', category: 'main', description: 'Restore the quarry gateway and make the first road safe.', prerequisites: [], minimumLevel: 1, objectives: [mine('copper', 'Mine 4 Copper Ore', 'copper-ore', 4), mine('iron', 'Mine 2 Iron Ore', 'iron-ore', 2), defeat('crawler', 'Defeat the Quarry Crawler', 'quarry-crawler'), interact('relay', 'Activate the quarry gateway relay', 'quarry-relay')], rewards: { xp: 120, coins: 100, resources: { 'copper-ingot': 2 }, unlocks: ['molten-caves-main-gate'] } },
  { id: 'zone1-mining-surveyors-share', npcId: 'oren-veinward', zoneId: 'starter-quarry', name: "A Surveyor's Share", category: 'side', description: 'Prove your mining skills and deliver the surveyed ore.', prerequisites: [], minimumLevel: 1, objectives: [mine('copper', 'Mine 3 Copper Ore', 'copper-ore', 3), mine('iron', 'Mine 2 Iron Ore', 'iron-ore', 2)], turnInCosts: { 'copper-ore': 3, 'iron-ore': 2 }, rewards: { xp: 45, coins: 30, resources: { 'copper-ingot': 1 } } },
  { id: 'zone1-blacksmith-first-heat', npcId: 'branna-forge', zoneId: 'starter-quarry', name: 'First Heat', category: 'side', description: 'Learn to smelt copper into a usable ingot.', prerequisites: [], minimumLevel: 1, objectives: [mine('copper', 'Mine 2 Copper Ore', 'copper-ore', 2), smelt('ingot', 'Smelt 1 Copper Ingot', 'copper-ingot', 1)], turnInCosts: { 'copper-ingot': 1 }, rewards: { xp: 45, coins: 35, resources: { 'iron-ore': 1 } } },
  { id: 'zone1-pickaxe-better-bite', npcId: 'tovin-picks', zoneId: 'starter-quarry', name: 'A Better Bite', category: 'side', description: 'Bring timber and copper to unlock improved pickaxe stock.', prerequisites: [], minimumLevel: 1, objectives: [collect('timber', 'Gather 2 Timber', 'timber', 2), smelt('ingot', 'Smelt 1 Copper Ingot', 'copper-ingot', 1)], turnInCosts: { timber: 2, 'copper-ingot': 1 }, rewards: { xp: 50, coins: 25, unlocks: ['copperhead-pickaxe-stock'] } },
  { id: 'zone1-refiner-tempered-edge', npcId: 'selka-edgewell', zoneId: 'starter-quarry', name: 'The Tempered Edge', category: 'side', description: 'Refine your equipped weapon for the first time.', prerequisites: [], minimumLevel: 1, objectives: [refine('rank', 'Refine an equipped weapon to Rank I', 1)], rewards: { xp: 45, coins: 40, unlocks: ['weapon-refinement-rank-1'] } },
  { id: 'zone1-timber-timberline-stock', npcId: 'edda-pine', zoneId: 'starter-quarry', name: 'Timberline Stock', category: 'side', description: 'Gather six timber bundles for the settlement mill.', prerequisites: [], minimumLevel: 1, objectives: [collect('timber', 'Gather 6 Timber', 'timber', 6)], turnInCosts: { timber: 6 }, rewards: { xp: 40, coins: 30, resources: { 'copper-ore': 2 } } },
  { id: 'zone1-billy-backyard', npcId: 'billy', zoneId: 'starter-quarry', name: "Billy's Backyard", category: 'side', description: 'Clean up the five clutter piles scattered around Billy’s backyard.', prerequisites: [], minimumLevel: 1, objectives: [interact('clutter', 'Clear 5 clutter piles', 'billy-clutter', 5)], rewards: { xp: 30, coins: 25, resources: { timber: 2 } } },

  // Zone 2 — Molten Caves
  { id: 'zone2-main-heart-furnace', npcId: 'kael-ember', zoneId: 'molten-caves', name: 'Heart of the Furnace', category: 'main', description: 'Stabilize the ancient furnace and reopen the route to Crystal Peaks.', prerequisites: ['zone1-main-quarry-wakes'], minimumLevel: 3, objectives: [mine('iron', 'Mine 4 Iron Ore', 'iron-ore', 4), mine('gold', 'Mine 3 Gold Ore', 'gold-ore', 3), defeat('stalker', 'Defeat the Ember Stalker', 'ember-stalker'), interact('vents', 'Stabilize 3 geothermal vent controls', 'geothermal-vent-control', 3)], rewards: { xp: 230, coins: 175, resources: { 'gold-ingot': 2 }, unlocks: ['crystal-peaks-main-gate'] } },
  { id: 'zone2-mining-gold-under-ash', npcId: 'vexa-orehand', zoneId: 'molten-caves', name: 'Gold Under the Ash', category: 'side', description: 'Survey the deep deposits and deliver the ore sample.', prerequisites: ['zone1-main-quarry-wakes'], minimumLevel: 3, objectives: [mine('gold', 'Mine 5 Gold Ore', 'gold-ore', 5), mine('iron', 'Mine 3 Iron Ore', 'iron-ore', 3)], turnInCosts: { 'gold-ore': 5, 'iron-ore': 3 }, rewards: { xp: 70, coins: 55, resources: { 'gold-ore': 2 } } },
  { id: 'zone2-blacksmith-cinder-to-ingot', npcId: 'dagna-cinder', zoneId: 'molten-caves', name: 'Cinder to Ingot', category: 'side', description: 'Produce three gold ingots for advanced forge work.', prerequisites: ['zone1-main-quarry-wakes'], minimumLevel: 3, objectives: [mine('gold', 'Mine 6 Gold Ore', 'gold-ore', 6), smelt('gold-ingots', 'Smelt 3 Gold Ingots', 'gold-ingot', 3)], turnInCosts: { 'gold-ingot': 3 }, rewards: { xp: 70, coins: 60, resources: { 'iron-ingot': 1 }, unlocks: ['basalt-alloy-recipe'] } },
  { id: 'zone2-pickaxe-basalt-breaker', npcId: 'rurik-tongs', zoneId: 'molten-caves', name: 'Basalt Breaker', category: 'side', description: 'Supply the shop with advanced ingots to unlock its second tier.', prerequisites: ['zone2-blacksmith-cinder-to-ingot'], minimumLevel: 3, objectives: [smelt('gold', 'Smelt 2 Gold Ingots', 'gold-ingot', 2), smelt('iron', 'Smelt 2 Iron Ingots', 'iron-ingot', 2)], turnInCosts: { 'gold-ingot': 2, 'iron-ingot': 2 }, rewards: { xp: 60, coins: 65, unlocks: ['tier-2-pickaxe-stock'] } },
  { id: 'zone2-refiner-ashbright-edge', npcId: 'ilyra-temper', zoneId: 'molten-caves', name: 'Ashbright Edge', category: 'side', description: 'Raise your equipped weapon to refinement Rank II.', prerequisites: ['zone1-refiner-tempered-edge'], minimumLevel: 3, objectives: [refine('rank', 'Refine an equipped weapon to Rank II', 2)], rewards: { xp: 60, coins: 75, unlocks: ['weapon-refinement-rank-2'] } },
  { id: 'zone2-jason-magma-corn-season', npcId: 'jason', zoneId: 'molten-caves', name: 'Magma Corn Season', category: 'side', description: 'Harvest six ripe magma corns from Jason’s garden.', prerequisites: ['zone1-main-quarry-wakes'], minimumLevel: 3, objectives: [collect('harvest', 'Harvest 6 Magma Corn', 'magma-corn', 6)], turnInCosts: { 'magma-corn': 6 }, rewards: { xp: 55, coins: 50, resources: { 'gold-ore': 1, 'magma-corn': 1 } } },
  { id: 'zone2-tyler-wheres-cinder', npcId: 'tyler', zoneId: 'molten-caves', name: "Where's Cinder?", category: 'side', description: 'Find Tyler’s missing cat near the geothermal spring and bring it home.', prerequisites: ['zone1-main-quarry-wakes'], minimumLevel: 3, objectives: [interact('cat', 'Find and call Cinder', 'tyler-missing-cat')], rewards: { xp: 50, coins: 45, resources: { 'gold-ore': 2 } } },
  { id: 'zone2-michael-sealed-word', npcId: 'michael', zoneId: 'molten-caves', name: 'A Sealed Word', category: 'side', description: 'Carry Michael’s message to Jason, then report back.', prerequisites: ['zone1-main-quarry-wakes'], minimumLevel: 3, objectives: [talk('jason', 'Deliver the message to Jason', 'jason'), talk('michael', 'Report back to Michael', 'michael')], rewards: { xp: 45, coins: 45, resources: { 'iron-ingot': 1 } } },

  // Zone 3 — Crystal Peaks
  { id: 'zone3-main-crown-peaks', npcId: 'seraphine-ward', zoneId: 'crystal-peaks', name: 'Crown of the Peaks', category: 'main', description: 'Defeat the Crystal Sentinel and relight the summit beacon.', prerequisites: ['zone2-main-heart-furnace'], minimumLevel: 5, objectives: [mine('crystal', 'Mine 5 Crystals', 'crystal', 5), mine('gold', 'Mine 3 Gold Ore', 'gold-ore', 3), defeat('sentinel', 'Defeat the Crystal Sentinel', 'crystal-sentinel'), interact('beacon', 'Activate the summit beacon', 'summit-beacon')], rewards: { xp: 300, coins: 250, resources: { crystal: 3 }, unlocks: ['forgebound-story-complete'] } },
  { id: 'zone3-mining-deep-blue-vein', npcId: 'pell-crystalmark', zoneId: 'crystal-peaks', name: 'The Deep Blue Vein', category: 'side', description: 'Extract six crystals from the designated high-altitude seams.', prerequisites: ['zone2-main-heart-furnace'], minimumLevel: 5, objectives: [mine('crystal', 'Mine 6 Crystals', 'crystal', 6)], turnInCosts: { crystal: 6 }, rewards: { xp: 85, coins: 80, resources: { crystal: 2 } } },
  { id: 'zone3-blacksmith-peakforge', npcId: 'haldor-anvil', zoneId: 'crystal-peaks', name: 'The Peakforge', category: 'side', description: 'Create and deliver one Frostglass Alloy at the Peakforge.', prerequisites: ['zone2-main-heart-furnace'], minimumLevel: 5, objectives: [collect('gold', 'Gather 2 Gold Ingots', 'gold-ingot', 2), collect('crystal', 'Gather 3 Crystals', 'crystal', 3), craft('alloy', 'Craft 1 Frostglass Alloy at the Peakforge', 'frostglass-alloy', 1)], turnInCosts: { 'frostglass-alloy': 1 }, rewards: { xp: 100, coins: 100, unlocks: ['masterwork-recipe'] } },
  { id: 'zone3-pickaxe-summit-tooth', npcId: 'niva-clasp', zoneId: 'crystal-peaks', name: 'Summit Tooth', category: 'side', description: 'Supply the summit shop with high-grade crystals and gold.', prerequisites: ['zone2-pickaxe-basalt-breaker'], minimumLevel: 5, objectives: [collect('crystal', 'Gather 3 Crystals', 'crystal', 3), smelt('gold', 'Smelt 2 Gold Ingots', 'gold-ingot', 2)], turnInCosts: { crystal: 3, 'gold-ingot': 2 }, rewards: { xp: 90, coins: 110, unlocks: ['tier-3-pickaxe-stock'] } },
  { id: 'zone3-refiner-prismatic-temper', npcId: 'corin-quench', zoneId: 'crystal-peaks', name: 'Prismatic Temper', category: 'side', description: 'Complete the final weapon refinement at Corin’s bench.', prerequisites: ['zone2-refiner-ashbright-edge'], minimumLevel: 5, objectives: [refine('rank', 'Refine an equipped weapon to Rank III', 3)], rewards: { xp: 90, coins: 125, unlocks: ['weapon-refinement-rank-3'] } },
  { id: 'zone3-frank-checkmate-lookout', npcId: 'frank', zoneId: 'crystal-peaks', name: 'Checkmate at the Lookout', category: 'side', description: 'Beat Frank in a complete chess match at the mountain lookout.', prerequisites: ['zone2-main-heart-furnace'], minimumLevel: 5, objectives: [mini('chess', 'Win a chess match against Frank', 'summit-chess')], rewards: { xp: 55, coins: 80, unlocks: ['chessmaster-crest'] } },
  { id: 'zone3-james-cold-catch', npcId: 'james', zoneId: 'crystal-peaks', name: 'A Cold Catch', category: 'side', description: 'Catch and deliver three Crystal Cod from Crystal Lake.', prerequisites: ['zone2-main-heart-furnace'], minimumLevel: 5, objectives: [collect('cod', 'Catch 3 Crystal Cod', 'crystal-cod', 3)], turnInCosts: { 'crystal-cod': 3 }, rewards: { xp: 65, coins: 75, resources: { crystal: 2 } } },
];

export const QUEST_BY_ID: Readonly<Record<string, QuestDefinition>> = Object.fromEntries(
  QUEST_DEFINITIONS.map((quest) => [quest.id, quest]),
);
