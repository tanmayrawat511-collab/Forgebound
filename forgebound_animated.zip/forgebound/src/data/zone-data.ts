import type { ZoneDefinition, ZoneId } from '../types/zones';
import { OPEN_WORLD_ZONES } from '../world/open-world-config';
import { getZoneTerrainHeight } from '../world/terrain-height';

export const ZONE_ORDER: readonly ZoneId[] = [
  'starter-quarry',
  'molten-caves',
  'crystal-peaks',
];

export const ZONE_DEFINITIONS: Readonly<Record<ZoneId, ZoneDefinition>> = {
  'starter-quarry': {
    id: 'starter-quarry',
    name: 'Starter Quarry',
    subtitle: 'THE GREENSTONE FRONTIER',
    description: 'A weathered open quarry of copper seams, iron shelves, and old timber works.',
    requiredLevel: 1,
    center: { x: OPEN_WORLD_ZONES['starter-quarry'].originX, z: 0 },
    spawn: { x: 0, y: getZoneTerrainHeight('starter-quarry', 0, 0) + 0.92, z: 0 },
    palette: {
      background: 0x142126,
      fog: 0x142126,
      floor: 0x59634d,
      wall: 0x414b48,
      obstacle: 0x697166,
      skyLight: 0xb9d1c8,
      groundLight: 0x3c3025,
      keyLight: 0xffdfad,
      fillLight: 0xd18a4d,
      accent: 0x9aa38a,
    },
  },
  'molten-caves': {
    id: 'molten-caves',
    name: 'Molten Caves',
    subtitle: 'THE BASALT DEEPS',
    description: 'A deep basalt chamber lit by warm fissures, with iron shelves and gold seams.',
    requiredLevel: 3,
    center: { x: OPEN_WORLD_ZONES['molten-caves'].originX, z: 0 },
    spawn: { x: 3000, y: getZoneTerrainHeight('molten-caves', 0, 0) + 0.92, z: 0 },
    palette: {
      background: 0x211512,
      fog: 0x301b16,
      floor: 0x39302c,
      wall: 0x211f20,
      obstacle: 0x51403a,
      skyLight: 0xd59a77,
      groundLight: 0x25100b,
      keyLight: 0xffa45f,
      fillLight: 0xf05a22,
      accent: 0xff8a45,
    },
  },
  'crystal-peaks': {
    id: 'crystal-peaks',
    name: 'Crystal Peaks',
    subtitle: 'THE GLASSFROST HEIGHTS',
    description: 'A cold highland cavern where luminous crystal growths rise from pale stone.',
    requiredLevel: 5,
    center: { x: OPEN_WORLD_ZONES['crystal-peaks'].originX, z: 0 },
    spawn: { x: 6000, y: getZoneTerrainHeight('crystal-peaks', 0, 0) + 0.92, z: 0 },
    palette: {
      background: 0x101b31,
      fog: 0x182642,
      floor: 0x3e4a60,
      wall: 0x242f45,
      obstacle: 0x56637f,
      skyLight: 0xb8d5ff,
      groundLight: 0x1e2844,
      keyLight: 0xb5caff,
      fillLight: 0x6f82ea,
      accent: 0x9ab4ff,
    },
  },
};

export function getZoneDefinition(zoneId: ZoneId): ZoneDefinition {
  return ZONE_DEFINITIONS[zoneId];
}
