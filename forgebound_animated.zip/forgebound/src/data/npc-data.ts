import type { AssetId } from '../assets/asset-manifest';
import type { ZoneId } from '../types/zones';
import type { MiniGameId } from '../systems/MiniGameSystem';

export type NpcRole = 'combat' | 'mining' | 'blacksmith' | 'pickaxe-shop' | 'weapon-refiner' | 'secondary' | 'tutorial';
export type NpcService = 'none' | 'forge' | 'shop' | 'refiner' | 'minigame';

export interface NpcDefinition {
  readonly id: string;
  readonly name: string;
  readonly title: string;
  readonly zoneId: ZoneId;
  readonly role: NpcRole;
  readonly service: NpcService;
  readonly questId: string;
  readonly assetId: AssetId;
  /** Zone-local offsets from the zone spawn point, in metres. */
  readonly offset: Readonly<{ x: number; z: number }>;
  readonly greeting: string;
  readonly miniGameId?: MiniGameId;
}

export const NPC_DEFINITIONS: readonly NpcDefinition[] = [
  // Zone 1 — Starter Quarry
  { id: 'mara-flint', name: 'Mara Flint', title: 'Combat Quest Giver', zoneId: 'starter-quarry', role: 'combat', service: 'none', questId: 'zone1-main-quarry-wakes', assetId: 'npc-combat-01', offset: { x: 0, z: -7 }, greeting: 'The quarry roads are no longer safe. I need someone who can hold a line.' },
  { id: 'oren-veinward', name: 'Oren Veinward', title: 'Mining Quest Giver', zoneId: 'starter-quarry', role: 'mining', service: 'none', questId: 'zone1-mining-surveyors-share', assetId: 'npc-miner-01', offset: { x: -11, z: -7 }, greeting: 'A good prospector knows the rock before taking a swing.' },
  { id: 'branna-forge', name: 'Branna Forge', title: 'Blacksmith', zoneId: 'starter-quarry', role: 'blacksmith', service: 'forge', questId: 'zone1-blacksmith-first-heat', assetId: 'npc-blacksmith-01', offset: { x: 11, z: -7 }, greeting: 'Bring me ore and I will show you what heat can do.' },
  { id: 'tovin-picks', name: 'Tovin Picks', title: 'Pickaxe Shop Owner', zoneId: 'starter-quarry', role: 'pickaxe-shop', service: 'shop', questId: 'zone1-pickaxe-better-bite', assetId: 'npc-shopkeeper-01', offset: { x: 17, z: 2 }, greeting: 'A sharper tool saves time, and time saves backs.' },
  { id: 'selka-edgewell', name: 'Selka Edgewell', title: 'Weapon Refiner', zoneId: 'starter-quarry', role: 'weapon-refiner', service: 'refiner', questId: 'zone1-refiner-tempered-edge', assetId: 'npc-refiner-01', offset: { x: -17, z: 2 }, greeting: 'Even a plain blade can learn a better edge.' },
  { id: 'edda-pine', name: 'Edda Pine', title: 'Timber Quest Giver', zoneId: 'starter-quarry', role: 'secondary', service: 'none', questId: 'zone1-timber-timberline-stock', assetId: 'npc-timber-giver', offset: { x: -20, z: 15 }, greeting: 'The mill is short on timber. The forest has plenty, if you are careful.' },
  { id: 'billy', name: 'Billy', title: 'Quarry Resident', zoneId: 'starter-quarry', role: 'secondary', service: 'none', questId: 'zone1-billy-backyard', assetId: 'npc-billy', offset: { x: 20, z: 15 }, greeting: 'Could you help me tidy my backyard? I will make it worth your while.' },
  { id: 'ben', name: 'Ben', title: 'Quarry Guide', zoneId: 'starter-quarry', role: 'tutorial', service: 'none', questId: 'zone1-main-quarry-wakes', assetId: 'npc-ben', offset: { x: -5, z: -13 }, greeting: 'Welcome to the frontier. There is a little you should know before you head out.' },

  // Zone 2 — Molten Caves
  { id: 'kael-ember', name: 'Kael Ember', title: 'Combat Quest Giver', zoneId: 'molten-caves', role: 'combat', service: 'none', questId: 'zone2-main-heart-furnace', assetId: 'npc-combat-02', offset: { x: 0, z: -8 }, greeting: 'The furnace has gone quiet, and the whole caldera is feeling it.' },
  { id: 'vexa-orehand', name: 'Vexa Orehand', title: 'Mining Quest Giver', zoneId: 'molten-caves', role: 'mining', service: 'none', questId: 'zone2-mining-gold-under-ash', assetId: 'npc-miner-02', offset: { x: -12, z: -8 }, greeting: 'There is gold under the ash. I need a reliable survey.' },
  { id: 'dagna-cinder', name: 'Dagna Cinder', title: 'Blacksmith', zoneId: 'molten-caves', role: 'blacksmith', service: 'forge', questId: 'zone2-blacksmith-cinder-to-ingot', assetId: 'npc-blacksmith-02', offset: { x: 12, z: -8 }, greeting: 'This forge can make more than bars. Bring the right stock.' },
  { id: 'rurik-tongs', name: 'Rurik Tongs', title: 'Pickaxe Shop Owner', zoneId: 'molten-caves', role: 'pickaxe-shop', service: 'shop', questId: 'zone2-pickaxe-basalt-breaker', assetId: 'npc-shopkeeper-02', offset: { x: 18, z: 3 }, greeting: 'Basalt eats cheap steel. You will need something better.' },
  { id: 'ilyra-temper', name: 'Ilyra Temper', title: 'Weapon Refiner', zoneId: 'molten-caves', role: 'weapon-refiner', service: 'refiner', questId: 'zone2-refiner-ashbright-edge', assetId: 'npc-refiner-02', offset: { x: -18, z: 3 }, greeting: 'The heat here can draw a keen edge from a worthy weapon.' },
  { id: 'jason', name: 'Jason', title: 'Garden Keeper', zoneId: 'molten-caves', role: 'secondary', service: 'none', questId: 'zone2-jason-magma-corn-season', assetId: 'npc-jason', offset: { x: -22, z: 17 }, greeting: 'My magma corn is ready, but the gardens need a hand.' },
  { id: 'tyler', name: 'Tyler', title: 'Worried Pet Owner', zoneId: 'molten-caves', role: 'secondary', service: 'none', questId: 'zone2-tyler-wheres-cinder', assetId: 'npc-tyler', offset: { x: 22, z: 17 }, greeting: 'Have you seen my cat, Cinder? He slipped away near the springs.' },
  { id: 'michael', name: 'Michael', title: 'Message Runner', zoneId: 'molten-caves', role: 'secondary', service: 'none', questId: 'zone2-michael-sealed-word', assetId: 'npc-michael', offset: { x: 0, z: 28 }, greeting: 'I have a message for Jason. Could you deliver it for me?' },

  // Zone 3 — Crystal Peaks
  { id: 'seraphine-ward', name: 'Seraphine Ward', title: 'Combat Quest Giver', zoneId: 'crystal-peaks', role: 'combat', service: 'none', questId: 'zone3-main-crown-peaks', assetId: 'npc-combat-03', offset: { x: 0, z: -8 }, greeting: 'The summit beacon is dark. The Sentinel will not let anyone approach.' },
  { id: 'pell-crystalmark', name: 'Pell Crystalmark', title: 'Mining Quest Giver', zoneId: 'crystal-peaks', role: 'mining', service: 'none', questId: 'zone3-mining-deep-blue-vein', assetId: 'npc-miner-03', offset: { x: -12, z: -8 }, greeting: 'The deep-blue seams are pure, but difficult to reach.' },
  { id: 'haldor-anvil', name: 'Haldor Anvil', title: 'Blacksmith', zoneId: 'crystal-peaks', role: 'blacksmith', service: 'forge', questId: 'zone3-blacksmith-peakforge', assetId: 'npc-blacksmith-03', offset: { x: 12, z: -8 }, greeting: 'Peakforge work demands a rare alloy. Let us make one.' },
  { id: 'niva-clasp', name: 'Niva Clasp', title: 'Pickaxe Shop Owner', zoneId: 'crystal-peaks', role: 'pickaxe-shop', service: 'shop', questId: 'zone3-pickaxe-summit-tooth', assetId: 'npc-shopkeeper-03', offset: { x: 18, z: 3 }, greeting: 'The summit stone is stubborn. My tools are not.' },
  { id: 'corin-quench', name: 'Corin Quench', title: 'Weapon Refiner', zoneId: 'crystal-peaks', role: 'weapon-refiner', service: 'refiner', questId: 'zone3-refiner-prismatic-temper', assetId: 'npc-refiner-03', offset: { x: -18, z: 3 }, greeting: 'Crystal resonance can bring a weapon to its final temper.' },
  { id: 'frank', name: 'Frank', title: 'Chess Challenger', zoneId: 'crystal-peaks', role: 'secondary', service: 'minigame', miniGameId: 'summit-chess', questId: 'zone3-frank-checkmate-lookout', assetId: 'npc-frank', offset: { x: -21, z: 17 }, greeting: 'Fancy a game of chess? I have been waiting for a worthy opponent.' },
  { id: 'james', name: 'James', title: 'Fisher', zoneId: 'crystal-peaks', role: 'secondary', service: 'minigame', miniGameId: 'crystal-fishing', questId: 'zone3-james-cold-catch', assetId: 'npc-james', offset: { x: 21, z: 17 }, greeting: 'Crystal Lake is full of cod today. Bring me three and I will share my tackle.' },
];

export const NPC_BY_ID: Readonly<Record<string, NpcDefinition>> = Object.fromEntries(
  NPC_DEFINITIONS.map((npc) => [npc.id, npc]),
);
