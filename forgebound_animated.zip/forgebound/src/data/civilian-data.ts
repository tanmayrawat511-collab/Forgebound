import type { ZoneId } from '../types/zones';

export interface CivilianDefinition {
  readonly id: string;
  readonly name: string;
  readonly zoneId: ZoneId;
  readonly assetId: `civilian-${string}`;
  readonly offset: Readonly<{ x: number; z: number }>;
  readonly walkRadius: number;
  readonly walkSpeed: number;
}

const names = [
  'Ada', 'Alden', 'Bera', 'Bram', 'Celia', 'Cobb', 'Dara', 'Davin', 'Elio',
  'Enna', 'Fenn', 'Gale', 'Hesta', 'Ivo', 'Jori', 'Kessa', 'Lenn', 'Mira',
  'Noll', 'Orla', 'Perrin', 'Quin', 'Rhea', 'Tamsin', 'Wren',
] as const;
const zones: readonly ZoneId[] = [
  'starter-quarry', 'starter-quarry', 'starter-quarry', 'starter-quarry', 'starter-quarry',
  'starter-quarry', 'starter-quarry', 'starter-quarry', 'starter-quarry',
  'molten-caves', 'molten-caves', 'molten-caves', 'molten-caves', 'molten-caves',
  'molten-caves', 'molten-caves', 'molten-caves',
  'crystal-peaks', 'crystal-peaks', 'crystal-peaks', 'crystal-peaks', 'crystal-peaks',
  'crystal-peaks', 'crystal-peaks', 'crystal-peaks',
];

export const CIVILIAN_DEFINITIONS: readonly CivilianDefinition[] = names.map((name, index) => ({
  id: `civilian-${String(index + 1).padStart(2, '0')}`,
  name,
  zoneId: zones[index]!,
  assetId: `civilian-${String(index + 1).padStart(2, '0')}` as `civilian-${string}`,
  offset: { x: -16 + (index % 5) * 8 + (Math.floor(index / 9) * 3), z: 25 + (index % 3) * 7 },
  walkRadius: 3.5 + (index % 4) * 0.8,
  walkSpeed: 0.45 + (index % 5) * 0.08,
}));

export const CIVILIAN_CAP_PER_ZONE = 6;
export const ACTIVE_DOG_CAP = 1;
