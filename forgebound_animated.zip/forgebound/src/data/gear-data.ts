import type { GearId, GearMaterialId, GearSlot, GearStats } from '../types/gear';

export interface GearDefinition {
  readonly id: GearId;
  readonly name: string;
  readonly slot: GearSlot;
  readonly description: string;
  readonly modelAsset: string;
  readonly baseStats: GearStats;
}

export interface GearMaterialDefinition {
  readonly id: GearMaterialId;
  readonly label: string;
  readonly ingotId: 'copper-ingot' | 'iron-ingot' | 'gold-ingot' | 'crystal-ingot';
  /** Data-driven starting balance values; tune after combat playtesting. */
  readonly statMultiplier: number;
  readonly tint: number;
}

export const GEAR_MATERIALS: Readonly<Record<GearMaterialId, GearMaterialDefinition>> = {
  copper: { id: 'copper', label: 'Copper', ingotId: 'copper-ingot', statMultiplier: 1.00, tint: 0xc87942 },
  iron: { id: 'iron', label: 'Iron', ingotId: 'iron-ingot', statMultiplier: 1.18, tint: 0xb8c4c4 },
  gold: { id: 'gold', label: 'Gold', ingotId: 'gold-ingot', statMultiplier: 1.38, tint: 0xe2b653 },
  crystal: { id: 'crystal', label: 'Crystal', ingotId: 'crystal-ingot', statMultiplier: 1.62, tint: 0x83a9ec },
};

export const GEAR_DEFINITIONS: Readonly<Record<GearId, GearDefinition>> = {
  daggers: { id: 'daggers', name: 'Daggers', slot: 'weapon', description: 'A matched pair built for fast, close strikes.', modelAsset: 'gear-daggers', baseStats: { damage: 4, attackSpeed: 2.0, defense: 0 } },
  'straight-sword': { id: 'straight-sword', name: 'Straight Sword', slot: 'weapon', description: 'A balanced single-hand blade.', modelAsset: 'gear-straight-sword', baseStats: { damage: 8, attackSpeed: 1.25, defense: 0 } },
  mace: { id: 'mace', name: 'Mace', slot: 'weapon', description: 'A heavy head delivers deliberate blows.', modelAsset: 'gear-mace', baseStats: { damage: 12, attackSpeed: 0.72, defense: 0 } },
  gauntlet: { id: 'gauntlet', name: 'Gauntlet', slot: 'weapon', description: 'Reinforced striking gloves.', modelAsset: 'gear-gauntlet', baseStats: { damage: 6, attackSpeed: 1.55, defense: 1 } },
  axe: { id: 'axe', name: 'Axe', slot: 'weapon', description: 'A compact, hard-hitting cutting weapon.', modelAsset: 'gear-axe', baseStats: { damage: 10, attackSpeed: 0.95, defense: 0 } },
  katana: { id: 'katana', name: 'Katana', slot: 'weapon', description: 'A curved blade with a quick draw.', modelAsset: 'gear-katana', baseStats: { damage: 9, attackSpeed: 1.35, defense: 0 } },
  'great-sword': { id: 'great-sword', name: 'Great Sword', slot: 'weapon', description: 'A long two-handed blade.', modelAsset: 'gear-great-sword', baseStats: { damage: 16, attackSpeed: 0.58, defense: 0 } },
  spear: { id: 'spear', name: 'Spear', slot: 'weapon', description: 'A long reach weapon with a balanced shaft.', modelAsset: 'gear-spear', baseStats: { damage: 11, attackSpeed: 1.05, defense: 0 } },
  'great-axe': { id: 'great-axe', name: 'Great Axe', slot: 'weapon', description: 'A broad, two-handed chopping weapon.', modelAsset: 'gear-great-axe', baseStats: { damage: 19, attackSpeed: 0.48, defense: 0 } },
  'colossal-sword': { id: 'colossal-sword', name: 'Colossal Sword', slot: 'weapon', description: 'A massive blade designed for powerful, slow attacks.', modelAsset: 'gear-colossal-sword', baseStats: { damage: 24, attackSpeed: 0.34, defense: 0 } },
  helmet: { id: 'helmet', name: 'Helmet', slot: 'helmet', description: 'A fitted protective helm.', modelAsset: 'gear-helmet', baseStats: { damage: 0, attackSpeed: 0, defense: 5 } },
  chestplate: { id: 'chestplate', name: 'Chestplate', slot: 'chestplate', description: 'A reinforced chest guard.', modelAsset: 'gear-chestplate', baseStats: { damage: 0, attackSpeed: 0, defense: 12 } },
  leggings: { id: 'leggings', name: 'Leggings', slot: 'leggings', description: 'Protective leg armor with flexible joints.', modelAsset: 'gear-leggings', baseStats: { damage: 0, attackSpeed: 0, defense: 7 } },
};

export const REFINEMENT_SUCCESS_CHANCES = [0, 0.90, 0.85, 0.80, 0.75, 0.70] as const;
export const REFINEMENT_STAT_BONUSES = [0, 0.05, 0.10, 0.15, 0.20, 0.25] as const;

export function getGearStats(gearId: GearId, materialId: GearMaterialId, refinementTier: number): GearStats {
  const base = GEAR_DEFINITIONS[gearId].baseStats;
  const material = GEAR_MATERIALS[materialId];
  const refined = 1 + REFINEMENT_STAT_BONUSES[Math.max(0, Math.min(5, Math.floor(refinementTier))) as 0 | 1 | 2 | 3 | 4 | 5];
  return {
    damage: Math.round(base.damage * material.statMultiplier * refined * 100) / 100,
    attackSpeed: Math.round(base.attackSpeed * material.statMultiplier * refined * 100) / 100,
    defense: Math.round(base.defense * material.statMultiplier * refined * 100) / 100,
  };
}
