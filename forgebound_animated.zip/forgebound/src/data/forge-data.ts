import type { ResourceId } from '../types/resources';
import type { EquipmentId } from '../types/equipment';

export type ResourceCosts = Partial<Record<ResourceId, number>>;

export interface SmeltingRecipe {
  readonly id: string;
  readonly name: string;
  readonly description: string;
  readonly inputs: ResourceCosts;
  readonly outputs: ResourceCosts;
}

export interface CraftingRecipe {
  readonly id: string;
  readonly equipmentId: EquipmentId;
  readonly costs: ResourceCosts;
}

export const SMELTING_RECIPES: readonly SmeltingRecipe[] = [
  {
    id: 'smelt-copper',
    name: 'Copper Ingot',
    description: 'Smelt copper ore into a workable bar.',
    inputs: { 'copper-ore': 2 },
    outputs: { 'copper-ingot': 1 },
  },
  {
    id: 'smelt-iron',
    name: 'Iron Ingot',
    description: 'Refine dense iron ore into a sturdy bar.',
    inputs: { 'iron-ore': 2 },
    outputs: { 'iron-ingot': 1 },
  },
  {
    id: 'smelt-crystal',
    name: 'Crystal Ingot',
    description: 'Temper raw crystal into a stable forge ingot.',
    inputs: { crystal: 2 },
    outputs: { 'crystal-ingot': 1 },
  },
  {
    id: 'smelt-gold',
    name: 'Gold Ingot',
    description: 'Purify gold ore for advanced forge work.',
    inputs: { 'gold-ore': 2 },
    outputs: { 'gold-ingot': 1 },
  },
];

export const CRAFTING_RECIPES: readonly CraftingRecipe[] = [
  {
    id: 'craft-copper-pickaxe',
    equipmentId: 'copper-pickaxe',
    costs: { 'copper-ingot': 3, 'iron-ingot': 1 },
  },
  {
    id: 'craft-copper-sword',
    equipmentId: 'copper-sword',
    costs: { 'copper-ingot': 2, 'iron-ingot': 1 },
  },
  {
    id: 'craft-iron-maul',
    equipmentId: 'iron-maul',
    costs: { 'iron-ingot': 3, 'copper-ingot': 1 },
  },
];
