import type { ResourceId } from '../types/resources';
import type { ZoneId } from '../types/zones';
import type { AssetId } from '../assets/asset-manifest';

export type DungeonId =
  | 'forgotten-mine'
  | 'old-stonewatch'
  | 'deep-ember-caverns'
  | 'forgotten-furnace'
  | 'luminous-caverns'
  | 'ancient-observatory'
  | 'summit-temple';

export type DungeonKind = 'cave' | 'ruin';

export interface DungeonReward {
  readonly xp: number;
  readonly coins: number;
  readonly resources: Partial<Record<ResourceId, number>>;
}

export interface DungeonPointDefinition {
  readonly id: string;
  readonly meshName: string;
  readonly label: string;
  readonly description: string;
  readonly offset: Readonly<{ x: number; z: number }>;
  readonly reward: DungeonReward;
}

export interface DungeonDefinition {
  readonly id: DungeonId;
  readonly name: string;
  readonly subtitle: string;
  readonly zoneId: ZoneId;
  readonly kind: DungeonKind;
  readonly entranceAssetId: Extract<AssetId, 'cave-arch' | 'stone-arch'>;
  /** Zone-local landmark position in metres, relative to the zone origin. */
  readonly entranceOffset: Readonly<{ x: number; z: number }>;
  readonly description: string;
  readonly lore: string;
  readonly assetFile: string;
  /** Isolated instance origin, outside the playable overworld coordinate ranges. */
  readonly instanceOrigin: Readonly<{ x: number; z: number }>;
  readonly playerSpawn: Readonly<{ x: number; y: number; z: number }>;
  readonly exitMeshName: 'dungeon_exit_gate';
  readonly discoveryReward: DungeonReward;
  readonly completionReward: DungeonReward;
  readonly points: readonly DungeonPointDefinition[];
  readonly atmosphere: Readonly<{
    background: number;
    fog: number;
    fogNear: number;
    fogFar: number;
    hemisphereSky: number;
    hemisphereGround: number;
    hemisphereIntensity: number;
    key: number;
    keyIntensity: number;
    fill: number;
    fillIntensity: number;
    lights: readonly Readonly<{ x: number; y: number; z: number; color: number; intensity: number; distance: number }>[];
  }>;
}

function poi(
  dungeonId: DungeonId,
  id: string,
  label: string,
  description: string,
  offset: Readonly<{ x: number; z: number }>,
  reward: DungeonReward,
): DungeonPointDefinition {
  return {
    id,
    meshName: `poi_${dungeonId.replaceAll('-', '_')}_${id.split('.').at(-1)?.replaceAll('-', '_') ?? id}`,
    label,
    description,
    offset,
    reward,
  };
}

const quarryCave = {
  background: 0x151714, fog: 0x28251f, fogNear: 26, fogFar: 92,
  hemisphereSky: 0xc2a981, hemisphereGround: 0x201811, hemisphereIntensity: 0.75,
  key: 0xe7bd7b, keyIntensity: 1.35, fill: 0xc77d43, fillIntensity: 12,
  lights: [
    { x: -17, y: 4.3, z: 10, color: 0xf0b36b, intensity: 28, distance: 19 },
    { x: 17, y: 4.0, z: -17, color: 0xe39a54, intensity: 25, distance: 18 },
    { x: -20, y: 3.5, z: -23, color: 0xffcd83, intensity: 20, distance: 15 },
  ],
} as const;
const quarryRuin = {
  background: 0x171914, fog: 0x2d2a21, fogNear: 30, fogFar: 100,
  hemisphereSky: 0xc7c0a6, hemisphereGround: 0x201b13, hemisphereIntensity: 0.8,
  key: 0xd9c18d, keyIntensity: 1.45, fill: 0xc59b5e, fillIntensity: 10,
  lights: [
    { x: -25, y: 3.8, z: 10, color: 0xf1cf91, intensity: 26, distance: 20 },
    { x: 25, y: 3.7, z: -19, color: 0xeac47b, intensity: 24, distance: 18 },
    { x: 0, y: 4.2, z: -28, color: 0xf8dda5, intensity: 22, distance: 18 },
  ],
} as const;
const emberCave = {
  background: 0x1b100e, fog: 0x351a11, fogNear: 24, fogFar: 86,
  hemisphereSky: 0xc77b4d, hemisphereGround: 0x1b0906, hemisphereIntensity: 0.68,
  key: 0xff8b4b, keyIntensity: 1.5, fill: 0xff4a1c, fillIntensity: 17,
  lights: [
    { x: -17, y: 4.1, z: 10, color: 0xff6c2f, intensity: 36, distance: 20 },
    { x: 17, y: 3.8, z: -17, color: 0xff7a38, intensity: 32, distance: 18 },
    { x: -20, y: 3.4, z: -23, color: 0xffb05b, intensity: 28, distance: 17 },
  ],
} as const;
const emberRuin = {
  background: 0x1b1210, fog: 0x382016, fogNear: 28, fogFar: 95,
  hemisphereSky: 0xd18a66, hemisphereGround: 0x21100a, hemisphereIntensity: 0.78,
  key: 0xffa05c, keyIntensity: 1.55, fill: 0xf3652b, fillIntensity: 13,
  lights: [
    { x: -25, y: 3.8, z: 10, color: 0xff873e, intensity: 31, distance: 20 },
    { x: 25, y: 3.7, z: -19, color: 0xff7834, intensity: 28, distance: 18 },
    { x: 0, y: 4.2, z: -28, color: 0xffc078, intensity: 25, distance: 18 },
  ],
} as const;
const crystalCave = {
  background: 0x10182a, fog: 0x202e4b, fogNear: 25, fogFar: 96,
  hemisphereSky: 0xadc8f4, hemisphereGround: 0x141d32, hemisphereIntensity: 0.82,
  key: 0xa8c9ff, keyIntensity: 1.45, fill: 0x6d8ff0, fillIntensity: 15,
  lights: [
    { x: -17, y: 4.1, z: 10, color: 0x83b9ff, intensity: 32, distance: 19 },
    { x: 17, y: 3.8, z: -17, color: 0x9a83ff, intensity: 30, distance: 18 },
    { x: -20, y: 3.4, z: -23, color: 0x7edaff, intensity: 27, distance: 17 },
  ],
} as const;
const crystalRuin = {
  background: 0x111b2e, fog: 0x243652, fogNear: 28, fogFar: 102,
  hemisphereSky: 0xc1d8ff, hemisphereGround: 0x18243b, hemisphereIntensity: 0.9,
  key: 0xc1d8ff, keyIntensity: 1.6, fill: 0x8297f4, fillIntensity: 13,
  lights: [
    { x: -25, y: 3.8, z: 10, color: 0xb8d8ff, intensity: 29, distance: 20 },
    { x: 25, y: 3.7, z: -19, color: 0x9b9cff, intensity: 28, distance: 18 },
    { x: 0, y: 4.2, z: -28, color: 0xa7d5ff, intensity: 26, distance: 18 },
  ],
} as const;

export const DUNGEON_DEFINITIONS: readonly DungeonDefinition[] = [
  {
    id: 'forgotten-mine', name: 'The Forgotten Mine', subtitle: 'DEEP IN THE GREENSTONE', zoneId: 'starter-quarry', kind: 'cave',
    entranceAssetId: 'cave-arch', entranceOffset: { x: -720, z: 220 },
    description: 'A worked copper mine swallowed by the hill. Old carts and prospector marks reveal the route into its lower chamber.',
    lore: 'The miners abandoned this shaft when the lower seam began to hum beneath their tools.',
    assetFile: '/assets/dungeons/forgotten-mine.glb', instanceOrigin: { x: 12_000, z: 10_000 }, playerSpawn: { x: 0, y: 1.1, z: 10.5 }, exitMeshName: 'dungeon_exit_gate',
    discoveryReward: { xp: 25, coins: 10, resources: {} }, completionReward: { xp: 55, coins: 30, resources: { 'copper-ore': 2 } },
    points: [
      poi('forgotten-mine', 'forgotten-mine.ore-cache', 'Foreman’s Cache', 'Search the old foreman’s coffer for the miners’ remaining supplies.', { x: -8, z: 8 }, { xp: 15, coins: 12, resources: { 'copper-ore': 1 } }),
      poi('forgotten-mine', 'forgotten-mine.prospector-mark', 'Prospector’s Inscription', 'Read the scratched warning left beside the lower passage.', { x: 8, z: -19 }, { xp: 18, coins: 10, resources: {} }),
      poi('forgotten-mine', 'forgotten-mine.deep-vein', 'Deep Copper Vein', 'Study the exposed copper seam and take a small sample.', { x: -21, z: -22 }, { xp: 20, coins: 8, resources: { 'copper-ore': 2 } }),
    ],
    atmosphere: quarryCave,
  },
  {
    id: 'old-stonewatch', name: 'Old Stonewatch', subtitle: 'THE WATCHER’S KEEP', zoneId: 'starter-quarry', kind: 'ruin',
    entranceAssetId: 'stone-arch', entranceOffset: { x: 510, z: -360 },
    description: 'A collapsed frontier watchpost with a sealed supply chamber and a carved record of the first quarry wardens.',
    lore: 'Stonewatch once guarded the road between the quarry and the old timber settlements.',
    assetFile: '/assets/dungeons/old-stonewatch.glb', instanceOrigin: { x: 12_160, z: 10_000 }, playerSpawn: { x: 0, y: 1.1, z: 10.5 }, exitMeshName: 'dungeon_exit_gate',
    discoveryReward: { xp: 25, coins: 12, resources: {} }, completionReward: { xp: 60, coins: 35, resources: { 'iron-ore': 1 } },
    points: [
      poi('old-stonewatch', 'old-stonewatch.watch-inscription', 'Warden’s Record', 'Read the final watch log carved into the old stone tablet.', { x: -8, z: 8 }, { xp: 18, coins: 10, resources: {} }),
      poi('old-stonewatch', 'old-stonewatch.sealed-cache', 'Sealed Supply Cache', 'Inspect the sealed cache beneath the collapsed watch lintel.', { x: 8, z: -19 }, { xp: 18, coins: 15, resources: { timber: 1 } }),
      poi('old-stonewatch', 'old-stonewatch.guardian-relief', 'Guardian Relief', 'Study the relief of the wardens’ stone guardian.', { x: -21, z: -22 }, { xp: 22, coins: 10, resources: { 'iron-ore': 1 } }),
    ],
    atmosphere: quarryRuin,
  },
  {
    id: 'deep-ember-caverns', name: 'Deep Ember Caverns', subtitle: 'BENEATH THE CALDERA', zoneId: 'molten-caves', kind: 'cave',
    entranceAssetId: 'cave-arch', entranceOffset: { x: -740, z: -430 },
    description: 'A basalt cavern threaded with warm fissures, unstable vents, and a hidden cache left by furnace runners.',
    lore: 'The earliest furnace keepers used these chambers to reach the caldera’s heart without crossing the open ash fields.',
    assetFile: '/assets/dungeons/deep-ember-caverns.glb', instanceOrigin: { x: 12_320, z: 10_000 }, playerSpawn: { x: 0, y: 1.1, z: 10.5 }, exitMeshName: 'dungeon_exit_gate',
    discoveryReward: { xp: 30, coins: 15, resources: {} }, completionReward: { xp: 65, coins: 40, resources: { 'gold-ore': 1 } },
    points: [
      poi('deep-ember-caverns', 'deep-ember-caverns.ember-core', 'Ember Core', 'Study the glowing core that feeds the cave’s geothermal warmth.', { x: -8, z: 8 }, { xp: 20, coins: 12, resources: { 'iron-ore': 1 } }),
      poi('deep-ember-caverns', 'deep-ember-caverns.vent-prism', 'Vent Prism', 'Tune the crystal prism to read the vent’s resonance.', { x: 8, z: -19 }, { xp: 22, coins: 12, resources: { 'gold-ore': 1 } }),
      poi('deep-ember-caverns', 'deep-ember-caverns.smuggler-cache', 'Smuggler’s Cache', 'Recover the supplies hidden by the old furnace runners.', { x: -21, z: -22 }, { xp: 20, coins: 15, resources: { 'gold-ore': 1 } }),
    ],
    atmosphere: emberCave,
  },
  {
    id: 'forgotten-furnace', name: 'The Forgotten Furnace', subtitle: 'THE FIRST GREAT FORGE', zoneId: 'molten-caves', kind: 'ruin',
    entranceAssetId: 'stone-arch', entranceOffset: { x: 580, z: -800 },
    description: 'The remains of an ancient smelting complex, containing a forge blueprint, a master anvil, and its sealed furnace heart.',
    lore: 'Before the modern settlements, the first smiths built a furnace here that could temper ore with geothermal heat.',
    assetFile: '/assets/dungeons/forgotten-furnace.glb', instanceOrigin: { x: 12_480, z: 10_000 }, playerSpawn: { x: 0, y: 1.1, z: 10.5 }, exitMeshName: 'dungeon_exit_gate',
    discoveryReward: { xp: 30, coins: 15, resources: {} }, completionReward: { xp: 70, coins: 45, resources: { 'gold-ingot': 1 } },
    points: [
      poi('forgotten-furnace', 'forgotten-furnace.furnace-blueprint', 'Furnace Blueprint', 'Recover the first furnace design etched into a wall tablet.', { x: -8, z: 8 }, { xp: 22, coins: 12, resources: {} }),
      poi('forgotten-furnace', 'forgotten-furnace.ancient-anvil', 'Ancient Anvil', 'Inspect the master anvil and its unusual tempering marks.', { x: 8, z: -19 }, { xp: 22, coins: 15, resources: { 'iron-ingot': 1 } }),
      poi('forgotten-furnace', 'forgotten-furnace.furnace-heart', 'Furnace Heart', 'Stabilize the last glowing ember within the furnace chamber.', { x: -21, z: -22 }, { xp: 25, coins: 18, resources: { 'gold-ore': 1 } }),
    ],
    atmosphere: emberRuin,
  },
  {
    id: 'luminous-caverns', name: 'The Luminous Caverns', subtitle: 'THE BLUE VEIN', zoneId: 'crystal-peaks', kind: 'cave',
    entranceAssetId: 'cave-arch', entranceOffset: { x: -680, z: 600 },
    description: 'A quiet crystal cave where resonance pools, mineral gardens, and deep blue deposits glow beneath the summit.',
    lore: 'The caverns are said to amplify even the smallest sound. The old miners used their echoes to map the lower chambers.',
    assetFile: '/assets/dungeons/luminous-caverns.glb', instanceOrigin: { x: 12_640, z: 10_000 }, playerSpawn: { x: 0, y: 1.1, z: 10.5 }, exitMeshName: 'dungeon_exit_gate',
    discoveryReward: { xp: 35, coins: 18, resources: {} }, completionReward: { xp: 75, coins: 45, resources: { crystal: 2 } },
    points: [
      poi('luminous-caverns', 'luminous-caverns.resonance-shard', 'Resonance Shard', 'Listen to the shard’s repeating tone and record its pattern.', { x: -8, z: 8 }, { xp: 22, coins: 15, resources: { crystal: 1 } }),
      poi('luminous-caverns', 'luminous-caverns.crystal-garden', 'Crystal Garden', 'Examine the crystal growths along the side alcove.', { x: 8, z: -19 }, { xp: 24, coins: 12, resources: { crystal: 1 } }),
      poi('luminous-caverns', 'luminous-caverns.crystal-cache', 'Miner’s Crystal Cache', 'Open the small cache left by an earlier summit expedition.', { x: -21, z: -22 }, { xp: 24, coins: 16, resources: { crystal: 1 } }),
    ],
    atmosphere: crystalCave,
  },
  {
    id: 'ancient-observatory', name: 'The Ancient Observatory', subtitle: 'THE STARWARD HALL', zoneId: 'crystal-peaks', kind: 'ruin',
    entranceAssetId: 'stone-arch', entranceOffset: { x: 420, z: 950 },
    description: 'A mountain observatory built around a star map and a lunar lens, with a sealed vault at the far end.',
    lore: 'Its astronomers tracked a bright winter star that appeared above the summit only when the beacon was lit.',
    assetFile: '/assets/dungeons/ancient-observatory.glb', instanceOrigin: { x: 12_800, z: 10_000 }, playerSpawn: { x: 0, y: 1.1, z: 10.5 }, exitMeshName: 'dungeon_exit_gate',
    discoveryReward: { xp: 35, coins: 20, resources: {} }, completionReward: { xp: 80, coins: 50, resources: { crystal: 2 } },
    points: [
      poi('ancient-observatory', 'ancient-observatory.star-map', 'Star Map', 'Read the old map and align its three marked peaks.', { x: -8, z: 8 }, { xp: 25, coins: 15, resources: {} }),
      poi('ancient-observatory', 'ancient-observatory.lunar-lens', 'Lunar Lens', 'Inspect the observatory lens and its refracted crystal pattern.', { x: 8, z: -19 }, { xp: 25, coins: 18, resources: { crystal: 1 } }),
      poi('ancient-observatory', 'ancient-observatory.vault', 'Observatory Vault', 'Unseal the small vault at the rear of the observatory.', { x: -21, z: -22 }, { xp: 28, coins: 20, resources: { 'gold-ingot': 1 } }),
    ],
    atmosphere: crystalRuin,
  },
  {
    id: 'summit-temple', name: 'The Summit Temple', subtitle: 'THE LAST BEACON', zoneId: 'crystal-peaks', kind: 'ruin',
    entranceAssetId: 'stone-arch', entranceOffset: { x: 720, z: -640 },
    description: 'An ancient temple dedicated to the summit beacon, with three sealed relic points leading to its inner sanctuary.',
    lore: 'The temple keepers believed the beacon was not a weapon, but a promise that the mountain would guide travellers home.',
    assetFile: '/assets/dungeons/summit-temple.glb', instanceOrigin: { x: 12_960, z: 10_000 }, playerSpawn: { x: 0, y: 1.1, z: 10.5 }, exitMeshName: 'dungeon_exit_gate',
    discoveryReward: { xp: 40, coins: 22, resources: {} }, completionReward: { xp: 100, coins: 60, resources: { crystal: 3 } },
    points: [
      poi('summit-temple', 'summit-temple.summit-rune', 'Summit Rune', 'Read the first rune that describes the beacon’s purpose.', { x: -8, z: 8 }, { xp: 28, coins: 18, resources: { crystal: 1 } }),
      poi('summit-temple', 'summit-temple.beacon-catalyst', 'Beacon Catalyst', 'Inspect the crystal catalyst once used to light the summit beacon.', { x: 8, z: -19 }, { xp: 30, coins: 20, resources: { crystal: 1 } }),
      poi('summit-temple', 'summit-temple.temple-relic', 'Temple Relic', 'Recover the final relic from the inner sanctuary.', { x: -21, z: -22 }, { xp: 32, coins: 24, resources: { crystal: 1 } }),
    ],
    atmosphere: crystalRuin,
  },
];

export const DUNGEON_BY_ID: Readonly<Record<DungeonId, DungeonDefinition>> = Object.fromEntries(
  DUNGEON_DEFINITIONS.map((dungeon) => [dungeon.id, dungeon]),
) as Record<DungeonId, DungeonDefinition>;

export const DUNGEON_ID_SET: ReadonlySet<string> = new Set(DUNGEON_DEFINITIONS.map((dungeon) => dungeon.id));
export const DUNGEON_POI_ID_SET: ReadonlySet<string> = new Set(DUNGEON_DEFINITIONS.flatMap((dungeon) => dungeon.points.map((point) => point.id)));
