import type { AssetId } from '../assets/asset-manifest';
import type { ResourceId } from '../types/resources';
import type { ZoneId } from '../types/zones';

export interface QuestWorldObjectDefinition {
  readonly id: string;
  readonly objectId: string;
  readonly title: string;
  readonly zoneId: ZoneId;
  readonly assetId: AssetId;
  readonly offset: Readonly<{ x: number; z: number }>;
  readonly collectResource?: ResourceId;
  readonly oneTime: boolean;
}

export const QUEST_WORLD_OBJECTS: readonly QuestWorldObjectDefinition[] = [
  { id: 'quarry-relay', objectId: 'quarry-relay', title: 'Quarry Gateway Relay', zoneId: 'starter-quarry', assetId: 'stone-arch', offset: { x: 30, z: -4 }, oneTime: true },
  { id: 'timber-pile-1', objectId: 'timber-pile', title: 'Timber Bundle', zoneId: 'starter-quarry', assetId: 'timber-stack', offset: { x: -23, z: 22 }, collectResource: 'timber', oneTime: true },
  { id: 'timber-pile-2', objectId: 'timber-pile', title: 'Timber Bundle', zoneId: 'starter-quarry', assetId: 'timber-stack', offset: { x: -19, z: 24 }, collectResource: 'timber', oneTime: true },
  { id: 'timber-pile-3', objectId: 'timber-pile', title: 'Timber Bundle', zoneId: 'starter-quarry', assetId: 'timber-stack', offset: { x: -25, z: 27 }, collectResource: 'timber', oneTime: true },
  { id: 'timber-pile-4', objectId: 'timber-pile', title: 'Timber Bundle', zoneId: 'starter-quarry', assetId: 'timber-stack', offset: { x: -20, z: 29 }, collectResource: 'timber', oneTime: true },
  { id: 'timber-pile-5', objectId: 'timber-pile', title: 'Timber Bundle', zoneId: 'starter-quarry', assetId: 'timber-stack', offset: { x: -16, z: 26 }, collectResource: 'timber', oneTime: true },
  { id: 'timber-pile-6', objectId: 'timber-pile', title: 'Timber Bundle', zoneId: 'starter-quarry', assetId: 'timber-stack', offset: { x: -13, z: 30 }, collectResource: 'timber', oneTime: true },
  { id: 'timber-pile-7', objectId: 'timber-pile', title: 'Timber Bundle', zoneId: 'starter-quarry', assetId: 'timber-stack', offset: { x: -9, z: 34 }, collectResource: 'timber', oneTime: true },
  { id: 'timber-pile-8', objectId: 'timber-pile', title: 'Timber Bundle', zoneId: 'starter-quarry', assetId: 'timber-stack', offset: { x: -5, z: 37 }, collectResource: 'timber', oneTime: true },
  { id: 'billy-clutter-1', objectId: 'billy-clutter', title: 'Backyard Clutter', zoneId: 'starter-quarry', assetId: 'ore-cart', offset: { x: 17, z: 13 }, oneTime: true },
  { id: 'billy-clutter-2', objectId: 'billy-clutter', title: 'Backyard Clutter', zoneId: 'starter-quarry', assetId: 'timber-stack', offset: { x: 23, z: 13 }, oneTime: true },
  { id: 'billy-clutter-3', objectId: 'billy-clutter', title: 'Backyard Clutter', zoneId: 'starter-quarry', assetId: 'rock-outcrop', offset: { x: 17, z: 18 }, oneTime: true },
  { id: 'billy-clutter-4', objectId: 'billy-clutter', title: 'Backyard Clutter', zoneId: 'starter-quarry', assetId: 'timber-stack', offset: { x: 23, z: 18 }, oneTime: true },
  { id: 'billy-clutter-5', objectId: 'billy-clutter', title: 'Backyard Clutter', zoneId: 'starter-quarry', assetId: 'ore-cart', offset: { x: 20, z: 22 }, oneTime: true },

  { id: 'geothermal-vent-1', objectId: 'geothermal-vent-control', title: 'Geothermal Vent Control', zoneId: 'molten-caves', assetId: 'volcanic-vent', offset: { x: -28, z: 20 }, oneTime: true },
  { id: 'geothermal-vent-2', objectId: 'geothermal-vent-control', title: 'Geothermal Vent Control', zoneId: 'molten-caves', assetId: 'volcanic-vent', offset: { x: 28, z: 20 }, oneTime: true },
  { id: 'geothermal-vent-3', objectId: 'geothermal-vent-control', title: 'Geothermal Vent Control', zoneId: 'molten-caves', assetId: 'volcanic-vent', offset: { x: 0, z: 34 }, oneTime: true },
  { id: 'magma-garden-1', objectId: 'magma-corn-plant', title: 'Ripe Magma Corn', zoneId: 'molten-caves', assetId: 'magma-corn', offset: { x: -31, z: 21 }, collectResource: 'magma-corn', oneTime: true },
  { id: 'magma-garden-2', objectId: 'magma-corn-plant', title: 'Ripe Magma Corn', zoneId: 'molten-caves', assetId: 'magma-corn', offset: { x: -26, z: 23 }, collectResource: 'magma-corn', oneTime: true },
  { id: 'magma-garden-3', objectId: 'magma-corn-plant', title: 'Ripe Magma Corn', zoneId: 'molten-caves', assetId: 'magma-corn', offset: { x: -21, z: 21 }, collectResource: 'magma-corn', oneTime: true },
  { id: 'magma-garden-4', objectId: 'magma-corn-plant', title: 'Ripe Magma Corn', zoneId: 'molten-caves', assetId: 'magma-corn', offset: { x: -31, z: 26 }, collectResource: 'magma-corn', oneTime: true },
  { id: 'magma-garden-5', objectId: 'magma-corn-plant', title: 'Ripe Magma Corn', zoneId: 'molten-caves', assetId: 'magma-corn', offset: { x: -26, z: 28 }, collectResource: 'magma-corn', oneTime: true },
  { id: 'magma-garden-6', objectId: 'magma-corn-plant', title: 'Ripe Magma Corn', zoneId: 'molten-caves', assetId: 'magma-corn', offset: { x: -21, z: 26 }, collectResource: 'magma-corn', oneTime: true },
  { id: 'tyler-missing-cat', objectId: 'tyler-missing-cat', title: 'Cinder the Cat', zoneId: 'molten-caves', assetId: 'quest-cat', offset: { x: 30, z: 29 }, oneTime: true },

  { id: 'peakforge-alloy', objectId: 'peakforge-alloy', title: 'Peakforge Alloy Crucible', zoneId: 'crystal-peaks', assetId: 'forge', offset: { x: 28, z: -8 }, oneTime: false },
  { id: 'summit-beacon', objectId: 'summit-beacon', title: 'Summit Beacon', zoneId: 'crystal-peaks', assetId: 'crystal-spire', offset: { x: 0, z: 36 }, oneTime: true },
];
