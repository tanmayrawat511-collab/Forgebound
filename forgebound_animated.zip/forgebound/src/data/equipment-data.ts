import type { EquipmentDefinition, EquipmentId, PickaxeDefinition, WeaponDefinition } from '../types/equipment';

export const EQUIPMENT_DEFINITIONS: Readonly<Record<EquipmentId, EquipmentDefinition>> = {
  'starter-pickaxe': {
    id: 'starter-pickaxe',
    name: 'Quarry Pickaxe',
    description: 'A dependable tool for the first seams.',
    slot: 'pickaxe',
    tier: 1,
    miningPower: 1,
  },
  'starter-sword': {
    id: 'starter-sword',
    name: 'Worn Quarry Sword',
    description: 'A simple blade issued to new prospectors.',
    slot: 'weapon',
    tier: 1,
    attackDamage: 5,
    attacksPerSecond: 1,
  },
  'copper-pickaxe': {
    id: 'copper-pickaxe',
    name: 'Copperhead Pickaxe',
    description: 'A heavier, better-balanced head bites into ore faster.',
    slot: 'pickaxe',
    tier: 2,
    miningPower: 2,
  },
  'copper-sword': {
    id: 'copper-sword',
    name: 'Emberline Sword',
    description: 'A keen copper-alloy blade with a quick recovery.',
    slot: 'weapon',
    tier: 2,
    attackDamage: 8,
    attacksPerSecond: 1.2,
  },
  'iron-maul': {
    id: 'iron-maul',
    name: 'Deepdelver Maul',
    description: 'A weighty iron weapon built for decisive strikes.',
    slot: 'weapon',
    tier: 3,
    attackDamage: 13,
    attacksPerSecond: 0.72,
  },
  'basalt-pickaxe': {
    id: 'basalt-pickaxe', name: 'Basalt Breaker', description: 'A reinforced pickaxe forged for volcanic stone.',
    slot: 'pickaxe', tier: 3, miningPower: 3,
  },
  'crystal-pickaxe': {
    id: 'crystal-pickaxe', name: 'Summit Tooth', description: 'A crystal-edged pickaxe made for the highest seams.',
    slot: 'pickaxe', tier: 4, miningPower: 4,
  },
};

export function isPickaxe(definition: EquipmentDefinition): definition is PickaxeDefinition {
  return definition.slot === 'pickaxe';
}

export function isWeapon(definition: EquipmentDefinition): definition is WeaponDefinition {
  return definition.slot === 'weapon';
}
