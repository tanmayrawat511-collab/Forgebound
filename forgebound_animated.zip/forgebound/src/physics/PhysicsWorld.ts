import RAPIER from '@dimforge/rapier3d-compat';
import { WORLD_CONFIG } from '../world/world-config';

export const FIXED_STEP_SECONDS = 1 / 60;

export interface StaticBoxTransform {
  readonly x: number;
  readonly y: number;
  readonly z: number;
}

export interface StaticBoxHalfExtents {
  readonly x: number;
  readonly y: number;
  readonly z: number;
}

export interface CharacterPhysicsBody {
  readonly body: RAPIER.RigidBody;
  readonly collider: RAPIER.Collider;
  readonly controller: RAPIER.KinematicCharacterController;
}

export interface PlayerPhysicsBody extends CharacterPhysicsBody {}

export class PhysicsWorld {
  readonly world: RAPIER.World;
  readonly player: PlayerPhysicsBody;

  private constructor(world: RAPIER.World, player: PlayerPhysicsBody) {
    this.world = world;
    this.player = player;
    this.world.timestep = FIXED_STEP_SECONDS;
  }

  static async create(): Promise<PhysicsWorld> {
    await RAPIER.init();

    const world = new RAPIER.World({ x: 0, y: -22, z: 0 });
    world.timestep = FIXED_STEP_SECONDS;

    const player = PhysicsWorld.createCharacterCapsuleInWorld(
      world,
      WORLD_CONFIG.spawn,
      0.55,
      0.34,
      0,
    );

    return new PhysicsWorld(world, player);
  }

  createCharacterCapsule(
    position: StaticBoxTransform,
    halfHeight: number,
    radius: number,
    friction = 0.05,
  ): CharacterPhysicsBody {
    return PhysicsWorld.createCharacterCapsuleInWorld(
      this.world,
      position,
      halfHeight,
      radius,
      friction,
    );
  }

  removeCharacter(body: RAPIER.RigidBody, controller: RAPIER.KinematicCharacterController): void {
    this.world.removeCharacterController(controller);
    this.world.removeRigidBody(body);
  }


  addStaticTrimesh(
    vertices: Float32Array,
    indices: Uint32Array,
    position: StaticBoxTransform,
  ): RAPIER.RigidBody {
    const body = this.world.createRigidBody(
      RAPIER.RigidBodyDesc.fixed().setTranslation(position.x, position.y, position.z),
    );
    this.world.createCollider(
      RAPIER.ColliderDesc.trimesh(vertices, indices).setFriction(0.92),
      body,
    );
    return body;
  }

  createFixedBox(
    center: StaticBoxTransform,
    halfExtents: StaticBoxHalfExtents,
    friction = 0.85,
  ): RAPIER.RigidBody {
    const body = this.world.createRigidBody(
      RAPIER.RigidBodyDesc.fixed().setTranslation(center.x, center.y, center.z),
    );
    this.world.createCollider(
      RAPIER.ColliderDesc.cuboid(halfExtents.x, halfExtents.y, halfExtents.z)
        .setFriction(friction),
      body,
    );
    return body;
  }

  removeRigidBody(body: RAPIER.RigidBody): void {
    this.world.removeRigidBody(body);
  }

  step(): void {
    this.world.step();
  }

  dispose(): void {
    this.world.removeCharacterController(this.player.controller);
    this.world.free();
  }

  private static createCharacterCapsuleInWorld(
    world: RAPIER.World,
    position: StaticBoxTransform,
    halfHeight: number,
    radius: number,
    friction: number,
  ): CharacterPhysicsBody {
    const body = world.createRigidBody(
      RAPIER.RigidBodyDesc.kinematicPositionBased()
        .setTranslation(position.x, position.y, position.z),
    );
    const collider = world.createCollider(
      RAPIER.ColliderDesc.capsule(halfHeight, radius)
        .setFriction(friction)
        .setRestitution(0),
      body,
    );
    const controller = world.createCharacterController(0.035);
    controller.setSlideEnabled(true);
    controller.setMaxSlopeClimbAngle(Math.PI / 4);
    controller.enableAutostep(0.24, 0.16, false);
    controller.enableSnapToGround(0.22);
    return { body, collider, controller };
  }
}
