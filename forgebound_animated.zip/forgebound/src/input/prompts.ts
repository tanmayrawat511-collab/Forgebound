/**
 * Prompt wording for the active input family. Keyboard strings are the originals, byte for byte,
 * so existing prompts and the test suite see no change on keyboard. Other families get their own
 * button names, so an on-screen prompt always names the control the player is actually holding.
 */
import type { InputFamily } from './actions';

export type PromptAction = 'interact' | 'jump' | 'satchel' | 'back' | 'confirm';

const LABELS: Readonly<Record<InputFamily, Readonly<Record<PromptAction, string>>>> = {
  keyboard: { interact: 'E', jump: 'Space', satchel: 'I', back: 'Esc', confirm: 'Enter' },
  touch: { interact: 'ACT', jump: 'JUMP', satchel: 'PACK', back: 'CLOSE', confirm: 'TAP' },
  dualsense: { interact: 'Cross', jump: 'Circle', satchel: 'Triangle', back: 'Circle', confirm: 'Cross' },
  gamepad: { interact: 'A', jump: 'B', satchel: 'Y', back: 'B', confirm: 'A' },
};

export function inputLabel(family: InputFamily, action: PromptAction): string {
  return LABELS[family][action];
}

/** Text for the "close this panel" hint. The keyboard wording is the original string. */
export function panelCloseHint(family: InputFamily): string {
  switch (family) {
    case 'keyboard':
      return 'Press I or Esc to close';
    case 'touch':
      return 'Tap × to close';
    case 'dualsense':
      return 'Press Triangle or Circle to close';
    case 'gamepad':
      return 'Press Y or B to close';
  }
}

/** Label for the camera readout. Keyboard keeps its original wording. */
export function lookModeLabel(family: InputFamily, pointerLocked: boolean): string {
  switch (family) {
    case 'keyboard':
      return pointerLocked ? 'MOUSE LOCKED' : 'CLICK TO LOOK';
    case 'touch':
      return 'TOUCH LOOK';
    case 'dualsense':
    case 'gamepad':
      return 'STICK LOOK';
  }
}
