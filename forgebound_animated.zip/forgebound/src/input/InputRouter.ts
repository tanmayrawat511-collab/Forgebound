/**
 * The game's single input entry point. It merges keyboard and mouse (InputManager), touch
 * controls, and controllers into the InputSnapshot the player already consumes, tracks which
 * input family is in use so prompts can match it, and owns the optional DualSense connection.
 *
 * Merge rules:
 *   - Movement: the strongest of keyboard, stick, and touch stick, so no source can add up past 1.
 *   - Edges (jump, interact, satchel, escape): OR of every source, each edge consumed once.
 *   - Look: mouse, touch drag, and right stick, summed, with per-source sensitivity.
 *   - Menus: while a panel is open, the controller's gameplay edges are suppressed and its
 *     D-pad, flicks, and Cross drive focus instead.
 */
import { InputManager, type InputSnapshot } from './InputManager';
import {
  NO_EDGES,
  menuIntentOf,
  mergeEdges,
  type ActionEdges,
  type InputFamily,
  type MenuIntent,
  type Vec2,
} from './actions';
import { DualSenseHidTransport, type HidStatus } from './gamepad/DualSenseHidTransport';
import { GamepadPoller, type GamepadLike, type PadNotice } from './gamepad/GamepadPoller';
import { TouchControls } from './touch/TouchControls';
import { STICK_DEADZONE, applyRadialDeadzone } from './touch/touchMath';
import { loadInputSettings, saveInputSettings, type InputSettings } from './settings';
import { lookModeLabel } from './prompts';
import { hidStateFor, type HapticFrame, type HapticOutput } from '../feedback/FeedbackSystem';
import type { StorageLike } from '../systems/SaveSystem';
import { DEFAULT_GAMEPAD_BINDINGS, type KeyboardBindings, type GamepadBindings } from '../systems/GameSettings';

/** Right-stick look speed at full deflection, in mouse-equivalent pixels per second. */
export const PAD_LOOK_PX_PER_SECOND = 620;
/** A WebHID sample older than this is ignored, so a stalled device cannot hold the stick. */
const HID_SAMPLE_MAX_AGE_MS = 60;
/** Frame deltas are capped the same way the game loop caps them. */
const MAX_LOOK_DELTA_SECONDS = 0.25;

export interface InputRouterOptions {
  readonly canvas: HTMLCanvasElement;
  /** Element that receives a data-input attribute: the active family. Styles key off it. */
  readonly shell: HTMLElement | null;
  /** Overlay for touch controls. When absent, touch input is disabled. */
  readonly touchLayer: HTMLElement | null;
  readonly storage: StorageLike | null;
  /** Optional "Enable DualSense triggers" control. Hidden where WebHID is unavailable. */
  readonly hidButton: HTMLButtonElement | null;
  /** Optional "Haptics: On/Off" control. Shown while a controller is in use. */
  readonly hapticsButton: HTMLButtonElement | null;
  readonly onNotice: (message: string) => void;
  /**
   * Gamepad button index that carries the touchpad click, if the browser exposes it. Null
   * disables it. Discover the index with ?inputDebug=1 and press the touchpad.
   */
  readonly touchpadButtonIndex?: number | null;
}

function touchCapable(): boolean {
  const maxTouchPoints = typeof navigator === 'undefined' ? 0 : (navigator as Partial<Navigator>).maxTouchPoints ?? 0;
  return maxTouchPoints > 0 || prefersCoarsePointer() || 'ontouchstart' in window;
}

function prefersCoarsePointer(): boolean {
  return typeof window !== 'undefined'
    && typeof window.matchMedia === 'function'
    && window.matchMedia('(pointer: coarse)').matches;
}

function readNavigatorGamepads(): ReadonlyArray<GamepadLike | null> {
  if (typeof navigator === 'undefined' || typeof navigator.getGamepads !== 'function') return [];
  return navigator.getGamepads();
}

function strongest(candidates: readonly Vec2[]): Vec2 {
  let best: Vec2 = { x: 0, y: 0 };
  let bestSquared = 0;
  for (const candidate of candidates) {
    const squared = candidate.x * candidate.x + candidate.y * candidate.y;
    if (squared > bestSquared) {
      best = candidate;
      bestSquared = squared;
    }
  }
  return best;
}

export class InputRouter {
  private readonly keyboard: InputManager;
  private readonly pad: GamepadPoller;
  private readonly hid: DualSenseHidTransport;
  private touch: TouchControls | null = null;
  private touchUsed = false;
  private family: InputFamily = 'keyboard';
  private menuOpen = false;
  private settingsState: InputSettings;
  private gamepadBindings: GamepadBindings = DEFAULT_GAMEPAD_BINDINGS;
  private gameEdges: ActionEdges = NO_EDGES;
  private menuEdges: ActionEdges = NO_EDGES;
  private padMove: Vec2 = { x: 0, y: 0 };
  private padLookPx: Vec2 = { x: 0, y: 0 };
  private readonly debugButtons: boolean;
  private readonly lastDebugButtons = new Map<number, boolean>();

  private readonly onKeyDown = (): void => this.setFamily('keyboard');
  private readonly onHidClick = (): void => this.connectDualSense();
  private readonly onHapticsClick = (): void => this.toggleHaptics();

  /** Feedback output used by FeedbackSystem. Routes to WebHID when open, otherwise Gamepad API. */
  private readonly hapticTarget: HapticOutput = {
    apply: (frame: HapticFrame): void => {
      if (this.hid.connected) {
        this.hid.setOutputs(hidStateFor(frame));
      } else {
        this.pad.rumble(frame.strongMotor, frame.weakMotor);
      }
    },
  };

  constructor(private readonly options: InputRouterOptions) {
    this.settingsState = loadInputSettings(options.storage);
    this.keyboard = new InputManager(options.canvas);
    this.pad = new GamepadPoller({
      source: readNavigatorGamepads,
      touchpadButtonIndex: options.touchpadButtonIndex ?? null,
      onNotice: (notice) => this.handlePadNotice(notice),
    });
    this.hid = new DualSenseHidTransport({ onStatus: (status) => this.handleHidStatus(status) });
    this.debugButtons = typeof location !== 'undefined'
      && new URLSearchParams(location.search).get('inputDebug') === '1';

    options.canvas.style.touchAction = 'none';
    if (options.shell) options.shell.dataset['input'] = this.family;
    window.addEventListener('keydown', this.onKeyDown);
    options.hidButton?.addEventListener('click', this.onHidClick);
    options.hapticsButton?.addEventListener('click', this.onHapticsClick);

    if (options.touchLayer && touchCapable()) {
      this.touch = new TouchControls({
        canvas: options.canvas,
        layer: options.touchLayer,
        storage: options.storage,
        onFirstUse: () => this.handleTouchUsed(),
      });
      if (prefersCoarsePointer()) this.touch.activate();
    }

    void this.hid.restoreGrantedDevice();
    this.refreshControls();
  }

  /** The input family in use right now. Prompts and HUD variants read this. */
  get activeFamily(): InputFamily {
    return this.family;
  }

  get settings(): InputSettings {
    return this.settingsState;
  }

  /** Updates settings and saves them. Takes effect on the next frame. */
  updateSettings(next: InputSettings): void {
    this.settingsState = next;
    saveInputSettings(this.options.storage, next);
    this.refreshControls();
  }

  updateKeyBindings(bindings: KeyboardBindings): void {
    this.keyboard.setKeyBindings(bindings);
  }

  updateGamepadBindings(bindings: GamepadBindings): void {
    this.gamepadBindings = { ...bindings };
  }

  openTouchLayoutEditor(): boolean {
    if (!this.touch) return false;
    this.touch.openEditor();
    return true;
  }

  /** The output FeedbackSystem drives. Null when no controller is present. */
  hapticOutput(): HapticOutput | null {
    return this.pad.family !== null || this.hid.connected ? this.hapticTarget : null;
  }

  /**
   * Polls the controller and advances per-frame state. Call once per rendered frame, before the
   * fixed-step loop, so each step sees the same controller reading.
   */
  beginFrame(deltaSeconds: number): void {
    if (this.debugButtons) this.logButtonIndices();
    const hidSample = this.hid.freshSample(HID_SAMPLE_MAX_AGE_MS);
    const poll = this.pad.poll(hidSample, this.menuOpen, this.gamepadBindings);
    this.gameEdges = mergeEdges(this.gameEdges, poll.step.edges);
    this.menuEdges = mergeEdges(this.menuEdges, poll.step.edges);
    this.padMove = poll.step.move;

    const dt = Math.min(Math.max(deltaSeconds, 0), MAX_LOOK_DELTA_SECONDS);
    const speed = this.settingsState.lookSensitivity * PAD_LOOK_PX_PER_SECOND * dt;
    const invert = this.settingsState.invertLookY ? -1 : 1;
    this.padLookPx = {
      x: this.padLookPx.x + poll.step.look.x * speed,
      y: this.padLookPx.y + poll.step.look.y * speed * invert,
    };

    if (poll.step.active && poll.family) this.setFamily(poll.family);
  }

  /** Gameplay snapshot in the shape PlayerController already consumes. */
  snapshot(gameplayEnabled = true): InputSnapshot {
    const keys = this.keyboard.snapshot(gameplayEnabled);
    const touchEdges = this.touch?.consumeEdges() ?? NO_EDGES;
    const edges = mergeEdges(this.gameEdges, touchEdges);
    this.gameEdges = NO_EDGES;

    const touchMove = this.touch
      ? applyRadialDeadzone(this.touch.moveVector().x, this.touch.moveVector().y, STICK_DEADZONE)
      : { x: 0, y: 0 };
    const move = gameplayEnabled
      ? strongest([{ x: keys.moveX, y: keys.moveZ }, this.padMove, touchMove])
      : { x: 0, y: 0 };

    return {
      moveX: move.x,
      moveZ: move.y,
      jumpPressed: gameplayEnabled && (keys.jumpPressed || edges.jump),
      interactPressed: gameplayEnabled && (keys.interactPressed || edges.interact),
      inventoryTogglePressed: keys.inventoryTogglePressed || edges.satchel,
      escapePressed: keys.escapePressed || edges.escape,
    };
  }

  /** Look delta in mouse-equivalent pixels since the last call. Clears the accumulators. */
  consumeLook(): Vec2 {
    const mouse = this.keyboard.consumeMouseDelta();
    const touch = this.touch?.consumeLook() ?? { x: 0, y: 0 };
    const touchInvert = this.settingsState.invertLookY ? -1 : 1;
    const touchScale = this.settingsState.lookSensitivity;
    const mouseScale = this.settingsState.lookSensitivity;
    const look = {
      x: mouse.x * mouseScale + touch.x * touchScale + this.padLookPx.x,
      y: mouse.y * mouseScale * touchInvert + touch.y * touchScale * touchInvert + this.padLookPx.y,
    };
    this.padLookPx = { x: 0, y: 0 };
    return look;
  }

  /** Menu directions and confirm since the last call. Only populated while a panel is open. */
  consumeMenuIntent(): MenuIntent {
    const intent = menuIntentOf(this.menuEdges);
    this.menuEdges = NO_EDGES;
    return intent;
  }

  /** Called when a panel opens or closes. Pauses touch and discards stale presses. */
  setMenuOpen(open: boolean): void {
    if (this.menuOpen === open) return;
    this.menuOpen = open;
    this.gameEdges = NO_EDGES;
    this.menuEdges = NO_EDGES;
    this.touch?.setEnabled(!open);
  }

  isPointerLocked(): boolean {
    return this.keyboard.isPointerLocked();
  }

  setPointerLockEnabled(enabled: boolean): void {
    this.keyboard.setPointerLockEnabled(enabled);
  }

  /** Camera readout text for the active family. */
  lookLabel(): string {
    return lookModeLabel(this.family, this.keyboard.isPointerLocked());
  }

  dispose(): void {
    window.removeEventListener('keydown', this.onKeyDown);
    this.options.hidButton?.removeEventListener('click', this.onHidClick);
    this.options.hapticsButton?.removeEventListener('click', this.onHapticsClick);
    this.touch?.dispose();
    this.keyboard.dispose();
    void this.hid.close();
  }

  private setFamily(family: InputFamily): void {
    if (this.family === family) return;
    this.family = family;
    if (this.options.shell) this.options.shell.dataset['input'] = family;
    this.refreshControls();
  }

  private handleTouchUsed(): void {
    this.touchUsed = true;
    this.setFamily('touch');
  }

  private handlePadNotice(notice: PadNotice): void {
    if (notice.kind === 'connected') {
      this.options.onNotice(notice.family === 'dualsense'
        ? 'DualSense connected · prompts now use PlayStation button names.'
        : 'Controller connected.');
    } else {
      this.options.onNotice('Controller disconnected · keyboard and touch still work.');
      if (this.family === 'dualsense' || this.family === 'gamepad') {
        this.setFamily(this.touchUsed ? 'touch' : 'keyboard');
      }
    }
    this.refreshControls();
  }

  private handleHidStatus(status: HidStatus): void {
    if (status === 'bluetooth') {
      this.options.onNotice('DualSense is on Bluetooth. Rumble still works; adaptive triggers need a USB cable.');
    } else if (status === 'error') {
      this.options.onNotice('DualSense output stopped. Reconnect the controller and enable it again.');
    }
    this.refreshControls();
  }

  private connectDualSense(): void {
    void this.hid.requestDevice().then((connected) => {
      this.options.onNotice(connected
        ? 'DualSense triggers and haptics enabled.'
        : 'DualSense not enabled. Use a USB cable in Chrome or Edge on https or localhost.');
      this.refreshControls();
    });
  }

  private toggleHaptics(): void {
    this.updateSettings({ ...this.settingsState, hapticsEnabled: !this.settingsState.hapticsEnabled });
  }

  private refreshControls(): void {
    const padInUse = this.family === 'dualsense' || this.family === 'gamepad';
    const hidButton = this.options.hidButton;
    if (hidButton) {
      const offer = this.family === 'dualsense' && DualSenseHidTransport.isSupported();
      hidButton.hidden = !offer;
      hidButton.disabled = this.hid.connected;
      hidButton.textContent = this.hid.connected ? 'Triggers active' : 'Enable DualSense triggers';
    }
    const hapticsButton = this.options.hapticsButton;
    if (hapticsButton) {
      hapticsButton.hidden = !padInUse;
      hapticsButton.textContent = `Haptics: ${this.settingsState.hapticsEnabled ? 'On' : 'Off'}`;
    }
  }

  /** Debug helper: logs which gamepad button indices change. Enabled with ?inputDebug=1. */
  private logButtonIndices(): void {
    for (const pad of readNavigatorGamepads()) {
      if (!pad) continue;
      for (let index = 0; index < pad.buttons.length; index += 1) {
        const pressed = pad.buttons[index]?.pressed === true;
        const previous = this.lastDebugButtons.get(index) ?? false;
        if (pressed === previous) continue;
        this.lastDebugButtons.set(index, pressed);
        if (pressed) console.info(`[input] ${pad.id} button ${index} pressed`);
      }
    }
  }
}

