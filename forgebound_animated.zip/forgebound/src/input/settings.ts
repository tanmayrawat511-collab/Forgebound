/**
 * Player-adjustable input and feedback settings. Parsing is defensive: anything malformed in
 * storage falls back to the default for that field, so a bad value can never break input.
 */
import type { StorageLike } from '../systems/SaveSystem';

export interface InputSettings {
  /** Master switch for rumble and adaptive-trigger output. */
  readonly hapticsEnabled: boolean;
  /** Scales rumble and trigger strength. Range 0 to 1. */
  readonly hapticIntensity: number;
  /** Adaptive trigger effects on DualSense (requires the optional WebHID connection). */
  readonly triggerEffectsEnabled: boolean;
  /** Multiplies touch-drag and right-stick look speed. Range 0.5 to 2. */
  readonly lookSensitivity: number;
  readonly invertLookY: boolean;
}

export const INPUT_SETTINGS_KEY = 'forgebound.input.v1';
export const LOOK_SENSITIVITY_LIMITS = { min: 0, max: 2 } as const;

export const DEFAULT_INPUT_SETTINGS: InputSettings = {
  hapticsEnabled: true,
  hapticIntensity: 1,
  triggerEffectsEnabled: true,
  lookSensitivity: 1,
  invertLookY: false,
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function unitOr(value: unknown, fallback: number): number {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1 ? value : fallback;
}

export function parseInputSettings(raw: unknown): InputSettings {
  if (!isRecord(raw)) return DEFAULT_INPUT_SETTINGS;
  const sensitivity = raw['lookSensitivity'];
  const validSensitivity = typeof sensitivity === 'number'
    && Number.isFinite(sensitivity)
    && sensitivity >= LOOK_SENSITIVITY_LIMITS.min
    && sensitivity <= LOOK_SENSITIVITY_LIMITS.max;
  return {
    hapticsEnabled: typeof raw['hapticsEnabled'] === 'boolean' ? raw['hapticsEnabled'] : DEFAULT_INPUT_SETTINGS.hapticsEnabled,
    hapticIntensity: unitOr(raw['hapticIntensity'], DEFAULT_INPUT_SETTINGS.hapticIntensity),
    triggerEffectsEnabled: typeof raw['triggerEffectsEnabled'] === 'boolean'
      ? raw['triggerEffectsEnabled']
      : DEFAULT_INPUT_SETTINGS.triggerEffectsEnabled,
    lookSensitivity: validSensitivity ? sensitivity : DEFAULT_INPUT_SETTINGS.lookSensitivity,
    invertLookY: typeof raw['invertLookY'] === 'boolean' ? raw['invertLookY'] : DEFAULT_INPUT_SETTINGS.invertLookY,
  };
}

/** Reads settings from storage. Missing, unreadable, or corrupt data yields the defaults. */
export function loadInputSettings(storage: StorageLike | null): InputSettings {
  if (!storage) return DEFAULT_INPUT_SETTINGS;
  try {
    const text = storage.getItem(INPUT_SETTINGS_KEY);
    return text ? parseInputSettings(JSON.parse(text) as unknown) : DEFAULT_INPUT_SETTINGS;
  } catch {
    return DEFAULT_INPUT_SETTINGS;
  }
}

/** Writes settings to storage. Storage failures are ignored: settings then last for the session. */
export function saveInputSettings(storage: StorageLike | null, settings: InputSettings): void {
  if (!storage) return;
  try {
    storage.setItem(INPUT_SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // Quota or privacy-mode failures must not interrupt play.
  }
}
