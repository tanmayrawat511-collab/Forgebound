/**
 * Pure touch geometry and gesture bookkeeping. No DOM access, so the multi-touch rules
 * (stick and look on separate fingers, tap versus drag, cancellation) run under Node tests.
 */
import type { Vec2 } from '../actions';

/** WCAG 2.5.5 and Apple/Google guidance: no touch target is smaller than this. */
export const MIN_TOUCH_TARGET_PX = 44;
/** Radial dead zone for the virtual stick, as a fraction of its radius. */
export const STICK_DEADZONE = 0.14;
/** A press counts as a tap only if it is at most this long and moves at most this far. */
export const TAP_MAX_DURATION_MS = 220;
export const TAP_MAX_TRAVEL_PX = 10;

/**
 * Converts a finger offset from the stick centre into a vector no longer than one. Offsets
 * beyond the radius are pinned to the rim, so the player can overshoot without losing direction.
 */
export function stickVectorFromOffset(dx: number, dy: number, radius: number): Vec2 {
  if (!(radius > 0) || !Number.isFinite(dx) || !Number.isFinite(dy)) return { x: 0, y: 0 };
  const magnitude = Math.hypot(dx, dy) / radius;
  if (magnitude === 0) return { x: 0, y: 0 };
  const scale = magnitude > 1 ? 1 / magnitude : 1;
  return { x: (dx * scale) / radius, y: (dy * scale) / radius };
}

/**
 * Radial dead zone with rescaling. Inside the dead zone the output is zero. Outside it, the
 * output ramps from zero to full magnitude, so there is no step when the stick leaves the zone.
 * Direction is preserved.
 */
export function applyRadialDeadzone(x: number, y: number, deadzone: number): Vec2 {
  if (!Number.isFinite(x) || !Number.isFinite(y)) return { x: 0, y: 0 };
  const raw = Math.hypot(x, y);
  if (raw <= deadzone) return { x: 0, y: 0 };
  const clamped = Math.min(raw, 1);
  const rescaled = (clamped - deadzone) / (1 - deadzone);
  const factor = rescaled / raw;
  return { x: x * factor, y: y * factor };
}

export function isTap(durationMs: number, travelPx: number): boolean {
  return durationMs <= TAP_MAX_DURATION_MS && travelPx <= TAP_MAX_TRAVEL_PX;
}

export interface GestureRecord<R> {
  readonly role: R;
  readonly startX: number;
  readonly startY: number;
  readonly startTime: number;
  lastX: number;
  lastY: number;
  /** Largest distance the pointer has been from its start point. */
  travelPx: number;
}

export interface GestureEnd<R> {
  readonly role: R;
  readonly tap: boolean;
  readonly durationMs: number;
}

/**
 * Tracks each active pointer separately. Pointers never share state, which is what lets a
 * thumb on the stick and a finger on the look area act at the same time without interfering.
 */
export class GestureTracker<R> {
  private readonly records = new Map<number, GestureRecord<R>>();

  /** Starts tracking a pointer. Returns false if that pointer id is already tracked. */
  begin(id: number, role: R, x: number, y: number, time: number): boolean {
    if (this.records.has(id)) return false;
    this.records.set(id, {
      role,
      startX: x,
      startY: y,
      startTime: time,
      lastX: x,
      lastY: y,
      travelPx: 0,
    });
    return true;
  }

  /** Records a move. Returns the change since the last move, or null for an untracked pointer. */
  move(id: number, x: number, y: number): { readonly record: GestureRecord<R>; readonly dx: number; readonly dy: number } | null {
    const record = this.records.get(id);
    if (!record) return null;
    const dx = x - record.lastX;
    const dy = y - record.lastY;
    record.lastX = x;
    record.lastY = y;
    record.travelPx = Math.max(record.travelPx, Math.hypot(x - record.startX, y - record.startY));
    return { record, dx, dy };
  }

  /** Stops tracking a pointer and reports whether its press was a tap. */
  end(id: number, time: number): GestureEnd<R> | null {
    const record = this.records.get(id);
    if (!record) return null;
    this.records.delete(id);
    const durationMs = Math.max(0, time - record.startTime);
    return { role: record.role, tap: isTap(durationMs, record.travelPx), durationMs };
  }

  /** Stops tracking without a tap decision, for pointercancel and focus loss. */
  cancel(id: number): R | null {
    const record = this.records.get(id);
    if (!record) return null;
    this.records.delete(id);
    return record.role;
  }

  get(id: number): GestureRecord<R> | undefined {
    return this.records.get(id);
  }

  has(id: number): boolean {
    return this.records.has(id);
  }

  some(predicate: (role: R) => boolean): boolean {
    for (const record of this.records.values()) {
      if (predicate(record.role)) return true;
    }
    return false;
  }

  /** Stops tracking everything and returns the roles that were active. */
  clear(): R[] {
    const roles = [...this.records.values()].map((record) => record.role);
    this.records.clear();
    return roles;
  }

  get size(): number {
    return this.records.size;
  }
}
