/**
 * On-screen touch controls: a move stick, ACT, JUMP, and PACK buttons, plus a layout panel that
 * can reposition or hide them. Each pointer is tracked separately (see GestureTracker), so the
 * stick thumb and a look drag can operate together.
 *
 * Gesture rules:
 *   - Drag the stick to move.
 *   - Drag anywhere on the world to look. A quick tap on the world acts on the reticle target.
 *   - Buttons act on press. Pointer events are used throughout, so latency is one event, not a
 *     click after release.
 * Pinch-to-zoom is not offered: the camera has a fixed distance and the reticle needs a steady view.
 */
import type { StorageLike } from '../../systems/SaveSystem';
import { NO_EDGES, type ActionEdges, type Vec2 } from '../actions';
import { GestureTracker, stickVectorFromOffset } from './touchMath';
import {
  TOUCH_CONTROL_IDS,
  clearTouchLayout,
  defaultLayout,
  loadTouchLayout,
  movedLayout,
  orientationOf,
  placeControl,
  saveTouchLayout,
  withVisibility,
  type ScreenOrientation,
  type TouchControlId,
  type TouchLayoutSettings,
} from './TouchLayout';

type ActionButtonId = Exclude<TouchControlId, 'stick'>;

type TouchRole =
  | { readonly kind: 'stick' }
  | { readonly kind: 'look' }
  | { readonly kind: 'button'; readonly id: ActionButtonId }
  | { readonly kind: 'drag'; readonly id: TouchControlId };

const CONTROL_NAMES: Readonly<Record<TouchControlId, string>> = {
  stick: 'Move',
  act: 'Act',
  jump: 'Jump',
  pack: 'Satchel',
  menu: 'Layout',
};

const BUTTON_TEXT: Readonly<Record<TouchControlId, string>> = {
  stick: '',
  act: 'ACT',
  jump: 'JUMP',
  pack: 'PACK',
  menu: '⋯',
};

function isControlId(value: string | undefined): value is TouchControlId {
  return typeof value === 'string' && (TOUCH_CONTROL_IDS as readonly string[]).includes(value);
}

export interface TouchControlsOptions {
  readonly canvas: HTMLCanvasElement;
  /** The overlay that holds the controls. It must sit above the canvas and cover the play area. */
  readonly layer: HTMLElement;
  readonly storage: StorageLike | null;
  /** Called the first time touch is used on this page, so the router can switch the prompt family. */
  readonly onFirstUse: () => void;
}

export class TouchControls {
  private readonly tracker = new GestureTracker<TouchRole>();
  private readonly elements = new Map<TouchControlId, HTMLElement>();
  private readonly knob: HTMLElement;
  private readonly panel: HTMLElement;
  private readonly editBar: HTMLElement;
  private readonly panelButtons = new Map<TouchControlId, HTMLButtonElement>();
  private layout: TouchLayoutSettings;
  private orientation: ScreenOrientation = 'portrait';
  private editing = false;
  private panelOpen = false;
  private shown = false;
  private enabled = true;
  private stickCentre: Vec2 = { x: 0, y: 0 };
  private stickRadius = 1;
  private stickVector: Vec2 = { x: 0, y: 0 };
  private pending = { interact: false, jump: false, satchel: false };
  private lookPx: Vec2 = { x: 0, y: 0 };

  private readonly onPointerDown = (event: PointerEvent): void => this.handlePointerDown(event);
  private readonly onPointerMove = (event: PointerEvent): void => this.handlePointerMove(event);
  private readonly onPointerUp = (event: PointerEvent): void => this.handlePointerEnd(event, false);
  private readonly onPointerCancel = (event: PointerEvent): void => this.handlePointerEnd(event, true);
  private readonly onBlur = (): void => this.cancelAll();
  private readonly onResize = (): void => this.render();
  private readonly onContextMenu = (event: Event): void => {
    if (!this.options.layer.hidden) event.preventDefault();
  };

  constructor(private readonly options: TouchControlsOptions) {
    this.layout = loadTouchLayout(options.storage);
    this.knob = document.createElement('span');
    this.knob.className = 'touch-stick-knob';
    this.panel = document.createElement('div');
    this.editBar = document.createElement('div');
    this.buildControls();
    this.buildPanel();
    this.buildEditBar();

    window.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
    window.addEventListener('pointercancel', this.onPointerCancel);
    window.addEventListener('blur', this.onBlur);
    window.addEventListener('resize', this.onResize);
    window.addEventListener('contextmenu', this.onContextMenu);
    this.syncVisibility();
  }

  /** Shows the controls. Called on the first touch, or at boot on a touch-first device. */
  activate(): void {
    if (!this.shown) {
      this.shown = true;
      this.options.onFirstUse();
    }
    this.syncVisibility();
  }

  /** Opens the touch layout editor from the Options screen, not only from the in-game panel. */
  openEditor(): void {
    this.shown = true;
    this.enabled = true;
    this.activate();
    this.beginEdit();
    this.syncVisibility();
  }

  /** Hides the overlay and drops any gestures in progress. Used while a menu panel is open. */
  setEnabled(enabled: boolean): void {
    if (this.enabled === enabled) return;
    this.enabled = enabled;
    if (!enabled) this.cancelAll();
    this.syncVisibility();
  }

  /** Edge-triggered actions since the last call. */
  consumeEdges(): ActionEdges {
    const edges: ActionEdges = {
      ...NO_EDGES,
      interact: this.pending.interact,
      jump: this.pending.jump,
      satchel: this.pending.satchel,
    };
    this.pending = { interact: false, jump: false, satchel: false };
    return edges;
  }

  /** Look movement in CSS pixels since the last call. Scaled by the router. */
  consumeLook(): Vec2 {
    const look = this.lookPx;
    this.lookPx = { x: 0, y: 0 };
    return look;
  }

  /** Current stick vector, inside the unit disc. The router applies the dead zone. */
  moveVector(): Vec2 {
    return this.stickVector;
  }

  dispose(): void {
    window.removeEventListener('pointerdown', this.onPointerDown);
    window.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerup', this.onPointerUp);
    window.removeEventListener('pointercancel', this.onPointerCancel);
    window.removeEventListener('blur', this.onBlur);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('contextmenu', this.onContextMenu);
    this.tracker.clear();
    this.options.layer.replaceChildren();
  }

  private handlePointerDown(event: PointerEvent): void {
    if (!this.enabled || event.pointerType === 'mouse') return;
    const role = this.roleFor(event);
    if (!role) return;
    const local = this.localPoint(event);
    if (!this.tracker.begin(event.pointerId, role, local.x, local.y, event.timeStamp)) return;
    this.activate();

    switch (role.kind) {
      case 'stick':
        this.updateStick(local);
        this.setPressed('stick', true);
        break;
      case 'button':
        this.pressButton(role.id);
        this.setPressed(role.id, true);
        break;
      case 'drag':
        this.setPressed(role.id, true);
        break;
      case 'look':
        break;
    }
  }

  private handlePointerMove(event: PointerEvent): void {
    if (!this.tracker.has(event.pointerId)) return;
    const local = this.localPoint(event);
    const moved = this.tracker.move(event.pointerId, local.x, local.y);
    if (!moved) return;
    const role = moved.record.role;
    switch (role.kind) {
      case 'look':
        this.lookPx = { x: this.lookPx.x + moved.dx, y: this.lookPx.y + moved.dy };
        break;
      case 'stick':
        this.updateStick(local);
        break;
      case 'drag':
        this.dragControl(role.id, local);
        break;
      case 'button':
        break;
    }
  }

  private handlePointerEnd(event: PointerEvent, cancelled: boolean): void {
    if (!this.tracker.has(event.pointerId)) return;
    const end = cancelled
      ? { role: this.tracker.cancel(event.pointerId), tap: false }
      : this.tracker.end(event.pointerId, event.timeStamp);
    if (!end || !end.role) return;

    switch (end.role.kind) {
      case 'look':
        if (end.tap && !cancelled && !this.editing) this.pending.interact = true;
        break;
      case 'stick':
        this.stickVector = { x: 0, y: 0 };
        this.resetKnob();
        this.setPressed('stick', false);
        break;
      case 'button':
        this.setPressed(end.role.id, false);
        break;
      case 'drag':
        this.setPressed(end.role.id, false);
        if (!cancelled) saveTouchLayout(this.options.storage, this.layout);
        break;
    }
  }

  private roleFor(event: PointerEvent): TouchRole | null {
    const target = event.target;
    if (target === this.options.canvas) return this.editing ? null : { kind: 'look' };
    if (!(target instanceof Element)) return null;
    const control = target.closest('[data-touch-control]');
    if (!(control instanceof HTMLElement)) return null;
    const id = control.dataset['touchControl'];
    if (!isControlId(id)) return null;
    if (this.editing) return { kind: 'drag', id };
    if (id === 'stick') {
      return this.tracker.some((role) => role.kind === 'stick') ? null : { kind: 'stick' };
    }
    return { kind: 'button', id };
  }

  private pressButton(id: ActionButtonId): void {
    if (id === 'act') this.pending.interact = true;
    if (id === 'jump') this.pending.jump = true;
    if (id === 'pack') this.pending.satchel = true;
    if (id === 'menu') this.togglePanel();
  }

  private localPoint(event: PointerEvent): Vec2 {
    const rect = this.options.layer.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  }

  private updateStick(local: Vec2): void {
    this.stickVector = stickVectorFromOffset(
      local.x - this.stickCentre.x,
      local.y - this.stickCentre.y,
      this.stickRadius,
    );
    const travel = this.stickRadius * 0.5;
    this.knob.style.transform = `translate(calc(-50% + ${(this.stickVector.x * travel).toFixed(1)}px), calc(-50% + ${(this.stickVector.y * travel).toFixed(1)}px))`;
  }

  private resetKnob(): void {
    this.knob.style.transform = 'translate(-50%, -50%)';
  }

  private dragControl(id: TouchControlId, local: Vec2): void {
    const area = { width: this.options.layer.clientWidth, height: this.options.layer.clientHeight };
    this.layout = movedLayout(this.layout, this.orientation, id, local.x, local.y, area);
    this.render();
  }

  private cancelAll(): void {
    const roles = this.tracker.clear();
    for (const role of roles) {
      if (role.kind === 'stick') this.setPressed('stick', false);
      if (role.kind === 'button' || role.kind === 'drag') this.setPressed(role.id, false);
    }
    this.stickVector = { x: 0, y: 0 };
    this.resetKnob();
  }

  private setPressed(id: TouchControlId, pressed: boolean): void {
    this.elements.get(id)?.classList.toggle('is-pressed', pressed);
  }

  private syncVisibility(): void {
    const show = this.shown && this.enabled;
    this.options.layer.hidden = !show;
    if (show) this.render();
  }

  /** Positions every control for the current size and orientation. Safe to call at any time. */
  private render(): void {
    const width = this.options.layer.clientWidth;
    const height = this.options.layer.clientHeight;
    if (width <= 0 || height <= 0) return;
    this.orientation = orientationOf(width, height);
    const area = { width, height };
    const placements = this.layout[this.orientation];

    for (const id of TOUCH_CONTROL_IDS) {
      const element = this.elements.get(id);
      if (!element) continue;
      const placement = placements[id];
      const { cx, cy, diameter } = placeControl(id, placement, area);
      element.style.width = `${diameter}px`;
      element.style.height = `${diameter}px`;
      element.style.left = `${cx - diameter / 2}px`;
      element.style.top = `${cy - diameter / 2}px`;
      element.hidden = !placement.visible && !this.editing;
      element.classList.toggle('is-ghost', !placement.visible);
      if (id === 'stick') {
        this.stickCentre = { x: cx, y: cy };
        this.stickRadius = diameter / 2;
      }
    }
    this.refreshPanelLabels();
  }

  private buildControls(): void {
    for (const id of TOUCH_CONTROL_IDS) {
      const element = document.createElement('button');
      element.type = 'button';
      element.tabIndex = -1;
      element.className = `touch-control touch-${id}`;
      element.dataset['touchControl'] = id;
      element.setAttribute('aria-label', CONTROL_NAMES[id]);
      if (id === 'stick') {
        element.append(this.knob);
        this.resetKnob();
      } else {
        element.textContent = BUTTON_TEXT[id];
      }
      this.options.layer.append(element);
      this.elements.set(id, element);
    }
  }

  private buildPanel(): void {
    this.panel.className = 'touch-panel';
    this.panel.hidden = true;
    this.panel.setAttribute('role', 'dialog');
    this.panel.setAttribute('aria-label', 'Touch layout');
    const heading = document.createElement('p');
    heading.className = 'touch-panel-title';
    heading.textContent = 'Touch layout';
    this.panel.append(heading);

    const editButton = this.panelButton('Move controls', () => this.beginEdit());
    this.panel.append(editButton);

    for (const id of TOUCH_CONTROL_IDS) {
      const button = this.panelButton('', () => this.toggleVisibility(id));
      this.panelButtons.set(id, button);
      const sizeRow = document.createElement('div');
      sizeRow.className = 'touch-size-row';
      const sizeLabel = document.createElement('span');
      sizeLabel.textContent = `${CONTROL_NAMES[id]} size`;
      sizeRow.append(sizeLabel);
      sizeRow.append(this.panelButton('Shrink −', () => this.adjustScale(id, -0.1)));
      sizeRow.append(this.panelButton('Stretch +', () => this.adjustScale(id, 0.1)));
      this.panel.append(button, sizeRow);
    }

    this.panel.append(this.panelButton('Reset layout', () => this.resetLayout()));
    this.panel.append(this.panelButton('Close', () => this.togglePanel(false)));
    this.options.layer.append(this.panel);
  }

  private buildEditBar(): void {
    this.editBar.className = 'touch-edit-bar';
    this.editBar.hidden = true;
    const hint = document.createElement('span');
    hint.textContent = 'Drag controls · tap Done when finished';
    this.editBar.append(hint, this.panelButton('Done', () => this.endEdit()));
    this.options.layer.append(this.editBar);
  }

  private panelButton(label: string, onClick: () => void): HTMLButtonElement {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'touch-panel-button';
    button.textContent = label;
    button.addEventListener('click', onClick);
    return button;
  }

  private refreshPanelLabels(): void {
    for (const id of TOUCH_CONTROL_IDS) {
      const button = this.panelButtons.get(id);
      if (!button) continue;
      const visible = this.layout[this.orientation][id].visible;
      button.textContent = `${visible ? 'Hide' : 'Show'} ${CONTROL_NAMES[id].toLowerCase()}`;
    }
  }

  private togglePanel(open?: boolean): void {
    this.panelOpen = open ?? !this.panelOpen;
    this.panel.hidden = !this.panelOpen;
    if (this.panelOpen) this.render();
  }

  private toggleVisibility(id: TouchControlId): void {
    const visible = this.layout[this.orientation][id].visible;
    this.layout = withVisibility(this.layout, this.orientation, id, !visible);
    saveTouchLayout(this.options.storage, this.layout);
    this.render();
  }

  private adjustScale(id: TouchControlId, delta: number): void {
    const current = this.layout[this.orientation][id];
    const scale = Math.max(0.75, Math.min(1.5, Math.round((current.scale + delta) * 100) / 100));
    const next = { ...this.layout[this.orientation], [id]: { ...current, scale } };
    this.layout = this.orientation === 'portrait'
      ? { portrait: next, landscape: this.layout.landscape }
      : { portrait: this.layout.portrait, landscape: next };
    saveTouchLayout(this.options.storage, this.layout);
    this.render();
  }

  private resetLayout(): void {
    this.layout = defaultLayout();
    clearTouchLayout(this.options.storage);
    this.render();
  }

  private beginEdit(): void {
    this.editing = true;
    this.togglePanel(false);
    this.editBar.hidden = false;
    this.options.layer.classList.add('is-editing');
    this.render();
  }

  private endEdit(): void {
    this.editing = false;
    this.editBar.hidden = true;
    this.options.layer.classList.remove('is-editing');
    saveTouchLayout(this.options.storage, this.layout);
    this.render();
    this.setEnabled(false);
  }
}
