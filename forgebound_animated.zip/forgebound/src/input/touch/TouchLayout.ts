/**
 * Touch control layout: where each on-screen control sits, how large it is, and whether it is
 * shown. Placement is stored as fractions of the play area, so one saved layout still fits after
 * a rotation or a window resize. Sizes are derived at render time and never fall below 44 px.
 */
import type { StorageLike } from '../../systems/SaveSystem';
import { MIN_TOUCH_TARGET_PX } from './touchMath';

export const TOUCH_CONTROL_IDS = ['stick', 'act', 'jump', 'pack', 'menu'] as const;
export type TouchControlId = (typeof TOUCH_CONTROL_IDS)[number];
export type ScreenOrientation = 'portrait' | 'landscape';

export interface ControlPlacement {
  /** Centre x as a fraction of the play area width, 0 to 1. */
  readonly x: number;
  /** Centre y as a fraction of the play area height, 0 to 1. */
  readonly y: number;
  /** Multiplier on the base diameter. Range 0.75 to 1.5. */
  readonly scale: number;
  readonly visible: boolean;
}

export type OrientationLayout = Readonly<Record<TouchControlId, ControlPlacement>>;

export interface TouchLayoutSettings {
  readonly portrait: OrientationLayout;
  readonly landscape: OrientationLayout;
}

export interface PlayArea {
  readonly width: number;
  readonly height: number;
}

export const TOUCH_LAYOUT_KEY = 'forgebound.touchLayout.v1';
export const TOUCH_LAYOUT_VERSION = 1;
export const SCALE_LIMITS = { min: 0.75, max: 1.5 } as const;

/** Diameter at scale 1 on a 400 px short side. Stick is wider because it is a sweep, not a tap. */
const BASE_DIAMETER_PX: Readonly<Record<TouchControlId, number>> = {
  stick: 150,
  act: 88,
  jump: 64,
  pack: 56,
  menu: 48,
};

const DEFAULT_PORTRAIT: OrientationLayout = {
  stick: { x: 0.2, y: 0.8, scale: 1, visible: true },
  act: { x: 0.8, y: 0.8, scale: 1, visible: true },
  jump: { x: 0.6, y: 0.92, scale: 1, visible: true },
  pack: { x: 0.9, y: 0.56, scale: 1, visible: true },
  menu: { x: 0.5, y: 0.95, scale: 1, visible: true },
};

const DEFAULT_LANDSCAPE: OrientationLayout = {
  stick: { x: 0.15, y: 0.68, scale: 1, visible: true },
  act: { x: 0.86, y: 0.7, scale: 1, visible: true },
  jump: { x: 0.72, y: 0.88, scale: 1, visible: true },
  pack: { x: 0.93, y: 0.42, scale: 1, visible: true },
  menu: { x: 0.5, y: 0.94, scale: 1, visible: true },
};

export function defaultLayout(): TouchLayoutSettings {
  return { portrait: copyLayout(DEFAULT_PORTRAIT), landscape: copyLayout(DEFAULT_LANDSCAPE) };
}

export function orientationOf(width: number, height: number): ScreenOrientation {
  return width >= height ? 'landscape' : 'portrait';
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

/** Gentle scaling with the screen's short side: phones stay usable, tablets get larger targets. */
export function uiScaleFor(shortSidePx: number): number {
  return clamp(shortSidePx / 400, 0.85, 1.2);
}

/** Rendered diameter in CSS pixels. Never below the 44 px touch-target minimum. */
export function diameterFor(id: TouchControlId, scale: number, shortSidePx: number): number {
  const scaled = BASE_DIAMETER_PX[id] * clamp(scale, SCALE_LIMITS.min, SCALE_LIMITS.max) * uiScaleFor(shortSidePx);
  return Math.max(MIN_TOUCH_TARGET_PX, Math.round(scaled));
}

function clampBetween(value: number, low: number, high: number): number {
  if (high < low) return (low + high) / 2;
  return clamp(value, low, high);
}

/** Centre and diameter of a control in play-area pixels, kept fully inside the area. */
export function placeControl(
  id: TouchControlId,
  placement: ControlPlacement,
  area: PlayArea,
): { readonly cx: number; readonly cy: number; readonly diameter: number } {
  const shortSide = Math.min(area.width, area.height);
  const diameter = diameterFor(id, placement.scale, shortSide);
  const radius = diameter / 2;
  return {
    cx: clampBetween(placement.x * area.width, radius, area.width - radius),
    cy: clampBetween(placement.y * area.height, radius, area.height - radius),
    diameter,
  };
}

/** Returns a new layout with one control moved to a pixel centre, clamped into the area. */
export function movedLayout(
  settings: TouchLayoutSettings,
  orientation: ScreenOrientation,
  id: TouchControlId,
  cx: number,
  cy: number,
  area: PlayArea,
): TouchLayoutSettings {
  if (!(area.width > 0) || !(area.height > 0)) return settings;
  const current = settings[orientation][id];
  const next: ControlPlacement = {
    x: clamp(cx / area.width, 0, 1),
    y: clamp(cy / area.height, 0, 1),
    scale: current.scale,
    visible: current.visible,
  };
  const updated = copyLayout(settings[orientation]);
  updated[id] = next;
  return orientation === 'portrait'
    ? { portrait: updated, landscape: settings.landscape }
    : { portrait: settings.portrait, landscape: updated };
}

/** Returns a new layout with one control's visibility changed. */
export function withVisibility(
  settings: TouchLayoutSettings,
  orientation: ScreenOrientation,
  id: TouchControlId,
  visible: boolean,
): TouchLayoutSettings {
  const updated = copyLayout(settings[orientation]);
  updated[id] = { ...settings[orientation][id], visible };
  return orientation === 'portrait'
    ? { portrait: updated, landscape: settings.landscape }
    : { portrait: settings.portrait, landscape: updated };
}

function copyLayout(layout: OrientationLayout): Record<TouchControlId, ControlPlacement> {
  return {
    stick: layout.stick,
    act: layout.act,
    jump: layout.jump,
    pack: layout.pack,
    menu: layout.menu,
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parsePlacement(raw: unknown, fallback: ControlPlacement): ControlPlacement {
  if (!isRecord(raw)) return fallback;
  const { x, y, scale, visible } = raw;
  const validUnit = (value: unknown): value is number => typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1;
  if (!validUnit(x) || !validUnit(y)) return fallback;
  if (typeof scale !== 'number' || !Number.isFinite(scale) || scale < SCALE_LIMITS.min || scale > SCALE_LIMITS.max) return fallback;
  if (typeof visible !== 'boolean') return fallback;
  return { x, y, scale, visible };
}

function parseOrientation(raw: unknown, fallback: OrientationLayout): OrientationLayout {
  if (!isRecord(raw)) return fallback;
  const parsed = copyLayout(fallback);
  for (const id of TOUCH_CONTROL_IDS) {
    parsed[id] = parsePlacement(raw[id], fallback[id]);
  }
  return parsed;
}

/**
 * Validates a stored layout field by field. A bad control reverts to its default, and the rest of
 * the layout is kept. Anything that is not an object yields the full defaults.
 */
export function parseTouchLayout(raw: unknown): TouchLayoutSettings {
  const defaults = defaultLayout();
  if (!isRecord(raw)) return defaults;
  return {
    portrait: parseOrientation(raw['portrait'], defaults.portrait),
    landscape: parseOrientation(raw['landscape'], defaults.landscape),
  };
}

export function loadTouchLayout(storage: StorageLike | null): TouchLayoutSettings {
  if (!storage) return defaultLayout();
  try {
    const text = storage.getItem(TOUCH_LAYOUT_KEY);
    if (!text) return defaultLayout();
    const envelope = JSON.parse(text) as unknown;
    if (!isRecord(envelope) || envelope['version'] !== TOUCH_LAYOUT_VERSION) return defaultLayout();
    return parseTouchLayout(envelope['layout']);
  } catch {
    return defaultLayout();
  }
}

export function saveTouchLayout(storage: StorageLike | null, settings: TouchLayoutSettings): void {
  if (!storage) return;
  try {
    storage.setItem(TOUCH_LAYOUT_KEY, JSON.stringify({ version: TOUCH_LAYOUT_VERSION, layout: settings }));
  } catch {
    // Storage may be full or blocked. The layout then lasts for this session only.
  }
}

export function clearTouchLayout(storage: StorageLike | null): void {
  if (!storage) return;
  try {
    storage.removeItem(TOUCH_LAYOUT_KEY);
  } catch {
    // Nothing to do: the stored value is simply left in place.
  }
}
