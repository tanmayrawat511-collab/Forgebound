import { DEFAULT_KEYBOARD_BINDINGS, type KeyboardBindings } from '../systems/GameSettings';

export interface InputSnapshot {
  readonly moveX: number;
  readonly moveZ: number;
  readonly jumpPressed: boolean;
  readonly interactPressed: boolean;
  readonly inventoryTogglePressed: boolean;
  readonly escapePressed: boolean;
}

export interface MouseDelta {
  readonly x: number;
  readonly y: number;
}

const INTERACTIVE_TAGS = new Set(['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON', 'A', 'SUMMARY']);

export class InputManager {
  private readonly downKeys = new Set<string>();
  private jumpQueued = false;
  private interactQueued = false;
  private inventoryToggleQueued = false;
  private escapeQueued = false;
  private mouseDeltaX = 0;
  private mouseDeltaY = 0;
  private pointerLockEnabled = true;
  private bindings: KeyboardBindings = DEFAULT_KEYBOARD_BINDINGS;

  private readonly onKeyDown = (event: KeyboardEvent): void => {
    if (event.code === 'Escape') {
      if (!event.repeat) this.escapeQueued = true;
      event.preventDefault();
      return;
    }
    if (this.isTypingTarget(event.target)) return;
    if (this.isBoundKey(event.code)) event.preventDefault();

    if (!event.repeat) {
      if (event.code === this.bindings.jump) this.jumpQueued = true;
      if (event.code === this.bindings.interact) this.interactQueued = true;
      if (event.code === this.bindings.inventory) this.inventoryToggleQueued = true;
    }
    this.downKeys.add(event.code);
  };

  private readonly onKeyUp = (event: KeyboardEvent): void => {
    this.downKeys.delete(event.code);
  };

  private readonly onMouseMove = (event: MouseEvent): void => {
    if (document.pointerLockElement !== this.canvas) return;
    this.mouseDeltaX += event.movementX;
    this.mouseDeltaY += event.movementY;
  };

  private readonly onCanvasClick = (): void => {
    if (!this.pointerLockEnabled || document.pointerLockElement === this.canvas) return;
    try {
      void this.canvas.requestPointerLock().catch(() => undefined);
    } catch {
      // Pointer lock can be unavailable in embedded or restricted browser contexts.
    }
  };

  private readonly onBlur = (): void => {
    this.downKeys.clear();
    this.clearQueuedActions();
    this.mouseDeltaX = 0;
    this.mouseDeltaY = 0;
  };

  constructor(private readonly canvas: HTMLCanvasElement) {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
    document.addEventListener('mousemove', this.onMouseMove);
    this.canvas.addEventListener('click', this.onCanvasClick);
  }

  snapshot(gameplayEnabled = true): InputSnapshot {
    const rawMoveX = Number(this.downKeys.has(this.bindings.moveRight)) - Number(this.downKeys.has(this.bindings.moveLeft));
    const rawMoveZ = Number(this.downKeys.has(this.bindings.moveBackward)) - Number(this.downKeys.has(this.bindings.moveForward));
    const magnitude = Math.hypot(rawMoveX, rawMoveZ);
    const normalized = magnitude > 1 ? 1 / magnitude : 1;

    const snapshot: InputSnapshot = {
      moveX: gameplayEnabled ? rawMoveX * normalized : 0,
      moveZ: gameplayEnabled ? rawMoveZ * normalized : 0,
      jumpPressed: gameplayEnabled && this.jumpQueued,
      interactPressed: gameplayEnabled && this.interactQueued,
      inventoryTogglePressed: this.inventoryToggleQueued,
      escapePressed: this.escapeQueued,
    };

    this.jumpQueued = false;
    this.interactQueued = false;
    this.inventoryToggleQueued = false;
    this.escapeQueued = false;
    return snapshot;
  }

  consumeMouseDelta(): MouseDelta {
    const delta = { x: this.mouseDeltaX, y: this.mouseDeltaY };
    this.mouseDeltaX = 0;
    this.mouseDeltaY = 0;
    return delta;
  }

  isPointerLocked(): boolean {
    return document.pointerLockElement === this.canvas;
  }

  setKeyBindings(bindings: KeyboardBindings): void {
    this.bindings = { ...bindings };
    this.downKeys.clear();
    this.clearQueuedActions();
  }

  private isBoundKey(code: string): boolean {
    return Object.values(this.bindings).includes(code);
  }

  setPointerLockEnabled(enabled: boolean): void {
    this.pointerLockEnabled = enabled;
    if (!enabled && this.isPointerLocked()) document.exitPointerLock();
  }

  dispose(): void {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    document.removeEventListener('mousemove', this.onMouseMove);
    this.canvas.removeEventListener('click', this.onCanvasClick);
    if (document.pointerLockElement === this.canvas) document.exitPointerLock();
    this.downKeys.clear();
    this.clearQueuedActions();
  }

  private clearQueuedActions(): void {
    this.jumpQueued = false;
    this.interactQueued = false;
    this.inventoryToggleQueued = false;
    this.escapeQueued = false;
  }

  private isTypingTarget(target: EventTarget | null): boolean {
    if (!(target instanceof HTMLElement)) return false;
    return INTERACTIVE_TAGS.has(target.tagName) || target.isContentEditable || target.tabIndex >= 0;
  }
}
