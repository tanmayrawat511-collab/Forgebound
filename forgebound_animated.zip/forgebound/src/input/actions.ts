/**
 * Device-neutral input vocabulary. Keyboard, touch, and gamepad sources translate their own
 * signals into these shapes, so game code never reads a device directly. Pure types and
 * helpers only: nothing here touches the DOM, which keeps it testable under Node.
 */

/** A 2D vector. Screen convention: +x is right, +y is down. */
export interface Vec2 {
  readonly x: number;
  readonly y: number;
}

/** The kind of input the player is using right now. Drives prompt labels and HUD variants. */
export type InputFamily = 'keyboard' | 'touch' | 'dualsense' | 'gamepad';

/** One-frame edges from touch and gamepad sources. Each flag is true only on the frame it fires. */
export interface ActionEdges {
  readonly jump: boolean;
  readonly interact: boolean;
  readonly satchel: boolean;
  readonly escape: boolean;
  readonly menuUp: boolean;
  readonly menuDown: boolean;
  readonly menuLeft: boolean;
  readonly menuRight: boolean;
  readonly menuConfirm: boolean;
}

export const NO_EDGES: ActionEdges = {
  jump: false,
  interact: false,
  satchel: false,
  escape: false,
  menuUp: false,
  menuDown: false,
  menuLeft: false,
  menuRight: false,
  menuConfirm: false,
};

/** Combines two edge sets. An edge that fired in either set is kept. */
export function mergeEdges(a: ActionEdges, b: ActionEdges): ActionEdges {
  return {
    jump: a.jump || b.jump,
    interact: a.interact || b.interact,
    satchel: a.satchel || b.satchel,
    escape: a.escape || b.escape,
    menuUp: a.menuUp || b.menuUp,
    menuDown: a.menuDown || b.menuDown,
    menuLeft: a.menuLeft || b.menuLeft,
    menuRight: a.menuRight || b.menuRight,
    menuConfirm: a.menuConfirm || b.menuConfirm,
  };
}

/** Menu-navigation intent consumed by the panel navigator. */
export interface MenuIntent {
  readonly up: boolean;
  readonly down: boolean;
  readonly left: boolean;
  readonly right: boolean;
  readonly confirm: boolean;
}

/** Returns the menu part of an edge set. */
export function menuIntentOf(edges: ActionEdges): MenuIntent {
  return {
    up: edges.menuUp,
    down: edges.menuDown,
    left: edges.menuLeft,
    right: edges.menuRight,
    confirm: edges.menuConfirm,
  };
}
