/**
 * Directional focus for panels. D-pad and left-stick flicks move focus through the panel's
 * enabled buttons in document order; Cross presses the focused one. Touch and mouse use the
 * buttons' own events, so this only matters for controllers.
 */
import type { MenuIntent } from '../actions';

const FOCUSABLE = 'button:not([disabled]):not([hidden])';

export class MenuNavigator {
  apply(intent: MenuIntent, root: HTMLElement | null): void {
    if (!root) return;
    const items = Array.from(root.querySelectorAll<HTMLElement>(FOCUSABLE));
    if (items.length === 0) return;

    if (intent.confirm) {
      const focused = items.find((element) => element === document.activeElement);
      focused?.click();
      return;
    }
    const forward = intent.down || intent.right;
    const backward = intent.up || intent.left;
    if (!forward && !backward) return;

    const current = items.findIndex((element) => element === document.activeElement);
    if (current < 0) {
      items[0]?.focus();
      return;
    }
    const step = forward ? 1 : -1;
    const next = (current + step + items.length) % items.length;
    items[next]?.focus();
  }
}
