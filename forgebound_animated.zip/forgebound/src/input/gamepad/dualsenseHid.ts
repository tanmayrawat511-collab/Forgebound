/**
 * DualSense WebHID wire format: pure encoders and decoders, no device access.
 *
 * IMPORTANT: Sony does not publish this protocol. The offsets and mode codes below follow the
 * layout documented by the open-source community (the same layout the Linux kernel and several
 * open libraries use). They are isolated here so a single hardware check can correct them. The
 * test suite locks the byte placement; it cannot prove what a real controller does with it.
 * See docs/INPUT_INTEGRATION.md, "DualSense hardware verification".
 */
import { noButtons, type PadButtons, type PadSample } from './dualsenseMapping';
import type { Vec2 } from '../actions';

export const DUALSENSE_VENDOR_ID = 0x054c;
export const DUALSENSE_PRODUCT_IDS = [0x0ce6, 0x0df2] as const;
export const DUALSENSE_HID_FILTERS = DUALSENSE_PRODUCT_IDS.map((productId) => ({
  vendorId: DUALSENSE_VENDOR_ID,
  productId,
}));

/** Report ids. USB and Bluetooth use different framing; only USB is driven in this build. */
export const USB_INPUT_REPORT_ID = 0x01;
export const BLUETOOTH_INPUT_REPORT_ID = 0x31;
export const USB_OUTPUT_REPORT_ID = 0x02;
export const USB_OUTPUT_REPORT_LENGTH = 48;

/** Offsets within the 48-byte USB output report, id at index 0. */
const FLAGS_0 = 1;
const MOTOR_RIGHT = 3;
const MOTOR_LEFT = 4;
const RIGHT_TRIGGER_BLOCK = 11;
const LEFT_TRIGGER_BLOCK = 22;
const TRIGGER_BLOCK_LENGTH = 11;

/** valid_flag0 bits. Compatible vibration selects the classic motors over the voice-coil path. */
const FLAG_COMPATIBLE_VIBRATION = 0x01;
const FLAG_RIGHT_TRIGGER_ENABLE = 0x04;
const FLAG_LEFT_TRIGGER_ENABLE = 0x08;

/** Trigger mode codes. Community-documented; confirm each on hardware. */
export const TRIGGER_MODE = {
  off: 0x00,
  resistance: 0x01,
  pulse: 0x02,
} as const;

/** Parameter scales for the mode bytes: start position 0 to 9, strength 0 to 8. */
export const TRIGGER_START_STEPS = 9;
export const TRIGGER_STRENGTH_STEPS = 8;

export type TriggerEffect =
  | { readonly kind: 'off' }
  | { readonly kind: 'resistance'; readonly start: number; readonly strength: number }
  | { readonly kind: 'pulse'; readonly start: number; readonly strength: number };

export const TRIGGER_OFF: TriggerEffect = { kind: 'off' };

export interface HidOutputState {
  /** Low-frequency (strong) motor, 0 to 1. */
  readonly motorLeft: number;
  /** High-frequency (weak) motor, 0 to 1. */
  readonly motorRight: number;
  readonly left: TriggerEffect;
  readonly right: TriggerEffect;
}

function clamp01(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.min(1, Math.max(0, value));
}

function toByte(value: number): number {
  return Math.round(clamp01(value) * 255);
}

function writeTrigger(report: Uint8Array<ArrayBuffer>, base: number, effect: TriggerEffect): void {
  for (let index = 0; index < TRIGGER_BLOCK_LENGTH; index += 1) report[base + index] = 0;
  if (effect.kind === 'off') {
    report[base] = TRIGGER_MODE.off;
    return;
  }
  report[base] = effect.kind === 'resistance' ? TRIGGER_MODE.resistance : TRIGGER_MODE.pulse;
  report[base + 1] = Math.round(clamp01(effect.start) * TRIGGER_START_STEPS);
  report[base + 2] = Math.round(clamp01(effect.strength) * TRIGGER_STRENGTH_STEPS);
}

/**
 * Builds the complete 48-byte USB output report. Index 0 is the report id. Both trigger motors
 * are always enabled, so setting a trigger back to "off" clears any effect still running.
 */
export function encodeUsbOutputReport(state: HidOutputState): Uint8Array<ArrayBuffer> {
  const report = new Uint8Array(USB_OUTPUT_REPORT_LENGTH);
  report[0] = USB_OUTPUT_REPORT_ID;
  report[FLAGS_0] = FLAG_COMPATIBLE_VIBRATION | FLAG_RIGHT_TRIGGER_ENABLE | FLAG_LEFT_TRIGGER_ENABLE;
  report[MOTOR_RIGHT] = toByte(state.motorRight);
  report[MOTOR_LEFT] = toByte(state.motorLeft);
  writeTrigger(report, RIGHT_TRIGGER_BLOCK, state.right);
  writeTrigger(report, LEFT_TRIGGER_BLOCK, state.left);
  return report;
}

export type HidTransportKind = 'usb' | 'bluetooth' | 'unknown';

export function detectTransport(reportId: number): HidTransportKind {
  if (reportId === USB_INPUT_REPORT_ID) return 'usb';
  if (reportId === BLUETOOTH_INPUT_REPORT_ID) return 'bluetooth';
  return 'unknown';
}

function stick(raw: number): number {
  return Math.min(1, Math.max(-1, (raw - 128) / 127.5));
}

function hatPressed(hat: number, directions: readonly number[]): boolean {
  return directions.includes(hat);
}

/**
 * Decodes a USB input report (0x01). `report` must start with the report id, so index n is the
 * byte n of the wire report. Returns null for short or non-USB reports. Layout: sticks at 1 to 4,
 * analog triggers at 5 and 6, face and d-pad hat at 8, shoulders and system buttons at 9 and 10.
 */
export function decodeUsbInputReport(report: Uint8Array): PadSample | null {
  if (report.length < 11 || report[0] !== USB_INPUT_REPORT_ID) return null;
  const face = report[8] ?? 0;
  const shoulders = report[9] ?? 0;
  const system = report[10] ?? 0;
  const hat = face & 0x0f;

  const buttons: PadButtons = {
    ...noButtons(),
    cross: (face & 0x20) !== 0,
    circle: (face & 0x40) !== 0,
    square: (face & 0x10) !== 0,
    triangle: (face & 0x80) !== 0,
    l1: (shoulders & 0x01) !== 0,
    r1: (shoulders & 0x02) !== 0,
    l2: (shoulders & 0x04) !== 0,
    r2: (shoulders & 0x08) !== 0,
    create: (shoulders & 0x10) !== 0,
    options: (shoulders & 0x20) !== 0,
    l3: (shoulders & 0x40) !== 0,
    r3: (shoulders & 0x80) !== 0,
    dpadUp: hatPressed(hat, [0, 1, 7]),
    dpadRight: hatPressed(hat, [1, 2, 3]),
    dpadDown: hatPressed(hat, [3, 4, 5]),
    dpadLeft: hatPressed(hat, [5, 6, 7]),
    ps: (system & 0x01) !== 0,
    touchpad: (system & 0x02) !== 0,
  };

  const stickLeft: Vec2 = { x: stick(report[1] ?? 128), y: stick(report[2] ?? 128) };
  const stickRight: Vec2 = { x: stick(report[3] ?? 128), y: stick(report[4] ?? 128) };
  return {
    buttons,
    triggerRight: clamp01((report[6] ?? 0) / 255),
    stickLeft,
    stickRight,
  };
}

