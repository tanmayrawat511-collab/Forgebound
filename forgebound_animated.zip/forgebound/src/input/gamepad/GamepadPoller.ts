/**
 * Standard Gamepad API polling. The browser can report a DualSense in two ways. This module
 * covers the common path (any browser with the Gamepad API). When a WebHID sample is supplied,
 * the router prefers it, because it carries the touchpad and does not depend on the browser's
 * own mapping of the controller.
 *
 * Connection changes are detected by polling, not only by gamepadconnected. Chromium fires that
 * event only after the player presses a button, so polling is what makes the prompt appear
 * immediately after a controller is switched on.
 */
import type { PadFamily, PadSample, PadState, PadStep, PadButton, PadActionBindings } from './dualsenseMapping';
import {
  IDLE_PAD_STEP,
  INITIAL_PAD_STATE,
  PAD_BUTTON_NAMES,
  identifyPad,
  interpretPadSample,
  noButtons,
} from './dualsenseMapping';

/** The subset of the browser's Gamepad type this module reads. */
export interface GamepadLike {
  readonly index: number;
  readonly id: string;
  readonly mapping: string;
  readonly connected: boolean;
  readonly buttons: ArrayLike<{ readonly pressed: boolean; readonly value: number }>;
  readonly axes: ArrayLike<number>;
  readonly vibrationActuator?: {
    playEffect(type: 'dual-rumble', params: { startDelay: number; duration: number; weakMagnitude: number; strongMagnitude: number }): Promise<unknown>;
    reset?(): Promise<unknown>;
  } | null;
}

/** Standard-mapping button indices (W3C Gamepad API "standard" layout). */
const STANDARD_INDEX: Readonly<Partial<Record<PadButton, number>>> = {
  cross: 0,
  circle: 1,
  square: 2,
  triangle: 3,
  l1: 4,
  r1: 5,
  l2: 6,
  r2: 7,
  create: 8,
  options: 9,
  l3: 10,
  r3: 11,
  dpadUp: 12,
  dpadDown: 13,
  dpadLeft: 14,
  dpadRight: 15,
  ps: 16,
};

const STANDARD_R2_INDEX = 7;

/** Converts a standard-mapping Gamepad into a PadSample. Touchpad needs an explicit index. */
export function sampleFromGamepad(pad: GamepadLike, touchpadButtonIndex: number | null): PadSample {
  const buttons: Record<PadButton, boolean> = { ...noButtons() };
  for (const name of PAD_BUTTON_NAMES) {
    const index = name === 'touchpad' ? touchpadButtonIndex : STANDARD_INDEX[name];
    if (index === null || index === undefined) continue;
    buttons[name] = pad.buttons[index]?.pressed === true;
  }
  const axis = (index: number): number => {
    const value = pad.axes[index];
    return typeof value === 'number' && Number.isFinite(value) ? Math.min(1, Math.max(-1, value)) : 0;
  };
  return {
    buttons,
    triggerRight: Math.min(1, Math.max(0, pad.buttons[STANDARD_R2_INDEX]?.value ?? 0)),
    stickLeft: { x: axis(0), y: axis(1) },
    stickRight: { x: axis(2), y: axis(3) },
  };
}

export interface PadNotice {
  readonly kind: 'connected' | 'disconnected';
  readonly family: PadFamily;
}

export interface GamepadPollerOptions {
  /** Returns the browser's gamepad slots. Injected so tests can supply fakes. */
  readonly source: () => ReadonlyArray<GamepadLike | null>;
  readonly touchpadButtonIndex: number | null;
  readonly onNotice: (notice: PadNotice) => void;
}

export interface PadPoll {
  readonly step: PadStep;
  /** The family of the controller that produced this step, or null when none is present. */
  readonly family: PadFamily | null;
}

function keyOf(pad: GamepadLike): string {
  return `${pad.index}:${pad.id}`;
}

export class GamepadPoller {
  private state: PadState = INITIAL_PAD_STATE;
  private activeKey: string | null = null;
  private activeFamily: PadFamily | null = null;
  private lastRumbleNonZero = false;

  constructor(private readonly options: GamepadPollerOptions) {}

  /**
   * Reads the controller and interprets it. `hidSample`, when present, is used in place of the
   * browser's Gamepad sample and is reported as DualSense, since only DualSense is opened over HID.
   */
  poll(hidSample: PadSample | null, menuOpen: boolean, bindings?: PadActionBindings): PadPoll {
    const pad = this.choosePad();
    this.trackConnection(pad);

    const sample = hidSample ?? (pad ? sampleFromGamepad(pad, this.options.touchpadButtonIndex) : null);
    if (!sample) {
      this.state = INITIAL_PAD_STATE;
      return { step: IDLE_PAD_STEP, family: null };
    }
    const step = interpretPadSample(sample, this.state, menuOpen, bindings);
    this.state = step.state;
    return { step, family: hidSample ? 'dualsense' : this.activeFamily };
  }

  /** Current family of the browser-visible controller, or null. */
  get family(): PadFamily | null {
    return this.activeFamily;
  }

  /**
   * Drives the controller's rumble motors through the Gamepad API. Only the standard
   * dual-rumble effect is used. Browsers without vibrationActuator simply get no rumble here.
   */
  rumble(strong: number, weak: number): void {
    const actuator = this.currentPad()?.vibrationActuator;
    if (!actuator) return;
    const silent = strong <= 0 && weak <= 0;
    if (silent) {
      if (this.lastRumbleNonZero && typeof actuator.reset === 'function') {
        void actuator.reset().catch(() => undefined);
      }
      this.lastRumbleNonZero = false;
      return;
    }
    if (typeof actuator.playEffect !== 'function') return;
    this.lastRumbleNonZero = true;
    void actuator.playEffect('dual-rumble', {
      startDelay: 0,
      duration: 140,
      strongMagnitude: Math.min(1, Math.max(0, strong)),
      weakMagnitude: Math.min(1, Math.max(0, weak)),
    }).catch(() => undefined);
  }

  private connectedPads(): GamepadLike[] {
    return this.options.source().filter((pad): pad is GamepadLike => pad !== null && pad.connected !== false);
  }

  private currentPad(): GamepadLike | null {
    if (this.activeKey === null) return null;
    return this.connectedPads().find((pad) => keyOf(pad) === this.activeKey) ?? null;
  }

  /** Keeps the same controller while it stays connected, and prefers a DualSense otherwise. */
  private choosePad(): GamepadLike | null {
    const pads = this.connectedPads();
    if (pads.length === 0) return null;
    const kept = this.activeKey === null ? undefined : pads.find((pad) => keyOf(pad) === this.activeKey);
    if (kept) return kept;
    return pads.find((pad) => identifyPad(pad.id) === 'dualsense') ?? pads[0] ?? null;
  }

  private trackConnection(pad: GamepadLike | null): void {
    const key = pad ? keyOf(pad) : null;
    if (key === this.activeKey) return;
    if (this.activeKey !== null && this.activeFamily !== null) {
      this.options.onNotice({ kind: 'disconnected', family: this.activeFamily });
    }
    this.state = INITIAL_PAD_STATE;
    this.activeKey = key;
    if (pad) {
      const family = identifyPad(pad.id);
      this.activeFamily = family;
      this.options.onNotice({ kind: 'connected', family });
    } else {
      this.activeFamily = null;
    }
  }
}

