/**
 * WebHID transport for the DualSense. Chromium-based browsers only, and only in a secure
 * context (https or localhost). Connecting requires a user gesture, so the page exposes an
 * explicit "Enable DualSense" control instead of prompting on load.
 *
 * This module is the only place that calls navigator.hid. Everything it sends and decodes is
 * built by dualsenseHid.ts, so the protocol assumptions stay in one file.
 */
import {
  decodeUsbInputReport,
  DUALSENSE_HID_FILTERS,
  detectTransport,
  encodeUsbOutputReport,
  USB_OUTPUT_REPORT_ID,
  type HidOutputState,
} from './dualsenseHid';
import type { PadSample } from './dualsenseMapping';

export type HidStatus = 'unavailable' | 'idle' | 'connected' | 'bluetooth' | 'error';

interface HidInputReportEvent {
  readonly reportId: number;
  readonly data: DataView;
}

interface HidDeviceLike {
  readonly vendorId: number;
  readonly productId: number;
  readonly productName: string;
  readonly opened: boolean;
  open(): Promise<void>;
  close(): Promise<void>;
  sendReport(reportId: number, data: BufferSource): Promise<void>;
  addEventListener(type: 'inputreport', listener: (event: HidInputReportEvent) => void): void;
  removeEventListener(type: 'inputreport', listener: (event: HidInputReportEvent) => void): void;
}

interface HidDisconnectEvent {
  readonly device: HidDeviceLike;
}

interface HidApiLike {
  getDevices(): Promise<HidDeviceLike[]>;
  requestDevice(options: { filters: ReadonlyArray<{ vendorId: number; productId?: number }> }): Promise<HidDeviceLike[]>;
  addEventListener(type: 'disconnect', listener: (event: HidDisconnectEvent) => void): void;
  removeEventListener(type: 'disconnect', listener: (event: HidDisconnectEvent) => void): void;
}

function hidApi(): HidApiLike | null {
  if (typeof navigator === 'undefined') return null;
  const api = (navigator as unknown as { hid?: HidApiLike }).hid;
  return api ?? null;
}

function isDualSense(device: HidDeviceLike): boolean {
  return DUALSENSE_HID_FILTERS.some((filter) => filter.vendorId === device.vendorId && filter.productId === device.productId);
}

function sameBytes(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  for (let index = 0; index < a.length; index += 1) {
    if (a[index] !== b[index]) return false;
  }
  return true;
}

export interface DualSenseHidOptions {
  readonly onStatus: (status: HidStatus) => void;
  /** Returns milliseconds on a monotonic clock. Injected for tests. */
  readonly clock?: () => number;
}

export class DualSenseHidTransport {
  private device: HidDeviceLike | null = null;
  private status: HidStatus;
  private lastSample: PadSample | null = null;
  private lastSampleAt = Number.NEGATIVE_INFINITY;
  private lastSent: Uint8Array<ArrayBuffer> | null = null;
  private readonly clock: () => number;

  private readonly onReport = (event: HidInputReportEvent): void => this.handleReport(event);
  private readonly onDisconnect = (event: HidDisconnectEvent): void => {
    if (event.device === this.device) this.drop();
  };

  constructor(private readonly options: DualSenseHidOptions) {
    this.clock = options.clock ?? (() => performance.now());
    const api = hidApi();
    this.status = api ? 'idle' : 'unavailable';
    api?.addEventListener('disconnect', this.onDisconnect);
  }

  static isSupported(): boolean {
    return hidApi() !== null;
  }

  /** True when a DualSense is open and can receive output reports over USB. */
  get connected(): boolean {
    return this.device !== null && this.device.opened && this.status !== 'bluetooth';
  }

  /** Re-opens a DualSense the player already granted in an earlier visit. No prompt is shown. */
  async restoreGrantedDevice(): Promise<void> {
    const api = hidApi();
    if (!api || this.device) return;
    try {
      const match = (await api.getDevices()).find(isDualSense);
      if (match) await this.open(match);
    } catch {
      this.setStatus('error');
    }
  }

  /** Shows the browser's device picker. Must be called from a click or tap handler. */
  async requestDevice(): Promise<boolean> {
    const api = hidApi();
    if (!api) return false;
    try {
      const [device] = await api.requestDevice({ filters: DUALSENSE_HID_FILTERS });
      if (!device) return false;
      await this.open(device);
      return true;
    } catch {
      // The player dismissed the picker, or the page is not a secure context.
      this.setStatus(this.device ? 'connected' : 'error');
      return false;
    }
  }

  /** Newest input sample, or null when none is fresh. Freshness stops stale values from sticking. */
  freshSample(maxAgeMs: number): PadSample | null {
    if (!this.connected || this.lastSample === null) return null;
    if (this.clock() - this.lastSampleAt > maxAgeMs) return null;
    return this.lastSample;
  }

  /** Sends the output state. Unchanged reports are skipped, so calling this every frame is cheap. */
  setOutputs(state: HidOutputState): void {
    const device = this.device;
    if (!device || !this.connected) return;
    const report = encodeUsbOutputReport(state);
    if (this.lastSent && sameBytes(report, this.lastSent)) return;
    this.lastSent = report;
    // WebHID takes the report id as a separate argument, so the id byte is not part of the data.
    device.sendReport(USB_OUTPUT_REPORT_ID, report.subarray(1)).catch(() => {
      this.lastSent = null;
      this.setStatus('error');
    });
  }

  async close(): Promise<void> {
    const device = this.device;
    this.drop();
    if (device?.opened) await device.close().catch(() => undefined);
    hidApi()?.removeEventListener('disconnect', this.onDisconnect);
  }

  private async open(device: HidDeviceLike): Promise<void> {
    if (this.device && this.device !== device) this.detachReports();
    if (!device.opened) await device.open();
    this.device = device;
    device.addEventListener('inputreport', this.onReport);
    this.lastSent = null;
    this.setStatus('connected');
  }

  private detachReports(): void {
    this.device?.removeEventListener('inputreport', this.onReport);
  }

  private drop(): void {
    this.detachReports();
    this.device = null;
    this.lastSample = null;
    this.lastSent = null;
    this.setStatus(hidApi() ? 'idle' : 'unavailable');
  }

  private handleReport(event: HidInputReportEvent): void {
    const kind = detectTransport(event.reportId);
    if (kind === 'bluetooth') {
      this.setStatus('bluetooth');
      return;
    }
    if (this.status === 'bluetooth') this.setStatus('connected');

    const report = new Uint8Array(event.data.byteLength + 1);
    report[0] = event.reportId;
    report.set(new Uint8Array(event.data.buffer, event.data.byteOffset, event.data.byteLength), 1);
    const sample = decodeUsbInputReport(report);
    if (!sample) return;
    this.lastSample = sample;
    this.lastSampleAt = this.clock();
  }

  private setStatus(status: HidStatus): void {
    if (this.status === status) return;
    this.status = status;
    this.options.onStatus(status);
  }
}
