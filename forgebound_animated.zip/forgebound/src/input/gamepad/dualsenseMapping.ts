/**
 * DualSense button mapping and edge detection. Pure: the sampler (Gamepad API or WebHID) produces
 * a PadSample, and this module turns successive samples into one-frame action edges.
 *
 * Layout (PlayStation convention, with the action bindings used by Forgebound):
 *   Left stick  move            Right stick  look
 *   Cross       interact        R2 (pressed) interact (the "strike" trigger)
 *   Circle      jump            (menus: back)
 *   Triangle    satchel         Options      escape / back
 *   D-pad       menu focus      Touchpad     satchel (optional, see touchpadButtonIndex)
 */
import { applyRadialDeadzone } from '../touch/touchMath';
import { NO_EDGES, type ActionEdges, type InputFamily, type Vec2 } from '../actions';

export type PadButton =
  | 'cross' | 'circle' | 'square' | 'triangle'
  | 'l1' | 'r1' | 'l2' | 'r2'
  | 'create' | 'options' | 'l3' | 'r3'
  | 'dpadUp' | 'dpadDown' | 'dpadLeft' | 'dpadRight'
  | 'ps' | 'touchpad';

export interface PadActionBindings {
  readonly jump: PadButton;
  readonly interact: PadButton;
  readonly inventory: PadButton;
  readonly pause: PadButton;
}

export const DEFAULT_PAD_ACTION_BINDINGS: PadActionBindings = {
  jump: 'circle', interact: 'cross', inventory: 'triangle', pause: 'options',
};

export type PadButtons = Readonly<Record<PadButton, boolean>>;

export type PadFamily = Extract<InputFamily, 'dualsense' | 'gamepad'>;
export type StickDirection = 'none' | 'up' | 'down' | 'left' | 'right';

/** A single controller reading. Stick axes are -1 to 1 with +y pointing down. */
export interface PadSample {
  readonly buttons: PadButtons;
  /** Analog R2 travel, 0 to 1. */
  readonly triggerRight: number;
  readonly stickLeft: Vec2;
  readonly stickRight: Vec2;
}

export interface PadState {
  readonly buttons: PadButtons;
  readonly triggerDown: boolean;
  readonly stickDirection: StickDirection;
}

export const PAD_BUTTON_NAMES: readonly PadButton[] = [
  'cross', 'circle', 'square', 'triangle', 'l1', 'r1', 'l2', 'r2', 'create', 'options', 'l3', 'r3',
  'dpadUp', 'dpadDown', 'dpadLeft', 'dpadRight', 'ps', 'touchpad',
];

export function noButtons(): PadButtons {
  return {
    cross: false, circle: false, square: false, triangle: false,
    l1: false, r1: false, l2: false, r2: false,
    create: false, options: false, l3: false, r3: false,
    dpadUp: false, dpadDown: false, dpadLeft: false, dpadRight: false,
    ps: false, touchpad: false,
  };
}

export const INITIAL_PAD_STATE: PadState = {
  buttons: noButtons(),
  triggerDown: false,
  stickDirection: 'none',
};

export const PAD_STICK_DEADZONE = 0.15;
export const TRIGGER_PRESS_THRESHOLD = 0.5;
export const TRIGGER_RELEASE_THRESHOLD = 0.35;
/** Stick magnitude that counts as a menu flick. */
export const STICK_FLICK_THRESHOLD = 0.6;
/** Stick magnitude that counts as the player touching the controller, for device switching. */
export const PAD_ACTIVITY_THRESHOLD = 0.5;

/**
 * Identifies a controller by its browser-reported id. Chromium reports DualSense with the USB id
 * "054c-0ce6-..." or "...Vendor: 054c Product: 0ce6" in other engines. The DualSense Edge is 0df2.
 */
export function identifyPad(id: string): PadFamily {
  return /dualsense|054c.*0(ce6|df2)/i.test(id) ? 'dualsense' : 'gamepad';
}

export interface PadStep {
  readonly state: PadState;
  /** Gameplay edges (jump, interact, satchel, escape) and menu edges, gated by the menu flag. */
  readonly edges: ActionEdges;
  /** Movement after the dead zone. Zero while a menu is open. */
  readonly move: Vec2;
  /** Right-stick look after the dead zone. Unscaled; the router applies speed and sensitivity. */
  readonly look: Vec2;
  /** True when the player touched a control this frame. Used to switch the prompt family. */
  readonly active: boolean;
}

function dominantDirection(vector: Vec2): StickDirection {
  const magnitude = Math.hypot(vector.x, vector.y);
  if (magnitude < STICK_FLICK_THRESHOLD) return 'none';
  if (Math.abs(vector.x) > Math.abs(vector.y)) return vector.x < 0 ? 'left' : 'right';
  return vector.y < 0 ? 'up' : 'down';
}

/**
 * Turns one sample into edges, given the previous state. Rising edges fire once per press, so a
 * held button produces no repeat. In menus, Cross confirms, Circle goes back, and R2 is ignored
 * so a stray trigger pull cannot act on the world.
 */
export function interpretPadSample(
  sample: PadSample, previous: PadState, menuOpen: boolean,
  bindings: PadActionBindings = DEFAULT_PAD_ACTION_BINDINGS,
): PadStep {
  const now = sample.buttons;
  const before = previous.buttons;
  const rising = (name: PadButton): boolean => now[name] && !before[name];

  const triggerDown = previous.triggerDown
    ? sample.triggerRight > TRIGGER_RELEASE_THRESHOLD
    : sample.triggerRight >= TRIGGER_PRESS_THRESHOLD;
  const triggerRising = triggerDown && !previous.triggerDown;

  const direction = dominantDirection(sample.stickLeft);
  const flick = direction !== 'none' && direction !== previous.stickDirection ? direction : 'none';

  const jumpRising = rising(bindings.jump);
  const interactRising = rising(bindings.interact);
  // The touchpad remains a convenience alias even when the primary inventory button is rebound.
  // This preserves the documented DualSense behavior without preventing user remapping.
  const inventoryRising = rising(bindings.inventory) || (bindings.inventory !== 'touchpad' && rising('touchpad'));
  const pauseRising = rising(bindings.pause);
  const up = rising('dpadUp') || flick === 'up';
  const down = rising('dpadDown') || flick === 'down';
  const left = rising('dpadLeft') || flick === 'left';
  const right = rising('dpadRight') || flick === 'right';

  const edges: ActionEdges = {
    jump: jumpRising && !menuOpen,
    interact: (interactRising || triggerRising) && !menuOpen,
    satchel: inventoryRising,
    escape: pauseRising || (menuOpen && jumpRising),
    menuUp: menuOpen && up,
    menuDown: menuOpen && down,
    menuLeft: menuOpen && left,
    menuRight: menuOpen && right,
    menuConfirm: menuOpen && interactRising,
  };

  const move = menuOpen
    ? { x: 0, y: 0 }
    : applyRadialDeadzone(sample.stickLeft.x, sample.stickLeft.y, PAD_STICK_DEADZONE);
  const look = applyRadialDeadzone(sample.stickRight.x, sample.stickRight.y, PAD_STICK_DEADZONE);

  const anyButtonRising = PAD_BUTTON_NAMES.some((name) => rising(name));
  const stickActive = Math.hypot(sample.stickLeft.x, sample.stickLeft.y) > PAD_ACTIVITY_THRESHOLD
    || Math.hypot(sample.stickRight.x, sample.stickRight.y) > PAD_ACTIVITY_THRESHOLD
    || triggerRising;

  return {
    state: { buttons: now, triggerDown, stickDirection: direction },
    edges,
    move,
    look,
    active: anyButtonRising || stickActive,
  };
}

/** Returned when no controller is present. Clears any edges left from the last one. */
export const IDLE_PAD_STEP: PadStep = {
  state: INITIAL_PAD_STATE,
  edges: NO_EDGES,
  move: { x: 0, y: 0 },
  look: { x: 0, y: 0 },
  active: false,
};

