import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { clone as cloneSkeleton } from 'three/addons/utils/SkeletonUtils.js';

import { ASSET_FILENAMES, type AssetId } from './asset-manifest';
export { ASSET_FILENAMES, type AssetId } from './asset-manifest';

function isHumanoidAsset(assetId: string): boolean {
  return assetId === 'player' || assetId.startsWith('npc-') || assetId.startsWith('civilian-');
}

/** Loads local GLB files and their embedded/shared skeletal animation clips. */
export class AssetRegistry {
  private readonly loader = new GLTFLoader();
  private readonly models = new Map<AssetId, THREE.Group>();
  private readonly animations = new Map<AssetId, THREE.AnimationClip[]>();
  private humanoidClips: THREE.AnimationClip[] = [];
  private readonly attempted = new Set<AssetId>();

  async loadAll(): Promise<void> {
    const loadSharedClips = this.loader
      .loadAsync('/assets/animations/humanoid-clips.glb')
      .then((gltf) => {
        this.humanoidClips = gltf.animations ?? [];
      })
      .catch(() => {
        this.humanoidClips = [];
      });

    const entries = Object.entries(ASSET_FILENAMES) as [AssetId, string][];
    const loadModels = Promise.all(entries.map(async ([assetId, filename]) => {
      this.attempted.add(assetId);
      try {
        const gltf = await this.loader.loadAsync(`/assets/models/${filename}`);
        const model = gltf.scene;
        model.name = `asset-${assetId}`;
        model.traverse((object: THREE.Object3D) => {
          if (!(object instanceof THREE.Mesh)) return;
          object.castShadow = true;
          object.receiveShadow = true;
        });
        this.models.set(assetId, model);
        if (gltf.animations && gltf.animations.length > 0) {
          this.animations.set(assetId, gltf.animations);
        }
      } catch (error) {
        const reason = error instanceof Error ? error.message : 'unknown loading error';
        console.warn(`Forgebound: ${filename} unavailable; procedural fallback retained (${reason}).`);
      }
    }));

    await Promise.all([loadSharedClips, loadModels]);
  }

  createInstance(assetId: AssetId): THREE.Group | null {
    const source = this.models.get(assetId);
    if (!source) return null;
    const instance = cloneSkeleton(source) as THREE.Group;
    instance.name = `instance-${assetId}`;
    instance.traverse((object: THREE.Object3D) => {
      if (!(object instanceof THREE.Mesh)) return;
      object.castShadow = true;
      object.receiveShadow = true;
    });
    return instance;
  }

  getAnimations(assetId: AssetId): readonly THREE.AnimationClip[] {
    const own = this.animations.get(assetId);
    if (own && own.length > 0) return own;
    if (isHumanoidAsset(assetId)) return this.humanoidClips;
    return [];
  }

  getSource(assetId: AssetId): THREE.Group | null {
    return this.models.get(assetId) ?? null;
  }

  assertLoaded(assetIds: readonly AssetId[]): void {
    const missing = assetIds.filter((assetId) => !this.models.has(assetId));
    if (missing.length > 0) throw new Error(`Required GLB assets failed to load: ${missing.join(', ')}`);
  }

  has(assetId: AssetId): boolean {
    return this.models.has(assetId);
  }

  attemptedCount(): number {
    return this.attempted.size;
  }

  loadedCount(): number {
    return this.models.size;
  }

  dispose(): void {
    for (const model of this.models.values()) {
      model.traverse((object: THREE.Object3D) => {
        if (!(object instanceof THREE.Mesh)) return;
        object.geometry.dispose();
        const materials = Array.isArray(object.material) ? object.material : [object.material];
        for (const material of materials) material.dispose();
      });
    }
    this.models.clear();
    this.animations.clear();
    this.humanoidClips = [];
    this.attempted.clear();
  }
}
