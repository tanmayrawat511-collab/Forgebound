import * as THREE from 'three';

export interface PlayClipOptions {
  readonly loop?: boolean;
  readonly fadeSeconds?: number;
  readonly timeScale?: number;
  readonly onFinished?: () => void;
}

/**
 * Lightweight Three.js AnimationMixer wrapper supporting smooth crossfades,
 * one-shot action clips (attack, mine, greet), and skeletal socket attachment.
 */
export class AnimationController {
  readonly mixer: THREE.AnimationMixer;
  private readonly actions = new Map<string, THREE.AnimationAction>();
  private currentLoopName: string | null = null;
  private activeAction: THREE.AnimationAction | null = null;
  private oneShotCleanup: (() => void) | null = null;
  private enabled = true;

  constructor(private readonly root: THREE.Object3D, clips: readonly THREE.AnimationClip[]) {
    this.mixer = new THREE.AnimationMixer(root);
    for (const clip of clips) {
      this.actions.set(clip.name, this.mixer.clipAction(clip));
    }
  }

  hasClip(name: string): boolean {
    return this.actions.has(name);
  }

  setEnabled(enabled: boolean): void {
    this.enabled = enabled;
    if (!enabled) {
      this.mixer.stopAllAction();
      this.activeAction = null;
    }
  }

  playLoop(name: string, fadeSeconds = 0.16, timeScale = 1): boolean {
    if (!this.enabled) return false;
    const next = this.actions.get(name);
    if (!next) return false;
    if (this.currentLoopName === name && this.activeAction === next && next.isRunning()) {
      next.setEffectiveTimeScale(timeScale);
      return true;
    }
    this.currentLoopName = name;
    this.clearOneShotListener();
    next.reset();
    next.setLoop(THREE.LoopRepeat, Infinity);
    next.clampWhenFinished = false;
    next.setEffectiveTimeScale(timeScale);
    next.setEffectiveWeight(1);
    next.play();
    if (this.activeAction && this.activeAction !== next) {
      this.activeAction.crossFadeTo(next, fadeSeconds, true);
    }
    this.activeAction = next;
    return true;
  }

  playOneShot(name: string, options: PlayClipOptions = {}): boolean {
    if (!this.enabled) return false;
    const next = this.actions.get(name);
    if (!next) return false;
    const fadeSeconds = options.fadeSeconds ?? 0.1;
    const timeScale = options.timeScale ?? 1;

    this.clearOneShotListener();
    next.reset();
    next.setLoop(THREE.LoopOnce, 1);
    next.clampWhenFinished = false;
    next.setEffectiveTimeScale(timeScale);
    next.setEffectiveWeight(1);
    next.play();

    const previous = this.activeAction;
    if (previous && previous !== next) {
      previous.crossFadeTo(next, fadeSeconds, true);
    }
    this.activeAction = next;

    const onFinished = (event: { action: THREE.AnimationAction }) => {
      if (event.action !== next) return;
      this.clearOneShotListener();
      options.onFinished?.();
      if (this.currentLoopName) {
        const resume = this.actions.get(this.currentLoopName);
        if (resume) {
          resume.reset();
          resume.setLoop(THREE.LoopRepeat, Infinity);
          resume.play();
          next.crossFadeTo(resume, fadeSeconds, true);
          this.activeAction = resume;
        }
      }
    };
    this.mixer.addEventListener('finished', onFinished);
    this.oneShotCleanup = () => this.mixer.removeEventListener('finished', onFinished);
    return true;
  }

  update(deltaSeconds: number): void {
    if (!this.enabled) return;
    const dt = Math.max(0, Math.min(deltaSeconds, 0.1));
    this.mixer.update(dt);
  }

  attachToSocket(socketName: string, child: THREE.Object3D): boolean {
    const socket = this.root.getObjectByName(socketName);
    if (!socket) return false;
    socket.add(child);
    return true;
  }

  clearSocket(socketName: string): void {
    const socket = this.root.getObjectByName(socketName);
    if (!socket) return;
    for (const child of [...socket.children]) {
      socket.remove(child);
    }
  }

  dispose(): void {
    this.clearOneShotListener();
    this.mixer.stopAllAction();
    this.mixer.uncacheRoot(this.root);
    this.actions.clear();
  }

  private clearOneShotListener(): void {
    if (this.oneShotCleanup) {
      this.oneShotCleanup();
      this.oneShotCleanup = null;
    }
  }
}
