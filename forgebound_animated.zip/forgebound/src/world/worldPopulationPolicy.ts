export interface WorldPlacementLike {
  readonly x: number;
  readonly z: number;
}

export const WORLD_PROP_CELL_SIZE_METRES = 768;

/** Partition generated placements into local cells so InstancedMesh bounds can be frustum-culled. */
export function partitionPlacementsByCell<T extends WorldPlacementLike>(
  placements: readonly T[],
  zoneOriginX: number,
  cellSize = WORLD_PROP_CELL_SIZE_METRES,
): ReadonlyMap<string, readonly T[]> {
  if (!Number.isFinite(cellSize) || cellSize <= 0) throw new Error('World prop cell size must be positive.');
  const cells = new Map<string, T[]>();
  for (const placement of placements) {
    const worldX = zoneOriginX + placement.x;
    const cellX = Math.floor(worldX / cellSize);
    const cellZ = Math.floor(placement.z / cellSize);
    const key = `${cellX}:${cellZ}`;
    const cell = cells.get(key);
    if (cell) cell.push(placement);
    else cells.set(key, [placement]);
  }
  return cells;
}
