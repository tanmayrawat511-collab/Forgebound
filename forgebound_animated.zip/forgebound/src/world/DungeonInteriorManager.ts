import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import type { PhysicsWorld } from '../physics/PhysicsWorld';
import type { DungeonDefinition } from '../data/dungeon-data';
import type { DungeonId } from '../data/dungeon-data';
import type { RigidBody } from '@dimforge/rapier3d-compat';

export interface DungeonInteriorRuntime {
  readonly definition: DungeonDefinition;
  readonly root: THREE.Group;
  readonly points: ReadonlyMap<string, THREE.Object3D>;
  readonly exit: THREE.Object3D;
}

function disposeInteriorRoot(root: THREE.Object3D): void {
  root.traverse((object) => {
    if (!(object instanceof THREE.Mesh)) return;
    object.geometry.dispose();
    const materials = Array.isArray(object.material) ? object.material : [object.material];
    for (const material of materials) {
      for (const value of Object.values(material)) {
        const candidate = value as { isTexture?: unknown; dispose?: () => void };
        if (candidate?.isTexture === true) candidate.dispose?.();
      }
      material.dispose();
    }
  });
}

interface CachedInterior {
  readonly runtime: DungeonInteriorRuntime;
  bodies: RigidBody[];
  active: boolean;
}

/** Lazy-loads Python-authored GLB interiors and mirrors their exact meshes into Rapier. */
export class DungeonInteriorManager {
  private readonly loader = new GLTFLoader();
  private readonly cache = new Map<DungeonId, CachedInterior>();
  private activeId: DungeonId | null = null;
  private disposed = false;

  constructor(private readonly scene: THREE.Scene, private readonly physics: PhysicsWorld) {}

  async activate(definition: DungeonDefinition): Promise<DungeonInteriorRuntime> {
    if (this.disposed) throw new Error('Dungeon interiors have already been disposed.');
    if (this.activeId && this.activeId !== definition.id) this.deactivate();

    let cached = this.cache.get(definition.id);
    if (!cached) {
      const gltf = await this.loader.loadAsync(definition.assetFile);
      if (this.disposed) throw new Error('Dungeon interiors were disposed while an asset was loading.');
      const root = gltf.scene;
      root.name = `dungeon-interior-${definition.id}`;
      root.position.set(definition.instanceOrigin.x, 0, definition.instanceOrigin.z);
      root.updateMatrixWorld(true);

      const pointObjects = new Map<string, THREE.Object3D>();
      for (const point of definition.points) {
        const object = root.getObjectByName(point.meshName);
        if (!object) throw new Error(`Dungeon ${definition.id} is missing POI mesh ${point.meshName}.`);
        pointObjects.set(point.id, object);
      }
      const exit = root.getObjectByName(definition.exitMeshName);
      if (!exit) throw new Error(`Dungeon ${definition.id} is missing exit mesh ${definition.exitMeshName}.`);

      const runtime: DungeonInteriorRuntime = { definition, root, points: pointObjects, exit };
      cached = { runtime, bodies: [], active: false };
      this.cache.set(definition.id, cached);
    }

    if (!cached.active) {
      cached.runtime.root.position.set(definition.instanceOrigin.x, 0, definition.instanceOrigin.z);
      cached.runtime.root.updateMatrixWorld(true);
      cached.bodies = this.createColliders(cached.runtime.root);
      cached.runtime.root.visible = true;
      this.scene.add(cached.runtime.root);
      cached.active = true;
    }
    this.activeId = definition.id;
    return cached.runtime;
  }

  getActive(): DungeonInteriorRuntime | null {
    return this.activeId ? this.cache.get(this.activeId)?.runtime ?? null : null;
  }

  deactivate(): void {
    if (!this.activeId) return;
    const cached = this.cache.get(this.activeId);
    if (cached?.active) {
      this.scene.remove(cached.runtime.root);
      cached.runtime.root.visible = false;
      for (const body of cached.bodies) this.physics.removeRigidBody(body);
      cached.bodies = [];
      cached.active = false;
      // Interiors are intentionally one-at-a-time. Release GLB GPU resources on exit so
      // visiting all seven locations cannot grow the renderer cache for the whole session.
      disposeInteriorRoot(cached.runtime.root);
      this.cache.delete(cached.runtime.definition.id);
    }
    this.activeId = null;
  }

  dispose(): void {
    if (this.disposed) return;
    this.deactivate();
    this.disposed = true;
    for (const cached of this.cache.values()) {
      for (const body of cached.bodies) this.physics.removeRigidBody(body);
      disposeInteriorRoot(cached.runtime.root);
      cached.runtime.root.removeFromParent();
    }
    this.cache.clear();
  }

  private createColliders(root: THREE.Group): RigidBody[] {
    root.updateMatrixWorld(true);
    const bodies: RigidBody[] = [];
    try {
      root.traverse((object) => {
        if (!(object instanceof THREE.Mesh)) return;
        const position = object.geometry.getAttribute('position');
        if (!position || position.count < 3) return;
        const geometry = object.geometry.clone();
        try {
          geometry.applyMatrix4(object.matrixWorld);
          const transformedPosition = geometry.getAttribute('position');
          const geometryIndex = geometry.getIndex();
          const indices = geometryIndex
            ? Uint32Array.from(geometryIndex.array as ArrayLike<number>)
            : Uint32Array.from({ length: transformedPosition.count }, (_, index) => index);
          const vertices = Float32Array.from(transformedPosition.array as ArrayLike<number>);
          if (vertices.length >= 9 && indices.length >= 3 && indices.length % 3 === 0) {
            bodies.push(this.physics.addStaticTrimesh(vertices, indices, { x: 0, y: 0, z: 0 }));
          }
        } finally {
          geometry.dispose();
        }
      });
      if (bodies.length === 0) throw new Error('Dungeon interior contains no usable collision meshes.');
      return bodies;
    } catch (error) {
      for (const body of bodies) this.physics.removeRigidBody(body);
      throw error;
    }
  }
}

