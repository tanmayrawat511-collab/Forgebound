import type { ZoneId } from '../types/zones';

/** Height function mirrored by tools/generate_assets.py, including its safe spawn terrace. */
export function getZoneTerrainHeight(zoneId: ZoneId, x: number, z: number): number {
  let height: number;
  if (zoneId === 'starter-quarry') {
    const ridge = 15 * Math.sin(x / 330) * Math.cos(z / 410) + 7 * Math.sin((x + z) / 140);
    const quarryBowl = -19 * Math.exp(-(((x - 80) ** 2 + (z + 70) ** 2) / (2 * 280 ** 2)));
    const riverAxis = 250 * Math.sin(z / 340);
    const river = -5.5 * Math.exp(-(((x - riverAxis) / 42) ** 2));
    height = ridge + quarryBowl + river;
  } else if (zoneId === 'molten-caves') {
    const radius = Math.hypot(x + 120, z - 90);
    const calderaRim = 34 * Math.exp(-(((radius - 620) / 190) ** 2));
    const basin = -13 * Math.exp(-((radius / 440) ** 2));
    const ridges = 10 * Math.sin(x / 220) + 8 * Math.cos(z / 180);
    const fissure = -3.5 * Math.exp(-(((z - 0.28 * x + 160) / 24) ** 2));
    height = 15 + calderaRim + basin + ridges + fissure;
  } else {
    const ridgeA = 58 * Math.abs(Math.sin(x / 360) * Math.cos(z / 290));
    const ridgeB = 31 * Math.abs(Math.sin((x + z) / 220));
    const peak = 28 * Math.exp(-(((x - 520) ** 2 + (z + 490) ** 2) / (2 * 260 ** 2)));
    const valley = -7 * Math.exp(-(((x + 110) ** 2 + (z - 180) ** 2) / (2 * 260 ** 2)));
    height = 14 + ridgeA + ridgeB + peak + valley;
  }
  const spawnHeight = zoneId === 'starter-quarry' ? 0 : zoneId === 'molten-caves' ? 12 : 14;
  const plateauWeight = Math.exp(-((x * x + z * z) / (2 * 75 ** 2)));
  return height * (1 - plateauWeight) + spawnHeight * plateauWeight;
}
