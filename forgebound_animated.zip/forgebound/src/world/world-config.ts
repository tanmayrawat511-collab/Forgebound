import type { ZoneId } from '../types/zones';

export interface BoxDefinition {
  readonly id: string;
  readonly zoneId: ZoneId;
  readonly center: Readonly<{ x: number; y: number; z: number }>;
  readonly halfExtents: Readonly<{ x: number; y: number; z: number }>;
  readonly tone: 'wall' | 'obstacle';
}

export interface ArenaLayout {
  readonly zoneId: ZoneId;
  readonly center: Readonly<{ x: number; z: number }>;
  readonly floor: Readonly<{
    center: Readonly<{ x: number; y: number; z: number }>;
    halfExtents: Readonly<{ x: number; y: number; z: number }>;
  }>;
  readonly obstacles: readonly BoxDefinition[];
}

const ARENA_HALF_SIZE = 14;
const WALL_HEIGHT = 4.2;
const WALL_THICKNESS = 0.7;

export const WORLD_CONFIG = {
  floor: {
    center: { x: 0, y: -0.3, z: 0 },
    halfExtents: { x: ARENA_HALF_SIZE, y: 0.3, z: ARENA_HALF_SIZE },
  },
  wallHeight: WALL_HEIGHT,
  wallThickness: WALL_THICKNESS,
  wallInset: ARENA_HALF_SIZE,
  spawn: { x: 0, y: 1, z: 0 },
  obstacles: [
    {
      id: 'quarry-barricade-west',
      zoneId: 'starter-quarry',
      center: { x: -1.2, y: 0.72, z: -1.8 },
      halfExtents: { x: 0.75, y: 0.72, z: 1.9 },
      tone: 'obstacle',
    },
    {
      id: 'quarry-boulder-east',
      zoneId: 'starter-quarry',
      center: { x: 4.1, y: 0.78, z: 1.2 },
      halfExtents: { x: 1.35, y: 0.78, z: 1.05 },
      tone: 'obstacle',
    },
  ] satisfies readonly BoxDefinition[],
} as const;

export const ARENA_LAYOUTS: readonly ArenaLayout[] = [
  {
    zoneId: 'starter-quarry',
    center: { x: 0, z: 0 },
    floor: WORLD_CONFIG.floor,
    obstacles: WORLD_CONFIG.obstacles,
  },
  {
    zoneId: 'molten-caves',
    center: { x: 36, z: 0 },
    floor: {
      center: { x: 36, y: -0.3, z: 0 },
      halfExtents: { x: ARENA_HALF_SIZE, y: 0.3, z: ARENA_HALF_SIZE },
    },
    obstacles: [
      {
        id: 'molten-basalt-spine',
        zoneId: 'molten-caves',
        center: { x: 35.1, y: 0.88, z: -1.2 },
        halfExtents: { x: 1.15, y: 0.88, z: 3.0 },
        tone: 'obstacle',
      },
      {
        id: 'molten-obsidian-shelf',
        zoneId: 'molten-caves',
        center: { x: 42.1, y: 0.72, z: 2.6 },
        halfExtents: { x: 1.75, y: 0.72, z: 1.0 },
        tone: 'obstacle',
      },
    ],
  },
  {
    zoneId: 'crystal-peaks',
    center: { x: 72, z: 0 },
    floor: {
      center: { x: 72, y: -0.3, z: 0 },
      halfExtents: { x: ARENA_HALF_SIZE, y: 0.3, z: ARENA_HALF_SIZE },
    },
    obstacles: [
      {
        id: 'peaks-glass-ridge',
        zoneId: 'crystal-peaks',
        center: { x: 70.8, y: 0.92, z: -1.6 },
        halfExtents: { x: 1.2, y: 0.92, z: 2.7 },
        tone: 'obstacle',
      },
      {
        id: 'peaks-frosted-boulder',
        zoneId: 'crystal-peaks',
        center: { x: 77.1, y: 0.8, z: 2.5 },
        halfExtents: { x: 1.4, y: 0.8, z: 1.25 },
        tone: 'obstacle',
      },
    ],
  },
];

export function createBoundaryBoxes(
  center: Readonly<{ x: number; z: number }> = { x: 0, z: 0 },
  zoneId: ZoneId = 'starter-quarry',
): BoxDefinition[] {
  const edge = ARENA_HALF_SIZE;
  const halfWall = WALL_THICKNESS / 2;
  const halfHeight = WALL_HEIGHT / 2;
  const wallY = halfHeight;

  return [
    {
      id: `${zoneId}-north-wall`,
      zoneId,
      center: { x: center.x, y: wallY, z: center.z - edge },
      halfExtents: { x: edge, y: halfHeight, z: halfWall },
      tone: 'wall',
    },
    {
      id: `${zoneId}-south-wall`,
      zoneId,
      center: { x: center.x, y: wallY, z: center.z + edge },
      halfExtents: { x: edge, y: halfHeight, z: halfWall },
      tone: 'wall',
    },
    {
      id: `${zoneId}-west-wall`,
      zoneId,
      center: { x: center.x - edge, y: wallY, z: center.z },
      halfExtents: { x: halfWall, y: halfHeight, z: edge },
      tone: 'wall',
    },
    {
      id: `${zoneId}-east-wall`,
      zoneId,
      center: { x: center.x + edge, y: wallY, z: center.z },
      halfExtents: { x: halfWall, y: halfHeight, z: edge },
      tone: 'wall',
    },
  ];
}

export function getStaticBoxes(): BoxDefinition[] {
  return ARENA_LAYOUTS.flatMap((arena) => [
    ...createBoundaryBoxes(arena.center, arena.zoneId),
    ...arena.obstacles,
  ]);
}
