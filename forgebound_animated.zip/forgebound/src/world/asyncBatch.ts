/** Run asynchronous work with a hard concurrency ceiling and stop queueing after a failure. */
export async function runBounded<T>(
  items: readonly T[],
  maximumConcurrency: number,
  worker: (item: T, index: number) => Promise<void>,
): Promise<void> {
  if (!Number.isSafeInteger(maximumConcurrency) || maximumConcurrency < 1) {
    throw new Error('Async batch concurrency must be a positive integer.');
  }
  if (items.length === 0) return;

  let nextIndex = 0;
  let stopped = false;
  const workerCount = Math.min(maximumConcurrency, items.length);
  await Promise.all(Array.from({ length: workerCount }, async () => {
    while (!stopped) {
      const index = nextIndex++;
      if (index >= items.length) return;
      try {
        await worker(items[index]!, index);
      } catch (error) {
        stopped = true;
        throw error;
      }
    }
  }));
}
