import * as THREE from 'three';
import { CIVILIAN_CAP_PER_ZONE, CIVILIAN_DEFINITIONS } from '../data/civilian-data';
import { ZONE_DEFINITIONS } from '../data/zone-data';
import type { ZoneId } from '../types/zones';
import { PhysicsWorld } from '../physics/PhysicsWorld';
import { Civilian } from '../entities/Civilian';
import { PetDog } from '../entities/PetDog';
import { getZoneTerrainHeight } from './terrain-height';

const DESPAWN_DISTANCE = 118;
const RESPAWN_DISTANCE = 92;
const RESPAWN_DELAY_SECONDS = 12;

/** Runtime population controller. Six active actors are permitted in each zone. */
export class CivilianPopulation {
  private readonly civilians: Civilian[] = [];
  private readonly respawnTimers = new Map<string, number>();
  private readonly zoneRotation = new Map<ZoneId, number>();
  private activeZone: ZoneId = 'starter-quarry';
  private dog: PetDog | null = null;

  constructor(
    private readonly scene: THREE.Scene,
    physics: PhysicsWorld,
    private readonly createModel: (assetId: string) => THREE.Group | null,
    private readonly getAnimations: (assetId: string) => readonly THREE.AnimationClip[] = () => [],
  ) {
    for (const definition of CIVILIAN_DEFINITIONS) {
      const zone = ZONE_DEFINITIONS[definition.zoneId];
      const x = zone.spawn.x + definition.offset.x;
      const z = zone.spawn.z + definition.offset.z;
      const y = getZoneTerrainHeight(definition.zoneId, definition.offset.x, definition.offset.z);
      const actor = new Civilian(definition, physics, this.createModel(definition.assetId), new THREE.Vector3(x, y, z));
      actor.setActive(false);
      this.civilians.push(actor);
      this.scene.add(actor.visualRoot);
    }
    const dogSpawn = ZONE_DEFINITIONS['starter-quarry'].spawn;
    const dogX = dogSpawn.x + 6;
    const dogZ = dogSpawn.z + 26;
    const dogY = getZoneTerrainHeight('starter-quarry', 6, 26);
    this.dog = new PetDog(physics, this.createModel('pet-dog'), 'starter-quarry', new THREE.Vector3(dogX, dogY, dogZ));
    this.dog.setActive(false);
    this.scene.add(this.dog.visualRoot);
    this.setActiveZone('starter-quarry');
  }

  setActiveZone(zoneId: ZoneId): void {
    this.activeZone = zoneId;
    for (const civilian of this.civilians) civilian.setActive(false);
    const pool = this.civilians.filter((civilian) => civilian.definition.zoneId === zoneId);
    const first = this.zoneRotation.get(zoneId) ?? 0;
    const count = Math.min(CIVILIAN_CAP_PER_ZONE, pool.length);
    for (let index = 0; index < count; index += 1) pool[(first + index) % pool.length]?.setActive(true);
    if (pool.length > 0) this.zoneRotation.set(zoneId, (first + count) % pool.length);
    this.respawnTimers.clear();
    this.dog?.setActive(zoneId === 'starter-quarry');
  }

  update(deltaSeconds: number, playerPosition: THREE.Vector3): void {
    const dt = Math.max(0, Math.min(deltaSeconds, 0.1));
    for (const civilian of this.civilians) {
      if (civilian.definition.zoneId !== this.activeZone) continue;
      const distance = civilian.distanceTo(playerPosition);
      const timer = this.respawnTimers.get(civilian.definition.id);
      if (civilian.visualRoot.visible && distance > DESPAWN_DISTANCE && timer === undefined) {
        civilian.setActive(false);
        this.respawnTimers.set(civilian.definition.id, RESPAWN_DELAY_SECONDS);
      } else if (timer !== undefined) {
        const remaining = timer - dt;
        if (remaining <= 0 && distance < RESPAWN_DISTANCE) {
          this.respawnTimers.delete(civilian.definition.id);
          this.spawnNextReserve(civilian.definition.zoneId);
        } else this.respawnTimers.set(civilian.definition.id, Math.max(0, remaining));
      } else if (civilian.visualRoot.visible) civilian.update(dt, this.activeZone);
    }
    if (this.dog?.visualRoot.visible) this.dog.update(dt, this.activeZone);
  }

  private spawnNextReserve(zoneId: ZoneId): void {
    const activeCount = this.civilians.filter((civilian) => civilian.definition.zoneId === zoneId && civilian.visualRoot.visible).length;
    if (activeCount >= CIVILIAN_CAP_PER_ZONE) return;
    const pool = this.civilians.filter((civilian) => civilian.definition.zoneId === zoneId);
    if (pool.length === 0) return;
    const nextStart = this.zoneRotation.get(zoneId) ?? 0;
    for (let offset = 0; offset < pool.length; offset += 1) {
      const candidateIndex = (nextStart + offset) % pool.length;
      const candidate = pool[candidateIndex];
      if (!candidate || candidate.visualRoot.visible || this.respawnTimers.has(candidate.definition.id)) continue;
      candidate.setActive(true);
      this.zoneRotation.set(zoneId, (candidateIndex + 1) % pool.length);
      return;
    }
  }

  greetNearest(position: THREE.Vector3, radius: number): Civilian | null {
    const nearest = this.getNearestCivilian(position, radius);
    nearest?.greet();
    return nearest;
  }

  isDogInRange(position: THREE.Vector3, radius: number): boolean {
    return Boolean(this.dog && this.dog.visualRoot.visible && this.dog.isPetReady() && this.dog.distanceTo(position) <= radius);
  }

  getNearestCivilian(position: THREE.Vector3, radius: number): Civilian | null {
    let nearest: Civilian | null = null;
    let distance = radius;
    for (const civilian of this.civilians) {
      if (!civilian.visualRoot.visible || this.respawnTimers.has(civilian.definition.id)) continue;
      const candidate = civilian.distanceTo(position);
      if (candidate < distance) { distance = candidate; nearest = civilian; }
    }
    return nearest;
  }

  petDog(position: THREE.Vector3, radius: number): boolean {
    if (!this.isDogInRange(position, radius) || !this.dog) return false;
    return this.dog.pet();
  }

  getMinimapMarkers(): readonly { id: string; kind: 'civilian' | 'dog'; x: number; z: number }[] {
    const markers: { id: string; kind: 'civilian' | 'dog'; x: number; z: number }[] = [];
    for (const civilian of this.civilians) {
      if (!civilian.visualRoot.visible || this.respawnTimers.has(civilian.definition.id)) continue;
      markers.push({ id: civilian.definition.id, kind: 'civilian', x: civilian.visualRoot.position.x, z: civilian.visualRoot.position.z });
    }
    if (this.dog?.visualRoot.visible) markers.push({ id: 'pet-dog', kind: 'dog', x: this.dog.visualRoot.position.x, z: this.dog.visualRoot.position.z });
    return markers;
  }

  dispose(): void {
    for (const civilian of this.civilians) { this.scene.remove(civilian.visualRoot); civilian.dispose(); }
    this.civilians.length = 0;
    if (this.dog) { this.scene.remove(this.dog.visualRoot); this.dog.dispose(); this.dog = null; }
    this.respawnTimers.clear();
  }
}
