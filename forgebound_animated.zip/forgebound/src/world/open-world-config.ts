import type { ZoneId } from '../types/zones';

/** Phase J world contract: exactly seven million square metres of playable ground per zone. */
export const PLAYABLE_AREA_SQUARE_METRES = 7_000_000;
export const ZONE_SIDE_METRES = Math.sqrt(PLAYABLE_AREA_SQUARE_METRES);
export const TERRAIN_CHUNK_SIZE_METRES = 256;
export const TERRAIN_CHUNKS_PER_SIDE = Math.ceil(ZONE_SIDE_METRES / TERRAIN_CHUNK_SIZE_METRES);
export const TERRAIN_STREAM_RADIUS_CHUNKS = 3;

export interface OpenWorldZoneConfig {
  readonly id: ZoneId;
  readonly originX: number;
  readonly originZ: number;
  readonly playableAreaSquareMetres: number;
  readonly sideLengthMetres: number;
  readonly chunkSizeMetres: number;
  readonly chunkCountX: number;
  readonly chunkCountZ: number;
  readonly terrainPath: string;
}

export const OPEN_WORLD_ZONES: Readonly<Record<ZoneId, OpenWorldZoneConfig>> = {
  'starter-quarry': {
    id: 'starter-quarry', originX: 0, originZ: 0,
    playableAreaSquareMetres: PLAYABLE_AREA_SQUARE_METRES, sideLengthMetres: ZONE_SIDE_METRES,
    chunkSizeMetres: TERRAIN_CHUNK_SIZE_METRES, chunkCountX: TERRAIN_CHUNKS_PER_SIDE,
    chunkCountZ: TERRAIN_CHUNKS_PER_SIDE, terrainPath: '/assets/terrain/starter-quarry',
  },
  'molten-caves': {
    id: 'molten-caves', originX: 3_000, originZ: 0,
    playableAreaSquareMetres: PLAYABLE_AREA_SQUARE_METRES, sideLengthMetres: ZONE_SIDE_METRES,
    chunkSizeMetres: TERRAIN_CHUNK_SIZE_METRES, chunkCountX: TERRAIN_CHUNKS_PER_SIDE,
    chunkCountZ: TERRAIN_CHUNKS_PER_SIDE, terrainPath: '/assets/terrain/molten-caves',
  },
  'crystal-peaks': {
    id: 'crystal-peaks', originX: 6_000, originZ: 0,
    playableAreaSquareMetres: PLAYABLE_AREA_SQUARE_METRES, sideLengthMetres: ZONE_SIDE_METRES,
    chunkSizeMetres: TERRAIN_CHUNK_SIZE_METRES, chunkCountX: TERRAIN_CHUNKS_PER_SIDE,
    chunkCountZ: TERRAIN_CHUNKS_PER_SIDE, terrainPath: '/assets/terrain/crystal-peaks',
  },
};

export interface TerrainChunkIndex {
  readonly x: number;
  readonly z: number;
}

/** Returns the bounded square of chunks around a center, clipped to the playable zone. */
export function getTerrainChunkWindow(
  zoneId: ZoneId,
  centerX: number,
  centerZ: number,
  radius: number,
): readonly TerrainChunkIndex[] {
  const zone = OPEN_WORLD_ZONES[zoneId];
  if (!Number.isInteger(centerX) || !Number.isInteger(centerZ)) {
    throw new Error('Terrain chunk center must use integer chunk coordinates.');
  }
  const safeRadius = Number.isFinite(radius) ? Math.min(10, Math.max(0, Math.floor(radius))) : 0;
  const chunks: TerrainChunkIndex[] = [];
  for (let z = centerZ - safeRadius; z <= centerZ + safeRadius; z += 1) {
    for (let x = centerX - safeRadius; x <= centerX + safeRadius; x += 1) {
      if (x < 0 || z < 0 || x >= zone.chunkCountX || z >= zone.chunkCountZ) continue;
      chunks.push({ x, z });
    }
  }
  return chunks;
}

export interface TerrainChunkCoordinate {
  readonly x: number;
  readonly z: number;
  readonly minX: number;
  readonly maxX: number;
  readonly minZ: number;
  readonly maxZ: number;
}

export function getTerrainChunkCoordinate(zoneId: ZoneId, worldX: number, worldZ: number): TerrainChunkCoordinate | null {
  const zone = OPEN_WORLD_ZONES[zoneId];
  const half = zone.sideLengthMetres / 2;
  const localX = worldX - zone.originX;
  const localZ = worldZ - zone.originZ;
  if (localX < -half || localX > half || localZ < -half || localZ > half) return null;
  const x = Math.min(zone.chunkCountX - 1, Math.floor((localX + half) / zone.chunkSizeMetres));
  const z = Math.min(zone.chunkCountZ - 1, Math.floor((localZ + half) / zone.chunkSizeMetres));
  const minX = -half + x * zone.chunkSizeMetres;
  const minZ = -half + z * zone.chunkSizeMetres;
  return {
    x, z, minX,
    maxX: Math.min(half, minX + zone.chunkSizeMetres),
    minZ,
    maxZ: Math.min(half, minZ + zone.chunkSizeMetres),
  };
}

export function getTerrainChunkFilename(x: number, z: number): string {
  return `chunk-${x}-${z}.glb`;
}
