import * as THREE from 'three';
import type { AssetId, AssetRegistry } from '../assets/AssetRegistry';
import type { ZoneId } from '../types/zones';
import { OPEN_WORLD_ZONES, ZONE_SIDE_METRES } from './open-world-config';
import { getZoneTerrainHeight } from './terrain-height';
import { partitionPlacementsByCell } from './worldPopulationPolicy';

interface Placement {
  readonly x: number;
  readonly z: number;
  readonly scale: number;
  readonly rotation: number;
  readonly yOffset?: number;
}

interface ZoneVisualGroup {
  readonly zoneId: ZoneId;
  readonly group: THREE.Group;
}

/** Deterministic, instanced placement of Python-generated GLB environment assets. */
export class WorldPopulation {
  private readonly cameraOccluderAssets = new Set<AssetId>(['rock-outcrop', 'stone-arch', 'cave-arch', 'volcanic-vent', 'crystal-spire']);
  private readonly zoneGroups: ZoneVisualGroup[] = [];
  private activeZoneId: ZoneId = 'starter-quarry';
  private worldVisible = true;

  constructor(
    private readonly scene: THREE.Scene,
    private readonly assets: AssetRegistry,
  ) {}

  build(): void {
    this.buildStarterQuarry();
    this.buildMoltenCaves();
    this.buildCrystalPeaks();
  }

  setActiveZone(zoneId: ZoneId): void {
    this.activeZoneId = zoneId;
    this.applyVisibility();
  }

  setWorldVisible(visible: boolean): void {
    this.worldVisible = visible;
    this.applyVisibility();
  }

  /** Add active-zone structural props to camera collision without ray-testing all vegetation. */
  appendCameraOccluders(output: THREE.Object3D[]): void {
    for (const entry of this.zoneGroups) {
      if (!entry.group.visible || entry.zoneId !== this.activeZoneId) continue;
      for (const child of entry.group.children) {
        if (child.userData['cameraOccluder'] === true && child.visible) output.push(child);
      }
    }
  }

  private applyVisibility(): void {
    for (const entry of this.zoneGroups) entry.group.visible = this.worldVisible && entry.zoneId === this.activeZoneId;
  }

  dispose(): void {
    for (const entry of this.zoneGroups) this.scene.remove(entry.group);
    this.zoneGroups.length = 0;
  }

  private buildStarterQuarry(): void {
    const group = this.zoneGroup('starter-quarry');
    this.addRandom(group, 'starter-quarry', 'tree-pine', 105, 0.82, 1.35, 0.12);
    this.addRandom(group, 'starter-quarry', 'tree-broadleaf', 82, 0.75, 1.25, 0.12);
    this.addRandom(group, 'starter-quarry', 'rock-outcrop', 75, 0.7, 1.8, 0.08);
    this.addRandom(group, 'starter-quarry', 'timber-stack', 18, 0.8, 1.3, 0.15);
    this.addRandom(group, 'starter-quarry', 'ore-cart', 8, 0.7, 1.05, 0.08);
    this.addFixed(group, 'starter-quarry', 'stone-arch', [
      { x: -420, z: 120, scale: 3.2, rotation: 0.2 },
      { x: 820, z: 640, scale: 2.5, rotation: 0.5 },
      { x: -970, z: -620, scale: 2.1, rotation: 1.1 },
    ]);
    this.addFixed(group, 'starter-quarry', 'cave-arch', [
      { x: 260, z: 890, scale: 2.2, rotation: 1.7 },
      { x: 950, z: -740, scale: 2.1, rotation: -0.7 },
    ]);
    this.addRiverWater(group, 'starter-quarry');
  }

  private buildMoltenCaves(): void {
    const group = this.zoneGroup('molten-caves');
    this.addRandom(group, 'molten-caves', 'rock-outcrop', 125, 0.95, 2.6, 0.1);
    this.addRandom(group, 'molten-caves', 'volcanic-vent', 52, 0.75, 1.4, 0.08);
    this.addRandom(group, 'molten-caves', 'tree-pine', 26, 0.55, 0.95, 0.1);
    this.addRandom(group, 'molten-caves', 'magma-corn', 48, 0.65, 1.0, 0.06);
    this.addFixed(group, 'molten-caves', 'cave-arch', [
      { x: 620, z: 550, scale: 2.5, rotation: -0.3 },
      { x: 960, z: -790, scale: 2.2, rotation: 0.8 },
      { x: -300, z: 980, scale: 2.8, rotation: 0 },
    ]);
    this.addFixed(group, 'molten-caves', 'stone-arch', [
      { x: -900, z: 200, scale: 2.8, rotation: 0.6 },
    ]);
  }

  private buildCrystalPeaks(): void {
    const group = this.zoneGroup('crystal-peaks');
    this.addRandom(group, 'crystal-peaks', 'rock-outcrop', 95, 0.8, 2.1, 0.08);
    this.addRandom(group, 'crystal-peaks', 'crystal-spire', 115, 0.75, 1.85, 0.08);
    this.addRandom(group, 'crystal-peaks', 'tree-pine', 38, 0.5, 0.92, 0.08);
    this.addFixed(group, 'crystal-peaks', 'cave-arch', [
      { x: -1000, z: -820, scale: 2.2, rotation: 1.2 },
    ]);
    this.addFixed(group, 'crystal-peaks', 'chessboard', [
      { x: 330, z: -210, scale: 1.5, rotation: 0.2, yOffset: 0.12 },
    ]);
    this.addRiverWater(group, 'crystal-peaks');
  }

  private zoneGroup(zoneId: ZoneId): THREE.Group {
    const group = new THREE.Group();
    group.name = `python-glb-population-${zoneId}`;
    this.scene.add(group);
    this.zoneGroups.push({ zoneId, group });
    return group;
  }

  private addRandom(
    group: THREE.Group,
    zoneId: ZoneId,
    assetId: AssetId,
    count: number,
    minScale: number,
    maxScale: number,
    spawnExclusionRadius: number,
  ): void {
    const random = this.randomFor(`${zoneId}:${assetId}`);
    const half = ZONE_SIDE_METRES / 2 - 20;
    const placements: Placement[] = [];
    let attempts = 0;
    while (placements.length < count && attempts < count * 8) {
      attempts += 1;
      const x = (random() * 2 - 1) * half;
      const z = (random() * 2 - 1) * half;
      if (Math.hypot(x, z) < 105 + spawnExclusionRadius * 100) continue;
      const scale = minScale + random() * (maxScale - minScale);
      placements.push({ x, z, scale, rotation: random() * Math.PI * 2 });
    }
    this.addInstances(group, zoneId, assetId, placements);
  }

  private addFixed(group: THREE.Group, zoneId: ZoneId, assetId: AssetId, placements: readonly Placement[]): void {
    this.addInstances(group, zoneId, assetId, placements);
  }

  private addRiverWater(group: THREE.Group, zoneId: ZoneId): void {
    const placements: Placement[] = [];
    for (let i = -4; i <= 4; i += 1) {
      const z = i * 245;
      const centerX = zoneId === 'starter-quarry' ? 250 * Math.sin(z / 340) : zoneId === 'crystal-peaks' ? i * 46 : 0;
      placements.push({ x: centerX, z, scale: 165, rotation: 0, yOffset: 1.8 });
    }
    this.addInstances(group, zoneId, 'water-plane', placements.map((item) => ({ ...item, scale: item.scale })));
  }

  private addInstances(group: THREE.Group, zoneId: ZoneId, assetId: AssetId, placements: readonly Placement[]): void {
    if (placements.length === 0) return;
    const source = this.assets.getSource(assetId);
    if (!source) throw new Error(`Required Python GLB asset is missing: ${assetId}`);
    source.updateMatrixWorld(true);
    const sourceMeshes: THREE.Mesh[] = [];
    source.traverse((object) => {
      if (object instanceof THREE.Mesh) sourceMeshes.push(object);
    });
    if (sourceMeshes.length === 0) throw new Error(`Python GLB asset contains no mesh: ${assetId}`);

    const originX = OPEN_WORLD_ZONES[zoneId].originX;
    const cells = partitionPlacementsByCell(placements, originX);
    const dummy = new THREE.Object3D();
    for (const [cellKey, cellPlacements] of cells) {
      for (const sourceMesh of sourceMeshes) {
        const instanced = new THREE.InstancedMesh(
          sourceMesh.geometry,
          sourceMesh.material,
          cellPlacements.length,
        );
        instanced.name = `instances-${assetId}-${zoneId}-${cellKey}`;
        instanced.castShadow = true;
        instanced.receiveShadow = true;
        instanced.frustumCulled = true;
        instanced.userData['cameraOccluder'] = this.cameraOccluderAssets.has(assetId);
        for (let i = 0; i < cellPlacements.length; i += 1) {
          const placement = cellPlacements[i]!;
          dummy.position.set(
            originX + placement.x,
            getZoneTerrainHeight(zoneId, placement.x, placement.z) + (placement.yOffset ?? 0),
            placement.z,
          );
          dummy.rotation.set(0, placement.rotation, 0);
          dummy.scale.setScalar(placement.scale);
          dummy.updateMatrix();
          const matrix = dummy.matrix.clone().multiply(sourceMesh.matrixWorld);
          instanced.setMatrixAt(i, matrix);
        }
        instanced.instanceMatrix.needsUpdate = true;
        instanced.computeBoundingSphere();
        group.add(instanced);
      }
    }
  }

  private randomFor(seedText: string): () => number {
    let seed = 2166136261;
    for (let i = 0; i < seedText.length; i += 1) {
      seed ^= seedText.charCodeAt(i);
      seed = Math.imul(seed, 16777619);
    }
    return () => {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      return seed / 0x1_0000_0000;
    };
  }
}
