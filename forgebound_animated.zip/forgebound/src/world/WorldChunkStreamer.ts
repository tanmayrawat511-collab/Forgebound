import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import type { PhysicsWorld, StaticBoxTransform } from '../physics/PhysicsWorld';
import type { ZoneId } from '../types/zones';
import { runBounded } from './asyncBatch';
import {
  OPEN_WORLD_ZONES,
  TERRAIN_STREAM_RADIUS_CHUNKS,
  getTerrainChunkCoordinate,
  getTerrainChunkWindow,
} from './open-world-config';

const TERRAIN_LOAD_CONCURRENCY = 6;

function clampStreamingRadius(radius: number): number {
  if (!Number.isFinite(radius)) return TERRAIN_STREAM_RADIUS_CHUNKS;
  return Math.min(10, Math.max(0, Math.floor(radius)));
}

interface TerrainManifestEntry {
  readonly zoneId: ZoneId;
  readonly x: number;
  readonly z: number;
  readonly originX: number;
  readonly originZ: number;
  readonly file: string;
}

interface TerrainManifest {
  readonly playableAreaSquareMeters: number;
  readonly chunks: readonly TerrainManifestEntry[];
}

function disposeChunkRoot(root: THREE.Object3D): void {
  root.traverse((object) => {
    if (!(object instanceof THREE.Mesh)) return;
    object.geometry.dispose();
    const materials = Array.isArray(object.material) ? object.material : [object.material];
    for (const material of materials) {
      for (const value of Object.values(material)) {
        const candidate = value as { isTexture?: unknown; dispose?: () => void };
        if (candidate?.isTexture === true) candidate.dispose?.();
      }
      material.dispose();
    }
  });
}

interface LoadedChunk {
  readonly root: THREE.Group;
  readonly bodies: readonly import('@dimforge/rapier3d-compat').RigidBody[];
}

/** Streams Python-generated terrain GLBs and matching static Rapier trimesh colliders. */
export class WorldChunkStreamer {
  private readonly loader = new GLTFLoader();
  private readonly entries = new Map<string, TerrainManifestEntry>();
  private readonly loaded = new Map<string, LoadedChunk>();
  private readonly pending = new Map<string, Promise<void>>();
  private readonly boundaryBodies = new Map<ZoneId, import('@dimforge/rapier3d-compat').RigidBody[]>();
  private currentCenterKey = '';
  private currentZoneId: ZoneId | null = null;
  private disposed = false;
  private suspended = false;
  private streamEpoch = 0;
  private manifestReady = false;
  private streamingRadiusChunks = TERRAIN_STREAM_RADIUS_CHUNKS;

  constructor(private readonly scene: THREE.Scene, private readonly physics: PhysicsWorld) {}

  async initialize(): Promise<void> {
    const response = await fetch('/assets/terrain/manifest.json');
    if (!response.ok) throw new Error(`Terrain manifest could not be loaded (${response.status}).`);
    const manifest = await response.json() as TerrainManifest;
    if (manifest.playableAreaSquareMeters !== 7_000_000 || !Array.isArray(manifest.chunks)) {
      throw new Error('Terrain manifest does not match the approved 7 km² zone specification.');
    }
    for (const entry of manifest.chunks) {
      const zoneId = entry.zoneId as ZoneId;
      if (!(zoneId in OPEN_WORLD_ZONES) || !Number.isInteger(entry.x) || !Number.isInteger(entry.z)) continue;
      this.entries.set(this.key(entry.zoneId, entry.x, entry.z), entry);
    }
    this.manifestReady = true;
  }

  async loadAround(zoneId: ZoneId, position: Readonly<{ x: number; z: number }>, radius = this.streamingRadiusChunks): Promise<void> {
    if (!this.manifestReady) throw new Error('Terrain streamer must be initialized before loading chunks.');
    this.suspended = false;
    const safeRadius = clampStreamingRadius(radius);
    const epoch = ++this.streamEpoch;
    const center = getTerrainChunkCoordinate(zoneId, position.x, position.z);
    if (!center) throw new Error(`Player position is outside the playable ${zoneId} terrain boundary.`);
    const centerKey = `${zoneId}:${center.x}:${center.z}`;
    this.currentZoneId = zoneId;
    this.currentCenterKey = centerKey;
    this.ensureZoneBounds(zoneId);

    const window = getTerrainChunkWindow(zoneId, center.x, center.z, safeRadius);
    try {
      await this.loadChunksBounded(zoneId, window.filter((tile) => !this.loaded.has(this.key(zoneId, tile.x, tile.z))), epoch);
      if (this.suspended || epoch !== this.streamEpoch) return;
      const missing = window.filter((tile) => !this.loaded.has(this.key(zoneId, tile.x, tile.z)));
      if (missing.length > 0) await this.loadChunksBounded(zoneId, missing, epoch);
    } catch (error) {
      // An old stream request must not invalidate a newer request for the same center tile.
      if (this.streamEpoch === epoch && this.currentCenterKey === centerKey) {
        this.currentCenterKey = '';
        this.streamEpoch += 1;
      }
      throw error;
    }
    if (this.suspended || epoch !== this.streamEpoch) return;
    this.unloadOutside(zoneId, center.x, center.z, safeRadius);
  }

  update(zoneId: ZoneId, position: Readonly<{ x: number; z: number }>): void {
    if (this.disposed || this.suspended || !this.manifestReady) return;
    const coordinate = getTerrainChunkCoordinate(zoneId, position.x, position.z);
    if (!coordinate) return;
    const key = `${zoneId}:${coordinate.x}:${coordinate.z}`;
    if (key === this.currentCenterKey && zoneId === this.currentZoneId) return;
    void this.loadAround(zoneId, position).catch((error: unknown) => {
      console.error('ForgeBound terrain streaming failed:', error);
    });
  }

  getLoadedChunkCount(): number {
    return this.loaded.size;
  }

  /** Changes real terrain load/collision radius; the next update streams the new budget. */
  setStreamingRadiusChunks(radius: number): void {
    const next = clampStreamingRadius(radius);
    if (next === this.streamingRadiusChunks) return;
    this.streamingRadiusChunks = next;
    this.streamEpoch += 1;
    this.currentCenterKey = '';
  }

  getStreamingRadiusChunks(): number {
    return this.streamingRadiusChunks;
  }

  /** Append roots for the active overworld zone to a caller-owned scratch array. */
  appendLoadedRoots(zoneId: ZoneId, output: THREE.Object3D[]): void {
    for (const [key, chunk] of this.loaded) {
      if (key.startsWith(`${zoneId}:`) && chunk.root.visible) output.push(chunk.root);
    }
  }

  /** Unloads overworld meshes and colliders while the player is in a detached interior. */
  suspend(): void {
    if (this.disposed || this.suspended) return;
    this.suspended = true;
    this.streamEpoch += 1;
    this.currentCenterKey = '';
    this.currentZoneId = null;
    for (const [key, chunk] of this.loaded) {
      this.scene.remove(chunk.root);
      for (const body of chunk.bodies) this.physics.removeRigidBody(body);
      disposeChunkRoot(chunk.root);
      this.loaded.delete(key);
    }
    for (const bodies of this.boundaryBodies.values()) {
      for (const body of bodies) this.physics.removeRigidBody(body);
    }
    this.boundaryBodies.clear();
  }

  dispose(): void {
    this.disposed = true;
    for (const [key, chunk] of this.loaded) {
      this.scene.remove(chunk.root);
      for (const body of chunk.bodies) this.physics.removeRigidBody(body);
      disposeChunkRoot(chunk.root);
      this.loaded.delete(key);
    }
    for (const bodies of this.boundaryBodies.values()) {
      for (const body of bodies) this.physics.removeRigidBody(body);
    }
    this.boundaryBodies.clear();
    this.entries.clear();
    this.pending.clear();
  }

  /** Keep far-distance startup from issuing 121 GLB requests and collider builds at once. */
  private async loadChunksBounded(
    zoneId: ZoneId,
    chunks: readonly Readonly<{ x: number; z: number }>[],
    epoch: number,
  ): Promise<void> {
    await runBounded(chunks, TERRAIN_LOAD_CONCURRENCY, async (chunk) => {
      if (this.disposed || this.suspended || epoch !== this.streamEpoch) return;
      await this.loadChunk(zoneId, chunk.x, chunk.z, epoch);
    });
  }

  private async loadChunk(zoneId: ZoneId, x: number, z: number, epoch: number): Promise<void> {
    const key = this.key(zoneId, x, z);
    const existing = this.pending.get(key);
    if (existing) return existing;
    const entry = this.entries.get(key);
    if (!entry) throw new Error(`Terrain chunk ${key} is missing from the verified manifest.`);

    const task = (async () => {
      const gltf = await this.loader.loadAsync(entry.file);
      if (this.disposed || this.suspended || epoch !== this.streamEpoch || this.loaded.has(key)) {
        disposeChunkRoot(gltf.scene);
        return;
      }
      const root = gltf.scene;
      root.name = `terrain-${key}`;
      root.updateMatrixWorld(true);
      const zone = OPEN_WORLD_ZONES[zoneId];
      const worldOrigin: StaticBoxTransform = {
        x: zone.originX + entry.originX,
        y: 0,
        z: zone.originZ + entry.originZ,
      };
      const bodies: import('@dimforge/rapier3d-compat').RigidBody[] = [];
      root.traverse((object) => {
        if (!(object instanceof THREE.Mesh)) return;
        object.receiveShadow = true;
        object.frustumCulled = true;
        const position = object.geometry.getAttribute('position');
        const index = object.geometry.getIndex();
        if (!position || !index || position.count < 3 || index.count < 3) return;
        const geometry = object.geometry.clone();
        geometry.applyMatrix4(object.matrixWorld);
        const vertices = Float32Array.from(geometry.getAttribute('position').array as ArrayLike<number>);
        const indices = Uint32Array.from(geometry.getIndex()!.array as ArrayLike<number>);
        if (vertices.length >= 9 && indices.length >= 3) {
          bodies.push(this.physics.addStaticTrimesh(vertices, indices, worldOrigin));
        }
        geometry.dispose();
      });
      root.position.set(worldOrigin.x, 0, worldOrigin.z);
      this.scene.add(root);
      this.loaded.set(key, { root, bodies });
    })().finally(() => this.pending.delete(key));
    this.pending.set(key, task);
    return task;
  }

  private ensureZoneBounds(zoneId: ZoneId): void {
    if (this.boundaryBodies.has(zoneId)) return;
    const zone = OPEN_WORLD_ZONES[zoneId];
    const half = zone.sideLengthMetres / 2;
    const originX = zone.originX;
    const originZ = zone.originZ;
    const thickness = 12;
    const topY = 0;
    const bodies = [
      this.physics.createFixedBox({ x: originX, y: topY, z: originZ - half }, { x: half, y: 200, z: thickness }),
      this.physics.createFixedBox({ x: originX, y: topY, z: originZ + half }, { x: half, y: 200, z: thickness }),
      this.physics.createFixedBox({ x: originX - half, y: topY, z: originZ }, { x: thickness, y: 200, z: half }),
      this.physics.createFixedBox({ x: originX + half, y: topY, z: originZ }, { x: thickness, y: 200, z: half }),
    ];
    this.boundaryBodies.set(zoneId, bodies);
  }

  private unloadOutside(zoneId: ZoneId, centerX: number, centerZ: number, radius: number): void {
    for (const [key, chunk] of this.loaded) {
      const [loadedZone, x, z] = key.split(':');
      if (loadedZone === zoneId && Math.abs(Number(x) - centerX) <= radius && Math.abs(Number(z) - centerZ) <= radius) continue;
      this.scene.remove(chunk.root);
      for (const body of chunk.bodies) this.physics.removeRigidBody(body);
      disposeChunkRoot(chunk.root);
      this.loaded.delete(key);
    }
  }

  private key(zoneId: ZoneId, x: number, z: number): string {
    return `${zoneId}:${x}:${z}`;
  }
}
