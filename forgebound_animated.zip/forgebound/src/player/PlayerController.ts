import * as THREE from 'three';
import { AnimationController } from '../assets/AnimationController';
import type { PlayerPhysicsBody } from '../physics/PhysicsWorld';
import type { InputSnapshot } from '../input/InputManager';

const WALK_SPEED = 5.1;
const GROUND_ACCELERATION = 24;
const AIR_ACCELERATION = 8;
const GRAVITY = 22;
const JUMP_SPEED = 8.2;

function approach(current: number, target: number, maximumDelta: number): number {
  if (current < target) return Math.min(current + maximumDelta, target);
  return Math.max(current - maximumDelta, target);
}

export class PlayerController {
  readonly visualRoot = new THREE.Group();
  readonly bodyMesh: THREE.Group;
  private readonly weaponMount = new THREE.Group();
  private readonly armorMount = new THREE.Group();
  private readonly anim: AnimationController | null = null;

  private horizontalVelocityX = 0;
  private horizontalVelocityZ = 0;
  private verticalVelocity = 0;
  private grounded = false;
  private animationsEnabled = true;
  private attackAnimationRemaining = 0;
  private interactionAnimationRemaining = 0;
  private gearEquipAnimationRemaining = 0;
  private visualClock = 0;
  private readonly desiredMovement = { x: 0, y: 0, z: 0 };
  private readonly nextTranslation = { x: 0, y: 0, z: 0 };

  constructor(
    private readonly physics: PlayerPhysicsBody,
    model: THREE.Object3D | null = null,
    clips: readonly THREE.AnimationClip[] = [],
  ) {
    this.bodyMesh = model ? this.createModelBody(model) : this.createVisual();
    this.weaponMount.name = 'player-equipped-weapon-mount';
    this.weaponMount.position.set(0.48, 0.12, 0.16);
    this.armorMount.name = 'player-equipped-armor-mount';
    this.bodyMesh.add(this.armorMount);
    this.bodyMesh.add(this.weaponMount);
    this.visualRoot.add(this.bodyMesh);
    if (model && clips.length > 0) {
      this.anim = new AnimationController(model, clips);
      this.anim.playLoop('idle', 0);
    }
    this.syncFromPhysics();
  }

  fixedUpdate(input: InputSnapshot, deltaSeconds: number, cameraYaw: number): void {
    this.updateCosmeticAnimation(deltaSeconds);
    if (input.jumpPressed && this.grounded) {
      this.verticalVelocity = JUMP_SPEED;
      this.grounded = false;
      this.anim?.playOneShot('jump', { fadeSeconds: 0.08 });
    }

    const horizontalAcceleration = this.grounded ? GROUND_ACCELERATION : AIR_ACCELERATION;
    const cameraRelativeX = input.moveX * Math.cos(cameraYaw) + input.moveZ * Math.sin(cameraYaw);
    const cameraRelativeZ = -input.moveX * Math.sin(cameraYaw) + input.moveZ * Math.cos(cameraYaw);
    this.horizontalVelocityX = approach(
      this.horizontalVelocityX,
      cameraRelativeX * WALK_SPEED,
      horizontalAcceleration * deltaSeconds,
    );
    this.horizontalVelocityZ = approach(
      this.horizontalVelocityZ,
      cameraRelativeZ * WALK_SPEED,
      horizontalAcceleration * deltaSeconds,
    );

    this.verticalVelocity = Math.max(this.verticalVelocity - GRAVITY * deltaSeconds, -24);

    this.desiredMovement.x = this.horizontalVelocityX * deltaSeconds;
    this.desiredMovement.y = this.verticalVelocity * deltaSeconds;
    this.desiredMovement.z = this.horizontalVelocityZ * deltaSeconds;

    this.physics.controller.computeColliderMovement(
      this.physics.collider,
      this.desiredMovement,
    );

    const resolvedMovement = this.physics.controller.computedMovement();
    const current = this.physics.body.translation();
    this.nextTranslation.x = current.x + resolvedMovement.x;
    this.nextTranslation.y = current.y + resolvedMovement.y;
    this.nextTranslation.z = current.z + resolvedMovement.z;

    this.physics.body.setNextKinematicTranslation(this.nextTranslation);
    this.grounded = this.physics.controller.computedGrounded();
    if (this.grounded && this.verticalVelocity < 0) {
      this.verticalVelocity = 0;
    }

    if (Math.abs(this.horizontalVelocityX) + Math.abs(this.horizontalVelocityZ) > 0.1) {
      this.bodyMesh.rotation.y = Math.atan2(this.horizontalVelocityX, this.horizontalVelocityZ);
    }
  }

  setAnimationsEnabled(enabled: boolean): void {
    this.animationsEnabled = enabled;
    this.anim?.setEnabled(enabled);
    if (!enabled) {
      this.attackAnimationRemaining = 0;
      this.interactionAnimationRemaining = 0;
      this.gearEquipAnimationRemaining = 0;
      this.weaponMount.rotation.set(0, 0, 0);
      this.armorMount.scale.setScalar(1);
      this.bodyMesh.rotation.x = 0;
      this.bodyMesh.rotation.z = 0;
      this.bodyMesh.position.y = 0;
    }
  }

  playAttackAnimation(): void {
    if (!this.animationsEnabled) return;
    this.attackAnimationRemaining = 0.24;
    this.anim?.playOneShot('attack', { fadeSeconds: 0.08 });
  }

  playInteractionAnimation(clipName = 'greet'): void {
    if (!this.animationsEnabled) return;
    this.interactionAnimationRemaining = 0.58;
    this.gearEquipAnimationRemaining = 0.58;
    this.anim?.playOneShot(clipName, { fadeSeconds: 0.1 });
  }

  setArmorModels(models: readonly { readonly slot: 'helmet' | 'chestplate' | 'leggings'; readonly model: THREE.Object3D }[]): void {
    for (const child of [...this.armorMount.children]) this.armorMount.remove(child);
    if (this.anim) {
      this.anim.clearSocket('Socket_Helmet');
      this.anim.clearSocket('Socket_Chest');
      this.anim.clearSocket('Socket_Legs');
    }
    for (const entry of models) {
      const model = entry.model;
      model.traverse((object) => { if (object instanceof THREE.Mesh) { object.castShadow = true; object.receiveShadow = true; } });
      const socketName = entry.slot === 'helmet' ? 'Socket_Helmet' : entry.slot === 'chestplate' ? 'Socket_Chest' : 'Socket_Legs';
      if (this.anim && this.anim.attachToSocket(socketName, model)) {
        model.position.set(0, 0, 0);
        model.scale.setScalar(1);
        continue;
      }
      if (entry.slot === 'helmet') { model.scale.setScalar(0.58); model.position.set(0, 1.35, 0.02); }
      else if (entry.slot === 'chestplate') { model.scale.setScalar(0.72); model.position.set(0, 0.86, 0.02); }
      else { model.scale.setScalar(0.48); model.position.set(0, 0.08, 0.01); }
      this.armorMount.add(model);
    }
  }

  setWeaponModel(model: THREE.Object3D | null): void {
    for (const child of [...this.weaponMount.children]) this.weaponMount.remove(child);
    this.anim?.clearSocket('Socket_Weapon_R');
    if (!model) return;
    model.name = 'equipped-weapon-glb';
    if (this.anim && this.anim.attachToSocket('Socket_Weapon_R', model)) {
      model.scale.setScalar(0.85);
      model.rotation.set(Math.PI * 0.45, 0, 0);
      model.position.set(0, 0, 0);
      return;
    }
    model.scale.setScalar(0.62);
    model.rotation.set(0.08, 0, -0.24);
    model.position.set(0, 0.08, 0);
    this.weaponMount.add(model);
  }

  private updateCosmeticAnimation(deltaSeconds: number): void {
    if (!this.animationsEnabled) return;
    if (this.anim) {
      const speed = Math.hypot(this.horizontalVelocityX, this.horizontalVelocityZ);
      const loopClip = speed > 3.8 ? 'run' : speed > 0.35 ? 'walk' : 'idle';
      this.anim.playLoop(loopClip, 0.16);
      this.anim.update(deltaSeconds);
      return;
    }
    this.visualClock += deltaSeconds;
    const moving = Math.abs(this.horizontalVelocityX) + Math.abs(this.horizontalVelocityZ) > 0.35;
    this.bodyMesh.position.y = moving ? Math.sin(this.visualClock * 11) * 0.035 : 0;
    if (this.attackAnimationRemaining > 0) {
      this.attackAnimationRemaining = Math.max(0, this.attackAnimationRemaining - deltaSeconds);
      const progress = 1 - this.attackAnimationRemaining / 0.24;
      this.bodyMesh.rotation.z = Math.sin(progress * Math.PI) * -0.2;
      this.weaponMount.rotation.x = -Math.sin(progress * Math.PI) * 0.85;
      this.weaponMount.rotation.z = Math.sin(progress * Math.PI) * -0.28;
    } else {
      this.bodyMesh.rotation.z = 0;
      this.weaponMount.rotation.set(0, 0, 0);
    }
    if (this.interactionAnimationRemaining > 0) {
      this.interactionAnimationRemaining = Math.max(0, this.interactionAnimationRemaining - deltaSeconds);
      const progress = 1 - this.interactionAnimationRemaining / 0.58;
      this.bodyMesh.rotation.x = Math.sin(progress * Math.PI) * -0.16;
    } else this.bodyMesh.rotation.x = 0;
    if (this.gearEquipAnimationRemaining > 0) {
      this.gearEquipAnimationRemaining = Math.max(0, this.gearEquipAnimationRemaining - deltaSeconds);
      const progress = 1 - this.gearEquipAnimationRemaining / 0.58;
      this.armorMount.scale.setScalar(1 + Math.sin(progress * Math.PI) * 0.07);
    } else this.armorMount.scale.setScalar(1);
  }

  private createModelBody(model: THREE.Object3D): THREE.Group {
    const pivot = new THREE.Group();
    model.name = 'player-local-glb';
    model.position.y = -0.88;
    pivot.add(model);
    return pivot;
  }

  respawnAt(position: Readonly<{ x: number; y: number; z: number }>): void {
    this.horizontalVelocityX = 0;
    this.horizontalVelocityZ = 0;
    this.verticalVelocity = 0;
    this.grounded = false;
    this.physics.body.setTranslation(position, true);
    this.physics.body.setNextKinematicTranslation(position);
    this.syncFromPhysics();
  }

  syncFromPhysics(): void {
    const position = this.physics.body.translation();
    this.visualRoot.position.set(position.x, position.y, position.z);
  }

  getPositionText(): string {
    const p = this.physics.body.translation();
    return `${p.x.toFixed(1)}, ${p.y.toFixed(1)}, ${p.z.toFixed(1)}`;
  }

  getIsGrounded(): boolean {
    return this.grounded;
  }

  private createVisual(): THREE.Group {
    const group = new THREE.Group();
    const armor = new THREE.MeshStandardMaterial({ color: 0x66847a, roughness: 0.78, metalness: 0.12 });
    const darkArmor = new THREE.MeshStandardMaterial({ color: 0x263c3d, roughness: 0.85 });
    const brass = new THREE.MeshStandardMaterial({ color: 0xc18a45, roughness: 0.48, metalness: 0.6 });
    const visor = new THREE.MeshStandardMaterial({ color: 0x91b5aa, roughness: 0.22, metalness: 0.32 });

    const capsule = new THREE.Mesh(new THREE.CapsuleGeometry(0.34, 1.1, 5, 10), armor);
    capsule.position.y = 0;
    capsule.castShadow = true;
    capsule.receiveShadow = true;
    group.add(capsule);

    const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 8), darkArmor);
    helmet.scale.set(1.05, 0.82, 1.02);
    helmet.position.set(0, 0.62, 0.01);
    helmet.castShadow = true;
    group.add(helmet);

    const facePlate = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.1, 0.055), visor);
    facePlate.position.set(0, 0.61, 0.255);
    group.add(facePlate);

    const belt = new THREE.Mesh(new THREE.TorusGeometry(0.25, 0.045, 6, 12), brass);
    belt.rotation.x = Math.PI / 2;
    belt.position.y = -0.27;
    group.add(belt);

    const leftShoulder = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.24, 0.27), darkArmor);
    leftShoulder.position.set(-0.34, 0.31, 0);
    leftShoulder.rotation.z = -0.22;
    leftShoulder.castShadow = true;
    group.add(leftShoulder);

    const rightShoulder = leftShoulder.clone();
    rightShoulder.position.x = 0.34;
    rightShoulder.rotation.z = 0.22;
    group.add(rightShoulder);

    return group;
  }
}
