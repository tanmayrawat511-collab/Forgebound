/**
 * Haptic and adaptive-trigger feedback. Gameplay code emits named events. This module turns them
 * into rumble envelopes and trigger profiles, merges active effects, and sends only real changes
 * to the output. It never touches a device itself: the router supplies the output.
 */
import type { HidOutputState, TriggerEffect } from '../input/gamepad/dualsenseHid';
import type { InputSettings } from '../input/settings';
import { sameTriggerEffect, triggerProfileFor, NO_TRIGGER_CONTEXT, type TriggerContext, type TriggerProfile } from './triggerProfiles';

export type FeedbackEventId =
  | 'mine-hit'
  | 'mine-depleted'
  | 'impact'
  | 'explosion'
  | 'player-hit'
  | 'player-defeated'
  | 'pacify'
  | 'zone-travel';

type EnvelopeShape = 'decay' | 'hold';

interface RumblePattern {
  /** Low-frequency motor peak, 0 to 1. */
  readonly strong: number;
  /** High-frequency motor peak, 0 to 1. */
  readonly weak: number;
  readonly durationMs: number;
  readonly shape: EnvelopeShape;
}

/** Peak values were tuned by feel, not measured. Adjust them with the checklist in the guide. */
export const RUMBLE_PATTERNS: Readonly<Record<FeedbackEventId, RumblePattern>> = {
  'mine-hit': { strong: 0.18, weak: 0.42, durationMs: 90, shape: 'decay' },
  'mine-depleted': { strong: 0.65, weak: 0.45, durationMs: 260, shape: 'decay' },
  impact: { strong: 0.5, weak: 0.25, durationMs: 70, shape: 'decay' },
  explosion: { strong: 1, weak: 0.9, durationMs: 650, shape: 'decay' },
  'player-hit': { strong: 0.85, weak: 0.55, durationMs: 200, shape: 'decay' },
  'player-defeated': { strong: 1, weak: 0.6, durationMs: 900, shape: 'decay' },
  pacify: { strong: 0, weak: 0.22, durationMs: 320, shape: 'hold' },
  'zone-travel': { strong: 0.25, weak: 0.1, durationMs: 300, shape: 'decay' },
};

/** Motor levels are quantised to 1/64 steps, so tiny envelope changes do not flood the device. */
const MOTOR_QUANTUM = 1 / 64;
/** While rumble is active, the output is refreshed at this interval. Covers timed effects. */
export const RUMBLE_REFRESH_MS = 80;

/** What is sent to the device: motor levels and both trigger effects. */
export interface HapticFrame {
  readonly strongMotor: number;
  readonly weakMotor: number;
  readonly left: TriggerEffect;
  readonly right: TriggerEffect;
}

export interface HapticOutput {
  apply(frame: HapticFrame): void;
}

export const SILENT_FRAME: HapticFrame = {
  strongMotor: 0,
  weakMotor: 0,
  left: { kind: 'off' },
  right: { kind: 'off' },
};

interface Envelope {
  readonly pattern: RumblePattern;
  readonly intensity: number;
  elapsedMs: number;
}

/** Strength of an envelope at a given age. Decay falls off quadratically; hold stays flat. */
export function envelopeLevel(pattern: RumblePattern, intensity: number, elapsedMs: number): { strong: number; weak: number } {
  if (elapsedMs >= pattern.durationMs) return { strong: 0, weak: 0 };
  const t = elapsedMs / pattern.durationMs;
  const shape = pattern.shape === 'decay' ? (1 - t) * (1 - t) : 1;
  return {
    strong: pattern.strong * intensity * shape,
    weak: pattern.weak * intensity * shape,
  };
}

function quantise(value: number): number {
  return Math.round(Math.min(1, Math.max(0, value)) / MOTOR_QUANTUM) * MOTOR_QUANTUM;
}

function sameFrame(a: HapticFrame, b: HapticFrame): boolean {
  return a.strongMotor === b.strongMotor
    && a.weakMotor === b.weakMotor
    && sameTriggerEffect(a.left, b.left)
    && sameTriggerEffect(a.right, b.right);
}

export interface FeedbackSystemOptions {
  /** Returns the current output, or null when no controller can receive feedback. */
  readonly output: () => HapticOutput | null;
  readonly settings: () => InputSettings;
}

export class FeedbackSystem {
  private readonly envelopes: Envelope[] = [];
  private context: TriggerContext = NO_TRIGGER_CONTEXT;
  private lastFrame: HapticFrame = SILENT_FRAME;
  private sinceSendMs = 0;

  constructor(private readonly options: FeedbackSystemOptions) {}

  /** Starts a rumble for a named event. Ignored while haptics are switched off. */
  emit(event: FeedbackEventId): void {
    const settings = this.options.settings();
    if (!settings.hapticsEnabled) return;
    this.envelopes.push({
      pattern: RUMBLE_PATTERNS[event],
      intensity: settings.hapticIntensity,
      elapsedMs: 0,
    });
  }

  /** Sets what the player is aiming at. Triggers follow this each frame. */
  setTriggerContext(context: TriggerContext): void {
    this.context = context;
  }

  /** Advances envelopes and sends the frame if it changed, or if timed rumble needs a refresh. */
  update(deltaSeconds: number): void {
    const deltaMs = Math.max(0, deltaSeconds) * 1000;
    this.sinceSendMs += deltaMs;
    for (const envelope of this.envelopes) envelope.elapsedMs += deltaMs;
    for (let index = this.envelopes.length - 1; index >= 0; index -= 1) {
      const envelope = this.envelopes[index];
      if (envelope && envelope.elapsedMs >= envelope.pattern.durationMs) this.envelopes.splice(index, 1);
    }

    const frame = this.computeFrame();
    const refreshDue = this.envelopes.length > 0 && this.sinceSendMs >= RUMBLE_REFRESH_MS;
    if (sameFrame(frame, this.lastFrame) && !refreshDue) return;

    this.lastFrame = frame;
    this.sinceSendMs = 0;
    this.options.output()?.apply(frame);
  }

  /** The frame that would be sent now. Exposed for tests and diagnostics. */
  currentFrame(): HapticFrame {
    return this.computeFrame();
  }

  /** Stops everything and sends one silent frame. Call on shutdown and on device disconnect. */
  reset(): void {
    this.envelopes.length = 0;
    this.context = NO_TRIGGER_CONTEXT;
    if (sameFrame(SILENT_FRAME, this.lastFrame)) return;
    this.lastFrame = SILENT_FRAME;
    this.sinceSendMs = 0;
    this.options.output()?.apply(SILENT_FRAME);
  }

  private computeFrame(): HapticFrame {
    const settings = this.options.settings();
    let strong = 0;
    let weak = 0;
    if (settings.hapticsEnabled) {
      for (const envelope of this.envelopes) {
        const level = envelopeLevel(envelope.pattern, envelope.intensity, envelope.elapsedMs);
        strong = Math.max(strong, level.strong);
        weak = Math.max(weak, level.weak);
      }
    }
    // The haptics switch is the master switch: when it is off, triggers go free as well.
    const triggersOn = settings.hapticsEnabled && settings.triggerEffectsEnabled;
    const profile: TriggerProfile = triggersOn
      ? triggerProfileFor(this.context)
      : { left: { kind: 'off' }, right: { kind: 'off' } };
    return {
      strongMotor: quantise(strong),
      weakMotor: quantise(weak),
      left: scaleEffect(profile.left, settings.hapticIntensity),
      right: scaleEffect(profile.right, settings.hapticIntensity),
    };
  }
}

/** Scales trigger strength by the intensity setting. Off and zero-strength effects are kept as they are. */
function scaleEffect(effect: TriggerEffect, intensity: number): TriggerEffect {
  if (effect.kind === 'off') return effect;
  return { kind: effect.kind, start: effect.start, strength: effect.strength * intensity };
}

/** Converts a frame into the HID output state the transport encodes. */
export function hidStateFor(frame: HapticFrame): HidOutputState {
  return {
    motorLeft: frame.strongMotor,
    motorRight: frame.weakMotor,
    left: frame.left,
    right: frame.right,
  };
}
