/**
 * Maps the player's current context to adaptive-trigger effects. The rules are deliberately
 * small: R2 is the "strike" trigger, so it tells the player when a swing will do something.
 */
import { TRIGGER_OFF, type TriggerEffect } from '../input/gamepad/dualsenseHid';

export type TriggerTargetKind = 'none' | 'ore' | 'creature' | 'other';

export interface TriggerContext {
  /** True while a menu is open or the player is recovering from defeat. Triggers go quiet. */
  readonly suppressed: boolean;
  readonly target: TriggerTargetKind;
  readonly inRange: boolean;
  /** True while the pickaxe or resonance cooldown is still running. */
  readonly cooldownActive: boolean;
}

export interface TriggerProfile {
  readonly left: TriggerEffect;
  readonly right: TriggerEffect;
}

export const NO_TRIGGER_CONTEXT: TriggerContext = {
  suppressed: false,
  target: 'none',
  inRange: false,
  cooldownActive: false,
};

export const TRIGGER_PROFILE_OFF: TriggerProfile = { left: TRIGGER_OFF, right: TRIGGER_OFF };

/**
 * Ore in reach: R2 gets firm resistance, like pick against rock. While the cooldown runs it
 * becomes heavier, so the player feels that the swing is not ready. Creatures in reach: a light
 * pulse, the resonance hum. Anything else, including forge and portal targets, is left free.
 */
export function triggerProfileFor(context: TriggerContext): TriggerProfile {
  if (context.suppressed || !context.inRange) return TRIGGER_PROFILE_OFF;
  if (context.target === 'ore') {
    const right: TriggerEffect = context.cooldownActive
      ? { kind: 'resistance', start: 0.1, strength: 0.9 }
      : { kind: 'resistance', start: 0.3, strength: 0.55 };
    return { left: TRIGGER_OFF, right };
  }
  if (context.target === 'creature') {
    return { left: TRIGGER_OFF, right: { kind: 'pulse', start: 0.4, strength: 0.5 } };
  }
  return TRIGGER_PROFILE_OFF;
}

export function sameTriggerEffect(a: TriggerEffect, b: TriggerEffect): boolean {
  if (a.kind === 'off' || b.kind === 'off') return a.kind === b.kind;
  return a.kind === b.kind && a.start === b.start && a.strength === b.strength;
}
