import { GameApp } from './core/GameApp';
import { detectDeviceProfile } from './render/deviceProfile';
import { resolveRenderQuality } from './render/qualityTiers';
import { DEFAULT_GAME_SETTINGS, parseGameSettings, type GameSettings, type KeyboardBindings } from './systems/GameSettings';
import './styles/main.css';

const loadingPanel = getElement('loading-panel');
const errorPanel = getElement('error-panel');
const loadingMessage = getElement('loading-message');
const loadingProgress = getElement('loading-progress');
const errorMessage = getElement('error-message');
const reloadButton = getElement('reload-button') as HTMLButtonElement;
const loadingSteps = Array.from(document.querySelectorAll<HTMLElement>('#loading-steps .step'));
const mainMenu = getElement('main-menu');
const optionsMenu = getElement('options-menu');
const continueButton = getElement('continue-adventure') as HTMLButtonElement;
const menuSaveHint = getElement('menu-save-hint');
const quitNotice = getElement('quit-notice');
const settingsStatus = getElement('settings-save-status');
const touchEditorStatus = getElement('touch-editor-status');

let gameApp: GameApp | null = null;
let settings: GameSettings = DEFAULT_GAME_SETTINGS;
let pendingBinding: keyof KeyboardBindings | null = null;
let pendingBindingButton: HTMLButtonElement | null = null;

function getElement(id: string): HTMLElement {
  const element = document.getElementById(id);
  if (!element) throw new Error(`Required HTML element #${id} is missing.`);
  return element;
}

function updateLoadingStage(stage: number, message: string): void {
  loadingMessage.textContent = message;
  loadingProgress.style.width = `${Math.min(100, Math.max(0, (stage / 3) * 100))}%`;
  loadingSteps.forEach((step, index) => {
    step.classList.toggle('complete', index < stage);
    step.classList.toggle('active', index === stage);
  });
}

const loadingUi = {
  setStage: updateLoadingStage,
  finish(): void {
    updateLoadingStage(3, 'ForgeBound is ready.');
    loadingPanel.classList.add('loading-fade-out');
    window.setTimeout(() => {
      loadingPanel.classList.add('is-hidden');
      mainMenu.hidden = false;
      mainMenu.classList.add('menu-enter');
    }, 520);
  },
};

function humanizeCode(code: string): string {
  if (code === 'Space') return 'Space';
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  return code;
}

function optionsPage(page: string): void {
  for (const element of document.querySelectorAll<HTMLElement>('[data-options-page]')) {
    const selected = element.dataset['optionsPage'] === page;
    element.classList.toggle('selected', selected);
    element.setAttribute('aria-pressed', String(selected));
  }
  for (const element of document.querySelectorAll<HTMLElement>('[data-options-content]')) {
    element.hidden = element.dataset['optionsContent'] !== page;
  }
}

function readPath(source: GameSettings, path: string): unknown {
  if (path === 'difficulty') return source.difficulty;
  const [section, field] = path.split('.');
  if (!section || !field) return undefined;
  return (source as unknown as Record<string, Record<string, unknown>>)[section]?.[field];
}

function updateSetting(path: string, value: unknown): void {
  const next: Record<string, unknown> = {
    ...settings,
    audio: { ...settings.audio },
    camera: { ...settings.camera },
    video: { ...settings.video },
    controls: { ...settings.controls },
  };
  if (path === 'difficulty') {
    next['difficulty'] = value;
  } else {
    const [section, field] = path.split('.');
    if (!section || !field || !next[section] || typeof next[section] !== 'object') return;
    (next[section] as Record<string, unknown>)[field] = value;
  }
  settings = parseGameSettings(next);
  const saved = gameApp?.applySettings(settings) ?? false;
  settingsStatus.textContent = saved ? 'Saved automatically' : 'Applied for this session · browser storage unavailable';
  syncSettingsControls();
}

function syncSettingsControls(): void {
  for (const element of document.querySelectorAll<HTMLInputElement | HTMLSelectElement>('[data-setting]')) {
    const path = element.dataset['setting'];
    if (!path) continue;
    const value = readPath(settings, path);
    if (element instanceof HTMLInputElement && element.type === 'checkbox') element.checked = Boolean(value);
    else if (element instanceof HTMLInputElement) element.value = String(value ?? '');
    else element.value = String(value ?? '');
  }
  for (const output of document.querySelectorAll<HTMLOutputElement>('[data-output]')) {
    const path = output.dataset['output'];
    if (!path) continue;
    const value = readPath(settings, path);
    const suffix = path === 'camera.fov' ? '°' : path === 'camera.sensitivity' || path === 'video.brightness'
      || path.endsWith('Volume') ? '%' : '';
    output.value = `${String(value ?? '')}${suffix}`;
    output.textContent = output.value;
  }
  for (const button of document.querySelectorAll<HTMLButtonElement>('[data-rebind]')) {
    const action = button.dataset['rebind'] as keyof KeyboardBindings | undefined;
    if (action) button.textContent = humanizeCode(settings.controls.keyboard[action]);
  }
  for (const select of document.querySelectorAll<HTMLSelectElement>('[data-gamepad-bind]')) {
    const action = select.dataset['gamepadBind'] as keyof GameSettings['controls']['gamepad'] | undefined;
    if (action) select.value = settings.controls.gamepad[action];
  }
}

function showMenu(): void {
  optionsMenu.hidden = true;
  mainMenu.hidden = false;
  quitNotice.hidden = true;
  gameApp?.setGameplayPaused(true);
}

function showOptions(): void {
  mainMenu.hidden = true;
  optionsMenu.hidden = false;
  optionsPage('general');
  syncSettingsControls();
  gameApp?.setGameplayPaused(true);
}

function attachMenuHandlers(app: GameApp): void {
  settings = app.getSettings();
  continueButton.disabled = !app.hasContinueSave();
  menuSaveHint.textContent = app.hasContinueSave()
    ? 'A saved adventure is available on this device.'
    : 'No saved adventure found. Start a new adventure to begin.';
  syncSettingsControls();

  (getElement('start-new-adventure') as HTMLButtonElement).addEventListener('click', async () => {
    const started = await app.startNewAdventure();
    if (started) mainMenu.hidden = true;
  });
  continueButton.addEventListener('click', async () => {
    if (!app.hasContinueSave()) return;
    mainMenu.hidden = true;
    await app.beginAdventure();
  });
  (getElement('open-options') as HTMLButtonElement).addEventListener('click', showOptions);
  (getElement('quit-game') as HTMLButtonElement).addEventListener('click', () => {
    quitNotice.hidden = false;
    app.setGameplayPaused(true);
  });
  (getElement('options-back-main') as HTMLButtonElement).addEventListener('click', showMenu);
  (getElement('options-done') as HTMLButtonElement).addEventListener('click', showMenu);
  for (const button of document.querySelectorAll<HTMLButtonElement>('[data-options-page]')) {
    button.addEventListener('click', () => optionsPage(button.dataset['optionsPage'] ?? 'general'));
  }

  for (const element of document.querySelectorAll<HTMLInputElement | HTMLSelectElement>('[data-setting]')) {
    const applyControlValue = (): void => {
      const path = element.dataset['setting'];
      if (!path) return;
      const value = element instanceof HTMLInputElement && element.type === 'checkbox'
        ? element.checked
        : element instanceof HTMLInputElement && element.type === 'range'
          ? Number(element.value)
          : element.value;
      updateSetting(path, value);
    };
    if (element instanceof HTMLInputElement && element.type === 'range') {
      element.addEventListener('input', applyControlValue);
    } else {
      element.addEventListener('change', applyControlValue);
    }
  }

  for (const button of document.querySelectorAll<HTMLButtonElement>('[data-rebind]')) {
    button.addEventListener('click', () => {
      pendingBinding = button.dataset['rebind'] as keyof KeyboardBindings;
      pendingBindingButton?.classList.remove('is-listening');
      pendingBindingButton = button;
      button.classList.add('is-listening');
      button.textContent = 'Press a key…';
      settingsStatus.textContent = 'Press the new key. Escape is reserved for closing menus.';
    });
  }
  window.addEventListener('keydown', (event) => {
    if (!pendingBinding || !pendingBindingButton || event.code === 'Escape' || event.repeat) return;
    if (event.target instanceof HTMLElement && ['INPUT', 'SELECT', 'TEXTAREA'].includes(event.target.tagName)) return;
    event.preventDefault();
    const duplicate = Object.entries(settings.controls.keyboard)
      .some(([action, code]) => action !== pendingBinding && code === event.code);
    if (duplicate) {
      settingsStatus.textContent = 'That key is already assigned. Choose a different key.';
      return;
    }
    const keyboard = { ...settings.controls.keyboard, [pendingBinding]: event.code };
    const next = parseGameSettings({ ...settings, controls: { ...settings.controls, keyboard } });
    settings = next;
    const saved = app.applySettings(next);
    settingsStatus.textContent = saved ? 'Key binding saved.' : 'Key binding active for this session.';
    pendingBindingButton.classList.remove('is-listening');
    pendingBindingButton = null;
    pendingBinding = null;
    syncSettingsControls();
  });

  for (const select of document.querySelectorAll<HTMLSelectElement>('[data-gamepad-bind]')) {
    select.addEventListener('change', () => {
      const action = select.dataset['gamepadBind'] as keyof GameSettings['controls']['gamepad'] | undefined;
      if (!action) return;
      const duplicate = Object.entries(settings.controls.gamepad)
        .some(([other, button]) => other !== action && button === select.value);
      if (duplicate) {
        settingsStatus.textContent = 'That controller button is already assigned.';
        syncSettingsControls();
        return;
      }
      const gamepad = { ...settings.controls.gamepad, [action]: select.value } as GameSettings['controls']['gamepad'];
      const next = parseGameSettings({ ...settings, controls: { ...settings.controls, gamepad } });
      settings = next;
      const saved = app.applySettings(next);
      settingsStatus.textContent = saved ? 'Controller binding saved.' : 'Controller binding active for this session.';
      syncSettingsControls();
    });
  }

  (getElement('edit-touch-layout') as HTMLButtonElement).addEventListener('click', () => {
    const opened = app.openTouchLayoutEditor();
    touchEditorStatus.textContent = opened
      ? 'Touch controls are visible. Drag a control to move it; use Shrink or Stretch in the touch layout panel.'
      : 'Touch layout editing is available on a touch-capable device.';
  });
  (getElement('reset-control-bindings') as HTMLButtonElement).addEventListener('click', () => {
    settings = parseGameSettings({ ...settings, controls: DEFAULT_GAME_SETTINGS.controls });
    const saved = app.applySettings(settings);
    settingsStatus.textContent = saved ? 'Default bindings restored.' : 'Defaults restored for this session.';
    syncSettingsControls();
  });
}

reloadButton.addEventListener('click', () => window.location.reload());

async function boot(): Promise<void> {
  const canvasHost = getElement('game-canvas');
  updateLoadingStage(0, 'Creating the Three.js renderer…');

  try {
    const override = new URLSearchParams(window.location.search).get('quality');
    const quality = resolveRenderQuality(detectDeviceProfile(), override);
    const app = new GameApp(canvasHost, loadingUi, quality);
    gameApp = app;
    attachMenuHandlers(app);
    window.addEventListener('beforeunload', () => app.dispose(), { once: true });
    await app.start();
  } catch (error) {
    console.error('ForgeBound initialization failed:', error);
    const message = error instanceof Error ? error.message : 'An unknown startup error occurred.';
    errorMessage.textContent = message;
    loadingPanel.classList.add('is-hidden');
    errorPanel.hidden = false;
  }
}

void boot();
