import * as THREE from 'three';
import { intersectVisible } from '../render/intersectVisible';
import type { Enemy } from '../entities/Enemy';
import type { OreNode } from '../entities/OreNode';
import type { ZonePortal } from '../entities/ZonePortal';
import type { Npc } from '../entities/Npc';
import type { QuestWorldObject } from '../entities/QuestWorldObject';
import type { MiniGameStation } from '../entities/MiniGameStation';
import type { ZoneId } from '../types/zones';

/**
 * Casts the centre-screen ray once per frame and answers each interaction system's
 * "first hit that I care about" query from that single result. Before this existed,
 * mining, combat, portal and forge each cast the same ray against overlapping object
 * lists, so most triangles were tested four times per frame.
 *
 * The admission rules below reproduce the candidate lists each system used to build,
 * so the answers are unchanged. Hidden objects are skipped, which is the intended fix.
 */

export type InteractionTarget = 'mining' | 'combat' | 'portal' | 'forge' | 'npc' | 'quest-object' | 'activity' | 'dungeon-entrance' | 'dungeon-point' | 'dungeon-exit';

/** Who a registered scene root belongs to. Owner state is read at query time. */
export type PickOwner =
  | { readonly kind: 'static' }
  | { readonly kind: 'ore'; readonly node: OreNode }
  | { readonly kind: 'enemy'; readonly enemy: Enemy }
  | { readonly kind: 'portal'; readonly portal: ZonePortal }
  | { readonly kind: 'npc'; readonly npc: Npc }
  | { readonly kind: 'quest-object'; readonly object: QuestWorldObject }
  | { readonly kind: 'activity'; readonly station: MiniGameStation }
  | { readonly kind: 'dungeon-entrance'; readonly dungeonId: string; readonly zoneId: ZoneId }
  | { readonly kind: 'dungeon-point'; readonly dungeonId: string; readonly pointId: string }
  | { readonly kind: 'dungeon-exit'; readonly dungeonId: string };

/** Maximum distance each target considers, matching the reach of its original raycaster. */
const REACH: Readonly<Record<InteractionTarget, number>> = {
  mining: 36,
  combat: 40,
  portal: 36,
  forge: 36,
  npc: 36,
  'quest-object': 36,
  activity: 36,
  'dungeon-entrance': 36,
  'dungeon-point': 36,
  'dungeon-exit': 36,
};

const PROBE_REACH = Math.max(REACH.mining, REACH.combat, REACH.portal, REACH.forge, REACH.activity);

export class InteractionProbe {
  private readonly raycaster = new THREE.Raycaster();
  private readonly screenCentre = new THREE.Vector2(0, 0);
  private readonly owners = new Map<THREE.Object3D, PickOwner>();
  private readonly roots: THREE.Object3D[] = [];
  private readonly hits: THREE.Intersection[] = [];

  constructor() {
    this.raycaster.near = 0;
    this.raycaster.far = PROBE_REACH;
  }

  /** Registers a top-level scene object. Re-registering the same object is a no-op. */
  register(root: THREE.Object3D, owner: PickOwner): void {
    if (this.owners.has(root)) return;
    this.owners.set(root, owner);
    this.roots.push(root);
  }

  unregister(root: THREE.Object3D): void {
    if (!this.owners.delete(root)) return;
    const index = this.roots.indexOf(root);
    if (index >= 0) this.roots.splice(index, 1);
    this.hits.length = 0;
  }

  /** Casts the centre ray. Call once per frame, after the camera has been placed. */
  beginFrame(camera: THREE.Camera): void {
    this.raycaster.setFromCamera(this.screenCentre, camera);
    intersectVisible(this.raycaster, this.roots, this.hits);
  }

  /** The nearest visible hit that `target` is allowed to act on, or null. */
  firstHit(target: InteractionTarget, activeZoneId: ZoneId): THREE.Intersection | null {
    const reach = REACH[target];
    for (const hit of this.hits) {
      if (hit.distance > reach) break;
      const owner = this.ownerOf(hit.object);
      if (owner !== null && admits(target, owner, activeZoneId)) return hit;
    }
    return null;
  }

  private ownerOf(object: THREE.Object3D): PickOwner | null {
    let current: THREE.Object3D | null = object;
    while (current !== null) {
      const owner = this.owners.get(current);
      if (owner !== undefined) return owner;
      current = current.parent;
    }
    return null;
  }
}

function admits(target: InteractionTarget, owner: PickOwner, activeZoneId: ZoneId): boolean {
  switch (owner.kind) {
    case 'static':
      // Boxes and the forge block every target, as they did in each original candidate list.
      return true;
    case 'portal':
      // Every portal blocks the other targets. Only the active zone's portals can be chosen.
      if (target === 'portal') return owner.portal.sourceZoneId === activeZoneId;
      return true;
    case 'npc':
      return target === 'npc' && owner.npc.definition.zoneId === activeZoneId;
    case 'quest-object':
      return target === 'quest-object' && owner.object.definition.zoneId === activeZoneId && owner.object.isAvailable();
    case 'activity':
      return target === 'activity' && owner.station.definition.zoneId === activeZoneId;
    case 'dungeon-entrance':
      return target === 'dungeon-entrance' && owner.zoneId === activeZoneId;
    case 'dungeon-point':
      return target === 'dungeon-point';
    case 'dungeon-exit':
      return target === 'dungeon-exit';
    case 'ore':
      // Combat treats every ore node as an occluder, even those in other zones.
      if (target === 'combat') return true;
      return owner.node.zoneId === activeZoneId && owner.node.isAvailable();
    case 'enemy':
      if (target === 'mining') return false;
      if (owner.enemy.definition.zoneId !== activeZoneId) return false;
      return target === 'forge' || owner.enemy.isAlive();
  }
}
